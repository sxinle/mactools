package info.guardianproject.database.sqlcipher; class SQLiteDatabaseCorruptException {/*

.class public Linfo/guardianproject/database/sqlcipher/SQLiteDatabaseCorruptException;
.super Linfo/guardianproject/database/sqlcipher/SQLiteException;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 23
    invoke-direct {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteException;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 0
    .parameter

    .prologue
    .line 26
    invoke-direct {p0, p1}, Linfo/guardianproject/database/sqlcipher/SQLiteException;-><init>(Ljava/lang/String;)V

    .line 27
    #p0=(Reference);
    return-void
.end method

*/}
