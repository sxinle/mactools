package info.guardianproject.database.sqlcipher; class SQLiteStatement {/*

.class public Linfo/guardianproject/database/sqlcipher/SQLiteStatement;
.super Linfo/guardianproject/database/sqlcipher/SQLiteProgram;
.source "SourceFile"


# direct methods
.method constructor <init>(Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;Ljava/lang/String;)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 39
    invoke-direct {p0, p1, p2}, Linfo/guardianproject/database/sqlcipher/SQLiteProgram;-><init>(Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;Ljava/lang/String;)V

    .line 40
    #p0=(Reference);
    return-void
.end method

.method private final native native_1x1_long()J
.end method

.method private final native native_1x1_string()Ljava/lang/String;
.end method

.method private final native native_execute()V
.end method


# virtual methods
.method public execute()V
    .locals 4

    .prologue
    .line 50
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->isOpen()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 51
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "database "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " already closed"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    .line 53
    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 54
    #v0=(LongLo);v1=(LongHi);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v2=(Reference);
    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->lock()V

    .line 56
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->acquireReference()V

    .line 58
    :try_start_0
    invoke-direct {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->native_execute()V

    .line 59
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    iget-object v3, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mSql:Ljava/lang/String;

    #v3=(Reference);
    invoke-virtual {v2, v3, v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->logTimeStat(Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 61
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 62
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 64
    return-void

    .line 60
    :catchall_0
    #v0=(LongLo);v3=(Conflicted);
    move-exception v0

    .line 61
    #v0=(Reference);
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 62
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v1=(Reference);
    invoke-virtual {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 63
    throw v0
.end method

.method public executeInsert()J
    .locals 4

    .prologue
    .line 76
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->isOpen()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 77
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "database "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " already closed"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    .line 79
    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 80
    #v0=(LongLo);v1=(LongHi);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v2=(Reference);
    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->lock()V

    .line 82
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->acquireReference()V

    .line 84
    :try_start_0
    invoke-direct {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->native_execute()V

    .line 85
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    iget-object v3, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mSql:Ljava/lang/String;

    #v3=(Reference);
    invoke-virtual {v2, v3, v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->logTimeStat(Ljava/lang/String;J)V

    .line 86
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->lastChangeCount()I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_1

    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->lastInsertRow()J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result-wide v0

    .line 88
    :goto_0
    #v0=(LongLo);
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 89
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 86
    return-wide v0

    :cond_1
    #v0=(Integer);
    const-wide/16 v0, -0x1

    #v0=(LongLo);
    goto :goto_0

    .line 87
    :catchall_0
    #v0=(Conflicted);v3=(Conflicted);
    move-exception v0

    .line 88
    #v0=(Reference);
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 89
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v1=(Reference);
    invoke-virtual {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 90
    throw v0
.end method

.method public simpleQueryForLong()J
    .locals 6

    .prologue
    .line 102
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->isOpen()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 103
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "database "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " already closed"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    .line 105
    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 106
    #v0=(LongLo);v1=(LongHi);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v2=(Reference);
    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->lock()V

    .line 108
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->acquireReference()V

    .line 110
    :try_start_0
    invoke-direct {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->native_1x1_long()J

    move-result-wide v2

    .line 111
    #v2=(LongLo);v3=(LongHi);
    iget-object v4, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v4=(Reference);
    iget-object v5, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mSql:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v4, v5, v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->logTimeStat(Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 112
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 115
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 112
    return-wide v2

    .line 113
    :catchall_0
    #v0=(LongLo);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-exception v0

    .line 114
    #v0=(Reference);
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 115
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v1=(Reference);
    invoke-virtual {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 116
    throw v0
.end method

.method public simpleQueryForString()Ljava/lang/String;
    .locals 5

    .prologue
    .line 128
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->isOpen()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 129
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "database "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " already closed"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    .line 131
    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 132
    #v0=(LongLo);v1=(LongHi);
    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v2=(Reference);
    invoke-virtual {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->lock()V

    .line 134
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->acquireReference()V

    .line 136
    :try_start_0
    invoke-direct {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->native_1x1_string()Ljava/lang/String;

    move-result-object v2

    .line 137
    iget-object v3, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v3=(Reference);
    iget-object v4, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mSql:Ljava/lang/String;

    #v4=(Reference);
    invoke-virtual {v3, v4, v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->logTimeStat(Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 140
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 141
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v0=(Reference);
    invoke-virtual {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 138
    return-object v2

    .line 139
    :catchall_0
    #v0=(LongLo);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    .line 140
    #v0=(Reference);
    invoke-virtual {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->releaseReference()V

    .line 141
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteStatement;->mDatabase:Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;

    #v1=(Reference);
    invoke-virtual {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->unlock()V

    .line 142
    throw v0
.end method

*/}
