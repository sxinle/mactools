package info.guardianproject.database.sqlcipher; class SQLiteCursorDriver {/*

.class public interface abstract Linfo/guardianproject/database/sqlcipher/SQLiteCursorDriver;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract cursorClosed()V
.end method

.method public abstract cursorDeactivated()V
.end method

.method public abstract cursorRequeried(Landroid/database/Cursor;)V
.end method

.method public abstract query(Linfo/guardianproject/database/sqlcipher/SQLiteDatabase$CursorFactory;[Ljava/lang/String;)Landroid/database/Cursor;
.end method

.method public abstract setBindArguments([Ljava/lang/String;)V
.end method

*/}
