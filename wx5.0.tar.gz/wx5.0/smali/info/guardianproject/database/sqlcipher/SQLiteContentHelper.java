package info.guardianproject.database.sqlcipher; class SQLiteContentHelper {/*

.class public Linfo/guardianproject/database/sqlcipher/SQLiteContentHelper;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method public static getBlobColumnAsAssetFile(Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;
    .locals 6
    .parameter
    .parameter
    .parameter

    .prologue
    .line 50
    const/4 v1, 0x0

    .line 53
    :try_start_0
    #v1=(Null);
    invoke-static {p0, p1, p2}, Linfo/guardianproject/database/sqlcipher/SQLiteContentHelper;->simpleQueryForBlobMemoryFile(Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;)Landroid/os/MemoryFile;

    move-result-object v4

    .line 54
    #v4=(Reference);
    if-nez v4, :cond_0

    .line 55
    new-instance v0, Ljava/io/FileNotFoundException;

    #v0=(UninitRef);
    const-string v1, "No results."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 67
    :catch_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-exception v0

    .line 68
    #v0=(Reference);
    new-instance v1, Ljava/io/FileNotFoundException;

    #v1=(UninitRef);
    invoke-virtual {v0}, Ljava/io/IOException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    throw v1

    .line 57
    :cond_0
    :try_start_1
    #v0=(Uninit);v1=(Null);v2=(Uninit);v3=(Uninit);v4=(Reference);v5=(Uninit);
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    move-result-object v0

    .line 59
    :try_start_2
    #v0=(Reference);
    const-string v2, "getParcelFileDescriptor"

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    new-array v3, v3, [Ljava/lang/Class;

    #v3=(Reference);
    invoke-virtual {v0, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    .line 60
    const/4 v2, 0x1

    #v2=(One);
    invoke-virtual {v0, v2}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 61
    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/Object;

    #v2=(Reference);
    invoke-virtual {v0, v4, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/ParcelFileDescriptor;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    move-object v1, v0

    .line 65
    :goto_0
    :try_start_3
    #v1=(Reference);
    new-instance v0, Landroid/content/res/AssetFileDescriptor;

    #v0=(UninitRef);
    const-wide/16 v2, 0x0

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {v4}, Landroid/os/MemoryFile;->length()I

    move-result v4

    #v4=(Integer);
    int-to-long v4, v4

    #v4=(LongLo);v5=(LongHi);
    invoke-direct/range {v0 .. v5}, Landroid/content/res/AssetFileDescriptor;-><init>(Landroid/os/ParcelFileDescriptor;JJ)V

    .line 66
    #v0=(Reference);
    return-object v0

    .line 62
    :catch_1
    #v1=(Null);v2=(Conflicted);v3=(Conflicted);v4=(Reference);v5=(Uninit);
    move-exception v0

    .line 63
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "SQLiteCursor.java: "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_0
.end method

.method private static simpleQueryForBlobMemoryFile(Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;)Landroid/os/MemoryFile;
    .locals 6
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 84
    #v0=(Null);
    invoke-virtual {p0, p1, p2}, Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 85
    #v1=(Reference);
    if-nez v1, :cond_0

    .line 100
    :goto_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    .line 89
    :cond_0
    :try_start_0
    #v0=(Null);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_1

    .line 102
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0

    .line 92
    :cond_1
    const/4 v2, 0x0

    :try_start_1
    #v2=(Null);
    invoke-interface {v1, v2}, Landroid/database/Cursor;->getBlob(I)[B
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-result-object v2

    .line 93
    #v2=(Reference);
    if-nez v2, :cond_2

    .line 102
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0

    .line 96
    :cond_2
    :try_start_2
    new-instance v0, Landroid/os/MemoryFile;

    #v0=(UninitRef);
    const/4 v3, 0x0

    #v3=(Null);
    array-length v4, v2

    #v4=(Integer);
    invoke-direct {v0, v3, v4}, Landroid/os/MemoryFile;-><init>(Ljava/lang/String;I)V

    .line 97
    #v0=(Reference);
    const/4 v3, 0x0

    const/4 v4, 0x0

    #v4=(Null);
    array-length v5, v2

    #v5=(Integer);
    invoke-virtual {v0, v2, v3, v4, v5}, Landroid/os/MemoryFile;->writeBytes([BIII)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 102
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0

    .line 101
    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-exception v0

    .line 102
    #v0=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 103
    throw v0
.end method

*/}
