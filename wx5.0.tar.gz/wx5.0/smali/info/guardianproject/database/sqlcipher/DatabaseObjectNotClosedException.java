package info.guardianproject.database.sqlcipher; class DatabaseObjectNotClosedException {/*

.class public Linfo/guardianproject/database/sqlcipher/DatabaseObjectNotClosedException;
.super Ljava/lang/RuntimeException;
.source "SourceFile"


# static fields
.field private static final s:Ljava/lang/String; = "Application did not close the cursor or database object that was opened here"


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 31
    const-string v0, "Application did not close the cursor or database object that was opened here"

    #v0=(Reference);
    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 32
    #p0=(Reference);
    return-void
.end method

*/}
