package info.guardianproject.database.sqlcipher; class SQLiteTransactionListener {/*

.class public interface abstract Linfo/guardianproject/database/sqlcipher/SQLiteTransactionListener;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract onBegin()V
.end method

.method public abstract onCommit()V
.end method

.method public abstract onRollback()V
.end method

*/}
