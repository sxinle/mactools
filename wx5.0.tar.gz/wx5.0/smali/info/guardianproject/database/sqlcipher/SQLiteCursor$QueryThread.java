package info.guardianproject.database.sqlcipher; class SQLiteCursor$QueryThread {/*

.class final Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final mThreadState:I

.field final synthetic this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;


# direct methods
.method constructor <init>(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;I)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 116
    iput-object p1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 117
    #p0=(Reference);
    iput p2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->mThreadState:I

    .line 118
    return-void
.end method

.method private sendMessage()V
    .locals 2

    .prologue
    const/4 v1, 0x1

    .line 120
    #v1=(One);
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v0=(Reference);
    iget-object v0, v0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->mNotificationHandler:Linfo/guardianproject/database/sqlcipher/SQLiteCursor$MainThreadNotificationHandler;

    if-eqz v0, :cond_0

    .line 121
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    iget-object v0, v0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->mNotificationHandler:Linfo/guardianproject/database/sqlcipher/SQLiteCursor$MainThreadNotificationHandler;

    invoke-virtual {v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$MainThreadNotificationHandler;->sendEmptyMessage(I)Z

    .line 122
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$0(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;Z)V

    .line 127
    :goto_0
    #v1=(Boolean);
    return-void

    .line 124
    :cond_0
    #v1=(One);
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-static {v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$0(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;Z)V

    goto :goto_0
.end method


# virtual methods
.method public final run()V
    .locals 4

    .prologue
    .line 130
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v0=(Reference);
    invoke-static {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$1(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Linfo/guardianproject/database/CursorWindow;

    move-result-object v0

    .line 131
    invoke-static {}, Landroid/os/Process;->myTid()I

    move-result v1

    #v1=(Integer);
    const/16 v2, 0xa

    #v2=(PosByte);
    invoke-static {v1, v2}, Landroid/os/Process;->setThreadPriority(II)V

    .line 134
    :goto_0
    #v1=(Conflicted);v2=(Integer);v3=(Conflicted);
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v1=(Reference);
    invoke-static {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$2(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 135
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-static {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$3(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)I

    move-result v1

    #v1=(Integer);
    iget v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->mThreadState:I

    if-eq v1, v2, :cond_0

    .line 136
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-static {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$2(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 156
    :goto_1
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    .line 140
    :cond_0
    :try_start_0
    #v1=(Integer);v2=(Integer);
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v1=(Reference);
    invoke-static {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$4(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Linfo/guardianproject/database/sqlcipher/SQLiteQuery;

    move-result-object v1

    iget-object v2, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v2=(Reference);
    invoke-static {v2}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$5(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)I

    move-result v2

    #v2=(Integer);
    iget-object v3, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v3=(Reference);
    invoke-static {v3}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$6(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v1, v0, v2, v3}, Linfo/guardianproject/database/sqlcipher/SQLiteQuery;->fillWindow(Linfo/guardianproject/database/CursorWindow;II)I

    move-result v1

    .line 142
    #v1=(Integer);
    if-eqz v1, :cond_2

    .line 143
    const/4 v2, -0x1

    #v2=(Byte);
    if-ne v1, v2, :cond_1

    .line 144
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v1=(Reference);
    invoke-static {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$6(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)I

    move-result v2

    #v2=(Integer);
    iget-object v3, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v3=(Reference);
    invoke-static {v3}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$5(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)I

    move-result v3

    #v3=(Integer);
    add-int/2addr v2, v3

    invoke-static {v1, v2}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$7(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;I)V

    .line 145
    invoke-direct {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->sendMessage()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 158
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-static {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$2(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    goto :goto_0

    .line 147
    :cond_1
    :try_start_1
    #v1=(Integer);v2=(Byte);
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-static {v0, v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$7(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;I)V

    .line 148
    invoke-direct {p0}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->sendMessage()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 158
    :cond_2
    #v2=(Integer);
    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-static {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$2(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    goto :goto_1

    :catch_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    move-exception v0

    iget-object v0, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    invoke-static {v0}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$2(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    goto :goto_1

    .line 157
    :catchall_0
    move-exception v0

    .line 158
    iget-object v1, p0, Linfo/guardianproject/database/sqlcipher/SQLiteCursor$QueryThread;->this$0:Linfo/guardianproject/database/sqlcipher/SQLiteCursor;

    #v1=(Reference);
    invoke-static {v1}, Linfo/guardianproject/database/sqlcipher/SQLiteCursor;->access$2(Linfo/guardianproject/database/sqlcipher/SQLiteCursor;)Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 159
    throw v0
.end method

*/}
