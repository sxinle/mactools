package info.guardianproject.database.sqlcipher; class SQLiteDatabase$CursorFactory {/*

.class public interface abstract Linfo/guardianproject/database/sqlcipher/SQLiteDatabase$CursorFactory;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract newCursor(Linfo/guardianproject/database/sqlcipher/SQLiteDatabase;Linfo/guardianproject/database/sqlcipher/SQLiteCursorDriver;Ljava/lang/String;Linfo/guardianproject/database/sqlcipher/SQLiteQuery;)Landroid/database/Cursor;
.end method

*/}
