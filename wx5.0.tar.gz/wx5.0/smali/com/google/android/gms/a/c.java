package com.google.android.gms.a; class c {/*

.class public final Lcom/google/android/gms/a/c;
.super Lcom/google/android/gms/a/d;


# instance fields
.field private final y:I


# direct methods
.method constructor <init>(ILjava/lang/String;Landroid/content/Intent;)V
    .locals 0

    invoke-direct {p0, p2, p3}, Lcom/google/android/gms/a/d;-><init>(Ljava/lang/String;Landroid/content/Intent;)V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/a/c;->y:I

    return-void
.end method

*/}
