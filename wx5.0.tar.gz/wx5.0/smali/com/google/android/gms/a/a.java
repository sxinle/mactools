package com.google.android.gms.a; class a {/*

.class public Lcom/google/android/gms/a/a;
.super Ljava/lang/Exception;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    #p0=(Reference);
    return-void
.end method

*/}
