package com.google.android.gms.a; class d {/*

.class public Lcom/google/android/gms/a/d;
.super Lcom/google/android/gms/a/a;


# instance fields
.field private final sR:Landroid/content/Intent;


# direct methods
.method public constructor <init>(Ljava/lang/String;Landroid/content/Intent;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/google/android/gms/a/a;-><init>(Ljava/lang/String;)V

    #p0=(Reference);
    iput-object p2, p0, Lcom/google/android/gms/a/d;->sR:Landroid/content/Intent;

    return-void
.end method


# virtual methods
.method public final getIntent()Landroid/content/Intent;
    .locals 2

    new-instance v0, Landroid/content/Intent;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/google/android/gms/a/d;->sR:Landroid/content/Intent;

    #v1=(Reference);
    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    #v0=(Reference);
    return-object v0
.end method

*/}
