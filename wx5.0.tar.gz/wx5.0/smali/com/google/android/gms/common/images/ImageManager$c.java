package com.google.android.gms.common.images; class ImageManager$c {/*

.class final Lcom/google/android/gms/common/images/ImageManager$c;
.super Landroid/os/ResultReceiver;


# instance fields
.field private final tl:Landroid/net/Uri;

.field private final tm:Ljava/util/ArrayList;

.field tn:Z

.field final synthetic to:Lcom/google/android/gms/common/images/ImageManager;


# direct methods
.method static synthetic a(Lcom/google/android/gms/common/images/ImageManager$c;)Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager$c;->tm:Ljava/util/ArrayList;

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final onReceiveResult(ILandroid/os/Bundle;)V
    .locals 5

    const-string v0, "com.google.android.gms.extra.fileDescriptor"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/os/ParcelFileDescriptor;

    iget-object v1, p0, Lcom/google/android/gms/common/images/ImageManager$c;->to:Lcom/google/android/gms/common/images/ImageManager;

    #v1=(Reference);
    invoke-static {v1}, Lcom/google/android/gms/common/images/ImageManager;->d(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    new-instance v2, Lcom/google/android/gms/common/images/c;

    #v2=(UninitRef);
    iget-object v3, p0, Lcom/google/android/gms/common/images/ImageManager$c;->to:Lcom/google/android/gms/common/images/ImageManager;

    #v3=(Reference);
    iget-object v4, p0, Lcom/google/android/gms/common/images/ImageManager$c;->tl:Landroid/net/Uri;

    #v4=(Reference);
    invoke-direct {v2, v3, v4, v0}, Lcom/google/android/gms/common/images/c;-><init>(Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;Landroid/os/ParcelFileDescriptor;)V

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

*/}
