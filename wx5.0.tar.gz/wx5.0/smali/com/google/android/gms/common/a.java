package com.google.android.gms.common; class a {/*

.class public final Lcom/google/android/gms/common/a;
.super Ljava/lang/Object;


# static fields
.field public static final sS:Lcom/google/android/gms/common/a;


# instance fields
.field private final p:I

.field private final sT:Landroid/app/PendingIntent;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Lcom/google/android/gms/common/a;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/a;-><init>(ILandroid/app/PendingIntent;)V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/common/a;->sS:Lcom/google/android/gms/common/a;

    return-void
.end method

.method public constructor <init>(ILandroid/app/PendingIntent;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/common/a;->p:I

    iput-object p2, p0, Lcom/google/android/gms/common/a;->sT:Landroid/app/PendingIntent;

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 4

    invoke-static {p0}, Lcom/google/android/gms/internal/g;->f(Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v1

    #v1=(Reference);
    const-string v2, "statusCode"

    #v2=(Reference);
    iget v0, p0, Lcom/google/android/gms/common/a;->p:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v3, "unknown status code "

    #v3=(Reference);
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    iget v3, p0, Lcom/google/android/gms/common/a;->p:I

    #v3=(Integer);
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    #v3=(Conflicted);
    invoke-virtual {v1, v2, v0}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "resolution"

    iget-object v2, p0, Lcom/google/android/gms/common/a;->sT:Landroid/app/PendingIntent;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/h;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_0
    #v0=(Integer);v3=(Uninit);
    const-string v0, "SUCCESS"

    #v0=(Reference);
    goto :goto_0

    :pswitch_1
    #v0=(Integer);
    const-string v0, "SERVICE_MISSING"

    #v0=(Reference);
    goto :goto_0

    :pswitch_2
    #v0=(Integer);
    const-string v0, "SERVICE_VERSION_UPDATE_REQUIRED"

    #v0=(Reference);
    goto :goto_0

    :pswitch_3
    #v0=(Integer);
    const-string v0, "SERVICE_DISABLED"

    #v0=(Reference);
    goto :goto_0

    :pswitch_4
    #v0=(Integer);
    const-string v0, "SIGN_IN_REQUIRED"

    #v0=(Reference);
    goto :goto_0

    :pswitch_5
    #v0=(Integer);
    const-string v0, "INVALID_ACCOUNT"

    #v0=(Reference);
    goto :goto_0

    :pswitch_6
    #v0=(Integer);
    const-string v0, "RESOLUTION_REQUIRED"

    #v0=(Reference);
    goto :goto_0

    :pswitch_7
    #v0=(Integer);
    const-string v0, "NETWORK_ERROR"

    #v0=(Reference);
    goto :goto_0

    :pswitch_8
    #v0=(Integer);
    const-string v0, "INTERNAL_ERROR"

    #v0=(Reference);
    goto :goto_0

    :pswitch_9
    #v0=(Integer);
    const-string v0, "SERVICE_INVALID"

    #v0=(Reference);
    goto :goto_0

    :pswitch_a
    #v0=(Integer);
    const-string v0, "DEVELOPER_ERROR"

    #v0=(Reference);
    goto :goto_0

    :pswitch_b
    #v0=(Integer);
    const-string v0, "LICENSE_CHECK_FAILED"

    #v0=(Reference);
    goto :goto_0

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);p0=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
    .end packed-switch
.end method

*/}
