package com.google.android.gms.common.images; class ImageManager {/*

.class public final Lcom/google/android/gms/common/images/ImageManager;
.super Ljava/lang/Object;


# static fields
.field private static final tf:Ljava/lang/Object;

.field private static tg:Ljava/util/HashSet;


# instance fields
.field private final mContext:Landroid/content/Context;

.field private final mHandler:Landroid/os/Handler;

.field private final th:Ljava/util/concurrent/ExecutorService;

.field private final ti:Lcom/google/android/gms/common/images/b;

.field private final tj:Ljava/util/Map;

.field private final tk:Ljava/util/Map;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/common/images/ImageManager;->tf:Ljava/lang/Object;

    new-instance v0, Ljava/util/HashSet;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/common/images/ImageManager;->tg:Ljava/util/HashSet;

    return-void
.end method

.method static synthetic a(Lcom/google/android/gms/common/images/ImageManager;)Landroid/content/Context;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager;->mContext:Landroid/content/Context;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager;->tk:Ljava/util/Map;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager;->tj:Ljava/util/Map;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic cQ()Ljava/lang/Object;
    .locals 1

    sget-object v0, Lcom/google/android/gms/common/images/ImageManager;->tf:Ljava/lang/Object;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic cR()Ljava/util/HashSet;
    .locals 1

    sget-object v0, Lcom/google/android/gms/common/images/ImageManager;->tg:Ljava/util/HashSet;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic d(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/concurrent/ExecutorService;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager;->th:Ljava/util/concurrent/ExecutorService;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic e(Lcom/google/android/gms/common/images/ImageManager;)Landroid/os/Handler;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager;->mHandler:Landroid/os/Handler;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic f(Lcom/google/android/gms/common/images/ImageManager;)Lcom/google/android/gms/common/images/b;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager;->ti:Lcom/google/android/gms/common/images/b;

    #v0=(Reference);
    return-object v0
.end method

*/}
