package com.google.android.gms.common.internal.safeparcel; class SafeParcelable {/*

.class public interface abstract Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;

*/}
