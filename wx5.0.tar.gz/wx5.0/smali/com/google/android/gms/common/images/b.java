package com.google.android.gms.common.images; class b {/*

.class final Lcom/google/android/gms/common/images/b;
.super Lcom/google/android/gms/internal/r;


# virtual methods
.method protected final synthetic e(Ljava/lang/Object;)I
    .locals 2

    check-cast p1, Landroid/graphics/Bitmap;

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getRowBytes()I

    move-result v1

    #v1=(Integer);
    mul-int/2addr v0, v1

    return v0
.end method

*/}
