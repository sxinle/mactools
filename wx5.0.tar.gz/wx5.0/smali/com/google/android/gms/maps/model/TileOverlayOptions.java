package com.google.android.gms.maps.model; class TileOverlayOptions {/*

.class public final Lcom/google/android/gms/maps/model/TileOverlayOptions;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final Bv:Lcom/google/android/gms/maps/model/m;


# instance fields
.field private AT:F

.field private AU:Z

.field private Bw:Lcom/google/android/gms/internal/az;

.field private Bx:Lcom/google/android/gms/maps/model/n;

.field private final tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/m;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/m;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->Bv:Lcom/google/android/gms/maps/model/m;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    const/4 v0, 0x1

    #v0=(One);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-boolean v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AU:Z

    iput v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tu:I

    return-void
.end method

.method constructor <init>(ILandroid/os/IBinder;ZF)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AU:Z

    iput p1, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tu:I

    invoke-static {p2}, Lcom/google/android/gms/internal/ba;->e(Landroid/os/IBinder;)Lcom/google/android/gms/internal/az;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->Bw:Lcom/google/android/gms/internal/az;

    iget-object v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->Bw:Lcom/google/android/gms/internal/az;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    iput-object v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->Bx:Lcom/google/android/gms/maps/model/n;

    iput-boolean p3, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AU:Z

    iput p4, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AT:F

    return-void

    :cond_0
    new-instance v0, Lcom/google/android/gms/maps/model/l;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/maps/model/l;-><init>(Lcom/google/android/gms/maps/model/TileOverlayOptions;)V

    #v0=(Reference);
    goto :goto_0
.end method

.method static synthetic a(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/internal/az;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->Bw:Lcom/google/android/gms/internal/az;

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final gY()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AT:F

    #v0=(Integer);
    return v0
.end method

.method public final hl()Landroid/os/IBinder;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->Bw:Lcom/google/android/gms/internal/az;

    #v0=(Reference);
    invoke-interface {v0}, Lcom/google/android/gms/internal/az;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    return-object v0
.end method

.method public final isVisible()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AU:Z

    #v0=(Boolean);
    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 3

    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->hl()Landroid/os/IBinder;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/IBinder;)V

    const/4 v1, 0x3

    iget-boolean v2, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AU:Z

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    const/4 v1, 0x4

    iget v2, p0, Lcom/google/android/gms/maps/model/TileOverlayOptions;->AT:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/maps/model/m;->a(Lcom/google/android/gms/maps/model/TileOverlayOptions;Landroid/os/Parcel;)V

    goto :goto_0
.end method

*/}
