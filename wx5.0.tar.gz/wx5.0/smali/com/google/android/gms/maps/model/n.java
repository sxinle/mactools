package com.google.android.gms.maps.model; class n {/*

.class public interface abstract Lcom/google/android/gms/maps/model/n;
.super Ljava/lang/Object;


# static fields
.field public static final BA:Lcom/google/android/gms/maps/model/Tile;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/Tile;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/Tile;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/n;->BA:Lcom/google/android/gms/maps/model/Tile;

    return-void
.end method

*/}
