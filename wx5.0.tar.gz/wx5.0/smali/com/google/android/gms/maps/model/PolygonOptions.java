package com.google.android.gms.maps.model; class PolygonOptions {/*

.class public final Lcom/google/android/gms/maps/model/PolygonOptions;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final Bp:Lcom/google/android/gms/maps/model/i;


# instance fields
.field private AQ:F

.field private AR:I

.field private AS:I

.field private AT:F

.field private AU:Z

.field private final Bq:Ljava/util/List;

.field private final Br:Ljava/util/List;

.field private Bs:Z

.field private final tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/i;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/i;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bp:Lcom/google/android/gms/maps/model/i;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    #v2=(One);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/high16 v0, 0x4120

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AQ:F

    const/high16 v0, -0x100

    iput v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AR:I

    iput v1, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AS:I

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AT:F

    iput-boolean v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AU:Z

    iput-boolean v1, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bs:Z

    iput v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->tu:I

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bq:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Br:Ljava/util/List;

    return-void
.end method

.method constructor <init>(ILjava/util/List;Ljava/util/List;FIIFZZ)V
    .locals 2

    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/high16 v0, 0x4120

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AQ:F

    const/high16 v0, -0x100

    iput v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AR:I

    iput v1, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AS:I

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AT:F

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AU:Z

    iput-boolean v1, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bs:Z

    iput p1, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bq:Ljava/util/List;

    iput-object p3, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Br:Ljava/util/List;

    iput p4, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AQ:F

    iput p5, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AR:I

    iput p6, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AS:I

    iput p7, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AT:F

    iput-boolean p8, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AU:Z

    iput-boolean p9, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bs:Z

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final gW()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AR:I

    #v0=(Integer);
    return v0
.end method

.method public final gX()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AS:I

    #v0=(Integer);
    return v0
.end method

.method public final gY()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AT:F

    #v0=(Integer);
    return v0
.end method

.method public final getStrokeWidth()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AQ:F

    #v0=(Integer);
    return v0
.end method

.method public final hi()Ljava/util/List;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Br:Ljava/util/List;

    #v0=(Reference);
    return-object v0
.end method

.method public final hj()Ljava/util/List;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bq:Ljava/util/List;

    #v0=(Reference);
    return-object v0
.end method

.method public final hk()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bs:Z

    #v0=(Boolean);
    return v0
.end method

.method public final isVisible()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AU:Z

    #v0=(Boolean);
    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bq:Ljava/util/List;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    iget-object v1, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Br:Ljava/util/List;

    #v1=(Reference);
    invoke-static {p1, v1}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;Ljava/util/List;)V

    const/4 v1, 0x4

    #v1=(PosByte);
    iget v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AQ:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x5

    iget v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AR:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x6

    iget v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AS:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x7

    iget v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AT:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0x8

    iget-boolean v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->AU:Z

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    const/16 v1, 0x9

    iget-boolean v2, p0, Lcom/google/android/gms/maps/model/PolygonOptions;->Bs:Z

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/maps/model/i;->a(Lcom/google/android/gms/maps/model/PolygonOptions;Landroid/os/Parcel;)V

    goto :goto_0
.end method

*/}
