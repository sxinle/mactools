package com.google.android.gms.maps; class b {/*

.class final Lcom/google/android/gms/maps/b;
.super Lcom/google/android/gms/internal/aj;


# instance fields
.field private final AC:Landroid/view/ViewGroup;

.field private final AD:Lcom/google/android/gms/maps/GoogleMapOptions;

.field private final mContext:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/view/ViewGroup;Landroid/content/Context;Lcom/google/android/gms/maps/GoogleMapOptions;)V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/internal/aj;-><init>()V

    #p0=(Reference);
    iput-object p1, p0, Lcom/google/android/gms/maps/b;->AC:Landroid/view/ViewGroup;

    iput-object p2, p0, Lcom/google/android/gms/maps/b;->mContext:Landroid/content/Context;

    iput-object p3, p0, Lcom/google/android/gms/maps/b;->AD:Lcom/google/android/gms/maps/GoogleMapOptions;

    return-void
.end method

*/}
