package com.google.android.gms.maps; class MapView {/*

.class public Lcom/google/android/gms/maps/MapView;
.super Landroid/widget/FrameLayout;


# instance fields
.field private final AB:Lcom/google/android/gms/maps/b;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    #p0=(Reference);
    new-instance v0, Lcom/google/android/gms/maps/b;

    #v0=(UninitRef);
    invoke-static {p1, p2}, Lcom/google/android/gms/maps/GoogleMapOptions;->b(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/gms/maps/GoogleMapOptions;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, p0, p1, v1}, Lcom/google/android/gms/maps/b;-><init>(Landroid/view/ViewGroup;Landroid/content/Context;Lcom/google/android/gms/maps/GoogleMapOptions;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/maps/MapView;->AB:Lcom/google/android/gms/maps/b;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    #p0=(Reference);
    new-instance v0, Lcom/google/android/gms/maps/b;

    #v0=(UninitRef);
    invoke-static {p1, p2}, Lcom/google/android/gms/maps/GoogleMapOptions;->b(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/gms/maps/GoogleMapOptions;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, p0, p1, v1}, Lcom/google/android/gms/maps/b;-><init>(Landroid/view/ViewGroup;Landroid/content/Context;Lcom/google/android/gms/maps/GoogleMapOptions;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/maps/MapView;->AB:Lcom/google/android/gms/maps/b;

    return-void
.end method

*/}
