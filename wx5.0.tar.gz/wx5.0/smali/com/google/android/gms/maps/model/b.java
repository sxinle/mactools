package com.google.android.gms.maps.model; class b {/*

.class public final Lcom/google/android/gms/maps/model/b;
.super Ljava/lang/Object;


# instance fields
.field private AJ:Lcom/google/android/gms/maps/model/LatLng;

.field private AK:F

.field private AL:F

.field private AM:F


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final L(F)Lcom/google/android/gms/maps/model/b;
    .locals 0

    iput p1, p0, Lcom/google/android/gms/maps/model/b;->AK:F

    return-object p0
.end method

.method public final M(F)Lcom/google/android/gms/maps/model/b;
    .locals 0

    iput p1, p0, Lcom/google/android/gms/maps/model/b;->AL:F

    return-object p0
.end method

.method public final N(F)Lcom/google/android/gms/maps/model/b;
    .locals 0

    iput p1, p0, Lcom/google/android/gms/maps/model/b;->AM:F

    return-object p0
.end method

.method public final a(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/b;
    .locals 0

    iput-object p1, p0, Lcom/google/android/gms/maps/model/b;->AJ:Lcom/google/android/gms/maps/model/LatLng;

    return-object p0
.end method

.method public final gT()Lcom/google/android/gms/maps/model/CameraPosition;
    .locals 5

    new-instance v0, Lcom/google/android/gms/maps/model/CameraPosition;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/google/android/gms/maps/model/b;->AJ:Lcom/google/android/gms/maps/model/LatLng;

    #v1=(Reference);
    iget v2, p0, Lcom/google/android/gms/maps/model/b;->AK:F

    #v2=(Integer);
    iget v3, p0, Lcom/google/android/gms/maps/model/b;->AL:F

    #v3=(Integer);
    iget v4, p0, Lcom/google/android/gms/maps/model/b;->AM:F

    #v4=(Integer);
    invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/android/gms/maps/model/CameraPosition;-><init>(Lcom/google/android/gms/maps/model/LatLng;FFF)V

    #v0=(Reference);
    return-object v0
.end method

*/}
