package com.google.android.gms.maps.model; class Tile {/*

.class public final Lcom/google/android/gms/maps/model/Tile;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final Bu:Lcom/google/android/gms/maps/model/k;


# instance fields
.field public final data:[B

.field public final height:I

.field private final tu:I

.field public final width:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/k;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/k;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/Tile;->Bu:Lcom/google/android/gms/maps/model/k;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, -0x1

    #v2=(Byte);
    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {p0, v0, v2, v2, v1}, Lcom/google/android/gms/maps/model/Tile;-><init>(III[B)V

    #p0=(Reference);
    return-void
.end method

.method constructor <init>(III[B)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/maps/model/Tile;->tu:I

    iput p2, p0, Lcom/google/android/gms/maps/model/Tile;->width:I

    iput p3, p0, Lcom/google/android/gms/maps/model/Tile;->height:I

    iput-object p4, p0, Lcom/google/android/gms/maps/model/Tile;->data:[B

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/Tile;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 3

    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/Tile;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget v2, p0, Lcom/google/android/gms/maps/model/Tile;->width:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x3

    iget v2, p0, Lcom/google/android/gms/maps/model/Tile;->height:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    iget-object v1, p0, Lcom/google/android/gms/maps/model/Tile;->data:[B

    #v1=(Reference);
    invoke-static {p1, v1}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;[B)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/maps/model/k;->a(Lcom/google/android/gms/maps/model/Tile;Landroid/os/Parcel;)V

    goto :goto_0
.end method

*/}
