package com.google.android.gms.maps.model; class a {/*

.class public final Lcom/google/android/gms/maps/model/a;
.super Ljava/lang/Object;


# instance fields
.field private final AE:Lcom/google/android/gms/internal/an;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/an;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/internal/an;

    iput-object v0, p0, Lcom/google/android/gms/maps/model/a;->AE:Lcom/google/android/gms/internal/an;

    return-void
.end method


# virtual methods
.method public final gS()Lcom/google/android/gms/internal/an;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/a;->AE:Lcom/google/android/gms/internal/an;

    #v0=(Reference);
    return-object v0
.end method

*/}
