package com.google.android.gms.maps.model; class e {/*

.class public final Lcom/google/android/gms/maps/model/e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/maps/model/GroundOverlayOptions;Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->gZ()Landroid/os/IBinder;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/IBinder;)V

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->ha()Lcom/google/android/gms/maps/model/LatLng;

    move-result-object v2

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->getWidth()F

    move-result v2

    #v2=(Float);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->getHeight()F

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->hb()Lcom/google/android/gms/maps/model/LatLngBounds;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->getBearing()F

    move-result v2

    #v2=(Float);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0x8

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->gY()F

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0x9

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->isVisible()Z

    move-result v2

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    const/16 v1, 0xa

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->hc()F

    move-result v2

    #v2=(Float);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0xb

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->hd()F

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0xc

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->he()F

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 16

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v14

    #v14=(Integer);
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x0

    #v3=(Null);
    const/4 v4, 0x0

    #v4=(Null);
    const/4 v5, 0x0

    #v5=(Null);
    const/4 v6, 0x0

    #v6=(Null);
    const/4 v7, 0x0

    #v7=(Null);
    const/4 v8, 0x0

    #v8=(Null);
    const/4 v9, 0x0

    #v9=(Null);
    const/4 v10, 0x0

    #v10=(Null);
    const/4 v11, 0x0

    #v11=(Null);
    const/4 v12, 0x0

    #v12=(Null);
    const/4 v13, 0x0

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Integer);v3=(Reference);v4=(Reference);v5=(Float);v6=(Float);v7=(Reference);v8=(Float);v9=(Float);v10=(Boolean);v11=(Float);v12=(Float);v13=(Float);v15=(Conflicted);
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    #v1=(Integer);
    if-ge v1, v14, :cond_0

    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const v15, 0xffff

    #v15=(Char);
    and-int/2addr v15, v1

    #v15=(Integer);
    packed-switch v15, :pswitch_data_0

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :pswitch_0
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v2

    goto :goto_0

    :pswitch_1
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->m(Landroid/os/Parcel;I)Landroid/os/IBinder;

    move-result-object v3

    goto :goto_0

    :pswitch_2
    #v0=(Conflicted);
    sget-object v4, Lcom/google/android/gms/maps/model/LatLng;->Be:Lcom/google/android/gms/maps/model/g;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1, v4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Lcom/google/android/gms/maps/model/LatLng;

    move-object v4, v1

    goto :goto_0

    :pswitch_3
    #v0=(Conflicted);v1=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v5

    goto :goto_0

    :pswitch_4
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v6

    goto :goto_0

    :pswitch_5
    #v0=(Conflicted);
    sget-object v7, Lcom/google/android/gms/maps/model/LatLngBounds;->Bh:Lcom/google/android/gms/maps/model/f;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1, v7}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Lcom/google/android/gms/maps/model/LatLngBounds;

    move-object v7, v1

    goto :goto_0

    :pswitch_6
    #v0=(Conflicted);v1=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v8

    goto :goto_0

    :pswitch_7
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v9

    goto :goto_0

    :pswitch_8
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v10

    goto :goto_0

    :pswitch_9
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v11

    goto :goto_0

    :pswitch_a
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v12

    goto :goto_0

    :pswitch_b
    #v0=(Conflicted);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v13

    goto :goto_0

    :cond_0
    #v0=(Conflicted);v15=(Conflicted);
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    if-eq v1, v14, :cond_1

    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Overread allowed size end="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-direct {v1, v2, v0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_1
    #v0=(Conflicted);v1=(Integer);v2=(Integer);
    new-instance v1, Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    #v1=(UninitRef);
    invoke-direct/range {v1 .. v13}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;-><init>(ILandroid/os/IBinder;Lcom/google/android/gms/maps/model/LatLng;FFLcom/google/android/gms/maps/model/LatLngBounds;FFZFFF)V

    #v1=(Reference);
    return-object v1

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
    .end packed-switch
.end method

.method public final bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    #v0=(Reference);
    return-object v0
.end method

*/}
