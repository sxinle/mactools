package com.google.android.gms.maps.model; class GroundOverlayOptions {/*

.class public final Lcom/google/android/gms/maps/model/GroundOverlayOptions;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final AV:Lcom/google/android/gms/maps/model/e;


# instance fields
.field private AM:F

.field private AT:F

.field private AU:Z

.field private AW:Lcom/google/android/gms/maps/model/a;

.field private AX:Lcom/google/android/gms/maps/model/LatLng;

.field private AY:F

.field private AZ:F

.field private Ba:Lcom/google/android/gms/maps/model/LatLngBounds;

.field private Bb:F

.field private Bc:F

.field private Bd:F

.field private final tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/e;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/e;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AV:Lcom/google/android/gms/maps/model/e;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    #v2=(One);
    const/high16 v1, 0x3f00

    #v1=(Integer);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-boolean v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AU:Z

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bb:F

    iput v1, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bc:F

    iput v1, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bd:F

    iput v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->tu:I

    return-void
.end method

.method constructor <init>(ILandroid/os/IBinder;Lcom/google/android/gms/maps/model/LatLng;FFLcom/google/android/gms/maps/model/LatLngBounds;FFZFFF)V
    .locals 2

    const/high16 v1, 0x3f00

    #v1=(Integer);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AU:Z

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bb:F

    iput v1, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bc:F

    iput v1, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bd:F

    iput p1, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->tu:I

    new-instance v0, Lcom/google/android/gms/maps/model/a;

    #v0=(UninitRef);
    invoke-static {p2}, Lcom/google/android/gms/internal/ap;->d(Landroid/os/IBinder;)Lcom/google/android/gms/internal/an;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/google/android/gms/maps/model/a;-><init>(Lcom/google/android/gms/internal/an;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AW:Lcom/google/android/gms/maps/model/a;

    iput-object p3, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AX:Lcom/google/android/gms/maps/model/LatLng;

    iput p4, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AY:F

    iput p5, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AZ:F

    iput-object p6, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Ba:Lcom/google/android/gms/maps/model/LatLngBounds;

    iput p7, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AM:F

    iput p8, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AT:F

    iput-boolean p9, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AU:Z

    iput p10, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bb:F

    iput p11, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bc:F

    iput p12, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bd:F

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final gY()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AT:F

    #v0=(Integer);
    return v0
.end method

.method public final gZ()Landroid/os/IBinder;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AW:Lcom/google/android/gms/maps/model/a;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/a;->gS()Lcom/google/android/gms/internal/an;

    move-result-object v0

    invoke-interface {v0}, Lcom/google/android/gms/internal/an;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    return-object v0
.end method

.method public final getBearing()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AM:F

    #v0=(Integer);
    return v0
.end method

.method public final getHeight()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AZ:F

    #v0=(Integer);
    return v0
.end method

.method public final getWidth()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AY:F

    #v0=(Integer);
    return v0
.end method

.method public final ha()Lcom/google/android/gms/maps/model/LatLng;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AX:Lcom/google/android/gms/maps/model/LatLng;

    #v0=(Reference);
    return-object v0
.end method

.method public final hb()Lcom/google/android/gms/maps/model/LatLngBounds;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Ba:Lcom/google/android/gms/maps/model/LatLngBounds;

    #v0=(Reference);
    return-object v0
.end method

.method public final hc()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bb:F

    #v0=(Integer);
    return v0
.end method

.method public final hd()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bc:F

    #v0=(Integer);
    return v0
.end method

.method public final he()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bd:F

    #v0=(Integer);
    return v0
.end method

.method public final isVisible()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AU:Z

    #v0=(Boolean);
    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->gZ()Landroid/os/IBinder;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/IBinder;)V

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AX:Lcom/google/android/gms/maps/model/LatLng;

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x4

    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AY:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x5

    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AZ:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x6

    iget-object v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Ba:Lcom/google/android/gms/maps/model/LatLngBounds;

    #v2=(Reference);
    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x7

    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AM:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0x8

    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AT:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0x9

    iget-boolean v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->AU:Z

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    const/16 v1, 0xa

    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bb:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0xb

    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bc:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0xc

    iget v2, p0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->Bd:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/maps/model/e;->a(Lcom/google/android/gms/maps/model/GroundOverlayOptions;Landroid/os/Parcel;I)V

    goto :goto_0
.end method

*/}
