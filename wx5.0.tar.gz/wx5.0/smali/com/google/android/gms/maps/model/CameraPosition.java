package com.google.android.gms.maps.model; class CameraPosition {/*

.class public final Lcom/google/android/gms/maps/model/CameraPosition;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final AF:Lcom/google/android/gms/maps/model/c;


# instance fields
.field public final AG:Lcom/google/android/gms/maps/model/LatLng;

.field public final AH:F

.field public final AI:F

.field public final eC:F

.field private final tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/c;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/c;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/CameraPosition;->AF:Lcom/google/android/gms/maps/model/c;

    return-void
.end method

.method constructor <init>(ILcom/google/android/gms/maps/model/LatLng;FFF)V
    .locals 5

    const/4 v2, 0x0

    #v2=(Null);
    const/high16 v4, 0x43b4

    #v4=(Integer);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const-string v0, "null camera target"

    #v0=(Reference);
    invoke-static {p2, v0}, Lcom/google/android/gms/internal/i;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    cmpg-float v0, v2, p4

    #v0=(Byte);
    if-gtz v0, :cond_0

    const/high16 v0, 0x42b4

    #v0=(Integer);
    cmpg-float v0, p4, v0

    #v0=(Byte);
    if-gtz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    const-string v1, "Tilt needs to be between 0 and 90 inclusive"

    #v1=(Reference);
    if-nez v0, :cond_1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Byte);v1=(Uninit);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0

    :cond_1
    #v0=(Boolean);v1=(Reference);
    iput p1, p0, Lcom/google/android/gms/maps/model/CameraPosition;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AG:Lcom/google/android/gms/maps/model/LatLng;

    iput p3, p0, Lcom/google/android/gms/maps/model/CameraPosition;->eC:F

    add-float v0, p4, v2

    #v0=(Float);
    iput v0, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AH:F

    float-to-double v0, p5

    #v0=(DoubleLo);v1=(DoubleHi);
    const-wide/16 v2, 0x0

    #v2=(LongLo);v3=(LongHi);
    cmpg-double v0, v0, v2

    #v0=(Byte);
    if-gtz v0, :cond_2

    rem-float v0, p5, v4

    #v0=(Float);
    add-float p5, v0, v4

    :cond_2
    rem-float v0, p5, v4

    iput v0, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AI:F

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/maps/model/LatLng;FFF)V
    .locals 6

    const/4 v1, 0x1

    #v1=(One);
    move-object v0, p0

    #v0=(UninitThis);
    move-object v2, p1

    #v2=(Reference);
    move v3, p2

    #v3=(Float);
    move v4, p3

    #v4=(Float);
    move v5, p4

    #v5=(Float);
    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/maps/model/CameraPosition;-><init>(ILcom/google/android/gms/maps/model/LatLng;FFF)V

    #v0=(Reference);p0=(Reference);
    return-void
.end method

.method public static c(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/gms/maps/model/CameraPosition;
    .locals 11

    const/4 v10, 0x4

    #v10=(PosByte);
    const/4 v5, 0x3

    #v5=(PosByte);
    const/4 v4, 0x2

    #v4=(PosByte);
    const/4 v9, 0x1

    #v9=(One);
    const/4 v1, 0x0

    #v1=(Null);
    if-nez p1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Float);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Uninit);v1=(Null);v2=(Uninit);v3=(Uninit);v4=(PosByte);v5=(PosByte);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    #v0=(Reference);
    sget-object v2, Lcom/google/android/gms/e;->sM:[I

    #v2=(Reference);
    invoke-virtual {v0, p1, v2}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_5

    invoke-virtual {v3, v4, v1}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    :goto_1
    #v0=(Float);
    invoke-virtual {v3, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_4

    invoke-virtual {v3, v5, v1}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    :goto_2
    #v2=(Float);
    new-instance v4, Lcom/google/android/gms/maps/model/LatLng;

    #v4=(UninitRef);
    float-to-double v5, v0

    #v5=(DoubleLo);v6=(DoubleHi);
    float-to-double v7, v2

    #v7=(DoubleLo);v8=(DoubleHi);
    invoke-direct {v4, v5, v6, v7, v8}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    #v4=(Reference);
    new-instance v0, Lcom/google/android/gms/maps/model/b;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/b;-><init>()V

    #v0=(Reference);
    invoke-virtual {v0, v4}, Lcom/google/android/gms/maps/model/b;->a(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/b;

    const/4 v2, 0x5

    #v2=(PosByte);
    invoke-virtual {v3, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_1

    const/4 v2, 0x5

    #v2=(PosByte);
    invoke-virtual {v3, v2, v1}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    #v2=(Float);
    invoke-virtual {v0, v2}, Lcom/google/android/gms/maps/model/b;->L(F)Lcom/google/android/gms/maps/model/b;

    :cond_1
    invoke-virtual {v3, v9}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_2

    invoke-virtual {v3, v9, v1}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v2

    #v2=(Float);
    invoke-virtual {v0, v2}, Lcom/google/android/gms/maps/model/b;->N(F)Lcom/google/android/gms/maps/model/b;

    :cond_2
    invoke-virtual {v3, v10}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    invoke-virtual {v3, v10, v1}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v1

    #v1=(Float);
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/b;->M(F)Lcom/google/android/gms/maps/model/b;

    :cond_3
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/b;->gT()Lcom/google/android/gms/maps/model/CameraPosition;

    move-result-object v0

    goto :goto_0

    :cond_4
    #v0=(Float);v1=(Null);v4=(PosByte);v5=(PosByte);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    move v2, v1

    #v2=(Null);
    goto :goto_2

    :cond_5
    #v0=(Boolean);v2=(Reference);
    move v0, v1

    #v0=(Null);
    goto :goto_1
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/CameraPosition;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    if-ne p0, p1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    :cond_1
    #v0=(One);v2=(Uninit);v3=(Uninit);
    instance-of v2, p1, Lcom/google/android/gms/maps/model/CameraPosition;

    #v2=(Boolean);
    if-nez v2, :cond_2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(One);
    check-cast p1, Lcom/google/android/gms/maps/model/CameraPosition;

    iget-object v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AG:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    iget-object v3, p1, Lcom/google/android/gms/maps/model/CameraPosition;->AG:Lcom/google/android/gms/maps/model/LatLng;

    #v3=(Reference);
    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/model/LatLng;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->eC:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v2

    iget v3, p1, Lcom/google/android/gms/maps/model/CameraPosition;->eC:F

    #v3=(Integer);
    invoke-static {v3}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v3

    if-ne v2, v3, :cond_3

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AH:F

    invoke-static {v2}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v2

    iget v3, p1, Lcom/google/android/gms/maps/model/CameraPosition;->AH:F

    invoke-static {v3}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v3

    if-ne v2, v3, :cond_3

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AI:F

    invoke-static {v2}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v2

    iget v3, p1, Lcom/google/android/gms/maps/model/CameraPosition;->AI:F

    invoke-static {v3}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v3

    if-eq v2, v3, :cond_0

    :cond_3
    #v3=(Conflicted);
    move v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public final hashCode()I
    .locals 3

    const/4 v0, 0x4

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AG:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->eC:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AH:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x3

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AI:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    invoke-static {p0}, Lcom/google/android/gms/internal/g;->f(Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "target"

    #v1=(Reference);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AG:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "zoom"

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->eC:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "tilt"

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AH:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "bearing"

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AI:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/h;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AG:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x3

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->eC:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x4

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AH:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x5

    iget v2, p0, Lcom/google/android/gms/maps/model/CameraPosition;->AI:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/maps/model/c;->a(Lcom/google/android/gms/maps/model/CameraPosition;Landroid/os/Parcel;I)V

    goto :goto_0
.end method

*/}
