package com.google.android.gms.maps.model; class VisibleRegion {/*

.class public final Lcom/google/android/gms/maps/model/VisibleRegion;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final BB:Lcom/google/android/gms/maps/model/o;


# instance fields
.field public final BC:Lcom/google/android/gms/maps/model/LatLng;

.field public final BD:Lcom/google/android/gms/maps/model/LatLng;

.field public final BE:Lcom/google/android/gms/maps/model/LatLng;

.field public final BF:Lcom/google/android/gms/maps/model/LatLng;

.field public final BG:Lcom/google/android/gms/maps/model/LatLngBounds;

.field private final tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/o;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/o;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/VisibleRegion;->BB:Lcom/google/android/gms/maps/model/o;

    return-void
.end method

.method constructor <init>(ILcom/google/android/gms/maps/model/LatLng;Lcom/google/android/gms/maps/model/LatLng;Lcom/google/android/gms/maps/model/LatLng;Lcom/google/android/gms/maps/model/LatLng;Lcom/google/android/gms/maps/model/LatLngBounds;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BC:Lcom/google/android/gms/maps/model/LatLng;

    iput-object p3, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BD:Lcom/google/android/gms/maps/model/LatLng;

    iput-object p4, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BE:Lcom/google/android/gms/maps/model/LatLng;

    iput-object p5, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BF:Lcom/google/android/gms/maps/model/LatLng;

    iput-object p6, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BG:Lcom/google/android/gms/maps/model/LatLngBounds;

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    if-ne p0, p1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    :cond_1
    #v0=(One);v2=(Uninit);v3=(Uninit);
    instance-of v2, p1, Lcom/google/android/gms/maps/model/VisibleRegion;

    #v2=(Boolean);
    if-nez v2, :cond_2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(One);
    check-cast p1, Lcom/google/android/gms/maps/model/VisibleRegion;

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BC:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    iget-object v3, p1, Lcom/google/android/gms/maps/model/VisibleRegion;->BC:Lcom/google/android/gms/maps/model/LatLng;

    #v3=(Reference);
    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/model/LatLng;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BD:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    iget-object v3, p1, Lcom/google/android/gms/maps/model/VisibleRegion;->BD:Lcom/google/android/gms/maps/model/LatLng;

    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/model/LatLng;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BE:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    iget-object v3, p1, Lcom/google/android/gms/maps/model/VisibleRegion;->BE:Lcom/google/android/gms/maps/model/LatLng;

    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/model/LatLng;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BF:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    iget-object v3, p1, Lcom/google/android/gms/maps/model/VisibleRegion;->BF:Lcom/google/android/gms/maps/model/LatLng;

    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/model/LatLng;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BG:Lcom/google/android/gms/maps/model/LatLngBounds;

    #v2=(Reference);
    iget-object v3, p1, Lcom/google/android/gms/maps/model/VisibleRegion;->BG:Lcom/google/android/gms/maps/model/LatLngBounds;

    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/model/LatLngBounds;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_0

    :cond_3
    move v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public final hashCode()I
    .locals 3

    const/4 v0, 0x5

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BC:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BD:Lcom/google/android/gms/maps/model/LatLng;

    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BE:Lcom/google/android/gms/maps/model/LatLng;

    aput-object v2, v0, v1

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BF:Lcom/google/android/gms/maps/model/LatLng;

    aput-object v2, v0, v1

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BG:Lcom/google/android/gms/maps/model/LatLngBounds;

    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    invoke-static {p0}, Lcom/google/android/gms/internal/g;->f(Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "nearLeft"

    #v1=(Reference);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BC:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "nearRight"

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BD:Lcom/google/android/gms/maps/model/LatLng;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "farLeft"

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BE:Lcom/google/android/gms/maps/model/LatLng;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "farRight"

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BF:Lcom/google/android/gms/maps/model/LatLng;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "latLngBounds"

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BG:Lcom/google/android/gms/maps/model/LatLngBounds;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/h;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BC:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BD:Lcom/google/android/gms/maps/model/LatLng;

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BE:Lcom/google/android/gms/maps/model/LatLng;

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x5

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BF:Lcom/google/android/gms/maps/model/LatLng;

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x6

    iget-object v2, p0, Lcom/google/android/gms/maps/model/VisibleRegion;->BG:Lcom/google/android/gms/maps/model/LatLngBounds;

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/maps/model/o;->a(Lcom/google/android/gms/maps/model/VisibleRegion;Landroid/os/Parcel;I)V

    goto :goto_0
.end method

*/}
