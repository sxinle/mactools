package com.google.android.gms.maps.model; class LatLng {/*

.class public final Lcom/google/android/gms/maps/model/LatLng;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final Be:Lcom/google/android/gms/maps/model/g;


# instance fields
.field public final Bf:D

.field public final Bg:D

.field private final tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/g;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/g;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/LatLng;->Be:Lcom/google/android/gms/maps/model/g;

    return-void
.end method

.method public constructor <init>(DD)V
    .locals 6

    const/4 v1, 0x1

    #v1=(One);
    move-object v0, p0

    #v0=(UninitThis);
    move-wide v2, p1

    #v2=(DoubleLo);v3=(DoubleHi);
    move-wide v4, p3

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/maps/model/LatLng;-><init>(IDD)V

    #v0=(Reference);p0=(Reference);
    return-void
.end method

.method constructor <init>(IDD)V
    .locals 6

    const-wide v4, 0x4076800000000000L

    #v4=(LongLo);v5=(LongHi);
    const-wide v2, 0x4066800000000000L

    #v2=(LongLo);v3=(LongHi);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/maps/model/LatLng;->tu:I

    const-wide v0, -0x3f99800000000000L

    #v0=(LongLo);v1=(LongHi);
    cmpg-double v0, v0, p4

    #v0=(Byte);
    if-gtz v0, :cond_0

    cmpg-double v0, p4, v2

    if-gez v0, :cond_0

    iput-wide p4, p0, Lcom/google/android/gms/maps/model/LatLng;->Bg:D

    :goto_0
    #v0=(Conflicted);
    const-wide v0, -0x3fa9800000000000L

    #v0=(LongLo);
    const-wide v2, 0x4056800000000000L

    invoke-static {v2, v3, p2, p3}, Ljava/lang/Math;->min(DD)D

    move-result-wide v2

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(DD)D

    move-result-wide v0

    #v0=(DoubleLo);v1=(DoubleHi);
    iput-wide v0, p0, Lcom/google/android/gms/maps/model/LatLng;->Bf:D

    return-void

    :cond_0
    #v0=(Byte);v1=(LongHi);v2=(LongLo);v3=(LongHi);
    sub-double v0, p4, v2

    #v0=(DoubleLo);v1=(DoubleHi);
    rem-double/2addr v0, v4

    add-double/2addr v0, v4

    rem-double/2addr v0, v4

    sub-double/2addr v0, v2

    iput-wide v0, p0, Lcom/google/android/gms/maps/model/LatLng;->Bg:D

    goto :goto_0
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/LatLng;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 6

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    if-ne p0, p1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    :cond_1
    #v0=(One);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    instance-of v2, p1, Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Boolean);
    if-nez v2, :cond_2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(One);
    check-cast p1, Lcom/google/android/gms/maps/model/LatLng;

    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->Bf:D

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {v2, v3}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    iget-wide v4, p1, Lcom/google/android/gms/maps/model/LatLng;->Bf:D

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-nez v2, :cond_3

    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->Bg:D

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {v2, v3}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    iget-wide v4, p1, Lcom/google/android/gms/maps/model/LatLng;->Bg:D

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-eqz v2, :cond_0

    :cond_3
    move v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public final hashCode()I
    .locals 5

    const/16 v4, 0x20

    #v4=(PosByte);
    iget-wide v0, p0, Lcom/google/android/gms/maps/model/LatLng;->Bf:D

    #v0=(DoubleLo);v1=(DoubleHi);
    invoke-static {v0, v1}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    ushr-long v2, v0, v4

    #v2=(LongLo);v3=(LongHi);
    xor-long/2addr v0, v2

    long-to-int v0, v0

    #v0=(Integer);
    add-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lcom/google/android/gms/maps/model/LatLng;->Bg:D

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    mul-int/lit8 v0, v0, 0x1f

    ushr-long v3, v1, v4

    #v3=(LongLo);v4=(LongHi);
    xor-long/2addr v1, v3

    long-to-int v1, v1

    #v1=(Integer);
    add-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "lat/lng: ("

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    iget-wide v1, p0, Lcom/google/android/gms/maps/model/LatLng;->Bf:D

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ","

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p0, Lcom/google/android/gms/maps/model/LatLng;->Bg:D

    #v1=(DoubleLo);
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/LatLng;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->Bf:D

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ID)V

    const/4 v1, 0x3

    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->Bg:D

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ID)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/maps/model/g;->a(Lcom/google/android/gms/maps/model/LatLng;Landroid/os/Parcel;)V

    goto :goto_0
.end method

*/}
