package com.google.android.gms.maps.model; class k {/*

.class public final Lcom/google/android/gms/maps/model/k;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/maps/model/Tile;Landroid/os/Parcel;)V
    .locals 3

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/Tile;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget v2, p0, Lcom/google/android/gms/maps/model/Tile;->width:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x3

    iget v2, p0, Lcom/google/android/gms/maps/model/Tile;->height:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    iget-object v1, p0, Lcom/google/android/gms/maps/model/Tile;->data:[B

    #v1=(Reference);
    invoke-static {p1, v1}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;[B)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method

.method public static m(Landroid/os/Parcel;)Lcom/google/android/gms/maps/model/Tile;
    .locals 7

    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {p0}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v4

    #v4=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v2, v1

    #v2=(Null);
    move v3, v1

    :goto_0
    #v0=(Reference);v1=(Integer);v2=(Integer);v3=(Integer);v5=(Conflicted);v6=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v5

    #v5=(Integer);
    if-ge v5, v4, :cond_0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const v6, 0xffff

    #v6=(Char);
    and-int/2addr v6, v5

    #v6=(Integer);
    packed-switch v6, :pswitch_data_0

    invoke-static {p0, v5}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :pswitch_0
    invoke-static {p0, v5}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v3

    goto :goto_0

    :pswitch_1
    invoke-static {p0, v5}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v2

    goto :goto_0

    :pswitch_2
    invoke-static {p0, v5}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v1

    goto :goto_0

    :pswitch_3
    invoke-static {p0, v5}, Lcom/google/android/gms/internal/o;->o(Landroid/os/Parcel;I)[B

    move-result-object v0

    goto :goto_0

    :cond_0
    #v6=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v5

    if-eq v5, v4, :cond_1

    new-instance v0, Lcom/google/android/gms/internal/p;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Overread allowed size end="

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v1=(Integer);v2=(Integer);
    new-instance v4, Lcom/google/android/gms/maps/model/Tile;

    #v4=(UninitRef);
    invoke-direct {v4, v3, v2, v1, v0}, Lcom/google/android/gms/maps/model/Tile;-><init>(III[B)V

    #v4=(Reference);
    return-object v4

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
    .end packed-switch
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Lcom/google/android/gms/maps/model/k;->m(Landroid/os/Parcel;)Lcom/google/android/gms/maps/model/Tile;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/maps/model/Tile;

    #v0=(Reference);
    return-object v0
.end method

*/}
