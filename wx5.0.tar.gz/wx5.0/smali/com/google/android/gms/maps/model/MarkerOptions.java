package com.google.android.gms.maps.model; class MarkerOptions {/*

.class public final Lcom/google/android/gms/maps/model/MarkerOptions;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final Bk:Lcom/google/android/gms/maps/model/h;


# instance fields
.field private AU:Z

.field private Bc:F

.field private Bd:F

.field private Bl:Lcom/google/android/gms/maps/model/LatLng;

.field private Bm:Ljava/lang/String;

.field private Bn:Lcom/google/android/gms/maps/model/a;

.field private Bo:Z

.field private final tu:I

.field private ys:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/h;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/h;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bk:Lcom/google/android/gms/maps/model/h;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    #v1=(One);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/high16 v0, 0x3f00

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bc:F

    const/high16 v0, 0x3f80

    iput v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bd:F

    iput-boolean v1, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->AU:Z

    iput v1, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->tu:I

    return-void
.end method

.method constructor <init>(ILcom/google/android/gms/maps/model/LatLng;Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;FFZZ)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/high16 v0, 0x3f00

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bc:F

    const/high16 v0, 0x3f80

    iput v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bd:F

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->AU:Z

    iput p1, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bl:Lcom/google/android/gms/maps/model/LatLng;

    iput-object p3, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->ys:Ljava/lang/String;

    iput-object p4, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bm:Ljava/lang/String;

    if-nez p5, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);
    iput-object v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bn:Lcom/google/android/gms/maps/model/a;

    iput p6, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bc:F

    iput p7, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bd:F

    iput-boolean p8, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bo:Z

    iput-boolean p9, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->AU:Z

    return-void

    :cond_0
    #v0=(One);v1=(Uninit);
    new-instance v0, Lcom/google/android/gms/maps/model/a;

    #v0=(UninitRef);
    invoke-static {p5}, Lcom/google/android/gms/internal/ap;->d(Landroid/os/IBinder;)Lcom/google/android/gms/internal/an;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/google/android/gms/maps/model/a;-><init>(Lcom/google/android/gms/internal/an;)V

    #v0=(Reference);
    goto :goto_0
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final getSnippet()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bm:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->ys:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final hd()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bc:F

    #v0=(Integer);
    return v0
.end method

.method public final he()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bd:F

    #v0=(Integer);
    return v0
.end method

.method public final hf()Landroid/os/IBinder;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bn:Lcom/google/android/gms/maps/model/a;

    #v0=(Reference);
    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bn:Lcom/google/android/gms/maps/model/a;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/a;->gS()Lcom/google/android/gms/internal/an;

    move-result-object v0

    invoke-interface {v0}, Lcom/google/android/gms/internal/an;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0
.end method

.method public final hg()Lcom/google/android/gms/maps/model/LatLng;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bl:Lcom/google/android/gms/maps/model/LatLng;

    #v0=(Reference);
    return-object v0
.end method

.method public final hh()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bo:Z

    #v0=(Boolean);
    return v0
.end method

.method public final isVisible()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->AU:Z

    #v0=(Boolean);
    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bl:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->ys:Ljava/lang/String;

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bm:Ljava/lang/String;

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/maps/model/MarkerOptions;->hf()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/IBinder;)V

    const/4 v1, 0x6

    iget v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bc:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x7

    iget v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bd:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0x8

    iget-boolean v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->Bo:Z

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    const/16 v1, 0x9

    iget-boolean v2, p0, Lcom/google/android/gms/maps/model/MarkerOptions;->AU:Z

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/maps/model/h;->a(Lcom/google/android/gms/maps/model/MarkerOptions;Landroid/os/Parcel;I)V

    goto :goto_0
.end method

*/}
