package com.google.android.gms.maps.model; class CircleOptions {/*

.class public final Lcom/google/android/gms/maps/model/CircleOptions;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final AN:Lcom/google/android/gms/maps/model/d;


# instance fields
.field private AO:Lcom/google/android/gms/maps/model/LatLng;

.field private AP:D

.field private AQ:F

.field private AR:I

.field private AS:I

.field private AT:F

.field private AU:Z

.field private final tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/maps/model/d;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/d;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/maps/model/CircleOptions;->AN:Lcom/google/android/gms/maps/model/d;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    #v2=(One);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AO:Lcom/google/android/gms/maps/model/LatLng;

    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AP:D

    const/high16 v0, 0x4120

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AQ:F

    const/high16 v0, -0x100

    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AR:I

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AS:I

    const/4 v0, 0x0

    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AT:F

    iput-boolean v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AU:Z

    iput v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->tu:I

    return-void
.end method

.method constructor <init>(ILcom/google/android/gms/maps/model/LatLng;DFIIFZ)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AO:Lcom/google/android/gms/maps/model/LatLng;

    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AP:D

    const/high16 v0, 0x4120

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AQ:F

    const/high16 v0, -0x100

    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AR:I

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AS:I

    const/4 v0, 0x0

    iput v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AT:F

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AU:Z

    iput p1, p0, Lcom/google/android/gms/maps/model/CircleOptions;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AO:Lcom/google/android/gms/maps/model/LatLng;

    iput-wide p3, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AP:D

    iput p5, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AQ:F

    iput p6, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AR:I

    iput p7, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AS:I

    iput p8, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AT:F

    iput-boolean p9, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AU:Z

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final gU()Lcom/google/android/gms/maps/model/LatLng;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AO:Lcom/google/android/gms/maps/model/LatLng;

    #v0=(Reference);
    return-object v0
.end method

.method public final gV()D
    .locals 2

    iget-wide v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AP:D

    #v0=(DoubleLo);v1=(DoubleHi);
    return-wide v0
.end method

.method public final gW()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AR:I

    #v0=(Integer);
    return v0
.end method

.method public final gX()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AS:I

    #v0=(Integer);
    return v0
.end method

.method public final gY()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AT:F

    #v0=(Integer);
    return v0
.end method

.method public final getStrokeWidth()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AQ:F

    #v0=(Integer);
    return v0
.end method

.method public final isVisible()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AU:Z

    #v0=(Boolean);
    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    invoke-static {}, Lcom/google/android/gms/internal/ay;->el()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AO:Lcom/google/android/gms/maps/model/LatLng;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v1, 0x3

    iget-wide v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AP:D

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ID)V

    const/4 v1, 0x4

    iget v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AQ:F

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x5

    iget v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AR:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x6

    iget v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AS:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x7

    iget v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AT:F

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/16 v1, 0x8

    iget-boolean v2, p0, Lcom/google/android/gms/maps/model/CircleOptions;->AU:Z

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/maps/model/d;->a(Lcom/google/android/gms/maps/model/CircleOptions;Landroid/os/Parcel;I)V

    goto :goto_0
.end method

*/}
