package com.google.android.gms; class b {/*

.class public final Lcom/google/android/gms/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final sF:I = 0x7f070095

.field public static final sG:I = 0x7f070096

*/}
