package com.google.android.gms.games; class Player {/*

.class public interface abstract Lcom/google/android/gms/games/Player;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;
.implements Lcom/google/android/gms/common/a/a;


# virtual methods
.method public abstract cW()Landroid/net/Uri;
.end method

.method public abstract cX()Landroid/net/Uri;
.end method

.method public abstract dh()Ljava/lang/String;
.end method

.method public abstract di()J
.end method

.method public abstract getDisplayName()Ljava/lang/String;
.end method

*/}
