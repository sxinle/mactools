package com.google.android.gms.games; class b {/*

.class public Lcom/google/android/gms/games/b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/games/GameEntity;Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cS()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->getDisplayName()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cT()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cU()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->getDescription()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cV()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cW()Landroid/net/Uri;

    move-result-object v2

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/16 v1, 0x8

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cX()Landroid/net/Uri;

    move-result-object v2

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/16 v1, 0x9

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cY()Landroid/net/Uri;

    move-result-object v2

    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/16 v1, 0xa

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->cZ()Z

    move-result v2

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    const/16 v1, 0xb

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->da()Z

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    const/16 v1, 0xc

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->db()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/16 v1, 0xd

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->dc()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/16 v1, 0xe

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->dd()I

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/16 v1, 0xf

    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->de()I

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/16 v1, 0x3e8

    #v1=(PosShort);
    invoke-virtual {p0}, Lcom/google/android/gms/games/GameEntity;->df()I

    move-result v2

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/google/android/gms/games/GameEntity;
    .locals 20

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v18

    #v18=(Integer);
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x0

    #v3=(Null);
    const/4 v4, 0x0

    #v4=(Null);
    const/4 v5, 0x0

    #v5=(Null);
    const/4 v6, 0x0

    #v6=(Null);
    const/4 v7, 0x0

    #v7=(Null);
    const/4 v8, 0x0

    #v8=(Null);
    const/4 v9, 0x0

    #v9=(Null);
    const/4 v10, 0x0

    #v10=(Null);
    const/4 v11, 0x0

    #v11=(Null);
    const/4 v12, 0x0

    #v12=(Null);
    const/4 v13, 0x0

    #v13=(Null);
    const/4 v14, 0x0

    #v14=(Null);
    const/4 v15, 0x0

    #v15=(Null);
    const/16 v16, 0x0

    #v16=(Null);
    const/16 v17, 0x0

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Integer);v3=(Reference);v4=(Reference);v5=(Reference);v6=(Reference);v7=(Reference);v8=(Reference);v9=(Reference);v10=(Reference);v11=(Reference);v12=(Boolean);v13=(Boolean);v14=(Reference);v15=(Integer);v16=(Integer);v17=(Integer);v19=(Conflicted);
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    #v1=(Integer);
    move/from16 v0, v18

    #v0=(Integer);
    if-ge v1, v0, :cond_0

    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const v19, 0xffff

    #v19=(Char);
    and-int v19, v19, v1

    #v19=(Integer);
    sparse-switch v19, :sswitch_data_0

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :sswitch_0
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v3

    goto :goto_0

    :sswitch_1
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v4

    goto :goto_0

    :sswitch_2
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v5

    goto :goto_0

    :sswitch_3
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v6

    goto :goto_0

    :sswitch_4
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v7

    goto :goto_0

    :sswitch_5
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v8

    goto :goto_0

    :sswitch_6
    #v0=(Integer);
    sget-object v9, Landroid/net/Uri;->CREATOR:Landroid/os/Parcelable$Creator;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1, v9}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Landroid/net/Uri;

    move-object v9, v1

    goto :goto_0

    :sswitch_7
    #v0=(Integer);v1=(Integer);
    sget-object v10, Landroid/net/Uri;->CREATOR:Landroid/os/Parcelable$Creator;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1, v10}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Landroid/net/Uri;

    move-object v10, v1

    goto :goto_0

    :sswitch_8
    #v0=(Integer);v1=(Integer);
    sget-object v11, Landroid/net/Uri;->CREATOR:Landroid/os/Parcelable$Creator;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1, v11}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Landroid/net/Uri;

    move-object v11, v1

    goto :goto_0

    :sswitch_9
    #v0=(Integer);v1=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v12

    goto :goto_0

    :sswitch_a
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v13

    goto :goto_0

    :sswitch_b
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v14

    goto :goto_0

    :sswitch_c
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v15

    goto/16 :goto_0

    :sswitch_d
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v16

    goto/16 :goto_0

    :sswitch_e
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v17

    goto/16 :goto_0

    :sswitch_f
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v2

    goto/16 :goto_0

    :cond_0
    #v0=(Integer);v19=(Conflicted);
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    move/from16 v0, v18

    if-eq v1, v0, :cond_1

    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Overread allowed size end="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    move/from16 v0, v18

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-direct {v1, v2, v0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_1
    #v0=(Integer);v1=(Integer);v2=(Integer);
    new-instance v1, Lcom/google/android/gms/games/GameEntity;

    #v1=(UninitRef);
    invoke-direct/range {v1 .. v17}, Lcom/google/android/gms/games/GameEntity;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;Landroid/net/Uri;ZZLjava/lang/String;III)V

    #v1=(Reference);
    return-object v1

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_0
        0x2 -> :sswitch_1
        0x3 -> :sswitch_2
        0x4 -> :sswitch_3
        0x5 -> :sswitch_4
        0x6 -> :sswitch_5
        0x7 -> :sswitch_6
        0x8 -> :sswitch_7
        0x9 -> :sswitch_8
        0xa -> :sswitch_9
        0xb -> :sswitch_a
        0xc -> :sswitch_b
        0xd -> :sswitch_c
        0xe -> :sswitch_d
        0xf -> :sswitch_e
        0x3e8 -> :sswitch_f
    .end sparse-switch
.end method

.method public synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/games/b;->a(Landroid/os/Parcel;)Lcom/google/android/gms/games/GameEntity;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/games/GameEntity;

    #v0=(Reference);
    return-object v0
.end method

*/}
