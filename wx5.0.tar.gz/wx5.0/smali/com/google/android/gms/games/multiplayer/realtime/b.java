package com.google.android.gms.games.multiplayer.realtime; class b {/*

.class final Lcom/google/android/gms/games/multiplayer/realtime/b;
.super Lcom/google/android/gms/games/multiplayer/realtime/c;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/games/multiplayer/realtime/c;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/games/multiplayer/realtime/b;->e(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final e(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;
    .locals 12

    invoke-static {}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->dg()Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->a(Ljava/lang/Integer;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    const-class v0, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->K(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    :cond_0
    invoke-super {p0, p1}, Lcom/google/android/gms/games/multiplayer/realtime/c;->e(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    move-result-object v0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);
    return-object v0

    :cond_1
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);v10=(Uninit);v11=(Uninit);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v6

    #v6=(Integer);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v8

    #v8=(Integer);
    invoke-virtual {p1}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;

    move-result-object v9

    #v9=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    #v1=(Integer);
    new-instance v10, Ljava/util/ArrayList;

    #v10=(UninitRef);
    invoke-direct {v10, v1}, Ljava/util/ArrayList;-><init>(I)V

    #v10=(Reference);
    const/4 v0, 0x0

    :goto_1
    #v0=(Integer);v11=(Conflicted);
    if-ge v0, v1, :cond_2

    sget-object v11, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->tV:Lcom/google/android/gms/games/multiplayer/d;

    #v11=(Reference);
    invoke-virtual {v11, p1}, Lcom/google/android/gms/games/multiplayer/d;->d(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    #v11=(Conflicted);
    new-instance v0, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    #v0=(UninitRef);
    const/4 v1, 0x1

    #v1=(One);
    invoke-direct/range {v0 .. v10}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;-><init>(ILjava/lang/String;Ljava/lang/String;JILjava/lang/String;ILandroid/os/Bundle;Ljava/util/ArrayList;)V

    #v0=(Reference);
    goto :goto_0
.end method

*/}
