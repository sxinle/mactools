package com.google.android.gms.games.multiplayer; class a {/*

.class final Lcom/google/android/gms/games/multiplayer/a;
.super Lcom/google/android/gms/games/multiplayer/b;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/games/multiplayer/b;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final c(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/InvitationEntity;
    .locals 10

    invoke-static {}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;->dg()Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;->a(Ljava/lang/Integer;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    const-class v0, Lcom/google/android/gms/games/multiplayer/InvitationEntity;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;->K(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    :cond_0
    invoke-super {p0, p1}, Lcom/google/android/gms/games/multiplayer/b;->c(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/InvitationEntity;

    move-result-object v0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    return-object v0

    :cond_1
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    sget-object v0, Lcom/google/android/gms/games/GameEntity;->tt:Lcom/google/android/gms/games/b;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/games/b;->a(Landroid/os/Parcel;)Lcom/google/android/gms/games/GameEntity;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v6

    #v6=(Integer);
    sget-object v0, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->tV:Lcom/google/android/gms/games/multiplayer/d;

    invoke-virtual {v0, p1}, Lcom/google/android/gms/games/multiplayer/d;->d(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    #v1=(Integer);
    new-instance v8, Ljava/util/ArrayList;

    #v8=(UninitRef);
    invoke-direct {v8, v1}, Ljava/util/ArrayList;-><init>(I)V

    #v8=(Reference);
    const/4 v0, 0x0

    :goto_1
    #v0=(Integer);v9=(Conflicted);
    if-ge v0, v1, :cond_2

    sget-object v9, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->tV:Lcom/google/android/gms/games/multiplayer/d;

    #v9=(Reference);
    invoke-virtual {v9, p1}, Lcom/google/android/gms/games/multiplayer/d;->d(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    #v9=(Conflicted);
    new-instance v0, Lcom/google/android/gms/games/multiplayer/InvitationEntity;

    #v0=(UninitRef);
    const/4 v1, 0x1

    #v1=(One);
    const/4 v9, -0x1

    #v9=(Byte);
    invoke-direct/range {v0 .. v9}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;-><init>(ILcom/google/android/gms/games/GameEntity;Ljava/lang/String;JILcom/google/android/gms/games/multiplayer/ParticipantEntity;Ljava/util/ArrayList;I)V

    #v0=(Reference);
    goto :goto_0
.end method

.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/games/multiplayer/a;->c(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/InvitationEntity;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

*/}
