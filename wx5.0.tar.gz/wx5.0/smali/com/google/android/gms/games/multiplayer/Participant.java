package com.google.android.gms.games.multiplayer; class Participant {/*

.class public interface abstract Lcom/google/android/gms/games/multiplayer/Participant;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;
.implements Lcom/google/android/gms/common/a/a;


# virtual methods
.method public abstract cW()Landroid/net/Uri;
.end method

.method public abstract cX()Landroid/net/Uri;
.end method

.method public abstract dq()Ljava/lang/String;
.end method

.method public abstract dr()I
.end method

.method public abstract ds()Z
.end method

.method public abstract dt()Ljava/lang/String;
.end method

.method public abstract du()Lcom/google/android/gms/games/Player;
.end method

.method public abstract getDisplayName()Ljava/lang/String;
.end method

.method public abstract getStatus()I
.end method

*/}
