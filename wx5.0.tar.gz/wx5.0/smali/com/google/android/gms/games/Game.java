package com.google.android.gms.games; class Game {/*

.class public interface abstract Lcom/google/android/gms/games/Game;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;
.implements Lcom/google/android/gms/common/a/a;


# virtual methods
.method public abstract cS()Ljava/lang/String;
.end method

.method public abstract cT()Ljava/lang/String;
.end method

.method public abstract cU()Ljava/lang/String;
.end method

.method public abstract cV()Ljava/lang/String;
.end method

.method public abstract cW()Landroid/net/Uri;
.end method

.method public abstract cX()Landroid/net/Uri;
.end method

.method public abstract cY()Landroid/net/Uri;
.end method

.method public abstract cZ()Z
.end method

.method public abstract da()Z
.end method

.method public abstract db()Ljava/lang/String;
.end method

.method public abstract dc()I
.end method

.method public abstract dd()I
.end method

.method public abstract de()I
.end method

.method public abstract getDescription()Ljava/lang/String;
.end method

.method public abstract getDisplayName()Ljava/lang/String;
.end method

*/}
