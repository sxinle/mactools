package com.google.android.gms.games.multiplayer.realtime; class Room {/*

.class public interface abstract Lcom/google/android/gms/games/multiplayer/realtime/Room;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;
.implements Lcom/google/android/gms/common/a/a;
.implements Lcom/google/android/gms/games/multiplayer/e;


# virtual methods
.method public abstract dm()J
.end method

.method public abstract do()I
.end method

.method public abstract dv()Ljava/lang/String;
.end method

.method public abstract dw()Ljava/lang/String;
.end method

.method public abstract dx()Landroid/os/Bundle;
.end method

.method public abstract getDescription()Ljava/lang/String;
.end method

.method public abstract getStatus()I
.end method

*/}
