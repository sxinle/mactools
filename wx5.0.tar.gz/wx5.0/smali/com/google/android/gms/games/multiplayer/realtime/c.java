package com.google.android.gms.games.multiplayer.realtime; class c {/*

.class public Lcom/google/android/gms/games/multiplayer/realtime/c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;Landroid/os/Parcel;)V
    .locals 5

    const/4 v4, 0x0

    #v4=(Null);
    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->dv()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/16 v1, 0x3e8

    #v1=(PosShort);
    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->dw()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->dm()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IJ)V

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->getStatus()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->getDescription()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->do()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->dx()Landroid/os/Bundle;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Bundle;)V

    const/16 v1, 0x8

    invoke-virtual {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->dp()Ljava/util/ArrayList;

    move-result-object v2

    invoke-static {p1, v1, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method


# virtual methods
.method public synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/games/multiplayer/realtime/c;->e(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public e(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;
    .locals 13

    const/4 v8, 0x0

    #v8=(Null);
    const/4 v10, 0x0

    #v10=(Null);
    invoke-static {p1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const-wide/16 v4, 0x0

    #v4=(LongLo);v5=(LongHi);
    move-object v9, v10

    #v9=(Null);
    move-object v7, v10

    #v7=(Null);
    move v6, v8

    #v6=(Null);
    move-object v3, v10

    #v3=(Null);
    move-object v2, v10

    #v2=(Null);
    move v1, v8

    :goto_0
    #v1=(Integer);v2=(Reference);v3=(Reference);v6=(Integer);v7=(Reference);v8=(Integer);v9=(Reference);v10=(Reference);v11=(Conflicted);v12=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v11

    #v11=(Integer);
    if-ge v11, v0, :cond_0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v11

    const v12, 0xffff

    #v12=(Char);
    and-int/2addr v12, v11

    #v12=(Integer);
    sparse-switch v12, :sswitch_data_0

    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :sswitch_0
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :sswitch_1
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v1

    goto :goto_0

    :sswitch_2
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v3

    goto :goto_0

    :sswitch_3
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->g(Landroid/os/Parcel;I)J

    move-result-wide v4

    goto :goto_0

    :sswitch_4
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v6

    goto :goto_0

    :sswitch_5
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v7

    goto :goto_0

    :sswitch_6
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v8

    goto :goto_0

    :sswitch_7
    invoke-static {p1, v11}, Lcom/google/android/gms/internal/o;->n(Landroid/os/Parcel;I)Landroid/os/Bundle;

    move-result-object v9

    goto :goto_0

    :sswitch_8
    sget-object v10, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->tV:Lcom/google/android/gms/games/multiplayer/d;

    invoke-static {p1, v11, v10}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v10

    goto :goto_0

    :cond_0
    #v12=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v11

    if-eq v11, v0, :cond_1

    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Overread allowed size end="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0, p1}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_1
    #v0=(Integer);v1=(Integer);
    new-instance v0, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    #v0=(UninitRef);
    invoke-direct/range {v0 .. v10}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;-><init>(ILjava/lang/String;Ljava/lang/String;JILjava/lang/String;ILandroid/os/Bundle;Ljava/util/ArrayList;)V

    #v0=(Reference);
    return-object v0

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);v7=(Unknown);v8=(Unknown);v9=(Unknown);v10=(Unknown);v11=(Unknown);v12=(Unknown);p0=(Unknown);p1=(Unknown);
    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_0
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x5 -> :sswitch_5
        0x6 -> :sswitch_6
        0x7 -> :sswitch_7
        0x8 -> :sswitch_8
        0x3e8 -> :sswitch_1
    .end sparse-switch
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    #v0=(Reference);
    return-object v0
.end method

*/}
