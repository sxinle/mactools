package com.google.android.gms.games.multiplayer; class Invitation {/*

.class public interface abstract Lcom/google/android/gms/games/multiplayer/Invitation;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;
.implements Lcom/google/android/gms/common/a/a;
.implements Lcom/google/android/gms/games/multiplayer/e;


# virtual methods
.method public abstract dj()Lcom/google/android/gms/games/Game;
.end method

.method public abstract dk()Ljava/lang/String;
.end method

.method public abstract dl()Lcom/google/android/gms/games/multiplayer/Participant;
.end method

.method public abstract dm()J
.end method

.method public abstract dn()I
.end method

.method public abstract do()I
.end method

*/}
