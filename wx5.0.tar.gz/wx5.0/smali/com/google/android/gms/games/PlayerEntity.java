package com.google.android.gms.games; class PlayerEntity {/*

.class public final Lcom/google/android/gms/games/PlayerEntity;
.super Lcom/google/android/gms/internal/bq;

# interfaces
.implements Lcom/google/android/gms/games/Player;


# static fields
.field public static final tK:Lcom/google/android/gms/games/d;


# instance fields
.field private final tB:Landroid/net/Uri;

.field private final tC:Landroid/net/Uri;

.field private final tL:Ljava/lang/String;

.field private final tM:J

.field private final tu:I

.field private final tw:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/games/c;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/games/c;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/games/PlayerEntity;->tK:Lcom/google/android/gms/games/d;

    return-void
.end method

.method constructor <init>(ILjava/lang/String;Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;J)V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/internal/bq;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/games/PlayerEntity;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/games/PlayerEntity;->tL:Ljava/lang/String;

    iput-object p3, p0, Lcom/google/android/gms/games/PlayerEntity;->tw:Ljava/lang/String;

    iput-object p4, p0, Lcom/google/android/gms/games/PlayerEntity;->tB:Landroid/net/Uri;

    iput-object p5, p0, Lcom/google/android/gms/games/PlayerEntity;->tC:Landroid/net/Uri;

    iput-wide p6, p0, Lcom/google/android/gms/games/PlayerEntity;->tM:J

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/games/Player;)V
    .locals 5

    const/4 v0, 0x1

    #v0=(One);
    invoke-direct {p0}, Lcom/google/android/gms/internal/bq;-><init>()V

    #p0=(Reference);
    iput v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tu:I

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->dh()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    iput-object v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tL:Ljava/lang/String;

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->getDisplayName()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tw:Ljava/lang/String;

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->cW()Landroid/net/Uri;

    move-result-object v1

    iput-object v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tB:Landroid/net/Uri;

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->cX()Landroid/net/Uri;

    move-result-object v1

    iput-object v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tC:Landroid/net/Uri;

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->di()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    iput-wide v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tM:J

    iget-object v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tL:Ljava/lang/String;

    #v1=(Reference);
    invoke-static {v1}, Lcom/google/android/gms/internal/cz;->j(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tw:Ljava/lang/String;

    invoke-static {v1}, Lcom/google/android/gms/internal/cz;->j(Ljava/lang/Object;)V

    iget-wide v1, p0, Lcom/google/android/gms/games/PlayerEntity;->tM:J

    #v1=(LongLo);
    const-wide/16 v3, 0x0

    #v3=(LongLo);v4=(LongHi);
    cmp-long v1, v1, v3

    #v1=(Byte);
    if-lez v1, :cond_0

    :goto_0
    #v0=(Boolean);
    if-nez v0, :cond_1

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(One);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0

    :cond_1
    #v0=(Boolean);
    return-void
.end method

.method static synthetic K(Ljava/lang/String;)Z
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/PlayerEntity;->R(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public static a(Lcom/google/android/gms/games/Player;)I
    .locals 4

    const/4 v0, 0x5

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->dh()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->getDisplayName()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->cW()Landroid/net/Uri;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x3

    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->cX()Landroid/net/Uri;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x4

    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->di()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public static a(Lcom/google/android/gms/games/Player;Ljava/lang/Object;)Z
    .locals 5

    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    #v0=(Null);
    instance-of v2, p1, Lcom/google/android/gms/games/Player;

    #v2=(Boolean);
    if-nez v2, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v3=(Conflicted);v4=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v3=(Uninit);v4=(Uninit);
    if-ne p0, p1, :cond_2

    move v0, v1

    #v0=(One);
    goto :goto_0

    :cond_2
    #v0=(Null);
    check-cast p1, Lcom/google/android/gms/games/Player;

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->dh()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->dh()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {v2, v3}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->getDisplayName()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->getDisplayName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->cW()Landroid/net/Uri;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->cW()Landroid/net/Uri;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->cX()Landroid/net/Uri;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->cX()Landroid/net/Uri;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-interface {p1}, Lcom/google/android/gms/games/Player;->di()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->di()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    #v3=(Reference);
    invoke-static {v2, v3}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    move v0, v1

    #v0=(One);
    goto :goto_0
.end method

.method static synthetic a(Ljava/lang/Integer;)Z
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/PlayerEntity;->b(Ljava/lang/Integer;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public static b(Lcom/google/android/gms/games/Player;)Ljava/lang/String;
    .locals 4

    invoke-static {p0}, Lcom/google/android/gms/internal/g;->f(Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "PlayerId"

    #v1=(Reference);
    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->dh()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "DisplayName"

    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->getDisplayName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "IconImageUri"

    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->cW()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "HiResImageUri"

    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->cX()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "RetrievedTimestamp"

    invoke-interface {p0}, Lcom/google/android/gms/games/Player;->di()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/h;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic dg()Ljava/lang/Integer;
    .locals 1

    invoke-static {}, Lcom/google/android/gms/games/PlayerEntity;->gE()Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final bridge synthetic cP()Ljava/lang/Object;
    .locals 0

    return-object p0
.end method

.method public final cW()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tB:Landroid/net/Uri;

    #v0=(Reference);
    return-object v0
.end method

.method public final cX()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tC:Landroid/net/Uri;

    #v0=(Reference);
    return-object v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final dh()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tL:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final di()J
    .locals 2

    iget-wide v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tM:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p0, p1}, Lcom/google/android/gms/games/PlayerEntity;->a(Lcom/google/android/gms/games/Player;Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final getDisplayName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tw:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/PlayerEntity;->a(Lcom/google/android/gms/games/Player;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/PlayerEntity;->b(Lcom/google/android/gms/games/Player;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {p0}, Lcom/google/android/gms/games/PlayerEntity;->gF()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    invoke-static {p0, p1, p2}, Lcom/google/android/gms/games/d;->a(Lcom/google/android/gms/games/PlayerEntity;Landroid/os/Parcel;I)V

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Null);
    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tL:Ljava/lang/String;

    #v0=(Reference);
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tw:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tB:Landroid/net/Uri;

    if-nez v0, :cond_1

    move-object v0, v1

    :goto_1
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tC:Landroid/net/Uri;

    if-nez v0, :cond_2

    :goto_2
    #v1=(Reference);
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-wide v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tM:J

    #v0=(LongLo);v1=(LongHi);
    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    goto :goto_0

    :cond_1
    #v0=(Reference);v1=(Null);
    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tB:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_2
    iget-object v0, p0, Lcom/google/android/gms/games/PlayerEntity;->tC:Landroid/net/Uri;

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    goto :goto_2
.end method

*/}
