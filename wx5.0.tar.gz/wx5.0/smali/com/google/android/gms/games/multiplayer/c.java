package com.google.android.gms.games.multiplayer; class c {/*

.class final Lcom/google/android/gms/games/multiplayer/c;
.super Lcom/google/android/gms/games/multiplayer/d;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/games/multiplayer/d;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/games/multiplayer/c;->d(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final d(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/ParticipantEntity;
    .locals 11

    const/4 v9, 0x0

    #v9=(Null);
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v1, 0x1

    #v1=(One);
    invoke-static {}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->dg()Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v2}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->a(Ljava/lang/Integer;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_0

    const-class v2, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    #v2=(Reference);
    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->K(Ljava/lang/String;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_1

    :cond_0
    invoke-super {p0, p1}, Lcom/google/android/gms/games/multiplayer/d;->d(Landroid/os/Parcel;)Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    move-result-object v0

    :goto_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Reference);v10=(Conflicted);
    return-object v0

    :cond_1
    #v0=(Null);v2=(Boolean);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Null);v10=(Uninit);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v4

    #v4=(Reference);
    if-nez v4, :cond_3

    move-object v4, v0

    :goto_1
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    #v5=(Reference);
    if-nez v5, :cond_4

    move-object v5, v0

    :goto_2
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v6

    #v6=(Integer);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v8

    #v8=(Integer);
    if-lez v8, :cond_5

    move v8, v1

    :goto_3
    #v8=(Boolean);
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v10

    #v10=(Integer);
    if-lez v10, :cond_2

    move v9, v1

    :cond_2
    #v9=(Boolean);
    if-eqz v9, :cond_6

    sget-object v0, Lcom/google/android/gms/games/PlayerEntity;->tK:Lcom/google/android/gms/games/d;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/games/d;->b(Landroid/os/Parcel;)Lcom/google/android/gms/games/PlayerEntity;

    move-result-object v9

    :goto_4
    #v9=(Reference);
    new-instance v0, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    #v0=(UninitRef);
    const/4 v10, 0x7

    #v10=(PosByte);
    invoke-direct/range {v0 .. v10}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;-><init>(ILjava/lang/String;Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;ILjava/lang/String;ZLcom/google/android/gms/games/PlayerEntity;I)V

    #v0=(Reference);
    goto :goto_0

    :cond_3
    #v0=(Null);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Null);v10=(Uninit);
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    goto :goto_1

    :cond_4
    #v5=(Reference);
    invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    goto :goto_2

    :cond_5
    #v6=(Integer);v7=(Reference);v8=(Integer);
    move v8, v9

    #v8=(Null);
    goto :goto_3

    :cond_6
    #v8=(Boolean);v9=(Boolean);v10=(Integer);
    move-object v9, v0

    #v9=(Null);
    goto :goto_4
.end method

*/}
