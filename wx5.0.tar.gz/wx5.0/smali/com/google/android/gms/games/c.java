package com.google.android.gms.games; class c {/*

.class final Lcom/google/android/gms/games/c;
.super Lcom/google/android/gms/games/d;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/games/d;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final b(Landroid/os/Parcel;)Lcom/google/android/gms/games/PlayerEntity;
    .locals 8

    const/4 v5, 0x0

    #v5=(Null);
    invoke-static {}, Lcom/google/android/gms/games/PlayerEntity;->dg()Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/google/android/gms/games/PlayerEntity;->a(Ljava/lang/Integer;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    const-class v0, Lcom/google/android/gms/games/PlayerEntity;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/games/PlayerEntity;->K(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    :cond_0
    invoke-super {p0, p1}, Lcom/google/android/gms/games/d;->b(Landroid/os/Parcel;)Lcom/google/android/gms/games/PlayerEntity;

    move-result-object v0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Reference);v6=(Conflicted);v7=(Conflicted);
    return-object v0

    :cond_1
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Null);v6=(Uninit);v7=(Uninit);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    if-nez v0, :cond_2

    move-object v4, v5

    :goto_1
    #v4=(Reference);
    if-nez v1, :cond_3

    :goto_2
    #v5=(Reference);
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v6

    #v6=(LongLo);v7=(LongHi);
    new-instance v0, Lcom/google/android/gms/games/PlayerEntity;

    #v0=(UninitRef);
    const/4 v1, 0x1

    #v1=(One);
    invoke-direct/range {v0 .. v7}, Lcom/google/android/gms/games/PlayerEntity;-><init>(ILjava/lang/String;Ljava/lang/String;Landroid/net/Uri;Landroid/net/Uri;J)V

    #v0=(Reference);
    goto :goto_0

    :cond_2
    #v1=(Reference);v4=(Uninit);v5=(Null);v6=(Uninit);v7=(Uninit);
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    #v4=(Reference);
    goto :goto_1

    :cond_3
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    #v5=(Reference);
    goto :goto_2
.end method

.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/games/c;->b(Landroid/os/Parcel;)Lcom/google/android/gms/games/PlayerEntity;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

*/}
