package com.google.android.gms.internal; class cm {/*

.class public final Lcom/google/android/gms/internal/cm;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field yM:Z

.field private final yN:Ljava/util/concurrent/BlockingQueue;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/cm;->yM:Z

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/cm;->yN:Ljava/util/concurrent/BlockingQueue;

    return-void
.end method


# virtual methods
.method public final gw()Landroid/os/IBinder;
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/cm;->yM:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Boolean);
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/cm;->yM:Z

    iget-object v0, p0, Lcom/google/android/gms/internal/cm;->yN:Ljava/util/concurrent/BlockingQueue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/concurrent/BlockingQueue;->take()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/IBinder;

    return-object v0
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/cm;->yN:Ljava/util/concurrent/BlockingQueue;

    #v0=(Reference);
    invoke-interface {v0, p2}, Ljava/util/concurrent/BlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-void

    :catch_0
    move-exception v0

    #v0=(Reference);
    goto :goto_0
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    return-void
.end method

*/}
