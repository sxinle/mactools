package com.google.android.gms.internal; class fj {/*

.class public Lcom/google/android/gms/internal/fj;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final yG:Lcom/google/android/gms/internal/cl;


# instance fields
.field private final tu:I

.field private final yH:Z

.field private final yI:Ljava/util/ArrayList;

.field private final yJ:Ljava/util/ArrayList;

.field private final yK:Landroid/os/Bundle;

.field private final yL:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/cl;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/cl;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/fj;->yG:Lcom/google/android/gms/internal/cl;

    return-void
.end method

.method public constructor <init>(IZLjava/util/ArrayList;Ljava/util/ArrayList;Landroid/os/Bundle;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/fj;->tu:I

    iput-boolean p2, p0, Lcom/google/android/gms/internal/fj;->yH:Z

    iput-object p3, p0, Lcom/google/android/gms/internal/fj;->yI:Ljava/util/ArrayList;

    iput-object p4, p0, Lcom/google/android/gms/internal/fj;->yJ:Ljava/util/ArrayList;

    iput-object p5, p0, Lcom/google/android/gms/internal/fj;->yK:Landroid/os/Bundle;

    iput-boolean p6, p0, Lcom/google/android/gms/internal/fj;->yL:Z

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/fj;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    instance-of v1, p1, Lcom/google/android/gms/internal/fj;

    #v1=(Boolean);
    if-nez v1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Integer);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v1=(Boolean);v2=(Uninit);
    check-cast p1, Lcom/google/android/gms/internal/fj;

    iget v1, p0, Lcom/google/android/gms/internal/fj;->tu:I

    #v1=(Integer);
    iget v2, p1, Lcom/google/android/gms/internal/fj;->tu:I

    #v2=(Integer);
    if-ne v1, v2, :cond_0

    iget-boolean v1, p0, Lcom/google/android/gms/internal/fj;->yH:Z

    #v1=(Boolean);
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    #v1=(Reference);
    iget-boolean v2, p1, Lcom/google/android/gms/internal/fj;->yH:Z

    #v2=(Boolean);
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fj;->yI:Ljava/util/ArrayList;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fj;->yI:Ljava/util/ArrayList;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fj;->yJ:Ljava/util/ArrayList;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fj;->yJ:Ljava/util/ArrayList;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fj;->yK:Landroid/os/Bundle;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fj;->yK:Landroid/os/Bundle;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final gr()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/fj;->yH:Z

    #v0=(Boolean);
    return v0
.end method

.method public final gs()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fj;->yI:Ljava/util/ArrayList;

    #v0=(Reference);
    return-object v0
.end method

.method public final gt()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fj;->yJ:Ljava/util/ArrayList;

    #v0=(Reference);
    return-object v0
.end method

.method public final gu()Landroid/os/Bundle;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fj;->yK:Landroid/os/Bundle;

    #v0=(Reference);
    return-object v0
.end method

.method public final gv()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/fj;->yL:Z

    #v0=(Boolean);
    return v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v0, 0x5

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget v2, p0, Lcom/google/android/gms/internal/fj;->tu:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget-boolean v2, p0, Lcom/google/android/gms/internal/fj;->yH:Z

    #v2=(Boolean);
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/internal/fj;->yI:Ljava/util/ArrayList;

    aput-object v2, v0, v1

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/internal/fj;->yJ:Ljava/util/ArrayList;

    aput-object v2, v0, v1

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/internal/fj;->yK:Landroid/os/Bundle;

    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/cl;->a(Lcom/google/android/gms/internal/fj;Landroid/os/Parcel;)V

    return-void
.end method

*/}
