package com.google.android.gms.internal; class q {/*

.class public final Lcom/google/android/gms/internal/q;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/os/Parcel;IB)V
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method

.method public static a(Landroid/os/Parcel;ID)V
    .locals 1

    const/16 v0, 0x8

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    invoke-virtual {p0, p2, p3}, Landroid/os/Parcel;->writeDouble(D)V

    return-void
.end method

.method public static a(Landroid/os/Parcel;IF)V
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeFloat(F)V

    return-void
.end method

.method public static a(Landroid/os/Parcel;IJ)V
    .locals 1

    const/16 v0, 0x8

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    invoke-virtual {p0, p2, p3}, Landroid/os/Parcel;->writeLong(J)V

    return-void
.end method

.method public static a(Landroid/os/Parcel;ILandroid/os/Bundle;)V
    .locals 1

    if-nez p2, :cond_0

    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_0
    #v0=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;ILandroid/os/IBinder;)V
    .locals 1

    if-nez p2, :cond_0

    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_0
    #v0=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V
    .locals 1

    if-nez p2, :cond_1

    if-eqz p4, :cond_0

    const/4 v0, 0x0

    #v0=(Null);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    :cond_0
    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_1
    #v0=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-interface {p2, p0, p3}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;ILjava/lang/String;Z)V
    .locals 1

    if-nez p2, :cond_1

    if-eqz p3, :cond_0

    const/4 v0, 0x0

    #v0=(Null);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    :cond_0
    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_1
    #v0=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 5

    const/4 v2, 0x0

    #v2=(Null);
    if-nez p2, :cond_1

    if-eqz p3, :cond_0

    invoke-static {p0, p1, v2}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    :cond_1
    #v0=(Uninit);v1=(Uninit);v3=(Uninit);v4=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v3

    #v3=(Integer);
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {p0, v4}, Landroid/os/Parcel;->writeInt(I)V

    move v1, v2

    :goto_1
    #v0=(Conflicted);v1=(Integer);
    if-ge v1, v4, :cond_3

    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/os/Parcelable;

    if-nez v0, :cond_2

    invoke-virtual {p0, v2}, Landroid/os/Parcel;->writeInt(I)V

    :goto_2
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    :cond_2
    #v0=(Reference);
    invoke-static {p0, v0, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    goto :goto_2

    :cond_3
    #v0=(Conflicted);
    invoke-static {p0, v3}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;IZ)V
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    if-eqz p2, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    return-void

    :cond_0
    #v0=(PosByte);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;I[Ljava/lang/String;)V
    .locals 1

    if-nez p2, :cond_0

    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_0
    #v0=(Uninit);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;Landroid/os/Parcel;)V
    .locals 3

    if-nez p1, :cond_0

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);
    return-void

    :cond_0
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);
    const/4 v0, 0x2

    #v0=(PosByte);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataSize()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p0, p1, v1, v2}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method private static a(Landroid/os/Parcel;Landroid/os/Parcelable;I)V
    .locals 3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    #v1=(Integer);
    invoke-interface {p1, p0, p2}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    sub-int v0, v2, v1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {p0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    return-void
.end method

.method public static a(Landroid/os/Parcel;Ljava/util/List;)V
    .locals 2

    const/4 v1, 0x3

    #v1=(PosByte);
    if-nez p1, :cond_0

    const/4 v0, 0x0

    #v0=(Null);
    invoke-static {p0, v1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    :goto_0
    #v0=(Integer);
    return-void

    :cond_0
    #v0=(Uninit);
    invoke-static {p0, v1}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;S)V
    .locals 2

    const/4 v0, 0x3

    #v0=(PosByte);
    const/4 v1, 0x4

    #v1=(PosByte);
    invoke-static {p0, v0, v1}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method

.method public static a(Landroid/os/Parcel;[B)V
    .locals 1

    if-nez p1, :cond_0

    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_0
    #v0=(Uninit);
    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeByteArray([B)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;[Landroid/os/Parcelable;I)V
    .locals 5

    const/4 v1, 0x0

    #v1=(Null);
    if-nez p1, :cond_0

    :goto_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    :cond_0
    #v0=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    const/4 v0, 0x2

    #v0=(PosByte);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v2

    #v2=(Integer);
    array-length v3, p1

    #v3=(Integer);
    invoke-virtual {p0, v3}, Landroid/os/Parcel;->writeInt(I)V

    move v0, v1

    :goto_1
    #v0=(Integer);v4=(Conflicted);
    if-ge v0, v3, :cond_2

    aget-object v4, p1, v0

    #v4=(Null);
    if-nez v4, :cond_1

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1
    invoke-static {p0, v4, p2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    goto :goto_2

    :cond_2
    #v4=(Conflicted);
    invoke-static {p0, v2}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method private static b(Landroid/os/Parcel;II)V
    .locals 1

    const v0, 0xffff

    #v0=(Char);
    if-lt p2, v0, :cond_0

    const/high16 v0, -0x1

    #v0=(Integer);
    or-int/2addr v0, p1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    return-void

    :cond_0
    #v0=(Char);
    shl-int/lit8 v0, p2, 0x10

    #v0=(Integer);
    or-int/2addr v0, p1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0
.end method

.method public static b(Landroid/os/Parcel;Ljava/util/List;)V
    .locals 1

    if-nez p1, :cond_0

    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_0
    #v0=(Uninit);
    const/4 v0, 0x3

    #v0=(PosByte);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeList(Ljava/util/List;)V

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    goto :goto_0
.end method

.method public static c(Landroid/os/Parcel;II)V
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/q;->b(Landroid/os/Parcel;II)V

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method

.method public static g(Landroid/os/Parcel;)I
    .locals 1

    const/16 v0, 0x4f45

    #v0=(PosShort);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/q;->t(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method private static t(Landroid/os/Parcel;I)I
    .locals 1

    const/high16 v0, -0x1

    #v0=(Integer);
    or-int/2addr v0, p1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method private static u(Landroid/os/Parcel;I)V
    .locals 3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    #v0=(Integer);
    sub-int v1, v0, p1

    #v1=(Integer);
    add-int/lit8 v2, p1, -0x4

    #v2=(Integer);
    invoke-virtual {p0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    return-void
.end method

.method public static v(Landroid/os/Parcel;I)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/q;->u(Landroid/os/Parcel;I)V

    return-void
.end method

*/}
