package com.google.android.gms.internal; class cz {/*

.class public final Lcom/google/android/gms/internal/cz;
.super Ljava/lang/Object;


# direct methods
.method public static j(Ljava/lang/Object;)V
    .locals 2

    if-nez p0, :cond_0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    const-string v1, "null reference"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Uninit);v1=(Uninit);
    return-void
.end method

*/}
