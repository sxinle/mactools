package com.google.android.gms.internal; class cs {/*

.class public final Lcom/google/android/gms/internal/cs;
.super Ljava/lang/Object;


# instance fields
.field public uy:I

.field public final zg:Lcom/google/android/gms/internal/ct;

.field private zh:I

.field private zi:I

.field private zj:Ljava/lang/ref/WeakReference;

.field private zk:Ljava/lang/ref/WeakReference;

.field private zl:Ljava/lang/ref/WeakReference;

.field private zm:I

.field private zn:Z


# direct methods
.method private static a(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)Lcom/google/android/gms/internal/cu;
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    if-eqz p0, :cond_1

    instance-of v0, p0, Lcom/google/android/gms/internal/cu;

    #v0=(Boolean);
    if-eqz v0, :cond_0

    check-cast p0, Lcom/google/android/gms/internal/cu;

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->gz()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    :cond_0
    :goto_0
    new-instance v0, Lcom/google/android/gms/internal/cu;

    #v0=(UninitRef);
    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/internal/cu;-><init>(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    #v0=(Reference);
    return-object v0

    :cond_1
    #v0=(Null);
    move-object p0, v0

    #p0=(Null);
    goto :goto_0
.end method

.method private a(Landroid/graphics/drawable/Drawable;Z)V
    .locals 10

    const/4 v9, 0x3

    #v9=(PosByte);
    const/4 v8, 0x2

    #v8=(PosByte);
    const/4 v4, 0x1

    #v4=(One);
    const/4 v3, 0x0

    #v3=(Null);
    iget v0, p0, Lcom/google/android/gms/internal/cs;->uy:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Reference);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-void

    :pswitch_0
    #v0=(Integer);v1=(Uninit);v2=(Uninit);v3=(Null);v4=(One);v5=(Uninit);v6=(Uninit);v7=(Uninit);
    iget-object v0, p0, Lcom/google/android/gms/internal/cs;->zj:Ljava/lang/ref/WeakReference;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/common/images/a;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/cs;->zg:Lcom/google/android/gms/internal/ct;

    iget-object v0, v0, Lcom/google/android/gms/internal/ct;->uri:Landroid/net/Uri;

    goto :goto_0

    :pswitch_1
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/cs;->zk:Ljava/lang/ref/WeakReference;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-eqz v0, :cond_0

    if-nez p2, :cond_3

    :goto_1
    #v4=(Boolean);
    if-eqz v4, :cond_1

    instance-of v1, v0, Lcom/google/android/gms/internal/cy;

    #v1=(Boolean);
    if-eqz v1, :cond_1

    move-object v1, v0

    #v1=(Reference);
    check-cast v1, Lcom/google/android/gms/internal/cy;

    invoke-virtual {v1}, Lcom/google/android/gms/internal/cy;->gC()I

    move-result v1

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/cs;->zh:I

    #v2=(Integer);
    if-eqz v2, :cond_1

    iget v2, p0, Lcom/google/android/gms/internal/cs;->zh:I

    if-eq v1, v2, :cond_0

    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    invoke-direct {p0}, Lcom/google/android/gms/internal/cs;->gy()Z

    move-result v5

    #v5=(Boolean);
    if-eqz v5, :cond_d

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v1, p1}, Lcom/google/android/gms/internal/cs;->a(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)Lcom/google/android/gms/internal/cu;

    move-result-object v1

    :goto_2
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    instance-of v2, v0, Lcom/google/android/gms/internal/cy;

    #v2=(Boolean);
    if-eqz v2, :cond_2

    check-cast v0, Lcom/google/android/gms/internal/cy;

    if-eqz p2, :cond_4

    iget-object v2, p0, Lcom/google/android/gms/internal/cs;->zg:Lcom/google/android/gms/internal/ct;

    #v2=(Reference);
    iget-object v2, v2, Lcom/google/android/gms/internal/ct;->uri:Landroid/net/Uri;

    :goto_3
    invoke-virtual {v0, v2}, Lcom/google/android/gms/internal/cy;->b(Landroid/net/Uri;)V

    if-eqz v4, :cond_5

    iget v2, p0, Lcom/google/android/gms/internal/cs;->zh:I

    :goto_4
    #v2=(Integer);
    invoke-virtual {v0, v2}, Lcom/google/android/gms/internal/cy;->ag(I)V

    :cond_2
    if-eqz v5, :cond_0

    move-object v0, v1

    check-cast v0, Lcom/google/android/gms/internal/cu;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/cu;->gA()V

    goto :goto_0

    :cond_3
    #v1=(Uninit);v2=(Uninit);v4=(One);v5=(Uninit);
    move v4, v3

    #v4=(Null);
    goto :goto_1

    :cond_4
    #v1=(Reference);v2=(Boolean);v4=(Boolean);v5=(Boolean);
    const/4 v2, 0x0

    #v2=(Null);
    goto :goto_3

    :cond_5
    #v2=(Reference);
    move v2, v3

    #v2=(Null);
    goto :goto_4

    :pswitch_2
    #v0=(Integer);v1=(Uninit);v2=(Uninit);v4=(One);v5=(Uninit);
    iget-object v0, p0, Lcom/google/android/gms/internal/cs;->zl:Ljava/lang/ref/WeakReference;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    iget v6, p0, Lcom/google/android/gms/internal/cs;->zm:I

    #v6=(Integer);
    invoke-direct {p0}, Lcom/google/android/gms/internal/cs;->gy()Z

    move-result v7

    #v7=(Boolean);
    invoke-static {}, Lcom/google/android/gms/internal/ai;->ea()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_6

    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    move-result-object v1

    #v1=(Reference);
    move-object v2, v1

    :goto_5
    #v2=(Reference);
    aget-object v1, v2, v6

    #v1=(Null);
    if-eqz v7, :cond_c

    invoke-static {v1, p1}, Lcom/google/android/gms/internal/cs;->a(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)Lcom/google/android/gms/internal/cu;

    move-result-object v1

    :goto_6
    #v1=(Reference);
    if-nez v6, :cond_7

    move-object v5, v1

    :goto_7
    #v5=(Reference);
    if-ne v6, v4, :cond_8

    move-object v4, v1

    :goto_8
    #v4=(Reference);
    if-ne v6, v8, :cond_9

    move-object v3, v1

    :goto_9
    #v3=(Reference);
    if-ne v6, v9, :cond_a

    move-object v2, v1

    :goto_a
    invoke-static {}, Lcom/google/android/gms/internal/ai;->ea()Z

    move-result v6

    #v6=(Boolean);
    if-eqz v6, :cond_b

    invoke-virtual {v0, v5, v4, v3, v2}, Landroid/widget/TextView;->setCompoundDrawablesRelativeWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    :goto_b
    if-eqz v7, :cond_0

    move-object v0, v1

    check-cast v0, Lcom/google/android/gms/internal/cu;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/cu;->gA()V

    goto/16 :goto_0

    :cond_6
    #v1=(Boolean);v2=(Uninit);v3=(Null);v4=(One);v5=(Uninit);v6=(Integer);
    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    move-result-object v1

    #v1=(Reference);
    move-object v2, v1

    #v2=(Reference);
    goto :goto_5

    :cond_7
    aget-object v3, v2, v3

    move-object v5, v3

    #v5=(Null);
    goto :goto_7

    :cond_8
    #v5=(Reference);
    aget-object v3, v2, v4

    move-object v4, v3

    #v4=(Null);
    goto :goto_8

    :cond_9
    #v4=(Reference);
    aget-object v3, v2, v8

    goto :goto_9

    :cond_a
    #v3=(Reference);
    aget-object v2, v2, v9

    #v2=(Null);
    goto :goto_a

    :cond_b
    #v2=(Reference);v6=(Boolean);
    invoke-virtual {v0, v5, v4, v3, v2}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    goto :goto_b

    :cond_c
    #v1=(Null);v3=(Null);v4=(One);v5=(Uninit);v6=(Integer);
    move-object v1, p1

    #v1=(Reference);
    goto :goto_6

    :cond_d
    #v1=(Conflicted);v2=(Conflicted);v4=(Boolean);v5=(Boolean);v6=(Uninit);v7=(Uninit);
    move-object v1, p1

    #v1=(Reference);
    goto/16 :goto_2

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);v7=(Unknown);v8=(Unknown);v9=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method private gy()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/cs;->zn:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method


# virtual methods
.method public final a(Landroid/content/Context;Landroid/graphics/Bitmap;)V
    .locals 2

    invoke-static {p2}, Lcom/google/android/gms/internal/cz;->j(Ljava/lang/Object;)V

    new-instance v0, Landroid/graphics/drawable/BitmapDrawable;

    #v0=(UninitRef);
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, v1, p2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    #v0=(Reference);
    const/4 v1, 0x1

    #v1=(One);
    invoke-direct {p0, v0, v1}, Lcom/google/android/gms/internal/cs;->a(Landroid/graphics/drawable/Drawable;Z)V

    return-void
.end method

.method public final e(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x0

    #v0=(Null);
    iget v1, p0, Lcom/google/android/gms/internal/cs;->zh:I

    #v1=(Integer);
    if-eqz v1, :cond_0

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/cs;->zh:I

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    :cond_0
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {p0, v0, v1}, Lcom/google/android/gms/internal/cs;->a(Landroid/graphics/drawable/Drawable;Z)V

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    #v0=(Null);
    instance-of v2, p1, Lcom/google/android/gms/internal/cs;

    #v2=(Boolean);
    if-nez v2, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Integer);v3=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v2=(Boolean);v3=(Uninit);
    if-ne p0, p1, :cond_2

    move v0, v1

    #v0=(One);
    goto :goto_0

    :cond_2
    #v0=(Null);
    check-cast p1, Lcom/google/android/gms/internal/cs;

    invoke-virtual {p1}, Lcom/google/android/gms/internal/cs;->hashCode()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/cs;->hashCode()I

    move-result v3

    #v3=(Integer);
    if-ne v2, v3, :cond_0

    move v0, v1

    #v0=(One);
    goto :goto_0
.end method

.method public final hashCode()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/cs;->zi:I

    #v0=(Integer);
    return v0
.end method

*/}
