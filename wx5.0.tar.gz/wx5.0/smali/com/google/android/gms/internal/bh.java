package com.google.android.gms.internal; class bh {/*

.class public abstract Lcom/google/android/gms/internal/bh;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/google/android/gms/internal/bg;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    #p0=(Reference);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p0, p0, v0}, Lcom/google/android/gms/internal/bh;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5

    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x1

    #v3=(One);
    sparse-switch p1, :sswitch_data_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v0

    :goto_0
    #v0=(Boolean);v1=(Conflicted);v4=(Conflicted);
    return v0

    :sswitch_0
    #v0=(Uninit);v1=(Uninit);v4=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    move v0, v3

    #v0=(One);
    goto :goto_0

    :sswitch_1
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_0

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_0
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_1

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_1
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto :goto_0

    :sswitch_2
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_2

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Bundle;

    move-object v1, v0

    :goto_1
    #v0=(Conflicted);v1=(Reference);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_3

    sget-object v0, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/ParcelFileDescriptor;

    :goto_2
    invoke-virtual {p0, v4, v1, v0}, Lcom/google/android/gms/internal/bh;->a(ILandroid/os/Bundle;Landroid/os/ParcelFileDescriptor;)V

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto :goto_0

    :cond_2
    #v0=(Integer);v1=(Uninit);
    move-object v1, v2

    #v1=(Null);
    goto :goto_1

    :cond_3
    #v1=(Reference);
    move-object v0, v2

    #v0=(Null);
    goto :goto_2

    :sswitch_3
    #v0=(Uninit);v1=(Uninit);v4=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto :goto_0

    :sswitch_4
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_4

    sget-object v0, Lcom/google/android/gms/internal/l;->yR:Lcom/google/android/gms/internal/cr;

    #v0=(Reference);
    invoke-static {p2}, Lcom/google/android/gms/internal/cr;->l(Landroid/os/Parcel;)Lcom/google/android/gms/internal/l;

    :cond_4
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_5
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_5

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_5
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_6

    sget-object v0, Lcom/google/android/gms/internal/ax;->vl:Lcom/google/android/gms/internal/ac;

    #v0=(Reference);
    invoke-static {p2}, Lcom/google/android/gms/internal/ac;->h(Landroid/os/Parcel;)Lcom/google/android/gms/internal/ax;

    :cond_6
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_6
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_7

    sget-object v0, Lcom/google/android/gms/internal/l;->yR:Lcom/google/android/gms/internal/cr;

    #v0=(Reference);
    invoke-static {p2}, Lcom/google/android/gms/internal/cr;->l(Landroid/os/Parcel;)Lcom/google/android/gms/internal/l;

    :cond_7
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_7
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_8

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_8
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_8
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_9

    sget-object v0, Lcom/google/android/gms/internal/l;->yR:Lcom/google/android/gms/internal/cr;

    #v0=(Reference);
    invoke-static {p2}, Lcom/google/android/gms/internal/cr;->l(Landroid/os/Parcel;)Lcom/google/android/gms/internal/l;

    :cond_9
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_9
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_a

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_a
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_b

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_b
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_a
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_c

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_c
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_b
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_d

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_d
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_e

    sget-object v0, Lcom/google/android/gms/internal/en;->wp:Lcom/google/android/gms/internal/bt;

    #v0=(Reference);
    invoke-static {p2}, Lcom/google/android/gms/internal/bt;->i(Landroid/os/Parcel;)Lcom/google/android/gms/internal/en;

    :cond_e
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_c
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_f

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_f
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_d
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_10

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_10
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_11

    sget-object v0, Lcom/google/android/gms/internal/fh;->yx:Lcom/google/android/gms/internal/ck;

    #v0=(Reference);
    invoke-static {p2}, Lcom/google/android/gms/internal/ck;->j(Landroid/os/Parcel;)Lcom/google/android/gms/internal/fh;

    :cond_11
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_e
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_12

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_12
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_13

    sget-object v0, Lcom/google/android/gms/internal/fj;->yG:Lcom/google/android/gms/internal/cl;

    #v0=(Reference);
    invoke-static {p2}, Lcom/google/android/gms/internal/cl;->k(Landroid/os/Parcel;)Lcom/google/android/gms/internal/fj;

    :cond_13
    #v0=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_f
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_14

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_14
    #v0=(Conflicted);
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    :sswitch_10
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.plus.internal.IPlusCallbacks"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_15

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    :cond_15
    #v0=(Conflicted);
    sget-object v0, Lcom/google/android/gms/internal/ak;->ux:Lcom/google/android/gms/internal/s;

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    move v0, v3

    #v0=(One);
    goto/16 :goto_0

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);p3=(Unknown);p4=(Unknown);
    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x5 -> :sswitch_5
        0x6 -> :sswitch_6
        0x7 -> :sswitch_7
        0x8 -> :sswitch_8
        0x9 -> :sswitch_9
        0xa -> :sswitch_a
        0xb -> :sswitch_b
        0xc -> :sswitch_c
        0xd -> :sswitch_d
        0xe -> :sswitch_e
        0xf -> :sswitch_f
        0x10 -> :sswitch_10
        0x5f4e5446 -> :sswitch_0
    .end sparse-switch
.end method

*/}
