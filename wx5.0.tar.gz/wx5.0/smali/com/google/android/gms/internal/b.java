package com.google.android.gms.internal; class b {/*

.class public abstract Lcom/google/android/gms/internal/b;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/google/android/gms/internal/a;


# direct methods
.method public static b(Landroid/os/IBinder;)Lcom/google/android/gms/internal/a;
    .locals 2

    if-nez p0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Uninit);v1=(Uninit);
    const-string v0, "com.google.android.auth.IAuthManagerService"

    #v0=(Reference);
    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/google/android/gms/internal/a;

    #v1=(Boolean);
    if-eqz v1, :cond_1

    check-cast v0, Lcom/google/android/gms/internal/a;

    goto :goto_0

    :cond_1
    #v1=(Conflicted);
    new-instance v0, Lcom/google/android/gms/internal/c;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/c;-><init>(Landroid/os/IBinder;)V

    #v0=(Reference);
    goto :goto_0
.end method


# virtual methods
.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 4

    const/4 v1, 0x1

    #v1=(One);
    sparse-switch p1, :sswitch_data_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v0

    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    :sswitch_0
    #v0=(Uninit);v2=(Uninit);v3=(Uninit);
    const-string v0, "com.google.android.auth.IAuthManagerService"

    #v0=(Reference);
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    move v0, v1

    #v0=(One);
    goto :goto_0

    :sswitch_1
    #v0=(Uninit);
    const-string v0, "com.google.android.auth.IAuthManagerService"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_0

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    #v0=(Reference);
    invoke-interface {v0, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Bundle;

    :goto_1
    invoke-virtual {p0, v2, v3, v0}, Lcom/google/android/gms/internal/b;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    if-eqz v0, :cond_1

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {v0, p3, v1}, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel;I)V

    :goto_2
    move v0, v1

    #v0=(One);
    goto :goto_0

    :cond_0
    #v0=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_1

    :cond_1
    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_2

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);p3=(Unknown);p4=(Unknown);
    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x5f4e5446 -> :sswitch_0
    .end sparse-switch
.end method

*/}
