package com.google.android.gms.internal; class am {/*

.class public Lcom/google/android/gms/internal/am;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final uD:Lcom/google/android/gms/internal/u;


# instance fields
.field private final tu:I

.field private final uE:Lcom/google/android/gms/internal/ao;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/u;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/u;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/am;->uD:Lcom/google/android/gms/internal/u;

    return-void
.end method

.method constructor <init>(ILcom/google/android/gms/internal/ao;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/am;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/internal/am;->uE:Lcom/google/android/gms/internal/ao;

    return-void
.end method

.method private constructor <init>(Lcom/google/android/gms/internal/ao;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/google/android/gms/internal/am;->tu:I

    iput-object p1, p0, Lcom/google/android/gms/internal/am;->uE:Lcom/google/android/gms/internal/ao;

    return-void
.end method

.method public static a(Lcom/google/android/gms/internal/x;)Lcom/google/android/gms/internal/am;
    .locals 2

    instance-of v0, p0, Lcom/google/android/gms/internal/ao;

    #v0=(Boolean);
    if-eqz v0, :cond_0

    new-instance v0, Lcom/google/android/gms/internal/am;

    #v0=(UninitRef);
    check-cast p0, Lcom/google/android/gms/internal/ao;

    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/am;-><init>(Lcom/google/android/gms/internal/ao;)V

    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Boolean);
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    const-string v1, "Unsupported safe parcelable field converter class."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method


# virtual methods
.method final dC()Lcom/google/android/gms/internal/ao;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/am;->uE:Lcom/google/android/gms/internal/ao;

    #v0=(Reference);
    return-object v0
.end method

.method public final dD()Lcom/google/android/gms/internal/x;
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/am;->uE:Lcom/google/android/gms/internal/ao;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/am;->uE:Lcom/google/android/gms/internal/ao;

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "There was no converter wrapped in this ConverterWrapper."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method public describeContents()I
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/am;->uD:Lcom/google/android/gms/internal/u;

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/am;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/am;->uD:Lcom/google/android/gms/internal/u;

    #v0=(Reference);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/internal/u;->a(Lcom/google/android/gms/internal/am;Landroid/os/Parcel;I)V

    return-void
.end method

*/}
