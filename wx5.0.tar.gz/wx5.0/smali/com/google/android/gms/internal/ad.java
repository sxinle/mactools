package com.google.android.gms.internal; class ad {/*

.class public final Lcom/google/android/gms/internal/ad;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/StringBuilder;[D)V
    .locals 4

    array-length v1, p1

    #v1=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);
    if-ge v0, v1, :cond_1

    if-eqz v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    aget-wide v2, p1, v0

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    #v2=(Conflicted);v3=(Conflicted);
    return-void
.end method

.method public static a(Ljava/lang/StringBuilder;[F)V
    .locals 3

    array-length v1, p1

    #v1=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);
    if-ge v0, v1, :cond_1

    if-eqz v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    aget v2, p1, v0

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->toString(F)Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    #v2=(Conflicted);
    return-void
.end method

.method public static a(Ljava/lang/StringBuilder;[J)V
    .locals 4

    array-length v1, p1

    #v1=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);
    if-ge v0, v1, :cond_1

    if-eqz v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    aget-wide v2, p1, v0

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    #v2=(Conflicted);v3=(Conflicted);
    return-void
.end method

.method public static a(Ljava/lang/StringBuilder;[Ljava/lang/Object;)V
    .locals 3

    array-length v1, p1

    #v1=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);
    if-ge v0, v1, :cond_1

    if-eqz v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    aget-object v2, p1, v0

    #v2=(Null);
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    #v2=(Conflicted);
    return-void
.end method

.method public static a(Ljava/lang/StringBuilder;[Ljava/lang/String;)V
    .locals 4

    array-length v1, p1

    #v1=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);
    if-ge v0, v1, :cond_1

    if-eqz v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    const-string v2, "\""

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    aget-object v3, p1, v0

    #v3=(Null);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "\""

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    #v2=(Conflicted);v3=(Conflicted);
    return-void
.end method

.method public static a(Ljava/lang/StringBuilder;[Z)V
    .locals 3

    array-length v1, p1

    #v1=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);
    if-ge v0, v1, :cond_1

    if-eqz v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    aget-boolean v2, p1, v0

    #v2=(Boolean);
    invoke-static {v2}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    #v2=(Conflicted);
    return-void
.end method

*/}
