package com.google.android.gms.internal; class cv {/*

.class final Lcom/google/android/gms/internal/cv;
.super Landroid/graphics/drawable/Drawable;


# static fields
.field private static final zE:Lcom/google/android/gms/internal/cv;

.field private static final zF:Lcom/google/android/gms/internal/cw;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/google/android/gms/internal/cv;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/cv;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/cv;->zE:Lcom/google/android/gms/internal/cv;

    new-instance v0, Lcom/google/android/gms/internal/cw;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/cw;-><init>(B)V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/cv;->zF:Lcom/google/android/gms/internal/cw;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static synthetic gB()Lcom/google/android/gms/internal/cv;
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/cv;->zE:Lcom/google/android/gms/internal/cv;

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .locals 0

    return-void
.end method

.method public final getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/cv;->zF:Lcom/google/android/gms/internal/cw;

    #v0=(Reference);
    return-object v0
.end method

.method public final getOpacity()I
    .locals 1

    const/4 v0, -0x2

    #v0=(Byte);
    return v0
.end method

.method public final setAlpha(I)V
    .locals 0

    return-void
.end method

.method public final setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0

    return-void
.end method

*/}
