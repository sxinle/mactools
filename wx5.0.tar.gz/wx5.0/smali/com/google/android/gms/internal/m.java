package com.google.android.gms.internal; class m {/*

.class public final Lcom/google/android/gms/internal/m;
.super Ljava/lang/Exception;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    #p0=(Reference);
    return-void
.end method

*/}
