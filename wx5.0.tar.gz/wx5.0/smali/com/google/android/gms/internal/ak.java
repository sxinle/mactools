package com.google.android.gms.internal; class ak {/*

.class public final Lcom/google/android/gms/internal/ak;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final ux:Lcom/google/android/gms/internal/s;


# instance fields
.field private final tu:I

.field private final tw:Ljava/lang/String;

.field private final uA:Ljava/lang/String;

.field private final uB:Ljava/lang/String;

.field private final uC:Ljava/lang/String;

.field private final uy:I

.field private final uz:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/s;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/s;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/ak;->ux:Lcom/google/android/gms/internal/s;

    return-void
.end method

.method public constructor <init>(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/ak;->tu:I

    iput p2, p0, Lcom/google/android/gms/internal/ak;->uy:I

    iput p3, p0, Lcom/google/android/gms/internal/ak;->uz:I

    iput-object p4, p0, Lcom/google/android/gms/internal/ak;->uA:Ljava/lang/String;

    iput-object p5, p0, Lcom/google/android/gms/internal/ak;->uB:Ljava/lang/String;

    iput-object p6, p0, Lcom/google/android/gms/internal/ak;->tw:Ljava/lang/String;

    iput-object p7, p0, Lcom/google/android/gms/internal/ak;->uC:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final dA()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ak;->uB:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final dB()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ak;->uC:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/ak;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final dy()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/ak;->uz:I

    #v0=(Integer);
    return v0
.end method

.method public final dz()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ak;->uA:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    instance-of v1, p1, Lcom/google/android/gms/internal/ak;

    #v1=(Boolean);
    if-nez v1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Integer);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v1=(Boolean);v2=(Uninit);
    check-cast p1, Lcom/google/android/gms/internal/ak;

    iget v1, p0, Lcom/google/android/gms/internal/ak;->tu:I

    #v1=(Integer);
    iget v2, p1, Lcom/google/android/gms/internal/ak;->tu:I

    #v2=(Integer);
    if-ne v1, v2, :cond_0

    iget v1, p0, Lcom/google/android/gms/internal/ak;->uy:I

    iget v2, p1, Lcom/google/android/gms/internal/ak;->uy:I

    if-ne v1, v2, :cond_0

    iget v1, p0, Lcom/google/android/gms/internal/ak;->uz:I

    iget v2, p1, Lcom/google/android/gms/internal/ak;->uz:I

    if-ne v1, v2, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ak;->uA:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ak;->uA:Ljava/lang/String;

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ak;->uB:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ak;->uB:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final getDisplayName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ak;->tw:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getType()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/ak;->uy:I

    #v0=(Integer);
    return v0
.end method

.method public final hashCode()I
    .locals 3

    const/4 v0, 0x5

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget v2, p0, Lcom/google/android/gms/internal/ak;->tu:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/internal/ak;->uy:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget v2, p0, Lcom/google/android/gms/internal/ak;->uz:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/internal/ak;->uA:Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/internal/ak;->uB:Ljava/lang/String;

    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    #v4=(PosByte);
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v1, 0x1

    #v1=(One);
    iget v0, p0, Lcom/google/android/gms/internal/ak;->uy:I

    #v0=(Integer);
    if-ne v0, v4, :cond_0

    move v0, v1

    :goto_0
    #v0=(Boolean);
    if-eqz v0, :cond_1

    const-string v0, "Person [%s] %s"

    #v0=(Reference);
    new-array v3, v4, [Ljava/lang/Object;

    #v3=(Reference);
    iget-object v4, p0, Lcom/google/android/gms/internal/ak;->uB:Ljava/lang/String;

    #v4=(Reference);
    aput-object v4, v3, v2

    iget-object v2, p0, Lcom/google/android/gms/internal/ak;->tw:Ljava/lang/String;

    #v2=(Reference);
    aput-object v2, v3, v1

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    :goto_1
    return-object v0

    :cond_0
    #v0=(Integer);v2=(Null);v3=(Uninit);v4=(PosByte);
    move v0, v2

    #v0=(Null);
    goto :goto_0

    :cond_1
    #v0=(Boolean);
    iget v0, p0, Lcom/google/android/gms/internal/ak;->uy:I

    #v0=(Integer);
    if-ne v0, v1, :cond_2

    iget v0, p0, Lcom/google/android/gms/internal/ak;->uz:I

    const/4 v3, -0x1

    #v3=(Byte);
    if-ne v0, v3, :cond_2

    move v0, v1

    :goto_2
    #v0=(Boolean);v3=(Conflicted);
    if-eqz v0, :cond_3

    const-string v0, "Circle [%s] %s"

    #v0=(Reference);
    new-array v3, v4, [Ljava/lang/Object;

    #v3=(Reference);
    iget-object v4, p0, Lcom/google/android/gms/internal/ak;->uA:Ljava/lang/String;

    #v4=(Reference);
    aput-object v4, v3, v2

    iget-object v2, p0, Lcom/google/android/gms/internal/ak;->tw:Ljava/lang/String;

    #v2=(Reference);
    aput-object v2, v3, v1

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_2
    #v0=(Integer);v2=(Null);v3=(Conflicted);v4=(PosByte);
    move v0, v2

    #v0=(Null);
    goto :goto_2

    :cond_3
    #v0=(Boolean);
    const-string v0, "Group [%s] %s"

    #v0=(Reference);
    new-array v3, v4, [Ljava/lang/Object;

    #v3=(Reference);
    iget-object v4, p0, Lcom/google/android/gms/internal/ak;->uA:Ljava/lang/String;

    #v4=(Reference);
    aput-object v4, v3, v2

    iget-object v2, p0, Lcom/google/android/gms/internal/ak;->tw:Ljava/lang/String;

    #v2=(Reference);
    aput-object v2, v3, v1

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/s;->a(Lcom/google/android/gms/internal/ak;Landroid/os/Parcel;)V

    return-void
.end method

*/}
