package com.google.android.gms.internal; class ax {/*

.class public Lcom/google/android/gms/internal/ax;
.super Lcom/google/android/gms/internal/ar;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final vl:Lcom/google/android/gms/internal/ac;


# instance fields
.field private final tu:I

.field private final uU:Lcom/google/android/gms/internal/au;

.field private final vg:Landroid/os/Parcel;

.field private final vh:I

.field private final vi:Ljava/lang/String;

.field private vj:I

.field private vk:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/ac;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/ac;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/ax;->vl:Lcom/google/android/gms/internal/ac;

    return-void
.end method

.method constructor <init>(ILandroid/os/Parcel;Lcom/google/android/gms/internal/au;)V
    .locals 2

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-direct {p0}, Lcom/google/android/gms/internal/ar;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/ax;->tu:I

    invoke-static {p2}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/os/Parcel;

    iput-object v0, p0, Lcom/google/android/gms/internal/ax;->vg:Landroid/os/Parcel;

    iput v1, p0, Lcom/google/android/gms/internal/ax;->vh:I

    iput-object p3, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/google/android/gms/internal/ax;->vi:Ljava/lang/String;

    :goto_0
    #v0=(Reference);
    iput v1, p0, Lcom/google/android/gms/internal/ax;->vj:I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/au;->dV()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/google/android/gms/internal/ax;->vi:Ljava/lang/String;

    goto :goto_0
.end method

.method private static a(Landroid/os/Bundle;)Ljava/util/HashMap;
    .locals 4

    new-instance v1, Ljava/util/HashMap;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    #v1=(Reference);
    invoke-virtual {p0}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    #v2=(Reference);v3=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/String;

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v1, v0, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    #v0=(Boolean);v3=(Conflicted);
    return-object v1
.end method

.method private static a(Ljava/lang/StringBuilder;ILjava/lang/Object;)V
    .locals 3

    packed-switch p1, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Unknown type = "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_0
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :pswitch_1
    #v0=(Uninit);v1=(Uninit);
    const-string v0, "\""

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v1}, Lcom/google/android/gms/internal/ag;->O(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :pswitch_2
    #v0=(Uninit);v1=(Uninit);
    const-string v0, "\""

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    check-cast p2, [B

    invoke-static {p2}, Lcom/google/android/gms/internal/ae;->a([B)Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :pswitch_3
    #v0=(Uninit);v1=(Uninit);
    const-string v0, "\""

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    check-cast p2, [B

    invoke-static {p2}, Lcom/google/android/gms/internal/ae;->b([B)Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\""

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :pswitch_4
    #v0=(Uninit);v1=(Uninit);
    check-cast p2, Ljava/util/HashMap;

    invoke-static {p0, p2}, Lcom/google/android/gms/internal/ah;->a(Ljava/lang/StringBuilder;Ljava/util/HashMap;)V

    goto :goto_0

    :pswitch_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    const-string v1, "Method does not accept concrete type."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method

.method private a(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Landroid/os/Parcel;I)V
    .locals 7

    const/4 v0, 0x0

    #v0=(Null);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-virtual {p2}, Lcom/google/android/gms/internal/ar$a;->dL()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_a

    const-string v1, "["

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/google/android/gms/internal/ar$a;->dK()I

    move-result v1

    #v1=(Integer);
    packed-switch v1, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "Unknown field type out."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_0
    #v0=(Null);v1=(Integer);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v3

    #v3=(Integer);
    if-nez v1, :cond_1

    :goto_0
    #v0=(Reference);
    array-length v1, v0

    :goto_1
    #v2=(Integer);v3=(Conflicted);
    if-ge v2, v1, :cond_2

    if-eqz v2, :cond_0

    const-string v3, ","

    #v3=(Reference);
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v3=(Conflicted);
    aget v3, v0, v2

    #v3=(Integer);
    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    #v0=(Null);v2=(Null);v3=(Integer);
    invoke-virtual {p3}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v3

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0

    :pswitch_1
    #v0=(Null);v3=(Uninit);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v3

    #v3=(Integer);
    if-nez v1, :cond_3

    :goto_2
    #v0=(Reference);v2=(Integer);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/ad;->a(Ljava/lang/StringBuilder;[Ljava/lang/Object;)V

    :cond_2
    :goto_3
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);
    const-string v0, "]"

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_4
    #v0=(Conflicted);
    return-void

    :cond_3
    #v0=(Null);v1=(Integer);v2=(Null);v3=(Integer);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    invoke-virtual {p3}, Landroid/os/Parcel;->readInt()I

    move-result v4

    #v4=(Integer);
    new-array v0, v4, [Ljava/math/BigInteger;

    :goto_5
    #v0=(Reference);v2=(Integer);v5=(Conflicted);v6=(Conflicted);
    if-ge v2, v4, :cond_4

    new-instance v5, Ljava/math/BigInteger;

    #v5=(UninitRef);
    invoke-virtual {p3}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v6

    #v6=(Reference);
    invoke-direct {v5, v6}, Ljava/math/BigInteger;-><init>([B)V

    #v5=(Reference);
    aput-object v5, v0, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_4
    #v5=(Conflicted);v6=(Conflicted);
    add-int/2addr v1, v3

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_2

    :pswitch_2
    #v0=(Null);v2=(Null);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_5

    :goto_6
    #v0=(Reference);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/ad;->a(Ljava/lang/StringBuilder;[J)V

    goto :goto_3

    :cond_5
    #v0=(Null);
    invoke-virtual {p3}, Landroid/os/Parcel;->createLongArray()[J

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_6

    :pswitch_3
    #v0=(Null);v2=(Null);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_6

    :goto_7
    #v0=(Reference);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/ad;->a(Ljava/lang/StringBuilder;[F)V

    goto :goto_3

    :cond_6
    #v0=(Null);
    invoke-virtual {p3}, Landroid/os/Parcel;->createFloatArray()[F

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_7

    :pswitch_4
    #v0=(Null);v2=(Null);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_7

    :goto_8
    #v0=(Reference);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/ad;->a(Ljava/lang/StringBuilder;[D)V

    goto :goto_3

    :cond_7
    #v0=(Null);
    invoke-virtual {p3}, Landroid/os/Parcel;->createDoubleArray()[D

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_8

    :pswitch_5
    #v0=(Null);v2=(Null);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->p(Landroid/os/Parcel;I)[Ljava/math/BigDecimal;

    move-result-object v0

    #v0=(Reference);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/ad;->a(Ljava/lang/StringBuilder;[Ljava/lang/Object;)V

    goto :goto_3

    :pswitch_6
    #v0=(Null);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_8

    :goto_9
    #v0=(Reference);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/ad;->a(Ljava/lang/StringBuilder;[Z)V

    goto :goto_3

    :cond_8
    #v0=(Null);
    invoke-virtual {p3}, Landroid/os/Parcel;->createBooleanArray()[Z

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_9

    :pswitch_7
    #v0=(Null);v2=(Null);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->q(Landroid/os/Parcel;I)[Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/ad;->a(Ljava/lang/StringBuilder;[Ljava/lang/String;)V

    goto/16 :goto_3

    :pswitch_8
    #v0=(Null);
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    #v0=(UninitRef);
    const-string v1, "List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_9
    #v0=(Null);v1=(Integer);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->s(Landroid/os/Parcel;I)[Landroid/os/Parcel;

    move-result-object v1

    #v1=(Reference);
    array-length v3, v1

    #v3=(Integer);
    move v0, v2

    :goto_a
    #v0=(Integer);v4=(Conflicted);v5=(Conflicted);
    if-ge v0, v3, :cond_2

    if-lez v0, :cond_9

    const-string v4, ","

    #v4=(Reference);
    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_9
    #v4=(Conflicted);
    aget-object v4, v1, v0

    #v4=(Null);
    invoke-virtual {v4, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    invoke-virtual {p2}, Lcom/google/android/gms/internal/ar$a;->dS()Ljava/util/HashMap;

    move-result-object v4

    #v4=(Reference);
    aget-object v5, v1, v0

    #v5=(Null);
    invoke-direct {p0, p1, v4, v5}, Lcom/google/android/gms/internal/ax;->a(Ljava/lang/StringBuilder;Ljava/util/HashMap;Landroid/os/Parcel;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :cond_a
    #v0=(Null);v1=(Boolean);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-virtual {p2}, Lcom/google/android/gms/internal/ar$a;->dK()I

    move-result v0

    #v0=(Integer);
    packed-switch v0, :pswitch_data_1

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "Unknown field type out"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_a
    #v0=(Integer);v1=(Boolean);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_b
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->h(Landroid/os/Parcel;I)Ljava/math/BigInteger;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_c
    #v0=(Integer);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->g(Landroid/os/Parcel;I)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_d
    #v0=(Integer);v1=(Boolean);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v0

    #v0=(Float);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_e
    #v0=(Integer);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->j(Landroid/os/Parcel;I)D

    move-result-wide v0

    #v0=(DoubleLo);v1=(DoubleHi);
    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_f
    #v0=(Integer);v1=(Boolean);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->k(Landroid/os/Parcel;I)Ljava/math/BigDecimal;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_10
    #v0=(Integer);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v0

    #v0=(Boolean);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_11
    #v0=(Integer);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "\""

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v0}, Lcom/google/android/gms/internal/ag;->O(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_12
    #v0=(Integer);v1=(Boolean);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->o(Landroid/os/Parcel;I)[B

    move-result-object v0

    #v0=(Reference);
    const-string v1, "\""

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v0}, Lcom/google/android/gms/internal/ae;->a([B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_13
    #v0=(Integer);v1=(Boolean);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->o(Landroid/os/Parcel;I)[B

    move-result-object v0

    #v0=(Reference);
    const-string v1, "\""

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {v0}, Lcom/google/android/gms/internal/ae;->b([B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\""

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_14
    #v0=(Integer);v1=(Boolean);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->n(Landroid/os/Parcel;I)Landroid/os/Bundle;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v1

    #v1=(Reference);
    invoke-interface {v1}, Ljava/util/Set;->size()I

    const-string v0, "{"

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x1

    #v0=(One);
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    #v4=(Reference);
    move v1, v0

    :goto_b
    #v0=(Conflicted);v1=(Boolean);v5=(Conflicted);
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/String;

    if-nez v1, :cond_b

    const-string v1, ","

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_b
    #v1=(Conflicted);
    const-string v1, "\""

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, "\""

    #v5=(Reference);
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\""

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v3, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/internal/ag;->O(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move v1, v2

    #v1=(Null);
    goto :goto_b

    :cond_c
    #v0=(Boolean);v1=(Boolean);v5=(Conflicted);
    const-string v0, "}"

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_4

    :pswitch_15
    #v0=(Integer);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-static {p3, p4}, Lcom/google/android/gms/internal/o;->r(Landroid/os/Parcel;I)Landroid/os/Parcel;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    invoke-virtual {p2}, Lcom/google/android/gms/internal/ar$a;->dS()Ljava/util/HashMap;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {p0, p1, v1, v0}, Lcom/google/android/gms/internal/ax;->a(Ljava/lang/StringBuilder;Ljava/util/HashMap;Landroid/os/Parcel;)V

    goto/16 :goto_4

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);p3=(Unknown);p4=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_8
        :pswitch_8
        :pswitch_9
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_f
        :pswitch_10
        :pswitch_11
        :pswitch_12
        :pswitch_13
        :pswitch_14
        :pswitch_15
    .end packed-switch
.end method

.method private a(Ljava/lang/StringBuilder;Ljava/util/HashMap;Landroid/os/Parcel;)V
    .locals 6

    new-instance v2, Ljava/util/HashMap;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    #v2=(Reference);
    invoke-virtual {p2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    #v1=(Conflicted);v3=(Reference);
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Lcom/google/android/gms/internal/ar$a;

    invoke-virtual {v1}, Lcom/google/android/gms/internal/ar$a;->dN()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v2, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    #v0=(Boolean);v1=(Conflicted);
    const/16 v0, 0x7b

    #v0=(PosByte);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {p3}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v3

    #v3=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :cond_1
    :goto_1
    #v0=(Conflicted);v1=(Boolean);v4=(Conflicted);v5=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    #v0=(Integer);
    if-ge v0, v3, :cond_4

    invoke-virtual {p3}, Landroid/os/Parcel;->readInt()I

    move-result v4

    #v4=(Integer);
    const v0, 0xffff

    #v0=(Char);
    and-int/2addr v0, v4

    #v0=(Integer);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    if-eqz v0, :cond_1

    if-eqz v1, :cond_2

    const-string v1, ","

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    #v1=(Conflicted);
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Ljava/lang/String;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/ar$a;

    const-string v5, "\""

    #v5=(Reference);
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, "\":"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/ar$a;->dQ()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/ar$a;->dK()I

    move-result v1

    #v1=(Integer);
    packed-switch v1, :pswitch_data_0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Unknown field out type = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v0}, Lcom/google/android/gms/internal/ar$a;->dK()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    throw v1

    :pswitch_0
    #v1=(Integer);v3=(Integer);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    :goto_2
    #v1=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    const/4 v0, 0x1

    #v0=(One);
    move v1, v0

    #v1=(One);
    goto :goto_1

    :pswitch_1
    #v0=(Reference);v1=(Integer);v4=(Integer);v5=(Reference);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->h(Landroid/os/Parcel;I)Ljava/math/BigInteger;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_2
    #v1=(Integer);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->g(Landroid/os/Parcel;I)J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_3
    #v1=(Integer);v4=(Integer);v5=(Reference);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v1

    #v1=(Float);
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_4
    #v1=(Integer);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->j(Landroid/os/Parcel;I)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_5
    #v1=(Integer);v4=(Integer);v5=(Reference);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->k(Landroid/os/Parcel;I)Ljava/math/BigDecimal;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_6
    #v1=(Integer);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v1

    #v1=(Boolean);
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_7
    #v1=(Integer);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_8
    #v1=(Integer);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->o(Landroid/os/Parcel;I)[B

    move-result-object v1

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto :goto_2

    :pswitch_9
    #v1=(Integer);
    invoke-static {p3, v4}, Lcom/google/android/gms/internal/o;->n(Landroid/os/Parcel;I)Landroid/os/Bundle;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v1}, Lcom/google/android/gms/internal/ax;->a(Landroid/os/Bundle;)Ljava/util/HashMap;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/google/android/gms/internal/ax;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/internal/ax;->b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto/16 :goto_2

    :pswitch_a
    #v1=(Integer);
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    const-string v1, "Method does not accept concrete type."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_3
    #v1=(Boolean);
    invoke-direct {p0, p1, v0, p3, v4}, Lcom/google/android/gms/internal/ax;->a(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Landroid/os/Parcel;I)V

    goto/16 :goto_2

    :cond_4
    #v0=(Integer);v4=(Conflicted);v5=(Conflicted);
    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    if-eq v0, v3, :cond_5

    new-instance v0, Lcom/google/android/gms/internal/p;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Overread allowed size end="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p3}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v0=(Reference);
    throw v0

    :cond_5
    #v0=(Integer);v1=(Boolean);
    const/16 v0, 0x7d

    #v0=(PosByte);
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    return-void

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);p3=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_8
        :pswitch_9
        :pswitch_a
    .end packed-switch
.end method

.method private static b(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V
    .locals 4

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dJ()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_2

    check-cast p2, Ljava/util/ArrayList;

    const-string v0, "["

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    #v1=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);
    if-ge v0, v1, :cond_1

    if-eqz v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dI()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p0, v2, v3}, Lcom/google/android/gms/internal/ax;->a(Ljava/lang/StringBuilder;ILjava/lang/Object;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    #v2=(Conflicted);v3=(Conflicted);
    const-string v0, "]"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :cond_2
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dI()I

    move-result v0

    #v0=(Integer);
    invoke-static {p0, v0, p2}, Lcom/google/android/gms/internal/ax;->a(Ljava/lang/StringBuilder;ILjava/lang/Object;)V

    goto :goto_1
.end method


# virtual methods
.method public final dF()Ljava/util/HashMap;
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    #v0=(Reference);
    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v1=(Conflicted);
    return-object v0

    :cond_0
    #v1=(Uninit);
    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    iget-object v1, p0, Lcom/google/android/gms/internal/ax;->vi:Ljava/lang/String;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/au;->N(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v0

    goto :goto_0
.end method

.method protected final dG()Ljava/lang/Object;
    .locals 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    #v0=(UninitRef);
    const-string v1, "Converting to JSON does not require this method."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method protected final dH()Z
    .locals 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    #v0=(UninitRef);
    const-string v1, "Converting to JSON does not require this method."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method public final dX()Landroid/os/Parcel;
    .locals 2

    iget v0, p0, Lcom/google/android/gms/internal/ax;->vj:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    :goto_0
    #v1=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->vg:Landroid/os/Parcel;

    #v0=(Reference);
    return-object v0

    :pswitch_0
    #v0=(Integer);v1=(Uninit);
    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->vg:Landroid/os/Parcel;

    #v0=(Reference);
    invoke-static {v0}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/internal/ax;->vk:I

    :pswitch_1
    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->vg:Landroid/os/Parcel;

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/ax;->vk:I

    #v1=(Integer);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    const/4 v0, 0x2

    #v0=(PosByte);
    iput v0, p0, Lcom/google/android/gms/internal/ax;->vj:I

    goto :goto_0

    #v0=(Unknown);v1=(Unknown);p0=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method final dY()Lcom/google/android/gms/internal/au;
    .locals 3

    iget v0, p0, Lcom/google/android/gms/internal/ax;->vh:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Invalid creation type: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget v2, p0, Lcom/google/android/gms/internal/ax;->vh:I

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_0
    #v0=(Integer);v1=(Uninit);v2=(Uninit);
    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :pswitch_1
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    #v0=(Reference);
    goto :goto_0

    :pswitch_2
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    #v0=(Reference);
    goto :goto_0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method public describeContents()I
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/ax;->vl:Lcom/google/android/gms/internal/ac;

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/ax;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    #v0=(Reference);
    const-string v1, "Cannot convert to JSON on client side."

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/i;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lcom/google/android/gms/internal/ax;->dX()Landroid/os/Parcel;

    move-result-object v0

    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const/16 v2, 0x64

    #v2=(PosByte);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/google/android/gms/internal/ax;->uU:Lcom/google/android/gms/internal/au;

    #v2=(Reference);
    iget-object v3, p0, Lcom/google/android/gms/internal/ax;->vi:Ljava/lang/String;

    #v3=(Reference);
    invoke-virtual {v2, v3}, Lcom/google/android/gms/internal/au;->N(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v2

    invoke-direct {p0, v1, v2, v0}, Lcom/google/android/gms/internal/ax;->a(Ljava/lang/StringBuilder;Ljava/util/HashMap;Landroid/os/Parcel;)V

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/ax;->vl:Lcom/google/android/gms/internal/ac;

    #v0=(Reference);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/internal/ac;->a(Lcom/google/android/gms/internal/ax;Landroid/os/Parcel;I)V

    return-void
.end method

*/}
