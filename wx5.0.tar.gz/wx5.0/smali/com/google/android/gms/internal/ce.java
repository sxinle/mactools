package com.google.android.gms.internal; class ce {/*

.class public final Lcom/google/android/gms/internal/ce;
.super Lcom/google/android/gms/internal/co;

# interfaces
.implements Lcom/google/android/gms/games/multiplayer/Invitation;


# instance fields
.field private final tT:Ljava/util/ArrayList;

.field private final vr:Lcom/google/android/gms/games/Game;

.field private final vs:Lcom/google/android/gms/internal/cf;


# direct methods
.method private ed()Lcom/google/android/gms/games/multiplayer/Invitation;
    .locals 1

    new-instance v0, Lcom/google/android/gms/games/multiplayer/InvitationEntity;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;-><init>(Lcom/google/android/gms/games/multiplayer/Invitation;)V

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final synthetic cP()Ljava/lang/Object;
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/ce;->ed()Lcom/google/android/gms/games/multiplayer/Invitation;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final dj()Lcom/google/android/gms/games/Game;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ce;->vr:Lcom/google/android/gms/games/Game;

    #v0=(Reference);
    return-object v0
.end method

.method public final dk()Ljava/lang/String;
    .locals 1

    const-string v0, "external_invitation_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ce;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final dl()Lcom/google/android/gms/games/multiplayer/Participant;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ce;->vs:Lcom/google/android/gms/internal/cf;

    #v0=(Reference);
    return-object v0
.end method

.method public final dm()J
    .locals 2

    const-string v0, "creation_timestamp"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ce;->getLong(Ljava/lang/String;)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final dn()I
    .locals 1

    const-string v0, "type"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ce;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final do()I
    .locals 1

    const-string v0, "variant"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ce;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final dp()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ce;->tT:Ljava/util/ArrayList;

    #v0=(Reference);
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p0, p1}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;->a(Lcom/google/android/gms/games/multiplayer/Invitation;Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;->a(Lcom/google/android/gms/games/multiplayer/Invitation;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;->b(Lcom/google/android/gms/games/multiplayer/Invitation;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/ce;->ed()Lcom/google/android/gms/games/multiplayer/Invitation;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/games/multiplayer/InvitationEntity;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/games/multiplayer/InvitationEntity;->writeToParcel(Landroid/os/Parcel;I)V

    return-void
.end method

*/}
