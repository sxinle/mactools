package com.google.android.gms.internal; class ay {/*

.class public final Lcom/google/android/gms/internal/ay;
.super Ljava/lang/Object;


# static fields
.field private static vD:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    sput-boolean v0, Lcom/google/android/gms/internal/ay;->vD:Z

    return-void
.end method

.method public static el()Z
    .locals 1

    sget-boolean v0, Lcom/google/android/gms/internal/ay;->vD:Z

    #v0=(Boolean);
    return v0
.end method

*/}
