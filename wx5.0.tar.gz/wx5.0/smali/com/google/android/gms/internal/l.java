package com.google.android.gms.internal; class l {/*

.class public final Lcom/google/android/gms/internal/l;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final yR:Lcom/google/android/gms/internal/cr;

.field private static final yS:Ljava/util/HashMap;

.field private static final yT:Ljava/lang/Object;

.field private static final za:Lcom/google/android/gms/internal/cq;


# instance fields
.field mClosed:Z

.field p:I

.field tu:I

.field yU:[Ljava/lang/String;

.field yV:Landroid/os/Bundle;

.field yW:[Landroid/database/CursorWindow;

.field yX:Landroid/os/Bundle;

.field yY:[I

.field yZ:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/google/android/gms/internal/cr;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/cr;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/l;->yR:Lcom/google/android/gms/internal/cr;

    const/4 v0, 0x0

    #v0=(Null);
    sput-object v0, Lcom/google/android/gms/internal/l;->yS:Ljava/util/HashMap;

    new-instance v0, Ljava/lang/Object;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/l;->yT:Ljava/lang/Object;

    new-instance v0, Lcom/google/android/gms/internal/cp;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    new-array v1, v1, [Ljava/lang/String;

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/cp;-><init>([Ljava/lang/String;)V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/l;->za:Lcom/google/android/gms/internal/cq;

    return-void
.end method

.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/l;->mClosed:Z

    return-void
.end method

.method private h(Ljava/lang/String;I)V
    .locals 3

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    invoke-virtual {v0, p1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    :cond_0
    #v0=(Conflicted);
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "No such column: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-direct {p0}, Lcom/google/android/gms/internal/l;->isClosed()Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    const-string v1, "Buffer is closed."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_2
    #v0=(Boolean);v1=(Uninit);
    if-ltz p2, :cond_3

    iget v0, p0, Lcom/google/android/gms/internal/l;->yZ:I

    #v0=(Integer);
    if-lt p2, v0, :cond_4

    :cond_3
    new-instance v0, Landroid/database/CursorIndexOutOfBoundsException;

    #v0=(UninitRef);
    iget v1, p0, Lcom/google/android/gms/internal/l;->yZ:I

    #v1=(Integer);
    invoke-direct {v0, p2, v1}, Landroid/database/CursorIndexOutOfBoundsException;-><init>(II)V

    #v0=(Reference);
    throw v0

    :cond_4
    #v0=(Integer);v1=(Uninit);
    return-void
.end method

.method private isClosed()Z
    .locals 1

    monitor-enter p0

    :try_start_0
    iget-boolean v0, p0, Lcom/google/android/gms/internal/l;->mClosed:Z

    #v0=(Boolean);
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit p0

    throw v0
.end method


# virtual methods
.method public final a(Ljava/lang/String;II)J
    .locals 3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/l;->h(Ljava/lang/String;I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v0=(Reference);
    aget-object v0, v0, p3

    #v0=(Null);
    iget-object v1, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v1=(Reference);
    aget v1, v1, p3

    #v1=(Integer);
    sub-int v1, p2, v1

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    #v2=(Reference);
    invoke-virtual {v2, p1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Landroid/database/CursorWindow;->getLong(II)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final af(I)I
    .locals 2

    const/4 v1, 0x0

    #v1=(Null);
    if-ltz p1, :cond_2

    iget v0, p0, Lcom/google/android/gms/internal/l;->yZ:I

    #v0=(Integer);
    if-ge p1, v0, :cond_2

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    invoke-static {v0}, Lcom/google/android/gms/internal/i;->d(Z)V

    :goto_1
    #v0=(Integer);v1=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v0=(Reference);
    array-length v0, v0

    #v0=(Integer);
    if-ge v1, v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v0=(Reference);
    aget v0, v0, v1

    #v0=(Integer);
    if-ge p1, v0, :cond_3

    add-int/lit8 v1, v1, -0x1

    :cond_0
    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v0=(Reference);
    array-length v0, v0

    #v0=(Integer);
    if-ne v1, v0, :cond_1

    add-int/lit8 v1, v1, -0x1

    :cond_1
    return v1

    :cond_2
    #v0=(Conflicted);v1=(Null);
    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_3
    #v0=(Integer);v1=(Integer);
    add-int/lit8 v1, v1, 0x1

    goto :goto_1
.end method

.method public final b(Ljava/lang/String;II)I
    .locals 3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/l;->h(Ljava/lang/String;I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v0=(Reference);
    aget-object v0, v0, p3

    #v0=(Null);
    iget-object v1, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v1=(Reference);
    aget v1, v1, p3

    #v1=(Integer);
    sub-int v1, p2, v1

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    #v2=(Reference);
    invoke-virtual {v2, p1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Landroid/database/CursorWindow;->getInt(II)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final c(Ljava/lang/String;II)Ljava/lang/String;
    .locals 3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/l;->h(Ljava/lang/String;I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v0=(Reference);
    aget-object v0, v0, p3

    #v0=(Null);
    iget-object v1, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v1=(Reference);
    aget v1, v1, p3

    #v1=(Integer);
    sub-int v1, p2, v1

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    #v2=(Reference);
    invoke-virtual {v2, p1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Landroid/database/CursorWindow;->getString(II)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final d(Ljava/lang/String;II)Z
    .locals 4

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/l;->h(Ljava/lang/String;I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v0=(Reference);
    aget-object v0, v0, p3

    #v0=(Null);
    iget-object v1, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v1=(Reference);
    aget v1, v1, p3

    #v1=(Integer);
    sub-int v1, p2, v1

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    #v2=(Reference);
    invoke-virtual {v2, p1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Landroid/database/CursorWindow;->getLong(II)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    #v0=(LongLo);
    const-wide/16 v2, 0x1

    #v2=(LongLo);v3=(LongHi);
    cmp-long v0, v0, v2

    #v0=(Byte);
    if-nez v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Byte);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final describeContents()I
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/l;->yR:Lcom/google/android/gms/internal/cr;

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final e(Ljava/lang/String;II)Landroid/net/Uri;
    .locals 1

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/gms/internal/l;->c(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    return-object v0

    :cond_0
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    goto :goto_0
.end method

.method public final f(Ljava/lang/String;II)Z
    .locals 3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/l;->h(Ljava/lang/String;I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v0=(Reference);
    aget-object v0, v0, p3

    #v0=(Null);
    iget-object v1, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v1=(Reference);
    aget v1, v1, p3

    #v1=(Integer);
    sub-int v1, p2, v1

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    #v2=(Reference);
    invoke-virtual {v2, p1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Landroid/database/CursorWindow;->isNull(II)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final getCount()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/l;->yZ:I

    #v0=(Integer);
    return v0
.end method

.method public final gx()V
    .locals 4

    const/4 v1, 0x0

    #v1=(Null);
    new-instance v0, Landroid/os/Bundle;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    move v0, v1

    :goto_0
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);
    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yU:[Ljava/lang/String;

    #v2=(Reference);
    array-length v2, v2

    #v2=(Integer);
    if-ge v0, v2, :cond_0

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yV:Landroid/os/Bundle;

    #v2=(Reference);
    iget-object v3, p0, Lcom/google/android/gms/internal/l;->yU:[Ljava/lang/String;

    #v3=(Reference);
    aget-object v3, v3, v0

    #v3=(Null);
    invoke-virtual {v2, v3, v0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    #v2=(Integer);v3=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v0=(Reference);
    array-length v0, v0

    #v0=(Integer);
    new-array v0, v0, [I

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/l;->yY:[I

    move v0, v1

    :goto_1
    #v0=(Integer);v1=(Integer);
    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v2=(Reference);
    array-length v2, v2

    #v2=(Integer);
    if-ge v1, v2, :cond_1

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yY:[I

    #v2=(Reference);
    aput v0, v2, v1

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    aget-object v2, v2, v1

    #v2=(Null);
    invoke-virtual {v2}, Landroid/database/CursorWindow;->getNumRows()I

    move-result v2

    #v2=(Integer);
    add-int/2addr v0, v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    iput v0, p0, Lcom/google/android/gms/internal/l;->yZ:I

    return-void
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/l;->yR:Lcom/google/android/gms/internal/cr;

    #v0=(Reference);
    invoke-static {p0, p1, p2}, Lcom/google/android/gms/internal/cr;->a(Lcom/google/android/gms/internal/l;Landroid/os/Parcel;I)V

    return-void
.end method

*/}
