package com.google.android.gms.internal; class r {/*

.class public Lcom/google/android/gms/internal/r;
.super Ljava/lang/Object;


# instance fields
.field private size:I

.field private final ur:Ljava/util/LinkedHashMap;

.field private us:I

.field private ut:I

.field private uu:I

.field private uv:I

.field private uw:I


# direct methods
.method private d(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 3

    invoke-virtual {p0, p2}, Lcom/google/android/gms/internal/r;->e(Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    if-gez v0, :cond_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Negative size: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Integer);v1=(Uninit);v2=(Uninit);
    return v0
.end method


# virtual methods
.method public final ad(I)V
    .locals 3

    :goto_0
    monitor-enter p0

    :try_start_0
    iget v0, p0, Lcom/google/android/gms/internal/r;->size:I

    #v0=(Integer);
    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/r;->ur:Ljava/util/LinkedHashMap;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->isEmpty()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    iget v0, p0, Lcom/google/android/gms/internal/r;->size:I

    #v0=(Integer);
    if-eqz v0, :cond_1

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    #v1=(Reference);
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ".sizeOf() is reporting inconsistent results!"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit p0

    throw v0

    :cond_1
    :try_start_1
    #v0=(Integer);
    iget v0, p0, Lcom/google/android/gms/internal/r;->size:I

    if-le v0, p1, :cond_2

    iget-object v0, p0, Lcom/google/android/gms/internal/r;->ur:Ljava/util/LinkedHashMap;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->isEmpty()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    :cond_2
    #v0=(Integer);
    monitor-exit p0

    return-void

    :cond_3
    #v0=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/internal/r;->ur:Ljava/util/LinkedHashMap;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    #v1=(Reference);
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    iget-object v2, p0, Lcom/google/android/gms/internal/r;->ur:Ljava/util/LinkedHashMap;

    #v2=(Reference);
    invoke-virtual {v2, v1}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget v2, p0, Lcom/google/android/gms/internal/r;->size:I

    #v2=(Integer);
    invoke-direct {p0, v1, v0}, Lcom/google/android/gms/internal/r;->d(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    sub-int v0, v2, v0

    iput v0, p0, Lcom/google/android/gms/internal/r;->size:I

    iget v0, p0, Lcom/google/android/gms/internal/r;->uu:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/google/android/gms/internal/r;->uu:I

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0
.end method

.method protected e(Ljava/lang/Object;)I
    .locals 1

    const/4 v0, 0x1

    #v0=(One);
    return v0
.end method

.method public final put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    if-eqz p1, :cond_0

    if-nez p2, :cond_1

    :cond_0
    new-instance v0, Ljava/lang/NullPointerException;

    #v0=(UninitRef);
    const-string v1, "key == null || value == null"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v0=(Uninit);v1=(Uninit);
    monitor-enter p0

    :try_start_0
    iget v0, p0, Lcom/google/android/gms/internal/r;->ut:I

    #v0=(Integer);
    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/google/android/gms/internal/r;->ut:I

    iget v0, p0, Lcom/google/android/gms/internal/r;->size:I

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/r;->d(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v1

    #v1=(Integer);
    add-int/2addr v0, v1

    iput v0, p0, Lcom/google/android/gms/internal/r;->size:I

    iget-object v0, p0, Lcom/google/android/gms/internal/r;->ur:Ljava/util/LinkedHashMap;

    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_2

    iget v1, p0, Lcom/google/android/gms/internal/r;->size:I

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/internal/r;->d(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v2

    #v2=(Integer);
    sub-int/2addr v1, v2

    iput v1, p0, Lcom/google/android/gms/internal/r;->size:I

    :cond_2
    #v2=(Conflicted);
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget v1, p0, Lcom/google/android/gms/internal/r;->us:I

    invoke-virtual {p0, v1}, Lcom/google/android/gms/internal/r;->ad(I)V

    return-object v0

    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized toString()Ljava/lang/String;
    .locals 5

    const/4 v0, 0x0

    #v0=(Null);
    monitor-enter p0

    :try_start_0
    iget v1, p0, Lcom/google/android/gms/internal/r;->uv:I

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/r;->uw:I

    #v2=(Integer);
    add-int/2addr v1, v2

    if-eqz v1, :cond_0

    iget v0, p0, Lcom/google/android/gms/internal/r;->uv:I

    #v0=(Integer);
    mul-int/lit8 v0, v0, 0x64

    div-int/2addr v0, v1

    :cond_0
    const-string v1, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]"

    #v1=(Reference);
    const/4 v2, 0x4

    #v2=(PosByte);
    new-array v2, v2, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    iget v4, p0, Lcom/google/android/gms/internal/r;->us:I

    #v4=(Integer);
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    #v4=(Reference);
    aput-object v4, v2, v3

    const/4 v3, 0x1

    #v3=(One);
    iget v4, p0, Lcom/google/android/gms/internal/r;->uv:I

    #v4=(Integer);
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    #v4=(Reference);
    aput-object v4, v2, v3

    const/4 v3, 0x2

    #v3=(PosByte);
    iget v4, p0, Lcom/google/android/gms/internal/r;->uw:I

    #v4=(Integer);
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    #v4=(Reference);
    aput-object v4, v2, v3

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    aput-object v0, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result-object v0

    monitor-exit p0

    return-object v0

    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit p0

    throw v0
.end method

*/}
