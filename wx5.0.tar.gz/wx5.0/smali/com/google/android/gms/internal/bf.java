package com.google.android.gms.internal; class bf {/*

.class public abstract Lcom/google/android/gms/internal/bf;
.super Lcom/google/android/gms/internal/bh;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/internal/bh;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public a(ILandroid/os/Bundle;Landroid/os/ParcelFileDescriptor;)V
    .locals 0

    return-void
.end method

*/}
