package com.google.android.gms.internal; class bk {/*

.class final Lcom/google/android/gms/internal/bk;
.super Lcom/google/android/gms/internal/bf;


# instance fields
.field private final vR:Lcom/google/android/gms/plus/b;

.field final synthetic vS:Lcom/google/android/gms/internal/bj;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/bj;Lcom/google/android/gms/plus/b;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/gms/internal/bk;->vS:Lcom/google/android/gms/internal/bj;

    invoke-direct {p0}, Lcom/google/android/gms/internal/bf;-><init>()V

    #p0=(Reference);
    iput-object p2, p0, Lcom/google/android/gms/internal/bk;->vR:Lcom/google/android/gms/plus/b;

    return-void
.end method


# virtual methods
.method public final a(ILandroid/os/Bundle;Landroid/os/ParcelFileDescriptor;)V
    .locals 5

    const/4 v0, 0x0

    #v0=(Null);
    if-eqz p2, :cond_0

    const-string v0, "pendingIntent"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/app/PendingIntent;

    :cond_0
    new-instance v1, Lcom/google/android/gms/common/a;

    #v1=(UninitRef);
    invoke-direct {v1, p1, v0}, Lcom/google/android/gms/common/a;-><init>(ILandroid/app/PendingIntent;)V

    #v1=(Reference);
    iget-object v0, p0, Lcom/google/android/gms/internal/bk;->vS:Lcom/google/android/gms/internal/bj;

    new-instance v2, Lcom/google/android/gms/internal/bn;

    #v2=(UninitRef);
    iget-object v3, p0, Lcom/google/android/gms/internal/bk;->vS:Lcom/google/android/gms/internal/bj;

    #v3=(Reference);
    iget-object v4, p0, Lcom/google/android/gms/internal/bk;->vR:Lcom/google/android/gms/plus/b;

    #v4=(Reference);
    invoke-direct {v2, v3, v4, v1, p3}, Lcom/google/android/gms/internal/bn;-><init>(Lcom/google/android/gms/internal/bj;Lcom/google/android/gms/plus/b;Lcom/google/android/gms/common/a;Landroid/os/ParcelFileDescriptor;)V

    #v2=(Reference);
    invoke-virtual {v0, v2}, Lcom/google/android/gms/internal/bj;->a(Lcom/google/android/gms/internal/db;)V

    return-void
.end method

*/}
