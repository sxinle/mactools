package com.google.android.gms.internal; class cx {/*

.class final Lcom/google/android/gms/internal/cx;
.super Landroid/graphics/drawable/Drawable$ConstantState;


# instance fields
.field zG:I

.field zH:I


# direct methods
.method constructor <init>(Lcom/google/android/gms/internal/cx;)V
    .locals 1

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    #p0=(Reference);
    if-eqz p1, :cond_0

    iget v0, p1, Lcom/google/android/gms/internal/cx;->zG:I

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/internal/cx;->zG:I

    iget v0, p1, Lcom/google/android/gms/internal/cx;->zH:I

    iput v0, p0, Lcom/google/android/gms/internal/cx;->zH:I

    :cond_0
    #v0=(Conflicted);
    return-void
.end method


# virtual methods
.method public final getChangingConfigurations()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/cx;->zG:I

    #v0=(Integer);
    return v0
.end method

.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/cu;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/cu;-><init>(Lcom/google/android/gms/internal/cx;)V

    #v0=(Reference);
    return-object v0
.end method

*/}
