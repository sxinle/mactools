package com.google.android.gms.internal; class ar {/*

.class public abstract Lcom/google/android/gms/internal/ar;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method protected static a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/internal/ar$a;->c(Lcom/google/android/gms/internal/ar$a;)Lcom/google/android/gms/internal/x;

    move-result-object v0

    #v0=(Reference);
    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/ar$a;->h(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    :cond_0
    return-object p1
.end method

.method private static a(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V
    .locals 2

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dI()I

    move-result v0

    #v0=(Integer);
    const/16 v1, 0xb

    #v1=(PosByte);
    if-ne v0, v1, :cond_0

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dO()Ljava/lang/Class;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p2}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/ar;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/ar;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_0
    #v0=(Integer);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dI()I

    move-result v0

    const/4 v1, 0x7

    if-ne v0, v1, :cond_1

    const-string v0, "\""

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    check-cast p2, Ljava/lang/String;

    invoke-static {p2}, Lcom/google/android/gms/internal/ag;->O(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\""

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_1
    #v0=(Integer);
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    goto :goto_0
.end method

.method private static a(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/util/ArrayList;)V
    .locals 3

    const-string v0, "["

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    :goto_0
    #v0=(Integer);v1=(Integer);v2=(Conflicted);
    if-ge v0, v1, :cond_2

    if-lez v0, :cond_0

    const-string v2, ","

    #v2=(Reference);
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v2=(Conflicted);
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    #v2=(Reference);
    if-eqz v2, :cond_1

    invoke-static {p0, p1, v2}, Lcom/google/android/gms/internal/ar;->a(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    #v2=(Conflicted);
    const-string v0, "]"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method


# virtual methods
.method protected a(Lcom/google/android/gms/internal/ar$a;)Z
    .locals 2

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dK()I

    move-result v0

    #v0=(Integer);
    const/16 v1, 0xb

    #v1=(PosByte);
    if-ne v0, v1, :cond_1

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dL()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dM()Ljava/lang/String;

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    #v0=(UninitRef);
    const-string v1, "Concrete type arrays not supported"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Boolean);v1=(PosByte);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dM()Ljava/lang/String;

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    #v0=(UninitRef);
    const-string v1, "Concrete types not supported"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v0=(Integer);v1=(PosByte);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dM()Ljava/lang/String;

    invoke-virtual {p0}, Lcom/google/android/gms/internal/ar;->dH()Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method protected b(Lcom/google/android/gms/internal/ar$a;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    #v3=(One);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dM()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dO()Ljava/lang/Class;

    move-result-object v1

    #v1=(Reference);
    if-eqz v1, :cond_0

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dM()Ljava/lang/String;

    invoke-virtual {p0}, Lcom/google/android/gms/internal/ar;->dG()Ljava/lang/Object;

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Concrete field shouldn\'t be value object: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dM()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/google/android/gms/internal/i;->a(ZLjava/lang/Object;)V

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dL()Z

    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "get"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    invoke-static {v2}, Ljava/lang/Character;->toUpperCase(C)C

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    const/4 v2, 0x1

    #v2=(One);
    invoke-virtual {v0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    invoke-virtual {v1, v0, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v1, 0x0

    #v1=(Null);
    new-array v1, v1, [Ljava/lang/Object;

    #v1=(Reference);
    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v0

    :goto_0
    #v2=(Conflicted);
    return-object v0

    :catch_0
    #v1=(Conflicted);
    move-exception v0

    new-instance v1, Ljava/lang/RuntimeException;

    #v1=(UninitRef);
    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    #v1=(Reference);
    throw v1

    :cond_0
    #v2=(Uninit);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dM()Ljava/lang/String;

    invoke-virtual {p0}, Lcom/google/android/gms/internal/ar;->dG()Ljava/lang/Object;

    move-result-object v0

    goto :goto_0
.end method

.method public abstract dF()Ljava/util/HashMap;
.end method

.method protected abstract dG()Ljava/lang/Object;
.end method

.method protected abstract dH()Z
.end method

.method public toString()Ljava/lang/String;
    .locals 7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/ar;->dF()Ljava/util/HashMap;

    move-result-object v3

    #v3=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const/16 v0, 0x64

    #v0=(PosByte);
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    #v4=(Reference);
    invoke-virtual {v3}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v5=(Reference);v6=(Conflicted);
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Lcom/google/android/gms/internal/ar$a;

    invoke-virtual {p0, v1}, Lcom/google/android/gms/internal/ar;->a(Lcom/google/android/gms/internal/ar$a;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-virtual {p0, v1}, Lcom/google/android/gms/internal/ar;->b(Lcom/google/android/gms/internal/ar$a;)Ljava/lang/Object;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/ar;->a(Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->length()I

    move-result v6

    #v6=(Integer);
    if-nez v6, :cond_1

    const-string v6, "{"

    #v6=(Reference);
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    const-string v6, "\""

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v6, "\":"

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez v2, :cond_2

    const-string v0, "null"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_1
    #v6=(Integer);
    const-string v6, ","

    #v6=(Reference);
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_2
    invoke-virtual {v1}, Lcom/google/android/gms/internal/ar$a;->dK()I

    move-result v0

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    invoke-virtual {v1}, Lcom/google/android/gms/internal/ar$a;->dJ()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    check-cast v2, Ljava/util/ArrayList;

    invoke-static {v4, v1, v2}, Lcom/google/android/gms/internal/ar;->a(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/util/ArrayList;)V

    goto :goto_0

    :pswitch_0
    #v0=(Integer);
    const-string v0, "\""

    #v0=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move-object v0, v2

    check-cast v0, [B

    invoke-static {v0}, Lcom/google/android/gms/internal/ae;->a([B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :pswitch_1
    #v0=(Integer);
    const-string v0, "\""

    #v0=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    check-cast v2, [B

    invoke-static {v2}, Lcom/google/android/gms/internal/ae;->b([B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_0

    :pswitch_2
    #v0=(Integer);
    check-cast v2, Ljava/util/HashMap;

    invoke-static {v4, v2}, Lcom/google/android/gms/internal/ah;->a(Ljava/lang/StringBuilder;Ljava/util/HashMap;)V

    goto/16 :goto_0

    :cond_3
    #v0=(Boolean);
    invoke-static {v4, v1, v2}, Lcom/google/android/gms/internal/ar;->a(Ljava/lang/StringBuilder;Lcom/google/android/gms/internal/ar$a;Ljava/lang/Object;)V

    goto/16 :goto_0

    :cond_4
    #v1=(Conflicted);v2=(Conflicted);v6=(Conflicted);
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_5

    const-string v0, "}"

    #v0=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_2
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_5
    #v0=(Integer);
    const-string v0, "{}"

    #v0=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

*/}
