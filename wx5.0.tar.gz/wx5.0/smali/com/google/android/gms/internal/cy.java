package com.google.android.gms.internal; class cy {/*

.class public final Lcom/google/android/gms/internal/cy;
.super Landroid/widget/ImageView;


# instance fields
.field private zI:Landroid/net/Uri;

.field private zJ:I


# virtual methods
.method public final ag(I)V
    .locals 0

    iput p1, p0, Lcom/google/android/gms/internal/cy;->zJ:I

    return-void
.end method

.method public final b(Landroid/net/Uri;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/gms/internal/cy;->zI:Landroid/net/Uri;

    return-void
.end method

.method public final gC()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/cy;->zJ:I

    #v0=(Integer);
    return v0
.end method

*/}
