package com.google.android.gms.internal; class bl {/*

.class public final Lcom/google/android/gms/internal/bl;
.super Lcom/google/android/gms/internal/co;

# interfaces
.implements Lcom/google/android/gms/games/Game;


# direct methods
.method private eb()Lcom/google/android/gms/games/Game;
    .locals 1

    new-instance v0, Lcom/google/android/gms/games/GameEntity;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/games/GameEntity;-><init>(Lcom/google/android/gms/games/Game;)V

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final synthetic cP()Ljava/lang/Object;
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/bl;->eb()Lcom/google/android/gms/games/Game;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final cS()Ljava/lang/String;
    .locals 1

    const-string v0, "external_game_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final cT()Ljava/lang/String;
    .locals 1

    const-string v0, "primary_category"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final cU()Ljava/lang/String;
    .locals 1

    const-string v0, "secondary_category"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final cV()Ljava/lang/String;
    .locals 1

    const-string v0, "developer_name"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final cW()Landroid/net/Uri;
    .locals 1

    const-string v0, "game_icon_image_uri"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->P(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final cX()Landroid/net/Uri;
    .locals 1

    const-string v0, "game_hi_res_image_uri"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->P(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final cY()Landroid/net/Uri;
    .locals 1

    const-string v0, "featured_image_uri"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->P(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final cZ()Z
    .locals 1

    const-string v0, "play_enabled_game"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final da()Z
    .locals 1

    const-string v0, "installed"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final db()Ljava/lang/String;
    .locals 1

    const-string v0, "package_name"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final dc()I
    .locals 1

    const-string v0, "gameplay_acl_status"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final dd()I
    .locals 1

    const-string v0, "achievement_total_count"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final de()I
    .locals 1

    const-string v0, "leaderboard_count"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p0, p1}, Lcom/google/android/gms/games/GameEntity;->a(Lcom/google/android/gms/games/Game;Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final getDescription()Ljava/lang/String;
    .locals 1

    const-string v0, "game_description"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getDisplayName()Ljava/lang/String;
    .locals 1

    const-string v0, "display_name"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bl;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/GameEntity;->a(Lcom/google/android/gms/games/Game;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/GameEntity;->b(Lcom/google/android/gms/games/Game;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/bl;->eb()Lcom/google/android/gms/games/Game;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/games/GameEntity;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/games/GameEntity;->writeToParcel(Landroid/os/Parcel;I)V

    return-void
.end method

*/}
