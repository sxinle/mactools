package com.google.android.gms.internal; class aw {/*

.class public final Lcom/google/android/gms/internal/aw;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/Boolean;)B
    .locals 1

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Byte);
    return v0

    :cond_0
    #v0=(Boolean);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0

    :cond_1
    #v0=(Uninit);
    const/4 v0, -0x1

    #v0=(Byte);
    goto :goto_0
.end method

.method public static a(B)Ljava/lang/Boolean;
    .locals 1

    packed-switch p0, :pswitch_data_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :pswitch_0
    #v0=(Uninit);
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    #v0=(Reference);
    goto :goto_0

    :pswitch_1
    #v0=(Uninit);
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    #v0=(Reference);
    goto :goto_0

    #v0=(Unknown);p0=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

*/}
