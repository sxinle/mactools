package com.google.android.gms.internal; class g {/*

.class public final Lcom/google/android/gms/internal/g;
.super Ljava/lang/Object;


# direct methods
.method public static b(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 1

    if-eq p0, p1, :cond_0

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    :cond_0
    #v0=(Conflicted);
    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_1
    #v0=(Conflicted);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public static f(Ljava/lang/Object;)Lcom/google/android/gms/internal/h;
    .locals 2

    new-instance v0, Lcom/google/android/gms/internal/h;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {v0, p0, v1}, Lcom/google/android/gms/internal/h;-><init>(Ljava/lang/Object;B)V

    #v0=(Reference);
    return-object v0
.end method

*/}
