package com.google.android.gms.internal; class af {/*

.class public final Lcom/google/android/gms/internal/af;
.super Landroid/widget/Button;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/internal/af;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    #p0=(Reference);
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const v0, 0x1010048

    #v0=(Integer);
    invoke-direct {p0, p1, p2, v0}, Landroid/widget/Button;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    #p0=(Reference);
    return-void
.end method

.method private static d(III)I
    .locals 3

    packed-switch p0, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Unknown color scheme: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_0
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);
    move p1, p2

    :pswitch_1
    return p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final a(Landroid/content/res/Resources;II)V
    .locals 7

    const/4 v1, 0x1

    #v1=(One);
    const/4 v2, 0x0

    #v2=(Null);
    const/high16 v6, 0x4240

    #v6=(Integer);
    const/high16 v5, 0x3f00

    #v5=(Integer);
    if-ltz p2, :cond_0

    const/4 v0, 0x3

    #v0=(PosByte);
    if-ge p2, v0, :cond_0

    move v0, v1

    :goto_0
    #v0=(Boolean);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "Unknown button size "

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/google/android/gms/internal/i;->a(ZLjava/lang/Object;)V

    if-ltz p3, :cond_1

    const/4 v0, 0x2

    #v0=(PosByte);
    if-ge p3, v0, :cond_1

    :goto_1
    #v1=(Boolean);
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v2, "Unknown color scheme "

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/i;->a(ZLjava/lang/Object;)V

    sget-object v0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setTypeface(Landroid/graphics/Typeface;)V

    const/high16 v0, 0x4160

    #v0=(Integer);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setTextSize(F)V

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    #v0=(Reference);
    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    #v0=(Integer);
    mul-float v1, v0, v6

    #v1=(Float);
    add-float/2addr v1, v5

    float-to-int v1, v1

    #v1=(Integer);
    invoke-virtual {p0, v1}, Lcom/google/android/gms/internal/af;->setMinHeight(I)V

    mul-float/2addr v0, v6

    #v0=(Float);
    add-float/2addr v0, v5

    float-to-int v0, v0

    #v0=(Integer);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setMinWidth(I)V

    packed-switch p2, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Unknown button size: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Conflicted);v1=(One);v2=(Null);v3=(Uninit);v4=(Uninit);
    move v0, v2

    #v0=(Null);
    goto :goto_0

    :cond_1
    #v0=(PosByte);v3=(Reference);v4=(Reference);
    move v1, v2

    #v1=(Null);
    goto :goto_1

    :pswitch_0
    #v0=(Integer);v1=(Integer);v2=(Reference);
    sget v0, Lcom/google/android/gms/c;->sF:I

    sget v1, Lcom/google/android/gms/c;->sG:I

    invoke-static {p3, v0, v1}, Lcom/google/android/gms/internal/af;->d(III)I

    move-result v0

    :goto_2
    const/4 v1, -0x1

    #v1=(Byte);
    if-ne v0, v1, :cond_2

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "Could not find background resource!"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_1
    #v0=(Integer);v1=(Integer);
    sget v0, Lcom/google/android/gms/c;->sH:I

    sget v1, Lcom/google/android/gms/c;->sI:I

    invoke-static {p3, v0, v1}, Lcom/google/android/gms/internal/af;->d(III)I

    move-result v0

    goto :goto_2

    :cond_2
    #v1=(Byte);
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    sget v0, Lcom/google/android/gms/b;->sF:I

    #v0=(Integer);
    sget v1, Lcom/google/android/gms/b;->sG:I

    #v1=(Integer);
    invoke-static {p3, v0, v1}, Lcom/google/android/gms/internal/af;->d(III)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setTextColor(Landroid/content/res/ColorStateList;)V

    packed-switch p2, :pswitch_data_1

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Unknown button size: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_2
    #v1=(Integer);
    sget v0, Lcom/google/android/gms/d;->sK:I

    #v0=(Integer);
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setText(Ljava/lang/CharSequence;)V

    :goto_3
    return-void

    :pswitch_3
    sget v0, Lcom/google/android/gms/d;->sL:I

    #v0=(Integer);
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3

    :pswitch_4
    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/af;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);p3=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
        :pswitch_1
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_2
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

*/}
