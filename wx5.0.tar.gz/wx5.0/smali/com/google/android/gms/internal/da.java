package com.google.android.gms.internal; class da {/*

.class public abstract Lcom/google/android/gms/internal/da;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/b;


# static fields
.field public static final zV:[Ljava/lang/String;


# instance fields
.field final mHandler:Landroid/os/Handler;

.field private zO:Landroid/os/IInterface;

.field private zP:Ljava/util/ArrayList;

.field final zQ:Ljava/util/ArrayList;

.field private zR:Z

.field private zS:Ljava/util/ArrayList;

.field private zT:Z

.field private final zU:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v0, 0x2

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/String;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    const-string v2, "service_esmobile"

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    const-string v2, "service_googleme"

    aput-object v2, v0, v1

    sput-object v0, Lcom/google/android/gms/internal/da;->zV:[Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/common/c;)V
    .locals 3

    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v2, "registerConnectionCallbacks(): listener "

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " is already registered"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :goto_0
    #v2=(Conflicted);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Lcom/google/android/gms/internal/da;->isConnected()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/da;->mHandler:Landroid/os/Handler;

    #v0=(Reference);
    iget-object v1, p0, Lcom/google/android/gms/internal/da;->mHandler:Landroid/os/Handler;

    const/4 v2, 0x4

    #v2=(PosByte);
    invoke-virtual {v1, v2, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_0
    #v0=(Conflicted);v2=(Conflicted);
    return-void

    :cond_1
    :try_start_1
    #v0=(Boolean);v2=(Uninit);
    iget-boolean v0, p0, Lcom/google/android/gms/internal/da;->zR:Z

    if-eqz v0, :cond_2

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    iget-object v2, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    :cond_2
    #v0=(Conflicted);v2=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final a(Lcom/google/android/gms/common/d;)V
    .locals 3

    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v2, "registerConnectionFailedListener(): listener "

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " is already registered"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :goto_0
    #v2=(Conflicted);
    monitor-exit v1

    return-void

    :cond_0
    #v0=(Boolean);v2=(Uninit);
    iget-boolean v0, p0, Lcom/google/android/gms/internal/da;->zT:Z

    if-eqz v0, :cond_1

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    iget-object v2, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    :cond_1
    #v0=(Conflicted);v2=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final a(Lcom/google/android/gms/internal/db;)V
    .locals 3

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->zU:Ljava/util/ArrayList;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zU:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Lcom/google/android/gms/internal/da;->mHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->mHandler:Landroid/os/Handler;

    const/4 v2, 0x2

    #v2=(PosByte);
    invoke-virtual {v1, v2, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void

    :catchall_0
    #v0=(Conflicted);v2=(Uninit);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final b(Lcom/google/android/gms/common/c;)Z
    .locals 2

    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final b(Lcom/google/android/gms/common/d;)Z
    .locals 2

    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final c(Lcom/google/android/gms/common/c;)V
    .locals 3

    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/da;->zR:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    iget-object v2, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    :cond_0
    #v0=(Conflicted);v2=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zP:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_2

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v2, "unregisterConnectionCallbacks(): listener "

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " not found"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_1
    :goto_0
    #v0=(Conflicted);v2=(Conflicted);
    monitor-exit v1

    return-void

    :cond_2
    #v0=(Boolean);
    iget-boolean v0, p0, Lcom/google/android/gms/internal/da;->zR:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zQ:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zQ:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final c(Lcom/google/android/gms/common/d;)V
    .locals 3

    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/da;->zT:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    iget-object v2, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    :cond_0
    #v0=(Conflicted);v2=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zS:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v2, "unregisterConnectionFailedListener(): listener "

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " not found"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    :cond_1
    #v0=(Conflicted);v2=(Conflicted);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method protected final gG()V
    .locals 2

    invoke-virtual {p0}, Lcom/google/android/gms/internal/da;->isConnected()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "Not connected. Call connect() and wait for onConnected() to be called."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Boolean);v1=(Uninit);
    return-void
.end method

.method protected final gH()Landroid/os/IInterface;
    .locals 1

    invoke-virtual {p0}, Lcom/google/android/gms/internal/da;->gG()V

    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zO:Landroid/os/IInterface;

    #v0=(Reference);
    return-object v0
.end method

.method public final isConnected()Z
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/da;->zO:Landroid/os/IInterface;

    #v0=(Reference);
    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

*/}
