package com.google.android.gms.internal; class bt {/*

.class public final Lcom/google/android/gms/internal/bt;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/internal/en;Landroid/os/Parcel;)V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/en;->getDescription()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/16 v1, 0x3e8

    #v1=(PosShort);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/en;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/en;->eA()Ljava/util/ArrayList;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/internal/en;->eB()Ljava/util/ArrayList;

    move-result-object v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/en;->eC()Z

    move-result v2

    #v2=(Boolean);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method

.method public static i(Landroid/os/Parcel;)Lcom/google/android/gms/internal/en;
    .locals 8

    const/4 v5, 0x0

    #v5=(Null);
    const/4 v4, 0x0

    #v4=(Null);
    invoke-static {p0}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    move-object v3, v4

    #v3=(Null);
    move-object v2, v4

    #v2=(Null);
    move v1, v5

    :goto_0
    #v1=(Integer);v2=(Reference);v3=(Reference);v4=(Reference);v5=(Boolean);v6=(Conflicted);v7=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v6

    #v6=(Integer);
    if-ge v6, v0, :cond_0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v6

    const v7, 0xffff

    #v7=(Char);
    and-int/2addr v7, v6

    #v7=(Integer);
    sparse-switch v7, :sswitch_data_0

    invoke-static {p0, v6}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :sswitch_0
    invoke-static {p0, v6}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :sswitch_1
    invoke-static {p0, v6}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v1

    goto :goto_0

    :sswitch_2
    sget-object v3, Lcom/google/android/gms/internal/ak;->ux:Lcom/google/android/gms/internal/s;

    invoke-static {p0, v6, v3}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v3

    goto :goto_0

    :sswitch_3
    sget-object v4, Lcom/google/android/gms/internal/ak;->ux:Lcom/google/android/gms/internal/s;

    invoke-static {p0, v6, v4}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v4

    goto :goto_0

    :sswitch_4
    invoke-static {p0, v6}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v5

    goto :goto_0

    :cond_0
    #v7=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v6

    if-eq v6, v0, :cond_1

    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Overread allowed size end="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0, p0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_1
    #v0=(Integer);v1=(Integer);
    new-instance v0, Lcom/google/android/gms/internal/en;

    #v0=(UninitRef);
    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/internal/en;-><init>(ILjava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;Z)V

    #v0=(Reference);
    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_0
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x3e8 -> :sswitch_1
    .end sparse-switch
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Lcom/google/android/gms/internal/bt;->i(Landroid/os/Parcel;)Lcom/google/android/gms/internal/en;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/internal/en;

    #v0=(Reference);
    return-object v0
.end method

*/}
