package com.google.android.gms.internal; class k {/*

.class public final Lcom/google/android/gms/internal/k;
.super Ljava/lang/Object;


# static fields
.field private static up:Landroid/content/Context;

.field private static uq:Lcom/google/android/gms/internal/d;


# direct methods
.method public static a(Landroid/content/Context;II)Landroid/view/View;
    .locals 3

    invoke-static {p0}, Lcom/google/android/gms/internal/k;->d(Landroid/content/Context;)Lcom/google/android/gms/internal/d;

    move-result-object v0

    :try_start_0
    #v0=(Reference);
    invoke-static {p0}, Lcom/google/android/gms/internal/as;->i(Ljava/lang/Object;)Lcom/google/android/gms/internal/an;

    move-result-object v1

    #v1=(Reference);
    invoke-interface {v0, v1, p1, p2}, Lcom/google/android/gms/internal/d;->a(Lcom/google/android/gms/internal/an;II)Lcom/google/android/gms/internal/an;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/internal/as;->a(Lcom/google/android/gms/internal/an;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    return-object v0

    :catch_0
    #v1=(Conflicted);
    move-exception v0

    new-instance v0, Lcom/google/android/gms/internal/m;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Could not get button with size "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " and color "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/m;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method private static d(Landroid/content/Context;)Lcom/google/android/gms/internal/d;
    .locals 2

    invoke-static {p0}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/google/android/gms/internal/k;->uq:Lcom/google/android/gms/internal/d;

    #v0=(Reference);
    if-nez v0, :cond_1

    sget-object v0, Lcom/google/android/gms/internal/k;->up:Landroid/content/Context;

    if-nez v0, :cond_0

    invoke-static {p0}, Lcom/google/android/gms/common/e;->c(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/internal/k;->up:Landroid/content/Context;

    if-nez v0, :cond_0

    new-instance v0, Lcom/google/android/gms/internal/m;

    #v0=(UninitRef);
    const-string v1, "Could not get remote context."

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/m;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v1=(Uninit);
    sget-object v0, Lcom/google/android/gms/internal/k;->up:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    :try_start_0
    const-string v1, "com.google.android.gms.common.ui.SignInButtonCreatorImpl"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/IBinder;

    invoke-static {v0}, Lcom/google/android/gms/internal/e;->c(Landroid/os/IBinder;)Lcom/google/android/gms/internal/d;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/internal/k;->uq:Lcom/google/android/gms/internal/d;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2

    :cond_1
    #v1=(Conflicted);
    sget-object v0, Lcom/google/android/gms/internal/k;->uq:Lcom/google/android/gms/internal/d;

    return-object v0

    :catch_0
    move-exception v0

    new-instance v0, Lcom/google/android/gms/internal/m;

    #v0=(UninitRef);
    const-string v1, "Could not load creator class."

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/m;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :catch_1
    #v1=(Conflicted);
    move-exception v0

    new-instance v0, Lcom/google/android/gms/internal/m;

    #v0=(UninitRef);
    const-string v1, "Could not instantiate creator."

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/m;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :catch_2
    #v1=(Conflicted);
    move-exception v0

    new-instance v0, Lcom/google/android/gms/internal/m;

    #v0=(UninitRef);
    const-string v1, "Could not access creator."

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/m;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

*/}
