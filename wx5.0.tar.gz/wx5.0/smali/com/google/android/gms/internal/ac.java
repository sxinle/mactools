package com.google.android.gms.internal; class ac {/*

.class public final Lcom/google/android/gms/internal/ac;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/internal/ax;Landroid/os/Parcel;I)V
    .locals 4

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/ax;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Lcom/google/android/gms/internal/ax;->dX()Landroid/os/Parcel;

    move-result-object v1

    #v1=(Reference);
    invoke-static {p1, v1}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;Landroid/os/Parcel;)V

    const/4 v1, 0x3

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/ax;->dY()Lcom/google/android/gms/internal/au;

    move-result-object v2

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1, v1, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method

.method public static h(Landroid/os/Parcel;)Lcom/google/android/gms/internal/ax;
    .locals 6

    const/4 v0, 0x0

    #v0=(Null);
    invoke-static {p0}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v3

    #v3=(Integer);
    const/4 v1, 0x0

    #v1=(Null);
    move v2, v1

    #v2=(Null);
    move-object v1, v0

    :goto_0
    #v0=(Reference);v1=(Reference);v2=(Integer);v4=(Conflicted);v5=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v4

    #v4=(Integer);
    if-ge v4, v3, :cond_0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const v5, 0xffff

    #v5=(Char);
    and-int/2addr v5, v4

    #v5=(Integer);
    packed-switch v5, :pswitch_data_0

    invoke-static {p0, v4}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :pswitch_0
    invoke-static {p0, v4}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v2

    goto :goto_0

    :pswitch_1
    invoke-static {p0, v4}, Lcom/google/android/gms/internal/o;->r(Landroid/os/Parcel;I)Landroid/os/Parcel;

    move-result-object v1

    goto :goto_0

    :pswitch_2
    sget-object v0, Lcom/google/android/gms/internal/au;->uX:Lcom/google/android/gms/internal/aa;

    invoke-static {p0, v4, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/au;

    goto :goto_0

    :cond_0
    #v5=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v4

    if-eq v4, v3, :cond_1

    new-instance v0, Lcom/google/android/gms/internal/p;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Overread allowed size end="

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v2=(Integer);
    new-instance v3, Lcom/google/android/gms/internal/ax;

    #v3=(UninitRef);
    invoke-direct {v3, v2, v1, v0}, Lcom/google/android/gms/internal/ax;-><init>(ILandroid/os/Parcel;Lcom/google/android/gms/internal/au;)V

    #v3=(Reference);
    return-object v3

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);p0=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Lcom/google/android/gms/internal/ac;->h(Landroid/os/Parcel;)Lcom/google/android/gms/internal/ax;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/internal/ax;

    #v0=(Reference);
    return-object v0
.end method

*/}
