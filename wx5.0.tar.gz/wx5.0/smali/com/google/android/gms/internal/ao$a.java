package com.google.android.gms.internal; class ao$a {/*

.class public final Lcom/google/android/gms/internal/ao$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final uJ:Lcom/google/android/gms/internal/w;


# instance fields
.field final uK:Ljava/lang/String;

.field final uL:I

.field final versionCode:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/w;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/w;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/ao$a;->uJ:Lcom/google/android/gms/internal/w;

    return-void
.end method

.method constructor <init>(ILjava/lang/String;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/ao$a;->versionCode:I

    iput-object p2, p0, Lcom/google/android/gms/internal/ao$a;->uK:Ljava/lang/String;

    iput p3, p0, Lcom/google/android/gms/internal/ao$a;->uL:I

    return-void
.end method

.method constructor <init>(Ljava/lang/String;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/google/android/gms/internal/ao$a;->versionCode:I

    iput-object p1, p0, Lcom/google/android/gms/internal/ao$a;->uK:Ljava/lang/String;

    iput p2, p0, Lcom/google/android/gms/internal/ao$a;->uL:I

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/ao$a;->uJ:Lcom/google/android/gms/internal/w;

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/ao$a;->uJ:Lcom/google/android/gms/internal/w;

    #v0=(Reference);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/w;->a(Lcom/google/android/gms/internal/ao$a;Landroid/os/Parcel;)V

    return-void
.end method

*/}
