package com.google.android.gms.internal; class ap {/*

.class public abstract Lcom/google/android/gms/internal/ap;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/google/android/gms/internal/an;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    #p0=(Reference);
    const-string v0, "com.google.android.gms.dynamic.IObjectWrapper"

    #v0=(Reference);
    invoke-virtual {p0, p0, v0}, Lcom/google/android/gms/internal/ap;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    return-void
.end method

.method public static d(Landroid/os/IBinder;)Lcom/google/android/gms/internal/an;
    .locals 2

    if-nez p0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Uninit);v1=(Uninit);
    const-string v0, "com.google.android.gms.dynamic.IObjectWrapper"

    #v0=(Reference);
    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/google/android/gms/internal/an;

    #v1=(Boolean);
    if-eqz v1, :cond_1

    check-cast v0, Lcom/google/android/gms/internal/an;

    goto :goto_0

    :cond_1
    #v1=(Conflicted);
    new-instance v0, Lcom/google/android/gms/internal/aq;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/aq;-><init>(Landroid/os/IBinder;)V

    #v0=(Reference);
    goto :goto_0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 1

    packed-switch p1, :pswitch_data_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v0

    :goto_0
    #v0=(Boolean);
    return v0

    :pswitch_0
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.dynamic.IObjectWrapper"

    #v0=(Reference);
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0

    #v0=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);p3=(Unknown);p4=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x5f4e5446
        :pswitch_0
    .end packed-switch
.end method

*/}
