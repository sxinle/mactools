package com.google.android.gms.internal; class bn {/*

.class final Lcom/google/android/gms/internal/bn;
.super Lcom/google/android/gms/internal/db;


# instance fields
.field final synthetic vS:Lcom/google/android/gms/internal/bj;

.field private final vT:Lcom/google/android/gms/common/a;

.field private final vU:Landroid/os/ParcelFileDescriptor;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/bj;Lcom/google/android/gms/plus/b;Lcom/google/android/gms/common/a;Landroid/os/ParcelFileDescriptor;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/gms/internal/bn;->vS:Lcom/google/android/gms/internal/bj;

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/db;-><init>(Lcom/google/android/gms/internal/da;Ljava/lang/Object;)V

    #p0=(Reference);
    iput-object p3, p0, Lcom/google/android/gms/internal/bn;->vT:Lcom/google/android/gms/common/a;

    iput-object p4, p0, Lcom/google/android/gms/internal/bn;->vU:Landroid/os/ParcelFileDescriptor;

    return-void
.end method

*/}
