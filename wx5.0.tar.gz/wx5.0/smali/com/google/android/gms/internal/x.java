package com.google.android.gms.internal; class x {/*

.class public interface abstract Lcom/google/android/gms/internal/x;
.super Ljava/lang/Object;


# virtual methods
.method public abstract h(Ljava/lang/Object;)Ljava/lang/Object;
.end method

*/}
