package com.google.android.gms.internal; class as {/*

.class public final Lcom/google/android/gms/internal/as;
.super Lcom/google/android/gms/internal/ap;


# instance fields
.field private final vq:Ljava/lang/Object;


# direct methods
.method private constructor <init>(Ljava/lang/Object;)V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/internal/ap;-><init>()V

    #p0=(Reference);
    iput-object p1, p0, Lcom/google/android/gms/internal/as;->vq:Ljava/lang/Object;

    return-void
.end method

.method public static a(Lcom/google/android/gms/internal/an;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    #v3=(One);
    instance-of v0, p0, Lcom/google/android/gms/internal/as;

    #v0=(Boolean);
    if-eqz v0, :cond_0

    check-cast p0, Lcom/google/android/gms/internal/as;

    iget-object v0, p0, Lcom/google/android/gms/internal/as;->vq:Ljava/lang/Object;

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);
    invoke-interface {p0}, Lcom/google/android/gms/internal/an;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v1

    array-length v2, v1

    #v2=(Integer);
    if-ne v2, v3, :cond_2

    const/4 v2, 0x0

    #v2=(Null);
    aget-object v1, v1, v2

    #v1=(Null);
    invoke-virtual {v1}, Ljava/lang/reflect/Field;->isAccessible()Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_1

    invoke-virtual {v1, v3}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    :try_start_0
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2

    move-result-object v0

    goto :goto_0

    :catch_0
    move-exception v0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    #v1=(UninitRef);
    const-string v2, "Binder object is null."

    #v2=(Reference);
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    #v1=(Reference);
    throw v1

    :catch_1
    #v1=(Null);v2=(Boolean);
    move-exception v0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    #v1=(UninitRef);
    const-string v2, "remoteBinder is the wrong class."

    #v2=(Reference);
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    #v1=(Reference);
    throw v1

    :catch_2
    #v1=(Null);v2=(Boolean);
    move-exception v0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    #v1=(UninitRef);
    const-string v2, "Could not access the field in remoteBinder."

    #v2=(Reference);
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    #v1=(Reference);
    throw v1

    :cond_1
    #v1=(Null);v2=(Boolean);
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    const-string v1, "The concrete class implementing IObjectWrapper must have exactly one declared *private* field for the wrapped object. Preferably, this is an instance of the ObjectWrapper<T> class."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_2
    #v2=(Integer);
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    const-string v1, "The concrete class implementing IObjectWrapper must have exactly *one* declared private field for the wrapped object.  Preferably, this is an instance of the ObjectWrapper<T> class."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method public static i(Ljava/lang/Object;)Lcom/google/android/gms/internal/an;
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/as;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/as;-><init>(Ljava/lang/Object;)V

    #v0=(Reference);
    return-object v0
.end method

*/}
