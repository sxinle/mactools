package com.google.android.gms.internal; class bv {/*

.class public final Lcom/google/android/gms/internal/bv;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/internal/er;Landroid/os/Parcel;I)V
    .locals 8

    const/4 v7, 0x6

    #v7=(PosByte);
    const/4 v6, 0x5

    #v6=(PosByte);
    const/4 v5, 0x4

    #v5=(PosByte);
    const/4 v4, 0x2

    #v4=(PosByte);
    const/4 v3, 0x1

    #v3=(One);
    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/er;->eD()Ljava/util/Set;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lcom/google/android/gms/internal/er;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v3, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    :cond_0
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lcom/google/android/gms/internal/er;->getId()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v4, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_1
    #v2=(Conflicted);
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_2

    invoke-virtual {p0}, Lcom/google/android/gms/internal/er;->fx()Lcom/google/android/gms/internal/ep;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v5, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    :cond_2
    #v2=(Conflicted);
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    invoke-virtual {p0}, Lcom/google/android/gms/internal/er;->fq()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v6, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_3
    #v2=(Conflicted);
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/er;->fy()Lcom/google/android/gms/internal/ep;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v7, v2, p2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    :cond_4
    #v2=(Conflicted);
    const/4 v2, 0x7

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_5

    const/4 v1, 0x7

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/er;->getType()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_5
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 10

    const/4 v7, 0x0

    #v7=(Null);
    invoke-static {p1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v8

    #v8=(Integer);
    new-instance v1, Ljava/util/HashSet;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    #v1=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    move-object v6, v7

    #v6=(Null);
    move-object v5, v7

    #v5=(Null);
    move-object v4, v7

    #v4=(Null);
    move-object v3, v7

    :goto_0
    #v0=(Conflicted);v2=(Integer);v3=(Reference);v4=(Reference);v5=(Reference);v6=(Reference);v7=(Reference);v9=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    #v0=(Integer);
    if-ge v0, v8, :cond_0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const v9, 0xffff

    #v9=(Char);
    and-int/2addr v9, v0

    #v9=(Integer);
    packed-switch v9, :pswitch_data_0

    :pswitch_0
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :pswitch_1
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v2

    const/4 v0, 0x1

    #v0=(One);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_2
    #v0=(Integer);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x2

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_3
    #v0=(Integer);
    sget-object v4, Lcom/google/android/gms/internal/ep;->wt:Lcom/google/android/gms/internal/bu;

    invoke-static {p1, v0, v4}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/internal/ep;

    const/4 v4, 0x4

    #v4=(PosByte);
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    #v4=(Reference);
    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object v4, v0

    goto :goto_0

    :pswitch_4
    #v0=(Integer);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v5

    const/4 v0, 0x5

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_5
    #v0=(Integer);
    sget-object v6, Lcom/google/android/gms/internal/ep;->wt:Lcom/google/android/gms/internal/bu;

    invoke-static {p1, v0, v6}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/internal/ep;

    const/4 v6, 0x6

    #v6=(PosByte);
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    #v6=(Reference);
    invoke-interface {v1, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object v6, v0

    goto :goto_0

    :pswitch_6
    #v0=(Integer);
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v7

    const/4 v0, 0x7

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    #v0=(Integer);v9=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    if-eq v0, v8, :cond_1

    new-instance v0, Lcom/google/android/gms/internal/p;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Overread allowed size end="

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v0=(Integer);v2=(Integer);
    new-instance v0, Lcom/google/android/gms/internal/er;

    #v0=(UninitRef);
    invoke-direct/range {v0 .. v7}, Lcom/google/android/gms/internal/er;-><init>(Ljava/util/Set;ILjava/lang/String;Lcom/google/android/gms/internal/ep;Ljava/lang/String;Lcom/google/android/gms/internal/ep;Ljava/lang/String;)V

    #v0=(Reference);
    return-object v0

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);v7=(Unknown);v8=(Unknown);v9=(Unknown);p0=(Unknown);p1=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_2
        :pswitch_0
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/internal/er;

    #v0=(Reference);
    return-object v0
.end method

*/}
