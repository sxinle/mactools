package com.google.android.gms.internal; class cu {/*

.class public final Lcom/google/android/gms/internal/cu;
.super Landroid/graphics/drawable/Drawable;

# interfaces
.implements Landroid/graphics/drawable/Drawable$Callback;


# instance fields
.field private zA:Z

.field private zB:Z

.field private zC:Z

.field private zD:I

.field private zn:Z

.field private zo:I

.field private zp:J

.field private zq:I

.field private zr:I

.field private zt:I

.field private zu:I

.field private zv:I

.field private zw:Z

.field private zx:Lcom/google/android/gms/internal/cx;

.field private zy:Landroid/graphics/drawable/Drawable;

.field private zz:Landroid/graphics/drawable/Drawable;


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/cu;-><init>(Lcom/google/android/gms/internal/cx;)V

    #p0=(Reference);
    if-nez p1, :cond_0

    invoke-static {}, Lcom/google/android/gms/internal/cv;->gB()Lcom/google/android/gms/internal/cv;

    move-result-object p1

    :cond_0
    iput-object p1, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zx:Lcom/google/android/gms/internal/cx;

    #v0=(Reference);
    iget v1, v0, Lcom/google/android/gms/internal/cx;->zH:I

    #v1=(Integer);
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result v2

    #v2=(Integer);
    or-int/2addr v1, v2

    iput v1, v0, Lcom/google/android/gms/internal/cx;->zH:I

    if-nez p2, :cond_1

    invoke-static {}, Lcom/google/android/gms/internal/cv;->gB()Lcom/google/android/gms/internal/cv;

    move-result-object p2

    :cond_1
    iput-object p2, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p2, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zx:Lcom/google/android/gms/internal/cx;

    iget v1, v0, Lcom/google/android/gms/internal/cx;->zH:I

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result v2

    or-int/2addr v1, v2

    iput v1, v0, Lcom/google/android/gms/internal/cx;->zH:I

    return-void
.end method

.method constructor <init>(Lcom/google/android/gms/internal/cx;)V
    .locals 2

    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    #p0=(Reference);
    iput v1, p0, Lcom/google/android/gms/internal/cu;->zo:I

    const/16 v0, 0xff

    #v0=(PosShort);
    iput v0, p0, Lcom/google/android/gms/internal/cu;->zt:I

    iput v1, p0, Lcom/google/android/gms/internal/cu;->zv:I

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zn:Z

    new-instance v0, Lcom/google/android/gms/internal/cx;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/cx;-><init>(Lcom/google/android/gms/internal/cx;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/cu;->zx:Lcom/google/android/gms/internal/cx;

    return-void
.end method

.method private canConstantState()Z
    .locals 2

    const/4 v1, 0x1

    #v1=(One);
    iget-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zA:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    if-eqz v0, :cond_1

    move v0, v1

    :goto_0
    #v0=(Boolean);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zB:Z

    iput-boolean v1, p0, Lcom/google/android/gms/internal/cu;->zA:Z

    :cond_0
    iget-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zB:Z

    return v0

    :cond_1
    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .locals 7

    const/4 v1, 0x1

    #v1=(One);
    const/high16 v6, 0x3f80

    #v6=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    iget v2, p0, Lcom/google/android/gms/internal/cu;->zo:I

    #v2=(Integer);
    packed-switch v2, :pswitch_data_0

    :cond_0
    :goto_0
    #v0=(Integer);v1=(Boolean);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move v0, v1

    :goto_1
    #v0=(Boolean);v1=(PosByte);v2=(Conflicted);
    iget v1, p0, Lcom/google/android/gms/internal/cu;->zv:I

    #v1=(Integer);
    iget-boolean v2, p0, Lcom/google/android/gms/internal/cu;->zn:Z

    #v2=(Boolean);
    iget-object v3, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v3=(Reference);
    iget-object v4, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    #v4=(Reference);
    if-eqz v0, :cond_6

    if-eqz v2, :cond_1

    if-nez v1, :cond_2

    :cond_1
    invoke-virtual {v3, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_2
    iget v0, p0, Lcom/google/android/gms/internal/cu;->zt:I

    #v0=(Integer);
    if-ne v1, v0, :cond_3

    iget v0, p0, Lcom/google/android/gms/internal/cu;->zt:I

    invoke-virtual {v4, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    invoke-virtual {v4, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_3
    :goto_2
    return-void

    :pswitch_0
    #v0=(Null);v1=(One);v2=(Integer);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    iput-wide v1, p0, Lcom/google/android/gms/internal/cu;->zp:J

    const/4 v1, 0x2

    #v1=(PosByte);
    iput v1, p0, Lcom/google/android/gms/internal/cu;->zo:I

    goto :goto_1

    :pswitch_1
    #v1=(One);v2=(Integer);
    iget-wide v2, p0, Lcom/google/android/gms/internal/cu;->zp:J

    #v2=(LongLo);v3=(LongHi);
    const-wide/16 v4, 0x0

    #v4=(LongLo);v5=(LongHi);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-ltz v2, :cond_0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    #v2=(LongLo);
    iget-wide v4, p0, Lcom/google/android/gms/internal/cu;->zp:J

    sub-long/2addr v2, v4

    long-to-float v2, v2

    #v2=(Float);
    iget v3, p0, Lcom/google/android/gms/internal/cu;->zu:I

    #v3=(Integer);
    int-to-float v3, v3

    #v3=(Float);
    div-float/2addr v2, v3

    cmpl-float v3, v2, v6

    #v3=(Byte);
    if-ltz v3, :cond_5

    :goto_3
    #v1=(Boolean);
    if-eqz v1, :cond_4

    iput v0, p0, Lcom/google/android/gms/internal/cu;->zo:I

    :cond_4
    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v0

    #v0=(Float);
    iget v2, p0, Lcom/google/android/gms/internal/cu;->zq:I

    #v2=(Integer);
    int-to-float v2, v2

    #v2=(Float);
    iget v3, p0, Lcom/google/android/gms/internal/cu;->zr:I

    #v3=(Integer);
    iget v4, p0, Lcom/google/android/gms/internal/cu;->zq:I

    #v4=(Integer);
    sub-int/2addr v3, v4

    int-to-float v3, v3

    #v3=(Float);
    mul-float/2addr v0, v3

    add-float/2addr v0, v2

    float-to-int v0, v0

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/internal/cu;->zv:I

    goto :goto_0

    :cond_5
    #v0=(Null);v1=(One);v3=(Byte);v4=(LongLo);
    move v1, v0

    #v1=(Null);
    goto :goto_3

    :cond_6
    #v0=(Boolean);v1=(Integer);v2=(Boolean);v3=(Reference);v4=(Reference);v5=(Conflicted);
    if-eqz v2, :cond_7

    iget v0, p0, Lcom/google/android/gms/internal/cu;->zt:I

    #v0=(Integer);
    sub-int/2addr v0, v1

    invoke-virtual {v3, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_7
    invoke-virtual {v3, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    if-eqz v2, :cond_8

    iget v0, p0, Lcom/google/android/gms/internal/cu;->zt:I

    invoke-virtual {v3, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_8
    if-lez v1, :cond_9

    invoke-virtual {v4, v1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    invoke-virtual {v4, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    iget v0, p0, Lcom/google/android/gms/internal/cu;->zt:I

    invoke-virtual {v4, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_9
    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->invalidateSelf()V

    goto :goto_2

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public final gA()V
    .locals 2

    const/4 v1, 0x0

    #v1=(Null);
    iput v1, p0, Lcom/google/android/gms/internal/cu;->zq:I

    iget v0, p0, Lcom/google/android/gms/internal/cu;->zt:I

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/internal/cu;->zr:I

    iput v1, p0, Lcom/google/android/gms/internal/cu;->zv:I

    const/16 v0, 0xfa

    #v0=(PosShort);
    iput v0, p0, Lcom/google/android/gms/internal/cu;->zu:I

    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/google/android/gms/internal/cu;->zo:I

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->invalidateSelf()V

    return-void
.end method

.method public final getChangingConfigurations()I
    .locals 2

    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result v0

    #v0=(Integer);
    iget-object v1, p0, Lcom/google/android/gms/internal/cu;->zx:Lcom/google/android/gms/internal/cx;

    #v1=(Reference);
    iget v1, v1, Lcom/google/android/gms/internal/cx;->zG:I

    #v1=(Integer);
    or-int/2addr v0, v1

    iget-object v1, p0, Lcom/google/android/gms/internal/cu;->zx:Lcom/google/android/gms/internal/cx;

    #v1=(Reference);
    iget v1, v1, Lcom/google/android/gms/internal/cx;->zH:I

    #v1=(Integer);
    or-int/2addr v0, v1

    return v0
.end method

.method public final getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;
    .locals 2

    invoke-direct {p0}, Lcom/google/android/gms/internal/cu;->canConstantState()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zx:Lcom/google/android/gms/internal/cx;

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->getChangingConfigurations()I

    move-result v1

    #v1=(Integer);
    iput v1, v0, Lcom/google/android/gms/internal/cx;->zG:I

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zx:Lcom/google/android/gms/internal/cx;

    :goto_0
    #v1=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Boolean);v1=(Uninit);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final getIntrinsicHeight()I
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    #v0=(Integer);
    iget-object v1, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    #v1=(Reference);
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v1

    #v1=(Integer);
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method public final getIntrinsicWidth()I
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    #v0=(Integer);
    iget-object v1, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    #v1=(Reference);
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v1

    #v1=(Integer);
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method public final getOpacity()I
    .locals 2

    iget-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zC:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getOpacity()I

    move-result v0

    #v0=(Integer);
    iget-object v1, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    #v1=(Reference);
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getOpacity()I

    move-result v1

    #v1=(Integer);
    invoke-static {v0, v1}, Landroid/graphics/drawable/Drawable;->resolveOpacity(II)I

    move-result v0

    iput v0, p0, Lcom/google/android/gms/internal/cu;->zD:I

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zC:Z

    :cond_0
    #v0=(Boolean);v1=(Conflicted);
    iget v0, p0, Lcom/google/android/gms/internal/cu;->zD:I

    #v0=(Integer);
    return v0
.end method

.method public final gz()Landroid/graphics/drawable/Drawable;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    return-object v0
.end method

.method public final invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    invoke-static {}, Lcom/google/android/gms/internal/ai;->dZ()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    #v0=(Reference);
    if-eqz v0, :cond_0

    invoke-interface {v0, p0}, Landroid/graphics/drawable/Drawable$Callback;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    #v0=(Conflicted);
    return-void
.end method

.method public final mutate()Landroid/graphics/drawable/Drawable;
    .locals 2

    iget-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zw:Z

    #v0=(Boolean);
    if-nez v0, :cond_1

    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    #v0=(Reference);
    if-ne v0, p0, :cond_1

    invoke-direct {p0}, Lcom/google/android/gms/internal/cu;->canConstantState()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "One or more children of this LayerDrawable does not have constant state; this drawable cannot be mutated."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_0
    #v0=(Boolean);v1=(Uninit);
    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/cu;->zw:Z

    :cond_1
    #v0=(Conflicted);
    return-object p0
.end method

.method protected final onBoundsChange(Landroid/graphics/Rect;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    return-void
.end method

.method public final scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .locals 1

    invoke-static {}, Lcom/google/android/gms/internal/ai;->dZ()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    #v0=(Reference);
    if-eqz v0, :cond_0

    invoke-interface {v0, p0, p2, p3, p4}, Landroid/graphics/drawable/Drawable$Callback;->scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V

    :cond_0
    #v0=(Conflicted);
    return-void
.end method

.method public final setAlpha(I)V
    .locals 2

    iget v0, p0, Lcom/google/android/gms/internal/cu;->zv:I

    #v0=(Integer);
    iget v1, p0, Lcom/google/android/gms/internal/cu;->zt:I

    #v1=(Integer);
    if-ne v0, v1, :cond_0

    iput p1, p0, Lcom/google/android/gms/internal/cu;->zv:I

    :cond_0
    iput p1, p0, Lcom/google/android/gms/internal/cu;->zt:I

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->invalidateSelf()V

    return-void
.end method

.method public final setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zy:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/cu;->zz:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    return-void
.end method

.method public final unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .locals 1

    invoke-static {}, Lcom/google/android/gms/internal/ai;->dZ()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cu;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    #v0=(Reference);
    if-eqz v0, :cond_0

    invoke-interface {v0, p0, p2}, Landroid/graphics/drawable/Drawable$Callback;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V

    :cond_0
    #v0=(Conflicted);
    return-void
.end method

*/}
