package com.google.android.gms.internal; class cw {/*

.class final Lcom/google/android/gms/internal/cw;
.super Landroid/graphics/drawable/Drawable$ConstantState;


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method synthetic constructor <init>(B)V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/internal/cw;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final getChangingConfigurations()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 1

    invoke-static {}, Lcom/google/android/gms/internal/cv;->gB()Lcom/google/android/gms/internal/cv;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

*/}
