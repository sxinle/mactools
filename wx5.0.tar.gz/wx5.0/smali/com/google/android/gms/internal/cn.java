package com.google.android.gms.internal; class cn {/*

.class public Lcom/google/android/gms/internal/cn;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final vC:Lcom/google/android/gms/internal/av;


# instance fields
.field private final tu:I

.field private final vA:F

.field private final vB:I

.field private final vv:Ljava/lang/String;

.field private final vw:J

.field private final vx:S

.field private final vy:D

.field private final vz:D


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/av;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/av;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/cn;->vC:Lcom/google/android/gms/internal/av;

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;ISDDFJ)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    if-eqz p2, :cond_0

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    const/16 v1, 0x64

    #v1=(PosByte);
    if-le v0, v1, :cond_1

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "requestId is null or too long: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v0=(Integer);v1=(PosByte);v2=(Uninit);
    const/4 v0, 0x0

    #v0=(Null);
    cmpg-float v0, p9, v0

    #v0=(Byte);
    if-gtz v0, :cond_2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "invalid radius: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p9}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_2
    #v0=(Byte);v1=(PosByte);v2=(Uninit);
    const-wide v0, 0x4056800000000000L

    #v0=(LongLo);v1=(LongHi);
    cmpl-double v0, p5, v0

    #v0=(Byte);
    if-gtz v0, :cond_3

    const-wide v0, -0x3fa9800000000000L

    #v0=(LongLo);
    cmpg-double v0, p5, v0

    #v0=(Byte);
    if-gez v0, :cond_4

    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "invalid latitude: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p5, p6}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_4
    #v0=(Byte);v1=(LongHi);v2=(Uninit);
    const-wide v0, 0x4066800000000000L

    #v0=(LongLo);
    cmpl-double v0, p7, v0

    #v0=(Byte);
    if-gtz v0, :cond_5

    const-wide v0, -0x3f99800000000000L

    #v0=(LongLo);
    cmpg-double v0, p7, v0

    #v0=(Byte);
    if-gez v0, :cond_6

    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "invalid longitude: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p7, p8}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_6
    #v0=(Byte);v1=(LongHi);v2=(Uninit);
    and-int/lit8 v0, p3, 0x3

    #v0=(Integer);
    if-nez v0, :cond_7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "No supported transition specified: "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :cond_7
    #v0=(Integer);v1=(LongHi);v2=(Uninit);
    iput p1, p0, Lcom/google/android/gms/internal/cn;->tu:I

    iput-short p4, p0, Lcom/google/android/gms/internal/cn;->vx:S

    iput-object p2, p0, Lcom/google/android/gms/internal/cn;->vv:Ljava/lang/String;

    iput-wide p5, p0, Lcom/google/android/gms/internal/cn;->vy:D

    iput-wide p7, p0, Lcom/google/android/gms/internal/cn;->vz:D

    iput p9, p0, Lcom/google/android/gms/internal/cn;->vA:F

    iput-wide p10, p0, Lcom/google/android/gms/internal/cn;->vw:J

    iput v0, p0, Lcom/google/android/gms/internal/cn;->vB:I

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/cn;->vC:Lcom/google/android/gms/internal/av;

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/cn;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final eg()S
    .locals 1

    iget-short v0, p0, Lcom/google/android/gms/internal/cn;->vx:S

    #v0=(Short);
    return v0
.end method

.method public final eh()F
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/cn;->vA:F

    #v0=(Integer);
    return v0
.end method

.method public final ei()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/cn;->vv:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final ej()J
    .locals 2

    iget-wide v0, p0, Lcom/google/android/gms/internal/cn;->vw:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final ek()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/cn;->vB:I

    #v0=(Integer);
    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    if-ne p0, p1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    :cond_1
    #v0=(One);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    if-nez p1, :cond_2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(One);
    instance-of v2, p1, Lcom/google/android/gms/internal/cn;

    #v2=(Boolean);
    if-nez v2, :cond_3

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_3
    #v0=(One);
    check-cast p1, Lcom/google/android/gms/internal/cn;

    iget v2, p0, Lcom/google/android/gms/internal/cn;->vA:F

    #v2=(Integer);
    iget v3, p1, Lcom/google/android/gms/internal/cn;->vA:F

    #v3=(Integer);
    cmpl-float v2, v2, v3

    #v2=(Byte);
    if-eqz v2, :cond_4

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_4
    #v0=(One);
    iget-wide v2, p0, Lcom/google/android/gms/internal/cn;->vy:D

    #v2=(DoubleLo);v3=(DoubleHi);
    iget-wide v4, p1, Lcom/google/android/gms/internal/cn;->vy:D

    #v4=(DoubleLo);v5=(DoubleHi);
    cmpl-double v2, v2, v4

    #v2=(Byte);
    if-eqz v2, :cond_5

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_5
    #v0=(One);
    iget-wide v2, p0, Lcom/google/android/gms/internal/cn;->vz:D

    #v2=(DoubleLo);
    iget-wide v4, p1, Lcom/google/android/gms/internal/cn;->vz:D

    cmpl-double v2, v2, v4

    #v2=(Byte);
    if-eqz v2, :cond_6

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_6
    #v0=(One);
    iget-short v2, p0, Lcom/google/android/gms/internal/cn;->vx:S

    #v2=(Short);
    iget-short v3, p1, Lcom/google/android/gms/internal/cn;->vx:S

    #v3=(Short);
    if-eq v2, v3, :cond_0

    move v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public final getLatitude()D
    .locals 2

    iget-wide v0, p0, Lcom/google/android/gms/internal/cn;->vy:D

    #v0=(DoubleLo);v1=(DoubleHi);
    return-wide v0
.end method

.method public final getLongitude()D
    .locals 2

    iget-wide v0, p0, Lcom/google/android/gms/internal/cn;->vz:D

    #v0=(DoubleLo);v1=(DoubleHi);
    return-wide v0
.end method

.method public hashCode()I
    .locals 5

    const/16 v4, 0x20

    #v4=(PosByte);
    iget-wide v0, p0, Lcom/google/android/gms/internal/cn;->vy:D

    #v0=(DoubleLo);v1=(DoubleHi);
    invoke-static {v0, v1}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    ushr-long v2, v0, v4

    #v2=(LongLo);v3=(LongHi);
    xor-long/2addr v0, v2

    long-to-int v0, v0

    #v0=(Integer);
    add-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lcom/google/android/gms/internal/cn;->vz:D

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    mul-int/lit8 v0, v0, 0x1f

    ushr-long v3, v1, v4

    #v3=(LongLo);v4=(LongHi);
    xor-long/2addr v1, v3

    long-to-int v1, v1

    #v1=(Integer);
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/google/android/gms/internal/cn;->vA:F

    invoke-static {v1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-short v1, p0, Lcom/google/android/gms/internal/cn;->vx:S

    #v1=(Short);
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/google/android/gms/internal/cn;->vB:I

    #v1=(Integer);
    add-int/2addr v0, v1

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const-string v1, "Geofence[%s id:%s transitions:%d %.6f, %.6f %.0fm, @%d]"

    #v1=(Reference);
    const/4 v0, 0x7

    #v0=(PosByte);
    new-array v2, v0, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    iget-short v0, p0, Lcom/google/android/gms/internal/cn;->vx:S

    #v0=(Short);
    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    aput-object v0, v2, v3

    const/4 v0, 0x1

    #v0=(One);
    iget-object v3, p0, Lcom/google/android/gms/internal/cn;->vv:Ljava/lang/String;

    #v3=(Reference);
    aput-object v3, v2, v0

    const/4 v0, 0x2

    #v0=(PosByte);
    iget v3, p0, Lcom/google/android/gms/internal/cn;->vB:I

    #v3=(Integer);
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    #v3=(Reference);
    aput-object v3, v2, v0

    const/4 v0, 0x3

    iget-wide v3, p0, Lcom/google/android/gms/internal/cn;->vy:D

    #v3=(DoubleLo);v4=(DoubleHi);
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    #v3=(Reference);
    aput-object v3, v2, v0

    const/4 v0, 0x4

    iget-wide v3, p0, Lcom/google/android/gms/internal/cn;->vz:D

    #v3=(DoubleLo);
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    #v3=(Reference);
    aput-object v3, v2, v0

    const/4 v0, 0x5

    iget v3, p0, Lcom/google/android/gms/internal/cn;->vA:F

    #v3=(Integer);
    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    #v3=(Reference);
    aput-object v3, v2, v0

    const/4 v0, 0x6

    iget-wide v3, p0, Lcom/google/android/gms/internal/cn;->vw:J

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    #v3=(Reference);
    aput-object v3, v2, v0

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0

    :pswitch_0
    #v0=(Short);v3=(Null);v4=(Uninit);
    const-string v0, "CIRCLE"

    #v0=(Reference);
    goto :goto_0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/cn;->vC:Lcom/google/android/gms/internal/av;

    #v0=(Reference);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/av;->a(Lcom/google/android/gms/internal/cn;Landroid/os/Parcel;)V

    return-void
.end method

*/}
