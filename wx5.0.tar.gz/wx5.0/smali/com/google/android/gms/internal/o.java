package com.google.android.gms.internal; class o {/*

.class public final Lcom/google/android/gms/internal/o;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/os/Parcel;I)I
    .locals 2

    const/high16 v1, -0x1

    #v1=(Integer);
    and-int v0, p1, v1

    #v0=(Integer);
    if-eq v0, v1, :cond_0

    shr-int/lit8 v0, p1, 0x10

    #v0=(Short);
    const v1, 0xffff

    #v1=(Char);
    and-int/2addr v0, v1

    :goto_0
    #v0=(Integer);v1=(Integer);
    return v0

    :cond_0
    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    goto :goto_0
.end method

.method public static a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-interface {p2, p0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/os/Parcelable;

    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method private static a(Landroid/os/Parcel;II)V
    .locals 4

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    if-eq v0, p2, :cond_0

    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Expected size "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " got "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " (0x"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ")"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0, p0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_0
    #v0=(Integer);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    return-void
.end method

.method public static b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-virtual {p0, p2}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static b(Landroid/os/Parcel;I)V
    .locals 2

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    #v1=(Integer);
    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    return-void
.end method

.method public static c(Landroid/os/Parcel;I)Z
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public static d(Landroid/os/Parcel;I)B
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    int-to-byte v0, v0

    #v0=(Byte);
    return v0
.end method

.method public static e(Landroid/os/Parcel;I)S
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    int-to-short v0, v0

    #v0=(Short);
    return v0
.end method

.method public static f(Landroid/os/Parcel;)I
    .locals 5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    const v3, 0xffff

    #v3=(Char);
    and-int/2addr v3, v0

    #v3=(Integer);
    const/16 v4, 0x4f45

    #v4=(PosShort);
    if-eq v3, v4, :cond_0

    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Expected object header. Got 0x"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0, p0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_0
    #v0=(Integer);v1=(Integer);v2=(Integer);v3=(Integer);
    add-int v0, v2, v1

    if-lt v0, v2, :cond_1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataSize()I

    move-result v1

    if-le v0, v1, :cond_2

    :cond_1
    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "Size read is invalid start="

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    #v2=(Reference);
    const-string v3, " end="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0, p0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_2
    #v0=(Integer);v1=(Integer);v2=(Integer);v3=(Integer);v4=(PosShort);
    return v0
.end method

.method public static f(Landroid/os/Parcel;I)I
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public static g(Landroid/os/Parcel;I)J
    .locals 2

    const/16 v0, 0x8

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public static h(Landroid/os/Parcel;I)Ljava/math/BigInteger;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    #v1=(Integer);
    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v2=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Integer);v2=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v2

    #v2=(Reference);
    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    new-instance v0, Ljava/math/BigInteger;

    #v0=(UninitRef);
    invoke-direct {v0, v2}, Ljava/math/BigInteger;-><init>([B)V

    #v0=(Reference);
    goto :goto_0
.end method

.method public static i(Landroid/os/Parcel;I)F
    .locals 1

    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Landroid/os/Parcel;->readFloat()F

    move-result v0

    #v0=(Float);
    return v0
.end method

.method public static j(Landroid/os/Parcel;I)D
    .locals 2

    const/16 v0, 0x8

    #v0=(PosByte);
    invoke-static {p0, p1, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;II)V

    invoke-virtual {p0}, Landroid/os/Parcel;->readDouble()D

    move-result-wide v0

    #v0=(DoubleLo);v1=(DoubleHi);
    return-wide v0
.end method

.method public static k(Landroid/os/Parcel;I)Ljava/math/BigDecimal;
    .locals 4

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    #v1=(Integer);
    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Integer);v1=(Integer);v2=(Uninit);v3=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v3

    #v3=(Integer);
    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    new-instance v0, Ljava/math/BigDecimal;

    #v0=(UninitRef);
    new-instance v1, Ljava/math/BigInteger;

    #v1=(UninitRef);
    invoke-direct {v1, v2}, Ljava/math/BigInteger;-><init>([B)V

    #v1=(Reference);
    invoke-direct {v0, v1, v3}, Ljava/math/BigDecimal;-><init>(Ljava/math/BigInteger;I)V

    #v0=(Reference);
    goto :goto_0
.end method

.method public static l(Landroid/os/Parcel;I)Ljava/lang/String;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static m(Landroid/os/Parcel;I)Landroid/os/IBinder;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static n(Landroid/os/Parcel;I)Landroid/os/Bundle;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static o(Landroid/os/Parcel;I)[B
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static p(Landroid/os/Parcel;I)[Ljava/math/BigDecimal;
    .locals 9

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v3

    #v3=(Integer);
    if-nez v2, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Uninit);v1=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    #v4=(Integer);
    new-array v0, v4, [Ljava/math/BigDecimal;

    #v0=(Reference);
    const/4 v1, 0x0

    :goto_1
    #v1=(Integer);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    if-ge v1, v4, :cond_1

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v5

    #v5=(Reference);
    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v6

    #v6=(Integer);
    new-instance v7, Ljava/math/BigDecimal;

    #v7=(UninitRef);
    new-instance v8, Ljava/math/BigInteger;

    #v8=(UninitRef);
    invoke-direct {v8, v5}, Ljava/math/BigInteger;-><init>([B)V

    #v8=(Reference);
    invoke-direct {v7, v8, v6}, Ljava/math/BigDecimal;-><init>(Ljava/math/BigInteger;I)V

    #v7=(Reference);
    aput-object v7, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_1
    #v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    add-int v1, v3, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static q(Landroid/os/Parcel;I)[Ljava/lang/String;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static r(Landroid/os/Parcel;I)Landroid/os/Parcel;
    .locals 3

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-nez v1, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Uninit);
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p0, v2, v1}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    add-int/2addr v1, v2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_0
.end method

.method public static s(Landroid/os/Parcel;I)[Landroid/os/Parcel;
    .locals 9

    const/4 v0, 0x0

    #v0=(Null);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v3

    #v3=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v4

    #v4=(Integer);
    if-nez v3, :cond_0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Null);v1=(Uninit);v2=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    #v5=(Integer);
    new-array v1, v5, [Landroid/os/Parcel;

    #v1=(Reference);
    const/4 v2, 0x0

    :goto_1
    #v2=(Integer);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    if-ge v2, v5, :cond_2

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v6

    #v6=(Integer);
    if-eqz v6, :cond_1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v7

    #v7=(Integer);
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v8

    #v8=(Reference);
    invoke-virtual {v8, p0, v7, v6}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    aput-object v8, v1, v2

    add-int/2addr v6, v7

    invoke-virtual {p0, v6}, Landroid/os/Parcel;->setDataPosition(I)V

    :goto_2
    #v7=(Conflicted);v8=(Conflicted);
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    aput-object v0, v1, v2

    goto :goto_2

    :cond_2
    #v6=(Conflicted);
    add-int v0, v4, v3

    #v0=(Integer);
    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    move-object v0, v1

    #v0=(Reference);
    goto :goto_0
.end method

*/}
