package com.google.android.gms.internal; class cf {/*

.class public final Lcom/google/android/gms/internal/cf;
.super Lcom/google/android/gms/internal/co;

# interfaces
.implements Lcom/google/android/gms/games/multiplayer/Participant;


# instance fields
.field private final vt:Lcom/google/android/gms/internal/bm;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/l;I)V
    .locals 1

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/co;-><init>(Lcom/google/android/gms/internal/l;I)V

    #p0=(Reference);
    new-instance v0, Lcom/google/android/gms/internal/bm;

    #v0=(UninitRef);
    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/internal/bm;-><init>(Lcom/google/android/gms/internal/l;I)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/cf;->vt:Lcom/google/android/gms/internal/bm;

    return-void
.end method

.method private ee()Lcom/google/android/gms/games/multiplayer/Participant;
    .locals 1

    new-instance v0, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;-><init>(Lcom/google/android/gms/games/multiplayer/Participant;)V

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final synthetic cP()Ljava/lang/Object;
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/cf;->ee()Lcom/google/android/gms/games/multiplayer/Participant;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final cW()Landroid/net/Uri;
    .locals 1

    const-string v0, "external_player_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->Q(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const-string v0, "default_display_image_uri"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->P(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    #v0=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/internal/cf;->vt:Lcom/google/android/gms/internal/bm;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/google/android/gms/internal/bm;->cW()Landroid/net/Uri;

    move-result-object v0

    goto :goto_0
.end method

.method public final cX()Landroid/net/Uri;
    .locals 1

    const-string v0, "external_player_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->Q(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/internal/cf;->vt:Lcom/google/android/gms/internal/bm;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/google/android/gms/internal/bm;->cX()Landroid/net/Uri;

    move-result-object v0

    goto :goto_0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final dq()Ljava/lang/String;
    .locals 1

    const-string v0, "client_address"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final dr()I
    .locals 1

    const-string v0, "capabilities"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final ds()Z
    .locals 1

    const-string v0, "connected"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final dt()Ljava/lang/String;
    .locals 1

    const-string v0, "external_participant_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final du()Lcom/google/android/gms/games/Player;
    .locals 1

    const-string v0, "external_player_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->Q(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/internal/cf;->vt:Lcom/google/android/gms/internal/bm;

    #v0=(Reference);
    goto :goto_0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p0, p1}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->a(Lcom/google/android/gms/games/multiplayer/Participant;Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final getDisplayName()Ljava/lang/String;
    .locals 1

    const-string v0, "external_player_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->Q(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const-string v0, "default_display_name"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    #v0=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/internal/cf;->vt:Lcom/google/android/gms/internal/bm;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/google/android/gms/internal/bm;->getDisplayName()Ljava/lang/String;

    move-result-object v0

    goto :goto_0
.end method

.method public final getStatus()I
    .locals 1

    const-string v0, "player_status"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/cf;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->a(Lcom/google/android/gms/games/multiplayer/Participant;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->b(Lcom/google/android/gms/games/multiplayer/Participant;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/cf;->ee()Lcom/google/android/gms/games/multiplayer/Participant;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/games/multiplayer/ParticipantEntity;->writeToParcel(Landroid/os/Parcel;I)V

    return-void
.end method

*/}
