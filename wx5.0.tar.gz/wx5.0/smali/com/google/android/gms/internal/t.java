package com.google.android.gms.internal; class t {/*

.class public abstract Lcom/google/android/gms/internal/t;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field private static final zK:Ljava/lang/Object;

.field private static zL:Ljava/lang/ClassLoader;

.field private static zM:Ljava/lang/Integer;


# instance fields
.field private zN:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    #v1=(Null);
    new-instance v0, Ljava/lang/Object;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/t;->zK:Ljava/lang/Object;

    sput-object v1, Lcom/google/android/gms/internal/t;->zL:Ljava/lang/ClassLoader;

    sput-object v1, Lcom/google/android/gms/internal/t;->zM:Ljava/lang/Integer;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/t;->zN:Z

    return-void
.end method

.method protected static R(Ljava/lang/String;)Z
    .locals 1

    invoke-static {}, Lcom/google/android/gms/internal/t;->gD()Ljava/lang/ClassLoader;

    move-result-object v0

    #v0=(Reference);
    if-nez v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    :try_start_0
    #v0=(Reference);
    invoke-virtual {v0, p0}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/internal/t;->b(Ljava/lang/Class;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    #v0=(Boolean);
    goto :goto_0

    :catch_0
    #v0=(Reference);
    move-exception v0

    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method private static b(Ljava/lang/Class;)Z
    .locals 4

    const/4 v0, 0x0

    :try_start_0
    #v0=(Null);
    const-string v1, "NULL"

    #v1=(Reference);
    invoke-virtual {p0, v1}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    const-string v2, "SAFE_PARCELABLE_NULL_STRING"

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {v1, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    :catch_0
    #v0=(Null);v1=(Conflicted);
    move-exception v1

    #v1=(Reference);
    goto :goto_0

    :catch_1
    #v1=(Conflicted);
    move-exception v1

    #v1=(Reference);
    goto :goto_0
.end method

.method private static gD()Ljava/lang/ClassLoader;
    .locals 2

    sget-object v1, Lcom/google/android/gms/internal/t;->zK:Ljava/lang/Object;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    sget-object v0, Lcom/google/android/gms/internal/t;->zL:Ljava/lang/ClassLoader;

    #v0=(Reference);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method protected static gE()Ljava/lang/Integer;
    .locals 2

    sget-object v1, Lcom/google/android/gms/internal/t;->zK:Ljava/lang/Object;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    sget-object v0, Lcom/google/android/gms/internal/t;->zM:Ljava/lang/Integer;

    #v0=(Reference);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method


# virtual methods
.method protected final gF()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/t;->zN:Z

    #v0=(Boolean);
    return v0
.end method

*/}
