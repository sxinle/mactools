package com.google.android.gms.internal; class en {/*

.class public Lcom/google/android/gms/internal/en;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final wp:Lcom/google/android/gms/internal/bt;


# instance fields
.field private final tu:I

.field private final tz:Ljava/lang/String;

.field private final wq:Ljava/util/ArrayList;

.field private final wr:Ljava/util/ArrayList;

.field private final ws:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/bt;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/bt;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/en;->wp:Lcom/google/android/gms/internal/bt;

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/en;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/internal/en;->tz:Ljava/lang/String;

    iput-object p3, p0, Lcom/google/android/gms/internal/en;->wq:Ljava/util/ArrayList;

    iput-object p4, p0, Lcom/google/android/gms/internal/en;->wr:Ljava/util/ArrayList;

    iput-boolean p5, p0, Lcom/google/android/gms/internal/en;->ws:Z

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/en;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final eA()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/en;->wq:Ljava/util/ArrayList;

    #v0=(Reference);
    return-object v0
.end method

.method public final eB()Ljava/util/ArrayList;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/en;->wr:Ljava/util/ArrayList;

    #v0=(Reference);
    return-object v0
.end method

.method public final eC()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/en;->ws:Z

    #v0=(Boolean);
    return v0
.end method

.method public final getDescription()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/en;->tz:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/bt;->a(Lcom/google/android/gms/internal/en;Landroid/os/Parcel;)V

    return-void
.end method

*/}
