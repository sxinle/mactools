package com.google.android.gms.internal; class bd {/*

.class public final Lcom/google/android/gms/internal/bd;
.super Landroid/widget/ImageView;

# interfaces
.implements Lcom/google/android/gms/common/c;
.implements Lcom/google/android/gms/plus/b;


# instance fields
.field private tl:Landroid/net/Uri;

.field private tq:Landroid/graphics/Bitmap;

.field private vM:I

.field private vN:Z

.field private vO:Z

.field private vP:Lcom/google/android/gms/plus/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final a(Landroid/net/Uri;I)V
    .locals 4

    const/4 v1, 0x1

    #v1=(One);
    const/4 v2, 0x0

    #v2=(Null);
    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    #v0=(Reference);
    if-nez v0, :cond_2

    if-nez p1, :cond_1

    move v0, v1

    :goto_0
    #v0=(Boolean);
    iget v3, p0, Lcom/google/android/gms/internal/bd;->vM:I

    #v3=(Integer);
    if-ne v3, p2, :cond_3

    move v3, v1

    :goto_1
    #v3=(Boolean);
    if-eqz v0, :cond_4

    if-eqz v3, :cond_4

    :cond_0
    :goto_2
    #v0=(Conflicted);v1=(Integer);v3=(Conflicted);
    return-void

    :cond_1
    #v0=(Reference);v1=(One);v3=(Uninit);
    move v0, v2

    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(Reference);
    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    invoke-virtual {v0, p1}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0

    :cond_3
    #v3=(Integer);
    move v3, v2

    #v3=(Null);
    goto :goto_1

    :cond_4
    #v3=(Boolean);
    iput-object p1, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    iput p2, p0, Lcom/google/android/gms/internal/bd;->vM:I

    iput-boolean v1, p0, Lcom/google/android/gms/internal/bd;->vO:Z

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    #v0=(Reference);
    if-eqz v0, :cond_5

    const-string v0, "android.resource"

    iget-object v3, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    #v3=(Reference);
    invoke-virtual {v3}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_5

    :goto_3
    #v0=(Conflicted);v1=(Boolean);v3=(Conflicted);
    iget-boolean v0, p0, Lcom/google/android/gms/internal/bd;->vO:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    #v0=(Reference);
    if-nez v0, :cond_6

    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bd;->setImageBitmap(Landroid/graphics/Bitmap;)V

    goto :goto_2

    :cond_5
    #v0=(Conflicted);v1=(One);
    move v1, v2

    #v1=(Null);
    goto :goto_3

    :cond_6
    #v0=(Reference);v1=(Boolean);
    if-nez v1, :cond_7

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    invoke-virtual {v0}, Lcom/google/android/gms/plus/a;->isConnected()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    :cond_7
    #v0=(Conflicted);
    if-eqz v1, :cond_8

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bd;->setImageURI(Landroid/net/Uri;)V

    :goto_4
    #v1=(Integer);
    iput-boolean v2, p0, Lcom/google/android/gms/internal/bd;->vO:Z

    goto :goto_2

    :cond_8
    #v0=(Conflicted);v1=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    iget-object v1, p0, Lcom/google/android/gms/internal/bd;->tl:Landroid/net/Uri;

    #v1=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/bd;->vM:I

    #v1=(Integer);
    invoke-virtual {v0, p0, v1}, Lcom/google/android/gms/plus/a;->a(Lcom/google/android/gms/plus/b;I)V

    goto :goto_4
.end method

.method protected final onAttachedToWindow()V
    .locals 1

    invoke-super {p0}, Landroid/widget/ImageView;->onAttachedToWindow()V

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/bd;->vN:Z

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->b(Lcom/google/android/gms/common/c;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->a(Lcom/google/android/gms/common/c;)V

    :cond_0
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->tq:Landroid/graphics/Bitmap;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->tq:Landroid/graphics/Bitmap;

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bd;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_1
    return-void
.end method

.method protected final onDetachedFromWindow()V
    .locals 1

    invoke-super {p0}, Landroid/widget/ImageView;->onDetachedFromWindow()V

    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/bd;->vN:Z

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->b(Lcom/google/android/gms/common/c;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/bd;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->c(Lcom/google/android/gms/common/c;)V

    :cond_0
    #v0=(Conflicted);
    return-void
.end method

*/}
