package com.google.android.gms.internal; class bw {/*

.class public final Lcom/google/android/gms/internal/bw;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/internal/eu;Landroid/os/Parcel;I)V
    .locals 8

    const/4 v7, 0x5

    #v7=(PosByte);
    const/4 v6, 0x4

    #v6=(PosByte);
    const/4 v5, 0x3

    #v5=(PosByte);
    const/4 v3, 0x2

    #v3=(PosByte);
    const/4 v4, 0x1

    #v4=(One);
    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->eD()Ljava/util/Set;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v4, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    :cond_0
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fz()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v3, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_1
    #v2=(Conflicted);
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_2

    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fA()Lcom/google/android/gms/internal/eu$a;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v5, v2, p2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    :cond_2
    #v2=(Conflicted);
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fB()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v6, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_3
    #v2=(Conflicted);
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fC()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {p1, v7, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_4
    #v2=(Conflicted);
    const/4 v2, 0x6

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_5

    const/4 v2, 0x6

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fD()I

    move-result v3

    #v3=(Integer);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    :cond_5
    const/4 v2, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_6

    const/4 v2, 0x7

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fE()Lcom/google/android/gms/internal/eu$b;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, p2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    :cond_6
    #v3=(Conflicted);
    const/16 v2, 0x8

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_7

    const/16 v2, 0x8

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fF()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_7
    #v3=(Conflicted);
    const/16 v2, 0x9

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_8

    const/16 v2, 0x9

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->getDisplayName()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_8
    #v3=(Conflicted);
    const/16 v2, 0xa

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_9

    const/16 v2, 0xa

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fG()Ljava/util/List;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    :cond_9
    #v3=(Conflicted);
    const/16 v2, 0xc

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_a

    const/16 v2, 0xc

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fH()I

    move-result v3

    #v3=(Integer);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    :cond_a
    #v3=(Conflicted);
    const/16 v2, 0xe

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_b

    const/16 v2, 0xe

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->getId()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_b
    #v3=(Conflicted);
    const/16 v2, 0xf

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_c

    const/16 v2, 0xf

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fI()Lcom/google/android/gms/internal/eu$d;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, p2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    :cond_c
    #v3=(Conflicted);
    const/16 v2, 0x10

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_d

    const/16 v2, 0x10

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fJ()Z

    move-result v3

    #v3=(Boolean);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    :cond_d
    #v3=(Conflicted);
    const/16 v2, 0x13

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_e

    const/16 v2, 0x13

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fK()Lcom/google/android/gms/internal/eu$e;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, p2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    :cond_e
    #v3=(Conflicted);
    const/16 v2, 0x12

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_f

    const/16 v2, 0x12

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->getLanguage()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_f
    #v3=(Conflicted);
    const/16 v2, 0x15

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_10

    const/16 v2, 0x15

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fM()I

    move-result v3

    #v3=(Integer);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    :cond_10
    #v3=(Conflicted);
    const/16 v2, 0x14

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_11

    const/16 v2, 0x14

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fL()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_11
    #v3=(Conflicted);
    const/16 v2, 0x17

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_12

    const/16 v2, 0x17

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fO()Ljava/util/List;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    :cond_12
    #v3=(Conflicted);
    const/16 v2, 0x16

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_13

    const/16 v2, 0x16

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fN()Ljava/util/List;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    :cond_13
    #v3=(Conflicted);
    const/16 v2, 0x19

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_14

    const/16 v2, 0x19

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fQ()I

    move-result v3

    #v3=(Integer);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    :cond_14
    #v3=(Conflicted);
    const/16 v2, 0x18

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_15

    const/16 v2, 0x18

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fP()I

    move-result v3

    #v3=(Integer);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    :cond_15
    #v3=(Conflicted);
    const/16 v2, 0x1b

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_16

    const/16 v2, 0x1b

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->getUrl()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_16
    #v3=(Conflicted);
    const/16 v2, 0x1a

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_17

    const/16 v2, 0x1a

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fR()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-static {p1, v2, v3, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    :cond_17
    #v3=(Conflicted);
    const/16 v2, 0x1d

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_18

    const/16 v2, 0x1d

    #v2=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fT()Z

    move-result v3

    #v3=(Boolean);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IZ)V

    :cond_18
    #v3=(Conflicted);
    const/16 v2, 0x1c

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_19

    const/16 v1, 0x1c

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/eu;->fS()Ljava/util/List;

    move-result-object v2

    invoke-static {p1, v1, v2, v4}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    :cond_19
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 32

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v30

    #v30=(Integer);
    new-instance v3, Ljava/util/HashSet;

    #v3=(UninitRef);
    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    #v3=(Reference);
    const/4 v4, 0x0

    #v4=(Null);
    const/4 v5, 0x0

    #v5=(Null);
    const/4 v6, 0x0

    #v6=(Null);
    const/4 v7, 0x0

    #v7=(Null);
    const/4 v8, 0x0

    #v8=(Null);
    const/4 v9, 0x0

    #v9=(Null);
    const/4 v10, 0x0

    #v10=(Null);
    const/4 v11, 0x0

    #v11=(Null);
    const/4 v12, 0x0

    #v12=(Null);
    const/4 v13, 0x0

    #v13=(Null);
    const/4 v14, 0x0

    #v14=(Null);
    const/4 v15, 0x0

    #v15=(Null);
    const/16 v16, 0x0

    #v16=(Null);
    const/16 v17, 0x0

    #v17=(Null);
    const/16 v18, 0x0

    #v18=(Null);
    const/16 v19, 0x0

    #v19=(Null);
    const/16 v20, 0x0

    #v20=(Null);
    const/16 v21, 0x0

    #v21=(Null);
    const/16 v22, 0x0

    #v22=(Null);
    const/16 v23, 0x0

    #v23=(Null);
    const/16 v24, 0x0

    #v24=(Null);
    const/16 v25, 0x0

    #v25=(Null);
    const/16 v26, 0x0

    #v26=(Null);
    const/16 v27, 0x0

    #v27=(Null);
    const/16 v28, 0x0

    #v28=(Null);
    const/16 v29, 0x0

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v4=(Integer);v5=(Reference);v6=(Reference);v7=(Reference);v8=(Reference);v9=(Integer);v10=(Reference);v11=(Reference);v12=(Reference);v13=(Reference);v14=(Integer);v15=(Reference);v16=(Reference);v17=(Boolean);v18=(Reference);v19=(Reference);v20=(Reference);v21=(Integer);v22=(Reference);v23=(Reference);v24=(Integer);v25=(Integer);v26=(Reference);v27=(Reference);v28=(Reference);v29=(Boolean);v31=(Conflicted);
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    move/from16 v0, v30

    #v0=(Integer);
    if-ge v2, v0, :cond_0

    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const v31, 0xffff

    #v31=(Char);
    and-int v31, v31, v2

    #v31=(Integer);
    packed-switch v31, :pswitch_data_0

    :pswitch_0
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :pswitch_1
    #v0=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v4

    const/4 v2, 0x1

    #v2=(One);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_2
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v5

    const/4 v2, 0x2

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_3
    #v0=(Integer);v2=(Integer);
    sget-object v6, Lcom/google/android/gms/internal/eu$a;->xU:Lcom/google/android/gms/internal/bx;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2, v6}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v2

    #v2=(Reference);
    check-cast v2, Lcom/google/android/gms/internal/eu$a;

    const/4 v6, 0x3

    #v6=(PosByte);
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    #v6=(Reference);
    invoke-interface {v3, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object v6, v2

    goto :goto_0

    :pswitch_4
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v7

    const/4 v2, 0x4

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_5
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v8

    const/4 v2, 0x5

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_6
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v9

    const/4 v2, 0x6

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :pswitch_7
    #v0=(Integer);v2=(Integer);
    sget-object v10, Lcom/google/android/gms/internal/eu$b;->xX:Lcom/google/android/gms/internal/by;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2, v10}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v2

    #v2=(Reference);
    check-cast v2, Lcom/google/android/gms/internal/eu$b;

    const/4 v10, 0x7

    #v10=(PosByte);
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    #v10=(Reference);
    invoke-interface {v3, v10}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object v10, v2

    goto/16 :goto_0

    :pswitch_8
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v11

    const/16 v2, 0x8

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_9
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v12

    const/16 v2, 0x9

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_a
    #v0=(Integer);v2=(Integer);
    sget-object v13, Lcom/google/android/gms/internal/eu$c;->yh:Lcom/google/android/gms/internal/cb;

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2, v13}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v13

    const/16 v2, 0xa

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_b
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v14

    const/16 v2, 0xc

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_c
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v15

    const/16 v2, 0xe

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_d
    #v0=(Integer);v2=(Integer);
    sget-object v16, Lcom/google/android/gms/internal/eu$d;->yj:Lcom/google/android/gms/internal/cc;

    move-object/from16 v0, p1

    #v0=(Reference);
    move-object/from16 v1, v16

    #v1=(Reference);
    invoke-static {v0, v2, v1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v2

    #v2=(Reference);
    check-cast v2, Lcom/google/android/gms/internal/eu$d;

    const/16 v16, 0xf

    #v16=(PosByte);
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    #v16=(Reference);
    move-object/from16 v0, v16

    invoke-interface {v3, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object/from16 v16, v2

    goto/16 :goto_0

    :pswitch_e
    #v0=(Integer);v1=(Conflicted);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v17

    const/16 v2, 0x10

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_f
    #v0=(Integer);v2=(Integer);
    sget-object v19, Lcom/google/android/gms/internal/eu$e;->yk:Lcom/google/android/gms/internal/cd;

    move-object/from16 v0, p1

    #v0=(Reference);
    move-object/from16 v1, v19

    #v1=(Reference);
    invoke-static {v0, v2, v1}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v2

    #v2=(Reference);
    check-cast v2, Lcom/google/android/gms/internal/eu$e;

    const/16 v19, 0x13

    #v19=(PosByte);
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v19

    #v19=(Reference);
    move-object/from16 v0, v19

    invoke-interface {v3, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-object/from16 v19, v2

    goto/16 :goto_0

    :pswitch_10
    #v0=(Integer);v1=(Conflicted);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v18

    const/16 v2, 0x12

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_11
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v21

    const/16 v2, 0x15

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_12
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v20

    const/16 v2, 0x14

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_13
    #v0=(Integer);v2=(Integer);
    sget-object v23, Lcom/google/android/gms/internal/eu$h;->yt:Lcom/google/android/gms/internal/ci;

    move-object/from16 v0, p1

    #v0=(Reference);
    move-object/from16 v1, v23

    #v1=(Reference);
    invoke-static {v0, v2, v1}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v23

    const/16 v2, 0x17

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_14
    #v0=(Integer);v1=(Conflicted);v2=(Integer);
    sget-object v22, Lcom/google/android/gms/internal/eu$g;->yp:Lcom/google/android/gms/internal/cg;

    move-object/from16 v0, p1

    #v0=(Reference);
    move-object/from16 v1, v22

    #v1=(Reference);
    invoke-static {v0, v2, v1}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v22

    const/16 v2, 0x16

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_15
    #v0=(Integer);v1=(Conflicted);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v25

    const/16 v2, 0x19

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_16
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v24

    const/16 v2, 0x18

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_17
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v27

    const/16 v2, 0x1b

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_18
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v26

    const/16 v2, 0x1a

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_19
    #v0=(Integer);v2=(Integer);
    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/o;->c(Landroid/os/Parcel;I)Z

    move-result v29

    const/16 v2, 0x1d

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :pswitch_1a
    #v0=(Integer);v2=(Integer);
    sget-object v28, Lcom/google/android/gms/internal/eu$i;->yu:Lcom/google/android/gms/internal/cj;

    move-object/from16 v0, p1

    #v0=(Reference);
    move-object/from16 v1, v28

    #v1=(Reference);
    invoke-static {v0, v2, v1}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v28

    const/16 v2, 0x1c

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_0
    #v0=(Integer);v1=(Conflicted);v2=(Integer);v31=(Conflicted);
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    move/from16 v0, v30

    if-eq v2, v0, :cond_1

    new-instance v2, Lcom/google/android/gms/internal/p;

    #v2=(UninitRef);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "Overread allowed size end="

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    move/from16 v0, v30

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move-object/from16 v0, p1

    #v0=(Reference);
    invoke-direct {v2, v3, v0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v2=(Reference);
    throw v2

    :cond_1
    #v0=(Integer);v2=(Integer);v4=(Integer);
    new-instance v2, Lcom/google/android/gms/internal/eu;

    #v2=(UninitRef);
    invoke-direct/range {v2 .. v29}, Lcom/google/android/gms/internal/eu;-><init>(Ljava/util/Set;ILjava/lang/String;Lcom/google/android/gms/internal/eu$a;Ljava/lang/String;Ljava/lang/String;ILcom/google/android/gms/internal/eu$b;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ILjava/lang/String;Lcom/google/android/gms/internal/eu$d;ZLjava/lang/String;Lcom/google/android/gms/internal/eu$e;Ljava/lang/String;ILjava/util/List;Ljava/util/List;IILjava/lang/String;Ljava/lang/String;Ljava/util/List;Z)V

    #v2=(Reference);
    return-object v2

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);v7=(Unknown);v8=(Unknown);v9=(Unknown);v10=(Unknown);v11=(Unknown);v12=(Unknown);v13=(Unknown);v14=(Unknown);v15=(Unknown);v16=(Unknown);v17=(Unknown);v18=(Unknown);v19=(Unknown);v20=(Unknown);v21=(Unknown);v22=(Unknown);v23=(Unknown);v24=(Unknown);v25=(Unknown);v26=(Unknown);v27=(Unknown);v28=(Unknown);v29=(Unknown);v30=(Unknown);v31=(Unknown);p0=(Unknown);p1=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_0
        :pswitch_b
        :pswitch_0
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_0
        :pswitch_10
        :pswitch_f
        :pswitch_12
        :pswitch_11
        :pswitch_14
        :pswitch_13
        :pswitch_16
        :pswitch_15
        :pswitch_18
        :pswitch_17
        :pswitch_1a
        :pswitch_19
    .end packed-switch
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/internal/eu;

    #v0=(Reference);
    return-object v0
.end method

*/}
