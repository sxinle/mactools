package com.google.android.gms.internal; class db {/*

.class public abstract Lcom/google/android/gms/internal/db;
.super Ljava/lang/Object;


# instance fields
.field private zW:Ljava/lang/Object;

.field private zX:Z

.field final synthetic zY:Lcom/google/android/gms/internal/da;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/da;Ljava/lang/Object;)V
    .locals 1

    iput-object p1, p0, Lcom/google/android/gms/internal/db;->zY:Lcom/google/android/gms/internal/da;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-object p2, p0, Lcom/google/android/gms/internal/db;->zW:Ljava/lang/Object;

    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/google/android/gms/internal/db;->zX:Z

    return-void
.end method

*/}
