package com.google.android.gms.internal; class co {/*

.class public abstract Lcom/google/android/gms/internal/co;
.super Ljava/lang/Object;


# instance fields
.field protected final yO:Lcom/google/android/gms/internal/l;

.field protected final yP:I

.field private final yQ:I


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/l;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    invoke-static {p1}, Lcom/google/android/gms/internal/i;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/internal/l;

    iput-object v0, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    if-ltz p2, :cond_0

    invoke-virtual {p1}, Lcom/google/android/gms/internal/l;->getCount()I

    move-result v0

    #v0=(Integer);
    if-ge p2, v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    invoke-static {v0}, Lcom/google/android/gms/internal/i;->d(Z)V

    iput p2, p0, Lcom/google/android/gms/internal/co;->yP:I

    iget v0, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v0=(Integer);
    invoke-virtual {p1, v0}, Lcom/google/android/gms/internal/l;->af(I)I

    move-result v0

    iput v0, p0, Lcom/google/android/gms/internal/co;->yQ:I

    return-void

    :cond_0
    #v0=(Conflicted);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method


# virtual methods
.method protected final P(Ljava/lang/String;)Landroid/net/Uri;
    .locals 3

    iget-object v0, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/gms/internal/l;->e(Ljava/lang/String;II)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method protected final Q(Ljava/lang/String;)Z
    .locals 3

    iget-object v0, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/gms/internal/l;->f(Ljava/lang/String;II)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    instance-of v1, p1, Lcom/google/android/gms/internal/co;

    #v1=(Boolean);
    if-eqz v1, :cond_0

    check-cast p1, Lcom/google/android/gms/internal/co;

    iget v1, p1, Lcom/google/android/gms/internal/co;->yP:I

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget v1, p1, Lcom/google/android/gms/internal/co;->yQ:I

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p1, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    #v1=(Reference);
    iget-object v2, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    if-ne v1, v2, :cond_0

    const/4 v0, 0x1

    :cond_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return v0
.end method

.method protected final getBoolean(Ljava/lang/String;)Z
    .locals 3

    iget-object v0, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/gms/internal/l;->d(Ljava/lang/String;II)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method protected final getInteger(Ljava/lang/String;)I
    .locals 3

    iget-object v0, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/gms/internal/l;->b(Ljava/lang/String;II)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method protected final getLong(Ljava/lang/String;)J
    .locals 3

    iget-object v0, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/gms/internal/l;->a(Ljava/lang/String;II)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method protected final getString(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    #v0=(Reference);
    iget v1, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v1=(Integer);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/gms/internal/l;->c(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v0, 0x3

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yP:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget v2, p0, Lcom/google/android/gms/internal/co;->yQ:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/internal/co;->yO:Lcom/google/android/gms/internal/l;

    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

*/}
