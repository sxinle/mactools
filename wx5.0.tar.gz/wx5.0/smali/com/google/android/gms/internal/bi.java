package com.google.android.gms.internal; class bi {/*

.class public interface abstract Lcom/google/android/gms/internal/bi;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract es()V
.end method

*/}
