package com.google.android.gms.internal; class bq {/*

.class public abstract Lcom/google/android/gms/internal/bq;
.super Lcom/google/android/gms/internal/t;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/internal/t;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method protected static b(Ljava/lang/Integer;)Z
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    if-nez p0, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    #v1=(Integer);
    const v2, 0x30d400

    #v2=(Integer);
    if-lt v1, v2, :cond_0

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

*/}
