package com.google.android.gms.internal; class cr {/*

.class public final Lcom/google/android/gms/internal/cr;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/internal/l;Landroid/os/Parcel;I)V
    .locals 3

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yU:[Ljava/lang/String;

    #v2=(Reference);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;I[Ljava/lang/String;)V

    const/16 v1, 0x3e8

    #v1=(PosShort);
    iget v2, p0, Lcom/google/android/gms/internal/l;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    iget-object v1, p0, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    #v1=(Reference);
    invoke-static {p1, v1, p2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;[Landroid/os/Parcelable;I)V

    const/4 v1, 0x3

    #v1=(PosByte);
    iget v2, p0, Lcom/google/android/gms/internal/l;->p:I

    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/internal/l;->yX:Landroid/os/Bundle;

    #v2=(Reference);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILandroid/os/Bundle;)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method

.method public static l(Landroid/os/Parcel;)Lcom/google/android/gms/internal/l;
    .locals 6

    new-instance v1, Lcom/google/android/gms/internal/l;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/google/android/gms/internal/l;-><init>()V

    #v1=(Reference);
    invoke-static {p0}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v2

    :goto_0
    #v0=(Conflicted);v2=(Integer);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    #v0=(Integer);
    if-ge v0, v2, :cond_1

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const v3, 0xffff

    #v3=(Char);
    and-int/2addr v3, v0

    #v3=(Integer);
    sparse-switch v3, :sswitch_data_0

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :sswitch_0
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/o;->q(Landroid/os/Parcel;I)[Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, v1, Lcom/google/android/gms/internal/l;->yU:[Ljava/lang/String;

    goto :goto_0

    :sswitch_1
    #v0=(Integer);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v0

    iput v0, v1, Lcom/google/android/gms/internal/l;->tu:I

    goto :goto_0

    :sswitch_2
    sget-object v3, Landroid/database/CursorWindow;->CREATOR:Landroid/os/Parcelable$Creator;

    #v3=(Reference);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/o;->a(Landroid/os/Parcel;I)I

    move-result v4

    #v4=(Integer);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v5

    #v5=(Integer);
    if-nez v4, :cond_0

    const/4 v0, 0x0

    :goto_1
    #v0=(Reference);v3=(Conflicted);
    check-cast v0, [Landroid/database/CursorWindow;

    iput-object v0, v1, Lcom/google/android/gms/internal/l;->yW:[Landroid/database/CursorWindow;

    goto :goto_0

    :cond_0
    #v0=(Integer);v3=(Reference);
    invoke-virtual {p0, v3}, Landroid/os/Parcel;->createTypedArray(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    add-int v3, v5, v4

    #v3=(Integer);
    invoke-virtual {p0, v3}, Landroid/os/Parcel;->setDataPosition(I)V

    goto :goto_1

    :sswitch_3
    #v0=(Integer);v4=(Conflicted);v5=(Conflicted);
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v0

    iput v0, v1, Lcom/google/android/gms/internal/l;->p:I

    goto :goto_0

    :sswitch_4
    invoke-static {p0, v0}, Lcom/google/android/gms/internal/o;->n(Landroid/os/Parcel;I)Landroid/os/Bundle;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, v1, Lcom/google/android/gms/internal/l;->yX:Landroid/os/Bundle;

    goto :goto_0

    :cond_1
    #v0=(Integer);v3=(Conflicted);
    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    if-eq v0, v2, :cond_2

    new-instance v0, Lcom/google/android/gms/internal/p;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v3, "Overread allowed size end="

    #v3=(Reference);
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v0=(Reference);
    throw v0

    :cond_2
    #v0=(Integer);v3=(Conflicted);
    invoke-virtual {v1}, Lcom/google/android/gms/internal/l;->gx()V

    return-object v1

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);p0=(Unknown);
    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_0
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x3e8 -> :sswitch_1
    .end sparse-switch
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Lcom/google/android/gms/internal/cr;->l(Landroid/os/Parcel;)Lcom/google/android/gms/internal/l;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/internal/l;

    #v0=(Reference);
    return-object v0
.end method

*/}
