package com.google.android.gms.internal; class ct {/*

.class public final Lcom/google/android/gms/internal/ct;
.super Ljava/lang/Object;


# instance fields
.field public final uri:Landroid/net/Uri;


# direct methods
.method public constructor <init>(Landroid/net/Uri;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-object p1, p0, Lcom/google/android/gms/internal/ct;->uri:Landroid/net/Uri;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    #v0=(Null);
    instance-of v2, p1, Lcom/google/android/gms/internal/ct;

    #v2=(Boolean);
    if-nez v2, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Integer);v3=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v2=(Boolean);v3=(Uninit);
    if-ne p0, p1, :cond_2

    move v0, v1

    #v0=(One);
    goto :goto_0

    :cond_2
    #v0=(Null);
    check-cast p1, Lcom/google/android/gms/internal/ct;

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ct;->hashCode()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/ct;->hashCode()I

    move-result v3

    #v3=(Integer);
    if-ne v2, v3, :cond_0

    move v0, v1

    #v0=(One);
    goto :goto_0
.end method

.method public final hashCode()I
    .locals 3

    const/4 v0, 0x1

    #v0=(One);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v2, p0, Lcom/google/android/gms/internal/ct;->uri:Landroid/net/Uri;

    #v2=(Reference);
    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

*/}
