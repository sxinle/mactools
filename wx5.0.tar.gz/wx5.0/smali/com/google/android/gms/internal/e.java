package com.google.android.gms.internal; class e {/*

.class public abstract Lcom/google/android/gms/internal/e;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/google/android/gms/internal/d;


# direct methods
.method public static c(Landroid/os/IBinder;)Lcom/google/android/gms/internal/d;
    .locals 2

    if-nez p0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Uninit);v1=(Uninit);
    const-string v0, "com.google.android.gms.common.internal.ISignInButtonCreator"

    #v0=(Reference);
    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/google/android/gms/internal/d;

    #v1=(Boolean);
    if-eqz v1, :cond_1

    check-cast v0, Lcom/google/android/gms/internal/d;

    goto :goto_0

    :cond_1
    #v1=(Conflicted);
    new-instance v0, Lcom/google/android/gms/internal/f;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/f;-><init>(Landroid/os/IBinder;)V

    #v0=(Reference);
    goto :goto_0
.end method


# virtual methods
.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 4

    const/4 v1, 0x1

    #v1=(One);
    sparse-switch p1, :sswitch_data_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v0

    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    :sswitch_0
    #v0=(Uninit);v2=(Uninit);v3=(Uninit);
    const-string v0, "com.google.android.gms.common.internal.ISignInButtonCreator"

    #v0=(Reference);
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    move v0, v1

    #v0=(One);
    goto :goto_0

    :sswitch_1
    #v0=(Uninit);
    const-string v0, "com.google.android.gms.common.internal.ISignInButtonCreator"

    #v0=(Reference);
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/internal/ap;->d(Landroid/os/IBinder;)Lcom/google/android/gms/internal/an;

    move-result-object v0

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {p0, v0, v2, v3}, Lcom/google/android/gms/internal/e;->a(Lcom/google/android/gms/internal/an;II)Lcom/google/android/gms/internal/an;

    move-result-object v0

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/google/android/gms/internal/an;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    :goto_1
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    move v0, v1

    #v0=(One);
    goto :goto_0

    :cond_0
    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_1

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);p0=(Unknown);p1=(Unknown);p2=(Unknown);p3=(Unknown);p4=(Unknown);
    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x5f4e5446 -> :sswitch_0
    .end sparse-switch
.end method

*/}
