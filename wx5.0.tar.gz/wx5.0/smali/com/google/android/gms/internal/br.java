package com.google.android.gms.internal; class br {/*

.class final Lcom/google/android/gms/internal/br;
.super Landroid/widget/CompoundButton;


# instance fields
.field final synthetic wl:Lcom/google/android/gms/internal/el;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/el;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/gms/internal/br;->wl:Lcom/google/android/gms/internal/el;

    invoke-direct {p0, p2}, Landroid/widget/CompoundButton;-><init>(Landroid/content/Context;)V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final toggle()V
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/br;->wl:Lcom/google/android/gms/internal/el;

    #v0=(Reference);
    iget-boolean v0, v0, Lcom/google/android/gms/internal/el;->vW:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/widget/CompoundButton;->toggle()V

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v1=(Uninit);
    iget-object v0, p0, Lcom/google/android/gms/internal/br;->wl:Lcom/google/android/gms/internal/el;

    #v0=(Reference);
    const/4 v1, 0x1

    #v1=(One);
    iput-boolean v1, v0, Lcom/google/android/gms/internal/el;->vW:Z

    iget-object v0, p0, Lcom/google/android/gms/internal/br;->wl:Lcom/google/android/gms/internal/el;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/el;->ew()V

    goto :goto_0
.end method

*/}
