package com.google.android.gms.internal; class bs {/*

.class public final Lcom/google/android/gms/internal/bs;
.super Landroid/widget/FrameLayout;


# instance fields
.field private wm:[Ljava/lang/String;

.field private final wn:Landroid/widget/ImageView;

.field private final wo:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/16 v3, 0x11

    #v3=(PosByte);
    const/4 v2, -0x2

    #v2=(Byte);
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/google/android/gms/internal/bs;->wm:[Ljava/lang/String;

    new-instance v0, Landroid/widget/ImageView;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/bs;->wn:Landroid/widget/ImageView;

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wn:Landroid/widget/ImageView;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    #v1=(UninitRef);
    invoke-direct {v1, v2, v2, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    #v1=(Reference);
    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/internal/bs;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/TextView;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    #v1=(UninitRef);
    invoke-direct {v1, v2, v2, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    #v1=(Reference);
    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/internal/bs;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bs;->bringChildToFront(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public final K(F)V
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v1, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    return-void
.end method

.method public final a(Landroid/net/Uri;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wn:Landroid/widget/ImageView;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageURI(Landroid/net/Uri;)V

    return-void
.end method

.method public final ez()V
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    const/16 v1, 0x11

    #v1=(PosByte);
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    return-void
.end method

.method protected final onMeasure(II)V
    .locals 7

    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v5

    #v5=(Integer);
    new-instance v6, Landroid/graphics/Paint;

    #v6=(UninitRef);
    invoke-direct {v6}, Landroid/graphics/Paint;-><init>()V

    #v6=(Reference);
    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/widget/TextView;->getTextSize()F

    move-result v0

    #v0=(Float);
    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/4 v2, 0x0

    #v2=(Null);
    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wm:[Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wm:[Ljava/lang/String;

    array-length v0, v0

    :goto_0
    #v0=(Integer);
    move v4, v1

    #v4=(Null);
    move v3, v1

    #v3=(Null);
    move-object v1, v2

    :goto_1
    #v2=(Integer);v3=(Integer);v4=(Integer);
    if-ge v4, v0, :cond_1

    iget-object v2, p0, Lcom/google/android/gms/internal/bs;->wm:[Ljava/lang/String;

    #v2=(Reference);
    aget-object v2, v2, v4

    #v2=(Null);
    if-eqz v2, :cond_4

    iget-object v2, p0, Lcom/google/android/gms/internal/bs;->wm:[Ljava/lang/String;

    #v2=(Reference);
    aget-object v2, v2, v4

    #v2=(Null);
    invoke-virtual {v6, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v2

    #v2=(Float);
    float-to-int v2, v2

    #v2=(Integer);
    if-gt v2, v5, :cond_4

    if-lt v2, v3, :cond_4

    iget-object v1, p0, Lcom/google/android/gms/internal/bs;->wm:[Ljava/lang/String;

    #v1=(Reference);
    aget-object v1, v1, v4

    :goto_2
    #v1=(Null);
    add-int/lit8 v3, v4, 0x1

    move v4, v3

    move v3, v2

    goto :goto_1

    :cond_0
    #v0=(Reference);v2=(Null);v3=(Uninit);v4=(Uninit);
    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_1
    #v0=(Integer);v2=(Integer);v3=(Integer);v4=(Integer);
    if-eqz v1, :cond_2

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_3

    :cond_2
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_3
    #v0=(Conflicted);
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    return-void

    :cond_4
    #v0=(Integer);
    move v2, v3

    goto :goto_2
.end method

.method public final setSingleLine()V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/widget/TextView;->setSingleLine()V

    return-void
.end method

.method public final setTextColor(I)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/bs;->wo:Landroid/widget/TextView;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method

*/}
