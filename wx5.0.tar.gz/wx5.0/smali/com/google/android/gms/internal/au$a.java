package com.google.android.gms.internal; class au$a {/*

.class public Lcom/google/android/gms/internal/au$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final vb:Lcom/google/android/gms/internal/ab;


# instance fields
.field final className:Ljava/lang/String;

.field final vc:Ljava/util/ArrayList;

.field final versionCode:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/ab;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/ab;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/au$a;->vb:Lcom/google/android/gms/internal/ab;

    return-void
.end method

.method constructor <init>(ILjava/lang/String;Ljava/util/ArrayList;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/au$a;->versionCode:I

    iput-object p2, p0, Lcom/google/android/gms/internal/au$a;->className:Ljava/lang/String;

    iput-object p3, p0, Lcom/google/android/gms/internal/au$a;->vc:Ljava/util/ArrayList;

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Ljava/util/HashMap;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/google/android/gms/internal/au$a;->versionCode:I

    iput-object p1, p0, Lcom/google/android/gms/internal/au$a;->className:Ljava/lang/String;

    invoke-static {p2}, Lcom/google/android/gms/internal/au$a;->a(Ljava/util/HashMap;)Ljava/util/ArrayList;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/au$a;->vc:Ljava/util/ArrayList;

    return-void
.end method

.method private static a(Ljava/util/HashMap;)Ljava/util/ArrayList;
    .locals 5

    if-nez p0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    new-instance v2, Ljava/util/ArrayList;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    #v2=(Reference);
    invoke-virtual {p0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    #v1=(Conflicted);v3=(Reference);v4=(Conflicted);
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/String;

    new-instance v4, Lcom/google/android/gms/internal/au$b;

    #v4=(UninitRef);
    invoke-virtual {p0, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    #v1=(Reference);
    check-cast v1, Lcom/google/android/gms/internal/ar$a;

    invoke-direct {v4, v0, v1}, Lcom/google/android/gms/internal/au$b;-><init>(Ljava/lang/String;Lcom/google/android/gms/internal/ar$a;)V

    #v4=(Reference);
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    #v0=(Boolean);v1=(Conflicted);v4=(Conflicted);
    move-object v0, v2

    #v0=(Reference);
    goto :goto_0
.end method


# virtual methods
.method final dW()Ljava/util/HashMap;
    .locals 5

    new-instance v2, Ljava/util/HashMap;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    #v2=(Reference);
    iget-object v0, p0, Lcom/google/android/gms/internal/au$a;->vc:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    #v3=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_0
    #v0=(Integer);v1=(Integer);v4=(Conflicted);
    if-ge v1, v3, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/au$a;->vc:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/au$b;

    iget-object v4, v0, Lcom/google/android/gms/internal/au$b;->ve:Ljava/lang/String;

    #v4=(Reference);
    iget-object v0, v0, Lcom/google/android/gms/internal/au$b;->vf:Lcom/google/android/gms/internal/ar$a;

    invoke-virtual {v2, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    :cond_0
    #v4=(Conflicted);
    return-object v2
.end method

.method public describeContents()I
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/au$a;->vb:Lcom/google/android/gms/internal/ab;

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/au$a;->vb:Lcom/google/android/gms/internal/ab;

    #v0=(Reference);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/ab;->a(Lcom/google/android/gms/internal/au$a;Landroid/os/Parcel;)V

    return-void
.end method

*/}
