package com.google.android.gms.internal; class bp {/*

.class public final Lcom/google/android/gms/internal/bp;
.super Ljava/lang/Object;


# instance fields
.field final synthetic wl:Lcom/google/android/gms/internal/el;


# direct methods
.method protected constructor <init>(Lcom/google/android/gms/internal/el;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/gms/internal/bp;->wl:Lcom/google/android/gms/internal/el;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

*/}
