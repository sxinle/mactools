package com.google.android.gms.internal; class el {/*

.class public Lcom/google/android/gms/internal/el;
.super Landroid/widget/LinearLayout;

# interfaces
.implements Lcom/google/android/gms/common/c;
.implements Lcom/google/android/gms/common/d;


# static fields
.field private static final vV:I


# instance fields
.field private dj:I

.field protected uy:I

.field protected vP:Lcom/google/android/gms/plus/a;

.field protected vW:Z

.field protected vX:I

.field protected final vY:Landroid/widget/LinearLayout;

.field protected final vZ:Landroid/widget/FrameLayout;

.field protected final wa:Landroid/widget/CompoundButton;

.field private final wb:Landroid/widget/ProgressBar;

.field protected final wc:Lcom/google/android/gms/internal/bs;

.field private final wd:[Lcom/google/android/gms/internal/bd;

.field private we:I

.field private wf:[Landroid/net/Uri;

.field protected wg:Lcom/google/android/gms/internal/be;

.field protected final wh:Landroid/content/res/Resources;

.field protected final wi:Landroid/view/LayoutInflater;

.field private wj:Lcom/google/android/gms/internal/bp;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "#666666"

    #v0=(Reference);
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    sput v0, Lcom/google/android/gms/internal/el;->vV:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 10

    const/16 v9, 0x11

    #v9=(PosByte);
    const/4 v3, 0x2

    #v3=(PosByte);
    const/4 v2, 0x1

    #v2=(One);
    const/4 v8, 0x0

    #v8=(Null);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    #p0=(Reference);
    iput v1, p0, Lcom/google/android/gms/internal/el;->vX:I

    const/4 v0, 0x4

    #v0=(PosByte);
    new-array v0, v0, [Lcom/google/android/gms/internal/bd;

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    iput v2, p0, Lcom/google/android/gms/internal/el;->uy:I

    iput v3, p0, Lcom/google/android/gms/internal/el;->we:I

    const/4 v0, 0x3

    #v0=(PosByte);
    iput v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    new-instance v0, Lcom/google/android/gms/internal/bp;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/bp;-><init>(Lcom/google/android/gms/internal/el;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/el;->wj:Lcom/google/android/gms/internal/bp;

    const-string v0, "Context must not be null."

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/i;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {p1}, Lcom/google/android/gms/common/e;->b(Landroid/content/Context;)I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_0

    iput-object v8, p0, Lcom/google/android/gms/internal/el;->wh:Landroid/content/res/Resources;

    iput-object v8, p0, Lcom/google/android/gms/internal/el;->wi:Landroid/view/LayoutInflater;

    :goto_0
    #v0=(Conflicted);v4=(Conflicted);
    const-string v0, "http://schemas.android.com/apk/lib/com.google.android.gms.plus"

    #v0=(Reference);
    const-string v4, "size"

    #v4=(Reference);
    invoke-static {v0, v4, p1, p2}, Lcom/google/android/gms/internal/n;->a(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Ljava/lang/String;

    move-result-object v0

    const-string v4, "SMALL"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_1

    move v0, v1

    :goto_1
    #v0=(PosByte);v4=(Conflicted);
    iput v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    const-string v0, "http://schemas.android.com/apk/lib/com.google.android.gms.plus"

    #v0=(Reference);
    const-string v4, "annotation"

    #v4=(Reference);
    invoke-static {v0, v4, p1, p2}, Lcom/google/android/gms/internal/n;->a(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Ljava/lang/String;

    move-result-object v0

    const-string v4, "INLINE"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_4

    move v0, v3

    :goto_2
    #v0=(PosByte);v4=(Conflicted);
    iput v0, p0, Lcom/google/android/gms/internal/el;->we:I

    new-instance v0, Landroid/graphics/Point;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    #v0=(Reference);
    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/el;->a(Landroid/graphics/Point;)V

    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->isInEditMode()Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_6

    new-instance v1, Landroid/widget/TextView;

    #v1=(UninitRef);
    invoke-direct {v1, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    #v1=(Reference);
    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setGravity(I)V

    const-string v2, "[ +1 ]"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    #v2=(UninitRef);
    iget v3, v0, Landroid/graphics/Point;->x:I

    #v3=(Integer);
    iget v0, v0, Landroid/graphics/Point;->y:I

    #v0=(Integer);
    invoke-direct {v2, v3, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    #v2=(Reference);
    invoke-virtual {p0, v1, v2}, Lcom/google/android/gms/internal/el;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iput-object v8, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    iput-object v8, p0, Lcom/google/android/gms/internal/el;->wb:Landroid/widget/ProgressBar;

    iput-object v8, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    iput-object v8, p0, Lcom/google/android/gms/internal/el;->vZ:Landroid/widget/FrameLayout;

    iput-object v8, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    :goto_3
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-void

    :cond_0
    #v0=(Integer);v1=(Null);v2=(One);v3=(PosByte);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);
    invoke-direct {p0}, Lcom/google/android/gms/internal/el;->et()Landroid/content/Context;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    #v4=(Reference);
    iput-object v4, p0, Lcom/google/android/gms/internal/el;->wh:Landroid/content/res/Resources;

    const-string v4, "layout_inflater"

    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    iput-object v0, p0, Lcom/google/android/gms/internal/el;->wi:Landroid/view/LayoutInflater;

    goto :goto_0

    :cond_1
    #v4=(Boolean);
    const-string v4, "MEDIUM"

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_2

    move v0, v2

    #v0=(One);
    goto :goto_1

    :cond_2
    #v0=(Reference);
    const-string v4, "TALL"

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_3

    move v0, v3

    #v0=(PosByte);
    goto :goto_1

    :cond_3
    #v0=(Reference);
    const-string v4, "STANDARD"

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    const/4 v0, 0x3

    #v0=(PosByte);
    goto :goto_1

    :cond_4
    #v0=(Reference);v4=(Boolean);
    const-string v4, "NONE"

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_5

    move v0, v1

    #v0=(Null);
    goto :goto_2

    :cond_5
    #v0=(Reference);
    const-string v4, "BUBBLE"

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move v0, v2

    #v0=(One);
    goto :goto_2

    :cond_6
    #v0=(Reference);v4=(Boolean);
    invoke-virtual {p0, v2}, Lcom/google/android/gms/internal/el;->setFocusable(Z)V

    new-instance v4, Landroid/widget/LinearLayout;

    #v4=(UninitRef);
    invoke-direct {v4, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    #v4=(Reference);
    iput-object v4, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v4}, Lcom/google/android/gms/internal/el;->addView(Landroid/view/View;)V

    new-instance v4, Lcom/google/android/gms/internal/br;

    #v4=(UninitRef);
    invoke-direct {v4, p0, p1}, Lcom/google/android/gms/internal/br;-><init>(Lcom/google/android/gms/internal/el;Landroid/content/Context;)V

    #v4=(Reference);
    iput-object v4, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    invoke-virtual {v4, v8}, Landroid/widget/CompoundButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v4, Lcom/google/android/gms/internal/bs;

    #v4=(UninitRef);
    invoke-direct {v4, p1}, Lcom/google/android/gms/internal/bs;-><init>(Landroid/content/Context;)V

    #v4=(Reference);
    invoke-virtual {v4, v1}, Lcom/google/android/gms/internal/bs;->setFocusable(Z)V

    invoke-virtual {v4}, Lcom/google/android/gms/internal/bs;->ez()V

    invoke-virtual {v4}, Lcom/google/android/gms/internal/bs;->setSingleLine()V

    iget v5, p0, Lcom/google/android/gms/internal/el;->dj:I

    #v5=(Integer);
    iget v6, p0, Lcom/google/android/gms/internal/el;->we:I

    #v6=(Integer);
    invoke-static {v5, v6}, Lcom/google/android/gms/internal/el;->g(II)I

    move-result v5

    int-to-float v5, v5

    #v5=(Float);
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    #v6=(Reference);
    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    invoke-static {v3, v5, v6}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v3

    #v3=(Float);
    invoke-virtual {v4, v3}, Lcom/google/android/gms/internal/bs;->K(F)V

    sget v3, Lcom/google/android/gms/internal/el;->vV:I

    #v3=(Integer);
    invoke-virtual {v4, v3}, Lcom/google/android/gms/internal/bs;->setTextColor(I)V

    invoke-virtual {v4, v1}, Lcom/google/android/gms/internal/bs;->setVisibility(I)V

    iput-object v4, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    new-instance v3, Landroid/widget/FrameLayout;

    #v3=(UninitRef);
    invoke-direct {v3, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    #v3=(Reference);
    invoke-virtual {v3, v1}, Landroid/widget/FrameLayout;->setFocusable(Z)V

    iput-object v3, p0, Lcom/google/android/gms/internal/el;->vZ:Landroid/widget/FrameLayout;

    iget-object v3, p0, Lcom/google/android/gms/internal/el;->vZ:Landroid/widget/FrameLayout;

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    #v5=(UninitRef);
    iget v6, v0, Landroid/graphics/Point;->x:I

    #v6=(Integer);
    iget v7, v0, Landroid/graphics/Point;->y:I

    #v7=(Integer);
    invoke-direct {v5, v6, v7, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    #v5=(Reference);
    invoke-virtual {v3, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/el;->b(Landroid/graphics/Point;)V

    new-instance v3, Landroid/widget/ProgressBar;

    #v3=(UninitRef);
    const v4, 0x1010288

    #v4=(Integer);
    invoke-direct {v3, p1, v8, v4}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    #v3=(Reference);
    invoke-virtual {v3, v1}, Landroid/widget/ProgressBar;->setFocusable(Z)V

    invoke-virtual {v3, v2}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    iput-object v3, p0, Lcom/google/android/gms/internal/el;->wb:Landroid/widget/ProgressBar;

    iget-object v3, p0, Lcom/google/android/gms/internal/el;->wb:Landroid/widget/ProgressBar;

    const/4 v4, 0x4

    #v4=(PosByte);
    invoke-virtual {v3, v4}, Landroid/widget/ProgressBar;->setVisibility(I)V

    iget-object v3, p0, Lcom/google/android/gms/internal/el;->vZ:Landroid/widget/FrameLayout;

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->wb:Landroid/widget/ProgressBar;

    #v4=(Reference);
    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    #v5=(UninitRef);
    iget v6, v0, Landroid/graphics/Point;->x:I

    iget v0, v0, Landroid/graphics/Point;->y:I

    #v0=(Integer);
    invoke-direct {v5, v6, v0, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    #v5=(Reference);
    invoke-virtual {v3, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v0=(Reference);
    array-length v0, v0

    :goto_4
    #v0=(Integer);v1=(Integer);v4=(Conflicted);
    if-ge v1, v0, :cond_7

    iget-object v3, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getContext()Landroid/content/Context;

    move-result-object v4

    #v4=(Reference);
    new-instance v5, Lcom/google/android/gms/internal/bd;

    #v5=(UninitRef);
    invoke-direct {v5, v4}, Lcom/google/android/gms/internal/bd;-><init>(Landroid/content/Context;)V

    #v5=(Reference);
    const/16 v4, 0x8

    #v4=(PosByte);
    invoke-virtual {v5, v4}, Lcom/google/android/gms/internal/bd;->setVisibility(I)V

    aput-object v5, v3, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    :cond_7
    #v4=(Conflicted);
    invoke-direct {p0, v2}, Lcom/google/android/gms/internal/el;->setType(I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wb:Landroid/widget/ProgressBar;

    #v0=(Reference);
    const/4 v1, 0x4

    #v1=(PosByte);
    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    invoke-direct {p0}, Lcom/google/android/gms/internal/el;->ex()V

    goto/16 :goto_3
.end method

.method private a(Landroid/graphics/Point;)V
    .locals 7

    const/16 v1, 0x18

    #v1=(PosByte);
    const/16 v0, 0x14

    #v0=(PosByte);
    const/4 v5, 0x1

    #v5=(One);
    const-wide/high16 v3, 0x3fe0

    #v3=(LongLo);v4=(LongHi);
    iget v2, p0, Lcom/google/android/gms/internal/el;->dj:I

    #v2=(Integer);
    packed-switch v2, :pswitch_data_0

    const/16 v0, 0x26

    move v6, v1

    #v6=(PosByte);
    move v1, v0

    move v0, v6

    :goto_0
    #v6=(Conflicted);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    int-to-float v1, v1

    #v1=(Float);
    invoke-static {v5, v1, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v1

    int-to-float v0, v0

    #v0=(Float);
    invoke-static {v5, v0, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    float-to-double v1, v1

    #v1=(DoubleLo);v2=(DoubleHi);
    add-double/2addr v1, v3

    double-to-int v1, v1

    #v1=(Integer);
    iput v1, p1, Landroid/graphics/Point;->x:I

    float-to-double v0, v0

    #v0=(DoubleLo);v1=(DoubleHi);
    add-double/2addr v0, v3

    double-to-int v0, v0

    #v0=(Integer);
    iput v0, p1, Landroid/graphics/Point;->y:I

    return-void

    :pswitch_0
    #v0=(PosByte);v1=(PosByte);v2=(Integer);v6=(Uninit);
    const/16 v1, 0x20

    goto :goto_0

    :pswitch_1
    const/16 v0, 0xe

    goto :goto_0

    :pswitch_2
    const/16 v1, 0x32

    goto :goto_0

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);p0=(Unknown);p1=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
        :pswitch_2
    .end packed-switch
.end method

.method private b(Landroid/graphics/Point;)V
    .locals 4

    iget v0, p1, Landroid/graphics/Point;->y:I

    #v0=(Integer);
    int-to-float v0, v0

    #v0=(Float);
    const/4 v1, 0x1

    #v1=(One);
    const/high16 v2, 0x40c0

    #v2=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    invoke-static {v1, v2, v3}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v1

    #v1=(Float);
    sub-float/2addr v0, v1

    float-to-int v0, v0

    #v0=(Integer);
    iput v0, p1, Landroid/graphics/Point;->y:I

    iget v0, p1, Landroid/graphics/Point;->y:I

    iput v0, p1, Landroid/graphics/Point;->x:I

    return-void
.end method

.method private et()Landroid/content/Context;
    .locals 3

    :try_start_0
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getContext()Landroid/content/Context;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "com.google.android.gms"

    #v1=(Reference);
    const/4 v2, 0x4

    #v2=(PosByte);
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v0

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-object v0

    :catch_0
    move-exception v0

    #v0=(Reference);
    const-string v0, "PlusOneButton"

    const/4 v1, 0x5

    #v1=(PosByte);
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method private ev()V
    .locals 8

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    const/high16 v2, 0x40a0

    #v2=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getContext()Landroid/content/Context;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    invoke-static {v0, v2, v3}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v2

    #v2=(Float);
    float-to-int v3, v2

    #v3=(Integer);
    const/high16 v2, 0x3f80

    #v2=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getContext()Landroid/content/Context;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    invoke-static {v0, v2, v4}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v2

    #v2=(Float);
    float-to-int v4, v2

    #v4=(Integer);
    iget-object v2, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v2=(Reference);
    array-length v5, v2

    #v5=(Integer);
    move v2, v1

    :goto_0
    #v0=(Boolean);v2=(Integer);v6=(Conflicted);v7=(Conflicted);
    if-ge v2, v5, :cond_2

    iget-object v6, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v6=(Reference);
    aget-object v6, v6, v2

    #v6=(Null);
    invoke-virtual {v6}, Lcom/google/android/gms/internal/bd;->getVisibility()I

    move-result v6

    #v6=(Integer);
    if-nez v6, :cond_0

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    #v6=(UninitRef);
    iget-object v7, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v7=(Reference);
    aget-object v7, v7, v2

    #v7=(Null);
    invoke-virtual {v7}, Lcom/google/android/gms/internal/bd;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    #v7=(Reference);
    invoke-direct {v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    #v6=(Reference);
    if-eqz v0, :cond_1

    invoke-virtual {v6, v3, v1, v4, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    move v0, v1

    :goto_1
    iget-object v7, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    aget-object v7, v7, v2

    #v7=(Null);
    invoke-virtual {v7, v6}, Lcom/google/android/gms/internal/bd;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    #v6=(Conflicted);v7=(Conflicted);
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    #v6=(Reference);v7=(Reference);
    invoke-virtual {v6, v4, v1, v4, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_1

    :cond_2
    #v6=(Conflicted);v7=(Conflicted);
    return-void
.end method

.method private ex()V
    .locals 8

    const/4 v7, 0x1

    #v7=(One);
    const/4 v6, 0x0

    #v6=(Null);
    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v1=(Reference);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wh:Landroid/content/res/Resources;

    #v0=(Reference);
    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    invoke-virtual {v1, v0}, Landroid/widget/CompoundButton;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    iget v0, p0, Lcom/google/android/gms/internal/el;->uy:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v0=(Reference);
    invoke-virtual {v0, v6}, Landroid/widget/CompoundButton;->setEnabled(Z)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    invoke-virtual {v0, v6}, Landroid/widget/CompoundButton;->setChecked(Z)V

    :goto_1
    return-void

    :cond_0
    #v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget-object v2, p0, Lcom/google/android/gms/internal/el;->wh:Landroid/content/res/Resources;

    #v2=(Reference);
    iget-object v3, p0, Lcom/google/android/gms/internal/el;->wh:Landroid/content/res/Resources;

    #v3=(Reference);
    iget v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_1

    const-string v0, "ic_plusone_standard"

    :goto_2
    #v0=(Reference);
    const-string v4, "drawable"

    #v4=(Reference);
    const-string v5, "com.google.android.gms"

    #v5=(Reference);
    invoke-virtual {v3, v0, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v2, v0}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    #v0=(Reference);
    goto :goto_0

    :pswitch_0
    #v0=(Integer);v4=(Uninit);v5=(Uninit);
    const-string v0, "ic_plusone_small"

    #v0=(Reference);
    goto :goto_2

    :pswitch_1
    #v0=(Integer);
    const-string v0, "ic_plusone_medium"

    #v0=(Reference);
    goto :goto_2

    :pswitch_2
    #v0=(Integer);
    const-string v0, "ic_plusone_tall"

    #v0=(Reference);
    goto :goto_2

    :pswitch_3
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v0=(Reference);
    invoke-virtual {v0, v7}, Landroid/widget/CompoundButton;->setEnabled(Z)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    invoke-virtual {v0, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_1

    :pswitch_4
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v0=(Reference);
    invoke-virtual {v0, v7}, Landroid/widget/CompoundButton;->setEnabled(Z)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    invoke-virtual {v0, v6}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_1

    :pswitch_5
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v0=(Reference);
    invoke-virtual {v0, v6}, Landroid/widget/CompoundButton;->setEnabled(Z)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    invoke-virtual {v0, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_4
        :pswitch_5
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method private ey()V
    .locals 11

    const/16 v10, 0x8

    #v10=(PosByte);
    const/4 v0, 0x0

    #v0=(Null);
    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wf:[Landroid/net/Uri;

    #v1=(Reference);
    if-eqz v1, :cond_2

    iget v1, p0, Lcom/google/android/gms/internal/el;->we:I

    #v1=(Integer);
    const/4 v2, 0x2

    #v2=(PosByte);
    if-ne v1, v2, :cond_2

    new-instance v3, Landroid/graphics/Point;

    #v3=(UninitRef);
    invoke-direct {v3}, Landroid/graphics/Point;-><init>()V

    #v3=(Reference);
    invoke-direct {p0, v3}, Lcom/google/android/gms/internal/el;->a(Landroid/graphics/Point;)V

    iget v1, v3, Landroid/graphics/Point;->y:I

    iput v1, v3, Landroid/graphics/Point;->x:I

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v1=(Reference);
    array-length v4, v1

    #v4=(Integer);
    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wf:[Landroid/net/Uri;

    array-length v5, v1

    #v5=(Integer);
    move v2, v0

    :goto_0
    #v1=(Conflicted);v2=(Integer);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    if-ge v2, v4, :cond_3

    if-ge v2, v5, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wf:[Landroid/net/Uri;

    #v1=(Reference);
    aget-object v1, v1, v2

    :goto_1
    #v1=(Null);
    if-nez v1, :cond_1

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v1=(Reference);
    aget-object v1, v1, v2

    #v1=(Null);
    invoke-virtual {v1, v10}, Lcom/google/android/gms/internal/bd;->setVisibility(I)V

    :goto_2
    add-int/lit8 v1, v2, 0x1

    #v1=(Integer);
    move v2, v1

    goto :goto_0

    :cond_0
    #v1=(Conflicted);
    const/4 v1, 0x0

    #v1=(Null);
    goto :goto_1

    :cond_1
    iget-object v6, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v6=(Reference);
    aget-object v6, v6, v2

    #v6=(Null);
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    #v7=(UninitRef);
    iget v8, v3, Landroid/graphics/Point;->x:I

    #v8=(Integer);
    iget v9, v3, Landroid/graphics/Point;->y:I

    #v9=(Integer);
    invoke-direct {v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    #v7=(Reference);
    invoke-virtual {v6, v7}, Lcom/google/android/gms/internal/bd;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v6, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v6=(Reference);
    aget-object v6, v6, v2

    #v6=(Null);
    iget v7, v3, Landroid/graphics/Point;->y:I

    #v7=(Integer);
    invoke-virtual {v6, v1, v7}, Lcom/google/android/gms/internal/bd;->a(Landroid/net/Uri;I)V

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v1=(Reference);
    aget-object v1, v1, v2

    #v1=(Null);
    invoke-virtual {v1, v0}, Lcom/google/android/gms/internal/bd;->setVisibility(I)V

    goto :goto_2

    :cond_2
    #v1=(Conflicted);v2=(Conflicted);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v1=(Reference);
    array-length v1, v1

    :goto_3
    #v0=(Integer);v1=(Integer);
    if-ge v0, v1, :cond_3

    iget-object v2, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v2=(Reference);
    aget-object v2, v2, v0

    #v2=(Null);
    invoke-virtual {v2, v10}, Lcom/google/android/gms/internal/bd;->setVisibility(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_3
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    invoke-direct {p0}, Lcom/google/android/gms/internal/el;->ev()V

    return-void
.end method

.method private static g(II)I
    .locals 2

    const/16 v0, 0xd

    #v0=(PosByte);
    packed-switch p0, :pswitch_data_0

    :cond_0
    :goto_0
    :pswitch_0
    #v1=(Conflicted);
    return v0

    :pswitch_1
    #v1=(Uninit);
    const/4 v1, 0x2

    #v1=(PosByte);
    if-eq p1, v1, :cond_0

    const/16 v0, 0xf

    goto :goto_0

    :pswitch_2
    #v1=(Uninit);
    const/16 v0, 0xb

    goto :goto_0

    #v0=(Unknown);v1=(Unknown);p0=(Unknown);p1=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method private setType(I)V
    .locals 10

    const/16 v9, 0x11

    #v9=(PosByte);
    const/4 v8, -0x2

    #v8=(Byte);
    const/4 v7, 0x2

    #v7=(PosByte);
    const/4 v2, 0x1

    #v2=(One);
    const/4 v3, 0x0

    #v3=(Null);
    iget v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    #v0=(Integer);
    iput p1, p0, Lcom/google/android/gms/internal/el;->uy:I

    iput v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->isInEditMode()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    new-instance v0, Landroid/graphics/Point;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    #v0=(Reference);
    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/el;->a(Landroid/graphics/Point;)V

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v1=(Reference);
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    #v4=(UninitRef);
    iget v5, v0, Landroid/graphics/Point;->x:I

    #v5=(Integer);
    iget v6, v0, Landroid/graphics/Point;->y:I

    #v6=(Integer);
    invoke-direct {v4, v5, v6, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    #v4=(Reference);
    invoke-virtual {v1, v4}, Landroid/widget/CompoundButton;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/el;->b(Landroid/graphics/Point;)V

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wb:Landroid/widget/ProgressBar;

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    #v4=(UninitRef);
    iget v5, v0, Landroid/graphics/Point;->x:I

    iget v0, v0, Landroid/graphics/Point;->y:I

    #v0=(Integer);
    invoke-direct {v4, v5, v0, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    #v4=(Reference);
    invoke-virtual {v1, v4}, Landroid/widget/ProgressBar;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget v0, p0, Lcom/google/android/gms/internal/el;->we:I

    if-ne v0, v2, :cond_1

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    iget v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    packed-switch v0, :pswitch_data_0

    const-string v0, "global_count_bubble_standard"

    :goto_0
    #v0=(Reference);
    invoke-static {v0}, Lcom/google/android/gms/internal/j;->L(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/google/android/gms/internal/bs;->a(Landroid/net/Uri;)V

    :goto_1
    invoke-direct {p0}, Lcom/google/android/gms/internal/el;->ey()V

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    iget v0, p0, Lcom/google/android/gms/internal/el;->we:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_1

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    #v0=(UninitRef);
    invoke-direct {v0, v8, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    :goto_2
    #v0=(Reference);v1=(Conflicted);
    iget v1, p0, Lcom/google/android/gms/internal/el;->dj:I

    #v1=(Integer);
    if-ne v1, v7, :cond_2

    move v1, v2

    :goto_3
    #v1=(Boolean);
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    iget v1, p0, Lcom/google/android/gms/internal/el;->dj:I

    #v1=(Integer);
    if-ne v1, v7, :cond_3

    move v1, v3

    :goto_4
    #v1=(Boolean);
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v4, v0}, Lcom/google/android/gms/internal/bs;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    #v0=(Integer);
    iget v1, p0, Lcom/google/android/gms/internal/el;->we:I

    #v1=(Integer);
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/el;->g(II)I

    move-result v0

    int-to-float v0, v0

    #v0=(Float);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getContext()Landroid/content/Context;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    invoke-static {v7, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    invoke-virtual {v1, v0}, Lcom/google/android/gms/internal/bs;->K(F)V

    iget-object v4, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    const/high16 v0, 0x4040

    #v0=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    invoke-static {v2, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    #v0=(Float);
    float-to-int v1, v0

    #v1=(Integer);
    const/high16 v0, 0x40a0

    #v0=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->getContext()Landroid/content/Context;

    move-result-object v5

    #v5=(Reference);
    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    invoke-static {v2, v0, v5}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    #v0=(Float);
    float-to-int v0, v0

    #v0=(Integer);
    iget v5, p0, Lcom/google/android/gms/internal/el;->we:I

    #v5=(Integer);
    if-ne v5, v7, :cond_4

    :goto_5
    iget v5, p0, Lcom/google/android/gms/internal/el;->dj:I

    if-ne v5, v7, :cond_5

    iget v5, p0, Lcom/google/android/gms/internal/el;->we:I

    if-ne v5, v2, :cond_5

    :goto_6
    invoke-virtual {v4, v0, v3, v3, v1}, Landroid/view/View;->setPadding(IIII)V

    iget v0, p0, Lcom/google/android/gms/internal/el;->dj:I

    if-ne v0, v7, :cond_6

    iget v0, p0, Lcom/google/android/gms/internal/el;->we:I

    if-ne v0, v2, :cond_6

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    #v0=(Reference);
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->vZ:Landroid/widget/FrameLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :goto_7
    #v2=(Boolean);v3=(Integer);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/el;->requestLayout()V

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return-void

    :pswitch_0
    #v0=(Integer);v1=(Reference);v2=(One);v3=(Null);v4=(Reference);v5=(Integer);v6=(Integer);
    const-string v0, "global_count_bubble_medium"

    #v0=(Reference);
    goto/16 :goto_0

    :pswitch_1
    #v0=(Integer);
    const-string v0, "global_count_bubble_small"

    #v0=(Reference);
    goto/16 :goto_0

    :pswitch_2
    #v0=(Integer);
    const-string v0, "global_count_bubble_tall"

    #v0=(Reference);
    goto/16 :goto_0

    :cond_1
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/bs;->a(Landroid/net/Uri;)V

    goto/16 :goto_1

    :pswitch_3
    #v0=(Integer);v1=(Reference);
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    #v0=(UninitRef);
    const/4 v1, -0x1

    #v1=(Byte);
    invoke-direct {v0, v8, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    #v0=(Reference);
    goto/16 :goto_2

    :pswitch_4
    #v0=(Integer);v1=(Reference);
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    #v0=(UninitRef);
    invoke-direct {v0, v8, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    #v0=(Reference);
    goto/16 :goto_2

    :cond_2
    #v1=(Integer);
    move v1, v3

    #v1=(Null);
    goto/16 :goto_3

    :cond_3
    #v1=(Integer);
    move v1, v2

    #v1=(One);
    goto/16 :goto_4

    :cond_4
    #v0=(Integer);v1=(Integer);
    move v0, v3

    #v0=(Null);
    goto :goto_5

    :cond_5
    #v0=(Integer);
    move v1, v3

    #v1=(Null);
    goto :goto_6

    :cond_6
    #v1=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    #v0=(Reference);
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->vZ:Landroid/widget/FrameLayout;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    array-length v0, v0

    :goto_8
    #v0=(Integer);v2=(Boolean);v3=(Integer);
    if-ge v3, v0, :cond_7

    iget-object v1, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lcom/google/android/gms/internal/el;->wd:[Lcom/google/android/gms/internal/bd;

    #v2=(Reference);
    aget-object v2, v2, v3

    #v2=(Null);
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_8

    :cond_7
    #v2=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vY:Landroid/widget/LinearLayout;

    #v0=(Reference);
    iget-object v1, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_7

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
        :pswitch_2
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_4
        :pswitch_3
    .end packed-switch
.end method


# virtual methods
.method public final eu()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/bo;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/bo;-><init>(Lcom/google/android/gms/internal/el;)V

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/el;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public final ew()V
    .locals 2

    const/4 v0, 0x2

    #v0=(PosByte);
    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/el;->setType(I)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wb:Landroid/widget/ProgressBar;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    invoke-direct {p0}, Lcom/google/android/gms/internal/el;->ex()V

    return-void
.end method

.method protected onAttachedToWindow()V
    .locals 1

    invoke-super {p0}, Landroid/widget/LinearLayout;->onAttachedToWindow()V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->b(Lcom/google/android/gms/common/c;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->a(Lcom/google/android/gms/common/c;)V

    :cond_0
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->b(Lcom/google/android/gms/common/d;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->a(Lcom/google/android/gms/common/d;)V

    :cond_1
    #v0=(Conflicted);
    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 1

    invoke-super {p0}, Landroid/widget/LinearLayout;->onDetachedFromWindow()V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->b(Lcom/google/android/gms/common/c;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->c(Lcom/google/android/gms/common/c;)V

    :cond_0
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->b(Lcom/google/android/gms/common/d;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->vP:Lcom/google/android/gms/plus/a;

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/google/android/gms/plus/a;->c(Lcom/google/android/gms/common/d;)V

    :cond_1
    #v0=(Conflicted);
    return-void
.end method

.method public performClick()Z
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/widget/CompoundButton;->performClick()Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public setOnClickListener(Landroid/view/View$OnClickListener;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wa:Landroid/widget/CompoundButton;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/widget/CompoundButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Lcom/google/android/gms/internal/el;->wc:Lcom/google/android/gms/internal/bs;

    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/bs;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

*/}
