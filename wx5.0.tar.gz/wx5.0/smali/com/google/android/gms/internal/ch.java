package com.google.android.gms.internal; class ch {/*

.class public final Lcom/google/android/gms/internal/ch;
.super Lcom/google/android/gms/internal/co;

# interfaces
.implements Lcom/google/android/gms/games/multiplayer/realtime/Room;


# instance fields
.field private final vu:I


# direct methods
.method private ef()Lcom/google/android/gms/games/multiplayer/realtime/Room;
    .locals 1

    new-instance v0, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;-><init>(Lcom/google/android/gms/games/multiplayer/realtime/Room;)V

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final synthetic cP()Ljava/lang/Object;
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/ch;->ef()Lcom/google/android/gms/games/multiplayer/realtime/Room;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final dm()J
    .locals 2

    const-string v0, "creation_timestamp"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getLong(Ljava/lang/String;)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final do()I
    .locals 1

    const-string v0, "variant"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final dp()Ljava/util/ArrayList;
    .locals 5

    new-instance v1, Ljava/util/ArrayList;

    #v1=(UninitRef);
    iget v0, p0, Lcom/google/android/gms/internal/ch;->vu:I

    #v0=(Integer);
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    #v1=(Reference);
    const/4 v0, 0x0

    :goto_0
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    iget v2, p0, Lcom/google/android/gms/internal/ch;->vu:I

    #v2=(Integer);
    if-ge v0, v2, :cond_0

    new-instance v2, Lcom/google/android/gms/internal/cf;

    #v2=(UninitRef);
    iget-object v3, p0, Lcom/google/android/gms/internal/ch;->yO:Lcom/google/android/gms/internal/l;

    #v3=(Reference);
    iget v4, p0, Lcom/google/android/gms/internal/ch;->yP:I

    #v4=(Integer);
    add-int/2addr v4, v0

    invoke-direct {v2, v3, v4}, Lcom/google/android/gms/internal/cf;-><init>(Lcom/google/android/gms/internal/l;I)V

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    #v2=(Integer);v3=(Conflicted);v4=(Conflicted);
    return-object v1
.end method

.method public final dv()Ljava/lang/String;
    .locals 1

    const-string v0, "external_match_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final dw()Ljava/lang/String;
    .locals 1

    const-string v0, "creator_external"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final dx()Landroid/os/Bundle;
    .locals 6

    const-string v0, "has_automatch_criteria"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    const-string v0, "automatch_min_players"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getInteger(Ljava/lang/String;)I

    move-result v1

    #v1=(Integer);
    const-string v0, "automatch_max_players"

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getInteger(Ljava/lang/String;)I

    move-result v2

    #v2=(Integer);
    const-string v0, "automatch_bit_mask"

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    new-instance v0, Landroid/os/Bundle;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    #v0=(Reference);
    const-string v5, "min_automatch_players"

    #v5=(Reference);
    invoke-virtual {v0, v5, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v1, "max_automatch_players"

    #v1=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v1, "exclusive_bit_mask"

    invoke-virtual {v0, v1, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    goto :goto_0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p0, p1}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->a(Lcom/google/android/gms/games/multiplayer/realtime/Room;Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final getDescription()Ljava/lang/String;
    .locals 1

    const-string v0, "description"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getStatus()I
    .locals 1

    const-string v0, "status"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/ch;->getInteger(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->a(Lcom/google/android/gms/games/multiplayer/realtime/Room;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->b(Lcom/google/android/gms/games/multiplayer/realtime/Room;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/ch;->ef()Lcom/google/android/gms/games/multiplayer/realtime/Room;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/games/multiplayer/realtime/RoomEntity;->writeToParcel(Landroid/os/Parcel;I)V

    return-void
.end method

*/}
