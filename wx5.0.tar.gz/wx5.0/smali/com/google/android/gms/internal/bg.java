package com.google.android.gms.internal; class bg {/*

.class public interface abstract Lcom/google/android/gms/internal/bg;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract a(ILandroid/os/Bundle;Landroid/os/ParcelFileDescriptor;)V
.end method

*/}
