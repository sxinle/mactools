package com.google.android.gms.internal; class ai {/*

.class public final Lcom/google/android/gms/internal/ai;
.super Ljava/lang/Object;


# direct methods
.method private static ae(I)Z
    .locals 1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    #v0=(Integer);
    if-lt v0, p0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public static dZ()Z
    .locals 1

    const/16 v0, 0xb

    #v0=(PosByte);
    invoke-static {v0}, Lcom/google/android/gms/internal/ai;->ae(I)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public static ea()Z
    .locals 1

    const/16 v0, 0x11

    #v0=(PosByte);
    invoke-static {v0}, Lcom/google/android/gms/internal/ai;->ae(I)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

*/}
