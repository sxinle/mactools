package com.google.android.gms.internal; class bm {/*

.class public final Lcom/google/android/gms/internal/bm;
.super Lcom/google/android/gms/internal/co;

# interfaces
.implements Lcom/google/android/gms/games/Player;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/l;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/internal/co;-><init>(Lcom/google/android/gms/internal/l;I)V

    #p0=(Reference);
    return-void
.end method

.method private ec()Lcom/google/android/gms/games/Player;
    .locals 1

    new-instance v0, Lcom/google/android/gms/games/PlayerEntity;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/games/PlayerEntity;-><init>(Lcom/google/android/gms/games/Player;)V

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final synthetic cP()Ljava/lang/Object;
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/bm;->ec()Lcom/google/android/gms/games/Player;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final cW()Landroid/net/Uri;
    .locals 1

    const-string v0, "profile_icon_image_uri"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bm;->P(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final cX()Landroid/net/Uri;
    .locals 1

    const-string v0, "profile_hi_res_image_uri"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bm;->P(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final dh()Ljava/lang/String;
    .locals 1

    const-string v0, "external_player_id"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bm;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final di()J
    .locals 2

    const-string v0, "last_updated"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bm;->getLong(Ljava/lang/String;)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p0, p1}, Lcom/google/android/gms/games/PlayerEntity;->a(Lcom/google/android/gms/games/Player;Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final getDisplayName()Ljava/lang/String;
    .locals 1

    const-string v0, "profile_name"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/bm;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final hashCode()I
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/PlayerEntity;->a(Lcom/google/android/gms/games/Player;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Lcom/google/android/gms/games/PlayerEntity;->b(Lcom/google/android/gms/games/Player;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/bm;->ec()Lcom/google/android/gms/games/Player;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/games/PlayerEntity;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/games/PlayerEntity;->writeToParcel(Landroid/os/Parcel;I)V

    return-void
.end method

*/}
