package com.google.android.gms.internal; class av {/*

.class public final Lcom/google/android/gms/internal/av;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/internal/cn;Landroid/os/Parcel;)V
    .locals 4

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->ei()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/16 v1, 0x3e8

    #v1=(PosShort);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->df()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->ej()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IJ)V

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->eg()S

    move-result v1

    #v1=(Short);
    invoke-static {p1, v1}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;S)V

    const/4 v1, 0x4

    #v1=(PosByte);
    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->getLatitude()D

    move-result-wide v2

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ID)V

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->getLongitude()D

    move-result-wide v2

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ID)V

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->eh()F

    move-result v2

    #v2=(Float);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IF)V

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/cn;->ek()I

    move-result v2

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 14

    const-wide/16 v7, 0x0

    #v7=(LongLo);v8=(LongHi);
    const/4 v4, 0x0

    #v4=(Null);
    invoke-static {p1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v9, 0x0

    #v9=(Null);
    const-wide/16 v10, 0x0

    #v10=(LongLo);v11=(LongHi);
    move-wide v5, v7

    #v5=(LongLo);v6=(LongHi);
    move v3, v4

    #v3=(Null);
    move v1, v4

    :goto_0
    #v1=(Integer);v2=(Reference);v3=(Integer);v4=(Short);v9=(Float);v12=(Conflicted);v13=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v12

    #v12=(Integer);
    if-ge v12, v0, :cond_0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v12

    const v13, 0xffff

    #v13=(Char);
    and-int/2addr v13, v12

    #v13=(Integer);
    sparse-switch v13, :sswitch_data_0

    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :sswitch_0
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->l(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :sswitch_1
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v1

    goto :goto_0

    :sswitch_2
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->g(Landroid/os/Parcel;I)J

    move-result-wide v10

    goto :goto_0

    :sswitch_3
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->e(Landroid/os/Parcel;I)S

    move-result v4

    goto :goto_0

    :sswitch_4
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->j(Landroid/os/Parcel;I)D

    move-result-wide v5

    #v5=(DoubleLo);v6=(DoubleHi);
    goto :goto_0

    :sswitch_5
    #v5=(LongLo);v6=(LongHi);
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->j(Landroid/os/Parcel;I)D

    move-result-wide v7

    #v7=(DoubleLo);v8=(DoubleHi);
    goto :goto_0

    :sswitch_6
    #v7=(LongLo);v8=(LongHi);
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->i(Landroid/os/Parcel;I)F

    move-result v9

    goto :goto_0

    :sswitch_7
    invoke-static {p1, v12}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v3

    goto :goto_0

    :cond_0
    #v13=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v12

    if-eq v12, v0, :cond_1

    new-instance v1, Lcom/google/android/gms/internal/p;

    #v1=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Overread allowed size end="

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0, p1}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v1=(Reference);
    throw v1

    :cond_1
    #v0=(Integer);v1=(Integer);v3=(Integer);
    new-instance v0, Lcom/google/android/gms/internal/cn;

    #v0=(UninitRef);
    invoke-direct/range {v0 .. v11}, Lcom/google/android/gms/internal/cn;-><init>(ILjava/lang/String;ISDDFJ)V

    #v0=(Reference);
    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_0
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x4 -> :sswitch_4
        0x5 -> :sswitch_5
        0x6 -> :sswitch_6
        0x7 -> :sswitch_7
        0x3e8 -> :sswitch_1
    .end sparse-switch
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/internal/cn;

    #v0=(Reference);
    return-object v0
.end method

*/}
