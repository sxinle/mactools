package com.google.android.gms.internal; class ed {/*

.class public Lcom/google/android/gms/internal/ed;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final vE:Lcom/google/android/gms/internal/bc;


# instance fields
.field private final tu:I

.field private final vF:Ljava/lang/String;

.field private final vG:[Ljava/lang/String;

.field private final vH:[Ljava/lang/String;

.field private final vI:[Ljava/lang/String;

.field private final vJ:Ljava/lang/String;

.field private final vK:Ljava/lang/String;

.field private final vL:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/bc;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/bc;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/ed;->vE:Lcom/google/android/gms/internal/bc;

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;[Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/ed;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/internal/ed;->vF:Ljava/lang/String;

    iput-object p3, p0, Lcom/google/android/gms/internal/ed;->vG:[Ljava/lang/String;

    iput-object p4, p0, Lcom/google/android/gms/internal/ed;->vH:[Ljava/lang/String;

    iput-object p5, p0, Lcom/google/android/gms/internal/ed;->vI:[Ljava/lang/String;

    iput-object p6, p0, Lcom/google/android/gms/internal/ed;->vJ:Ljava/lang/String;

    iput-object p7, p0, Lcom/google/android/gms/internal/ed;->vK:Ljava/lang/String;

    iput-object p8, p0, Lcom/google/android/gms/internal/ed;->vL:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/ed;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public final em()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ed;->vG:[Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final en()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ed;->vH:[Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final eo()[Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ed;->vI:[Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final ep()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ed;->vJ:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final eq()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ed;->vK:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    instance-of v1, p1, Lcom/google/android/gms/internal/ed;

    #v1=(Boolean);
    if-nez v1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Integer);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v1=(Boolean);v2=(Uninit);
    check-cast p1, Lcom/google/android/gms/internal/ed;

    iget v1, p0, Lcom/google/android/gms/internal/ed;->tu:I

    #v1=(Integer);
    iget v2, p1, Lcom/google/android/gms/internal/ed;->tu:I

    #v2=(Integer);
    if-ne v1, v2, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ed;->vF:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ed;->vF:Ljava/lang/String;

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ed;->vG:[Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ed;->vG:[Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ed;->vH:[Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ed;->vH:[Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ed;->vI:[Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ed;->vI:[Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ed;->vJ:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ed;->vJ:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ed;->vK:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ed;->vK:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/ed;->vL:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/ed;->vL:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final er()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ed;->vL:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getAccountName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/ed;->vF:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/16 v0, 0x8

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget v2, p0, Lcom/google/android/gms/internal/ed;->tu:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vF:Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vG:[Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vH:[Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vI:[Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x5

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vJ:Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vK:Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x7

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vL:Ljava/lang/String;

    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    invoke-static {p0}, Lcom/google/android/gms/internal/g;->f(Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "versionCode"

    #v1=(Reference);
    iget v2, p0, Lcom/google/android/gms/internal/ed;->tu:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "accountName"

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vF:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "requestedScopes"

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vG:[Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "visibleActivities"

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vH:[Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "requiredFeatures"

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vI:[Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "packageNameForAuth"

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vJ:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "callingPackageName"

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vK:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    const-string v1, "applicationName"

    iget-object v2, p0, Lcom/google/android/gms/internal/ed;->vL:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/internal/h;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/internal/h;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/h;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/gms/internal/bc;->a(Lcom/google/android/gms/internal/ed;Landroid/os/Parcel;)V

    return-void
.end method

*/}
