package com.google.android.gms.internal; class cp {/*

.class final Lcom/google/android/gms/internal/cp;
.super Lcom/google/android/gms/internal/cq;


# direct methods
.method constructor <init>([Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/internal/cq;-><init>([Ljava/lang/String;B)V

    #p0=(Reference);
    return-void
.end method

*/}
