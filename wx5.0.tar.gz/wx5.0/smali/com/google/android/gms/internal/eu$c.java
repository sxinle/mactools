package com.google.android.gms.internal; class eu$c {/*

.class public final Lcom/google/android/gms/internal/eu$c;
.super Lcom/google/android/gms/internal/ar;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;
.implements Lcom/google/android/gms/plus/a/b/f;


# static fields
.field private static final wu:Ljava/util/HashMap;

.field public static final yh:Lcom/google/android/gms/internal/cb;


# instance fields
.field private mValue:Ljava/lang/String;

.field private final tu:I

.field private uy:I

.field private final wv:Ljava/util/Set;

.field private yi:Z


# direct methods
.method static constructor <clinit>()V
    .locals 8

    const/4 v7, 0x2

    #v7=(PosByte);
    new-instance v0, Lcom/google/android/gms/internal/cb;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/cb;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/eu$c;->yh:Lcom/google/android/gms/internal/cb;

    new-instance v0, Ljava/util/HashMap;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/eu$c;->wu:Ljava/util/HashMap;

    const-string v1, "primary"

    #v1=(Reference);
    const-string v2, "primary"

    #v2=(Reference);
    invoke-static {v2, v7}, Lcom/google/android/gms/internal/ar$a;->f(Ljava/lang/String;I)Lcom/google/android/gms/internal/ar$a;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/google/android/gms/internal/eu$c;->wu:Ljava/util/HashMap;

    const-string v1, "type"

    const-string v2, "type"

    const/4 v3, 0x3

    #v3=(PosByte);
    new-instance v4, Lcom/google/android/gms/internal/ao;

    #v4=(UninitRef);
    invoke-direct {v4}, Lcom/google/android/gms/internal/ao;-><init>()V

    #v4=(Reference);
    const-string v5, "home"

    #v5=(Reference);
    const/4 v6, 0x0

    #v6=(Null);
    invoke-virtual {v4, v5, v6}, Lcom/google/android/gms/internal/ao;->c(Ljava/lang/String;I)Lcom/google/android/gms/internal/ao;

    move-result-object v4

    const-string v5, "work"

    const/4 v6, 0x1

    #v6=(One);
    invoke-virtual {v4, v5, v6}, Lcom/google/android/gms/internal/ao;->c(Ljava/lang/String;I)Lcom/google/android/gms/internal/ao;

    move-result-object v4

    const-string v5, "other"

    invoke-virtual {v4, v5, v7}, Lcom/google/android/gms/internal/ao;->c(Ljava/lang/String;I)Lcom/google/android/gms/internal/ao;

    move-result-object v4

    invoke-static {v2, v3, v4}, Lcom/google/android/gms/internal/ar$a;->a(Ljava/lang/String;ILcom/google/android/gms/internal/x;)Lcom/google/android/gms/internal/ar$a;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lcom/google/android/gms/internal/eu$c;->wu:Ljava/util/HashMap;

    const-string v1, "value"

    const-string v2, "value"

    const/4 v3, 0x4

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/ar$a;->g(Ljava/lang/String;I)Lcom/google/android/gms/internal/ar$a;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/ar;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/google/android/gms/internal/eu$c;->tu:I

    new-instance v0, Ljava/util/HashSet;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/eu$c;->wv:Ljava/util/Set;

    return-void
.end method

.method constructor <init>(Ljava/util/Set;IZILjava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Lcom/google/android/gms/internal/ar;-><init>()V

    #p0=(Reference);
    iput-object p1, p0, Lcom/google/android/gms/internal/eu$c;->wv:Ljava/util/Set;

    iput p2, p0, Lcom/google/android/gms/internal/eu$c;->tu:I

    iput-boolean p3, p0, Lcom/google/android/gms/internal/eu$c;->yi:Z

    iput p4, p0, Lcom/google/android/gms/internal/eu$c;->uy:I

    iput-object p5, p0, Lcom/google/android/gms/internal/eu$c;->mValue:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method protected final a(Lcom/google/android/gms/internal/ar$a;)Z
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/internal/eu$c;->wv:Ljava/util/Set;

    #v0=(Reference);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dN()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method protected final b(Lcom/google/android/gms/internal/ar$a;)Ljava/lang/Object;
    .locals 3

    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dN()I

    move-result v0

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Unknown safe parcelable id="

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {p1}, Lcom/google/android/gms/internal/ar$a;->dN()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    :pswitch_0
    #v0=(Integer);v1=(Uninit);v2=(Uninit);
    iget-boolean v0, p0, Lcom/google/android/gms/internal/eu$c;->yi:Z

    #v0=(Boolean);
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    :goto_0
    #v0=(Reference);
    return-object v0

    :pswitch_1
    #v0=(Integer);
    iget v0, p0, Lcom/google/android/gms/internal/eu$c;->uy:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    goto :goto_0

    :pswitch_2
    #v0=(Integer);
    iget-object v0, p0, Lcom/google/android/gms/internal/eu$c;->mValue:Ljava/lang/String;

    #v0=(Reference);
    goto :goto_0

    #v0=(Unknown);v1=(Unknown);v2=(Unknown);p0=(Unknown);p1=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method public final synthetic cP()Ljava/lang/Object;
    .locals 0

    return-object p0
.end method

.method public final dF()Ljava/util/HashMap;
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/eu$c;->wu:Ljava/util/HashMap;

    #v0=(Reference);
    return-object v0
.end method

.method protected final dG()Ljava/lang/Object;
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return-object v0
.end method

.method protected final dH()Z
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final describeContents()I
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/eu$c;->yh:Lcom/google/android/gms/internal/cb;

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/eu$c;->tu:I

    #v0=(Integer);
    return v0
.end method

.method final eD()Ljava/util/Set;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/eu$c;->wv:Ljava/util/Set;

    #v0=(Reference);
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v2, 0x1

    #v2=(One);
    const/4 v1, 0x0

    #v1=(Null);
    instance-of v0, p1, Lcom/google/android/gms/internal/eu$c;

    #v0=(Boolean);
    if-nez v0, :cond_0

    move v0, v1

    :goto_0
    #v3=(Conflicted);v4=(Conflicted);
    return v0

    :cond_0
    #v3=(Uninit);v4=(Uninit);
    if-ne p0, p1, :cond_1

    move v0, v2

    #v0=(One);
    goto :goto_0

    :cond_1
    #v0=(Boolean);
    check-cast p1, Lcom/google/android/gms/internal/eu$c;

    sget-object v0, Lcom/google/android/gms/internal/eu$c;->wu:Ljava/util/HashMap;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_2
    #v0=(Conflicted);v3=(Reference);v4=(Conflicted);
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/internal/ar$a;

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/eu$c;->a(Lcom/google/android/gms/internal/ar$a;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_4

    invoke-virtual {p1, v0}, Lcom/google/android/gms/internal/eu$c;->a(Lcom/google/android/gms/internal/ar$a;)Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/eu$c;->b(Lcom/google/android/gms/internal/ar$a;)Ljava/lang/Object;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {p1, v0}, Lcom/google/android/gms/internal/eu$c;->b(Lcom/google/android/gms/internal/ar$a;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_3
    #v0=(Reference);v4=(Boolean);
    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_4
    #v0=(Reference);
    invoke-virtual {p1, v0}, Lcom/google/android/gms/internal/eu$c;->a(Lcom/google/android/gms/internal/ar$a;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_5
    #v0=(Boolean);v4=(Conflicted);
    move v0, v2

    #v0=(One);
    goto :goto_0
.end method

.method public final ga()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/eu$c;->yi:Z

    #v0=(Boolean);
    return v0
.end method

.method public final getType()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/eu$c;->uy:I

    #v0=(Integer);
    return v0
.end method

.method public final getValue()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/eu$c;->mValue:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final hashCode()I
    .locals 4

    const/4 v0, 0x0

    #v0=(Null);
    sget-object v1, Lcom/google/android/gms/internal/eu$c;->wu:Ljava/util/HashMap;

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    #v2=(Reference);
    move v1, v0

    :goto_0
    #v0=(Integer);v1=(Integer);v3=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/google/android/gms/internal/ar$a;

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/eu$c;->a(Lcom/google/android/gms/internal/ar$a;)Z

    move-result v3

    #v3=(Boolean);
    if-eqz v3, :cond_1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/ar$a;->dN()I

    move-result v3

    #v3=(Integer);
    add-int/2addr v1, v3

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/eu$c;->b(Lcom/google/android/gms/internal/ar$a;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    #v0=(Integer);
    add-int/2addr v0, v1

    :goto_1
    move v1, v0

    goto :goto_0

    :cond_0
    #v0=(Boolean);v3=(Conflicted);
    return v1

    :cond_1
    #v0=(Reference);v3=(Boolean);
    move v0, v1

    #v0=(Integer);
    goto :goto_1
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/internal/eu$c;->yh:Lcom/google/android/gms/internal/cb;

    #v0=(Reference);
    invoke-static {p0, p1}, Lcom/google/android/gms/internal/cb;->a(Lcom/google/android/gms/internal/eu$c;Landroid/os/Parcel;)V

    return-void
.end method

*/}
