package com.google.android.gms.internal; class aj {/*

.class public abstract Lcom/google/android/gms/internal/aj;
.super Ljava/lang/Object;


# instance fields
.field private final vo:Lcom/google/android/gms/internal/at;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    new-instance v0, Lcom/google/android/gms/internal/al;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/al;-><init>(Lcom/google/android/gms/internal/aj;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/internal/aj;->vo:Lcom/google/android/gms/internal/at;

    return-void
.end method

*/}
