package com.google.android.gms.internal; class fh {/*

.class public Lcom/google/android/gms/internal/fh;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final yx:Lcom/google/android/gms/internal/ck;


# instance fields
.field private final tu:I

.field private final wZ:Ljava/lang/String;

.field private final yA:Landroid/net/Uri;

.field private final yB:Ljava/lang/String;

.field private final yC:Ljava/lang/String;

.field private final yD:Ljava/lang/String;

.field private final yE:Landroid/os/Bundle;

.field private final yF:Landroid/os/Bundle;

.field private final yy:Ljava/util/List;

.field private final yz:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/internal/ck;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/internal/ck;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/internal/fh;->yx:Lcom/google/android/gms/internal/ck;

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/util/List;Ljava/util/List;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Landroid/os/Bundle;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput p1, p0, Lcom/google/android/gms/internal/fh;->tu:I

    iput-object p2, p0, Lcom/google/android/gms/internal/fh;->wZ:Ljava/lang/String;

    iput-object p3, p0, Lcom/google/android/gms/internal/fh;->yy:Ljava/util/List;

    iput-object p4, p0, Lcom/google/android/gms/internal/fh;->yz:Ljava/util/List;

    iput-object p5, p0, Lcom/google/android/gms/internal/fh;->yA:Landroid/net/Uri;

    iput-object p6, p0, Lcom/google/android/gms/internal/fh;->yB:Ljava/lang/String;

    iput-object p7, p0, Lcom/google/android/gms/internal/fh;->yC:Ljava/lang/String;

    iput-object p8, p0, Lcom/google/android/gms/internal/fh;->yD:Ljava/lang/String;

    iput-object p9, p0, Lcom/google/android/gms/internal/fh;->yE:Landroid/os/Bundle;

    iput-object p10, p0, Lcom/google/android/gms/internal/fh;->yF:Landroid/os/Bundle;

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final df()I
    .locals 1

    iget v0, p0, Lcom/google/android/gms/internal/fh;->tu:I

    #v0=(Integer);
    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    instance-of v1, p1, Lcom/google/android/gms/internal/fh;

    #v1=(Boolean);
    if-nez v1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Integer);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v1=(Boolean);v2=(Uninit);
    check-cast p1, Lcom/google/android/gms/internal/fh;

    iget v1, p0, Lcom/google/android/gms/internal/fh;->tu:I

    #v1=(Integer);
    iget v2, p1, Lcom/google/android/gms/internal/fh;->tu:I

    #v2=(Integer);
    if-ne v1, v2, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fh;->yy:Ljava/util/List;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fh;->yy:Ljava/util/List;

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fh;->yz:Ljava/util/List;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fh;->yz:Ljava/util/List;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fh;->yA:Landroid/net/Uri;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fh;->yA:Landroid/net/Uri;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fh;->yB:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fh;->yB:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fh;->yC:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fh;->yC:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/android/gms/internal/fh;->yD:Ljava/lang/String;

    #v1=(Reference);
    iget-object v2, p1, Lcom/google/android/gms/internal/fh;->yD:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/google/android/gms/internal/g;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final getId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->wZ:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final gj()Ljava/util/List;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yy:Ljava/util/List;

    #v0=(Reference);
    return-object v0
.end method

.method public final gk()Ljava/util/List;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yz:Ljava/util/List;

    #v0=(Reference);
    return-object v0
.end method

.method public final gl()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yA:Landroid/net/Uri;

    #v0=(Reference);
    return-object v0
.end method

.method public final gm()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yB:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final gn()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yC:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final go()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yD:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final gp()Landroid/os/Bundle;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yE:Landroid/os/Bundle;

    #v0=(Reference);
    return-object v0
.end method

.method public final gq()Landroid/os/Bundle;
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/internal/fh;->yF:Landroid/os/Bundle;

    #v0=(Reference);
    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v0, 0x7

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget v2, p0, Lcom/google/android/gms/internal/fh;->tu:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget-object v2, p0, Lcom/google/android/gms/internal/fh;->yy:Ljava/util/List;

    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-object v2, p0, Lcom/google/android/gms/internal/fh;->yz:Ljava/util/List;

    aput-object v2, v0, v1

    const/4 v1, 0x3

    iget-object v2, p0, Lcom/google/android/gms/internal/fh;->yA:Landroid/net/Uri;

    aput-object v2, v0, v1

    const/4 v1, 0x4

    iget-object v2, p0, Lcom/google/android/gms/internal/fh;->yB:Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x5

    iget-object v2, p0, Lcom/google/android/gms/internal/fh;->yC:Ljava/lang/String;

    aput-object v2, v0, v1

    const/4 v1, 0x6

    iget-object v2, p0, Lcom/google/android/gms/internal/fh;->yD:Ljava/lang/String;

    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    invoke-static {p0, p1, p2}, Lcom/google/android/gms/internal/ck;->a(Lcom/google/android/gms/internal/fh;Landroid/os/Parcel;I)V

    return-void
.end method

*/}
