package com.google.android.gms.plus.a.b; class i {/*

.class public interface abstract Lcom/google/android/gms/plus/a/b/i;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/a/a;

*/}
