package com.google.android.gms.plus; class b {/*

.class public interface abstract Lcom/google/android/gms/plus/b;
.super Ljava/lang/Object;

*/}
