package com.google.android.gms.plus; class PlusOneButton {/*

.class public final Lcom/google/android/gms/plus/PlusOneButton;
.super Landroid/view/ViewGroup;


# instance fields
.field private final BI:Lcom/google/android/gms/internal/el;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    #p0=(Reference);
    new-instance v0, Lcom/google/android/gms/internal/el;

    #v0=(UninitRef);
    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/internal/el;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/google/android/gms/plus/PlusOneButton;->BI:Lcom/google/android/gms/internal/el;

    iget-object v0, p0, Lcom/google/android/gms/plus/PlusOneButton;->BI:Lcom/google/android/gms/internal/el;

    invoke-virtual {p0, v0}, Lcom/google/android/gms/plus/PlusOneButton;->addView(Landroid/view/View;)V

    invoke-virtual {p0}, Lcom/google/android/gms/plus/PlusOneButton;->isInEditMode()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    :goto_0
    #v0=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);
    iget-object v0, p0, Lcom/google/android/gms/plus/PlusOneButton;->BI:Lcom/google/android/gms/internal/el;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/google/android/gms/internal/el;->eu()V

    goto :goto_0
.end method


# virtual methods
.method protected final onLayout(ZIIII)V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    iget-object v0, p0, Lcom/google/android/gms/plus/PlusOneButton;->BI:Lcom/google/android/gms/internal/el;

    #v0=(Reference);
    sub-int v1, p4, p2

    #v1=(Integer);
    sub-int v2, p5, p3

    #v2=(Integer);
    invoke-virtual {v0, v3, v3, v1, v2}, Lcom/google/android/gms/internal/el;->layout(IIII)V

    return-void
.end method

.method protected final onMeasure(II)V
    .locals 2

    iget-object v0, p0, Lcom/google/android/gms/plus/PlusOneButton;->BI:Lcom/google/android/gms/internal/el;

    #v0=(Reference);
    invoke-virtual {p0, v0, p1, p2}, Lcom/google/android/gms/plus/PlusOneButton;->measureChild(Landroid/view/View;II)V

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0, v1, v0}, Lcom/google/android/gms/plus/PlusOneButton;->setMeasuredDimension(II)V

    return-void
.end method

*/}
