package com.google.android.gms.plus; class c {/*

.class public interface abstract Lcom/google/android/gms/plus/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Intent;)V
.end method

*/}
