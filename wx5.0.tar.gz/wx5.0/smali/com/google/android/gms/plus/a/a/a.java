package com.google.android.gms.plus.a.a; class a {/*

.class public interface abstract Lcom/google/android/gms/plus/a/a/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/a/a;

*/}
