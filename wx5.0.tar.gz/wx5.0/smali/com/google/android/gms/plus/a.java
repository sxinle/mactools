package com.google.android.gms.plus; class a {/*

.class public final Lcom/google/android/gms/plus/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/b;


# instance fields
.field final BH:Lcom/google/android/gms/internal/bj;


# virtual methods
.method public final a(Lcom/google/android/gms/common/c;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/bj;->a(Lcom/google/android/gms/common/c;)V

    return-void
.end method

.method public final a(Lcom/google/android/gms/common/d;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/bj;->a(Lcom/google/android/gms/common/d;)V

    return-void
.end method

.method public final a(Lcom/google/android/gms/plus/b;I)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/internal/bj;->a(Lcom/google/android/gms/plus/b;I)V

    return-void
.end method

.method public final b(Lcom/google/android/gms/common/c;)Z
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/bj;->b(Lcom/google/android/gms/common/c;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final b(Lcom/google/android/gms/common/d;)Z
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/bj;->b(Lcom/google/android/gms/common/d;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final c(Lcom/google/android/gms/common/c;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/bj;->c(Lcom/google/android/gms/common/c;)V

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/d;)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/google/android/gms/internal/bj;->c(Lcom/google/android/gms/common/d;)V

    return-void
.end method

.method public final isConnected()Z
    .locals 1

    iget-object v0, p0, Lcom/google/android/gms/plus/a;->BH:Lcom/google/android/gms/internal/bj;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/google/android/gms/internal/bj;->isConnected()Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

*/}
