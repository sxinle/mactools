package com.google.android.gms.plus.a.b; class h {/*

.class public interface abstract Lcom/google/android/gms/plus/a/b/h;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/a/a;

*/}
