package com.google.android.gms.location; class a {/*

.class public final Lcom/google/android/gms/location/a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method static a(Lcom/google/android/gms/location/ActivityRecognitionResult;Landroid/os/Parcel;)V
    .locals 4

    invoke-static {p1}, Lcom/google/android/gms/internal/q;->g(Landroid/os/Parcel;)I

    move-result v0

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    iget-object v2, p0, Lcom/google/android/gms/location/ActivityRecognitionResult;->Ac:Ljava/util/List;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;ILjava/util/List;Z)V

    const/16 v1, 0x3e8

    #v1=(PosShort);
    iget v2, p0, Lcom/google/android/gms/location/ActivityRecognitionResult;->tu:I

    #v2=(Integer);
    invoke-static {p1, v1, v2}, Lcom/google/android/gms/internal/q;->c(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-wide v2, p0, Lcom/google/android/gms/location/ActivityRecognitionResult;->Ad:J

    #v2=(LongLo);v3=(LongHi);
    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IJ)V

    const/4 v1, 0x3

    iget-wide v2, p0, Lcom/google/android/gms/location/ActivityRecognitionResult;->Ae:J

    invoke-static {p1, v1, v2, v3}, Lcom/google/android/gms/internal/q;->a(Landroid/os/Parcel;IJ)V

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/q;->v(Landroid/os/Parcel;I)V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 4

    new-instance v0, Lcom/google/android/gms/location/ActivityRecognitionResult;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/location/ActivityRecognitionResult;-><init>()V

    #v0=(Reference);
    invoke-static {p1}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;)I

    move-result v1

    :goto_0
    #v1=(Integer);v2=(Conflicted);v3=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    #v2=(Integer);
    if-ge v2, v1, :cond_0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const v3, 0xffff

    #v3=(Char);
    and-int/2addr v3, v2

    #v3=(Integer);
    sparse-switch v3, :sswitch_data_0

    invoke-static {p1, v2}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;I)V

    goto :goto_0

    :sswitch_0
    sget-object v3, Lcom/google/android/gms/location/DetectedActivity;->Af:Lcom/google/android/gms/location/b;

    #v3=(Reference);
    invoke-static {p1, v2, v3}, Lcom/google/android/gms/internal/o;->b(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v2

    #v2=(Reference);
    iput-object v2, v0, Lcom/google/android/gms/location/ActivityRecognitionResult;->Ac:Ljava/util/List;

    goto :goto_0

    :sswitch_1
    #v2=(Integer);v3=(Integer);
    invoke-static {p1, v2}, Lcom/google/android/gms/internal/o;->f(Landroid/os/Parcel;I)I

    move-result v2

    iput v2, v0, Lcom/google/android/gms/location/ActivityRecognitionResult;->tu:I

    goto :goto_0

    :sswitch_2
    invoke-static {p1, v2}, Lcom/google/android/gms/internal/o;->g(Landroid/os/Parcel;I)J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    iput-wide v2, v0, Lcom/google/android/gms/location/ActivityRecognitionResult;->Ad:J

    goto :goto_0

    :sswitch_3
    #v2=(Integer);v3=(Integer);
    invoke-static {p1, v2}, Lcom/google/android/gms/internal/o;->g(Landroid/os/Parcel;I)J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    iput-wide v2, v0, Lcom/google/android/gms/location/ActivityRecognitionResult;->Ae:J

    goto :goto_0

    :cond_0
    #v2=(Integer);v3=(Conflicted);
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    if-eq v2, v1, :cond_1

    new-instance v0, Lcom/google/android/gms/internal/p;

    #v0=(UninitRef);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Overread allowed size end="

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/internal/p;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    #v0=(Reference);
    throw v0

    :cond_1
    #v1=(Integer);v2=(Integer);v3=(Conflicted);
    return-object v0

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_0
        0x2 -> :sswitch_2
        0x3 -> :sswitch_3
        0x3e8 -> :sswitch_1
    .end sparse-switch
.end method

.method public final bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1

    new-array v0, p1, [Lcom/google/android/gms/location/ActivityRecognitionResult;

    #v0=(Reference);
    return-object v0
.end method

*/}
