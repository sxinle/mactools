package com.google.android.gms.location; class LocationRequest {/*

.class public final Lcom/google/android/gms/location/LocationRequest;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# static fields
.field public static final Ap:Lcom/google/android/gms/location/c;


# instance fields
.field Ai:I

.field Aj:J

.field Ak:J

.field Al:Z

.field Am:J

.field An:I

.field Ao:F

.field tu:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/google/android/gms/location/c;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/google/android/gms/location/c;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/google/android/gms/location/LocationRequest;->Ap:Lcom/google/android/gms/location/c;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/16 v0, 0x66

    #v0=(PosByte);
    iput v0, p0, Lcom/google/android/gms/location/LocationRequest;->Ai:I

    const-wide/32 v0, 0x36ee80

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/google/android/gms/location/LocationRequest;->Aj:J

    iget-wide v0, p0, Lcom/google/android/gms/location/LocationRequest;->Aj:J

    long-to-double v0, v0

    #v0=(DoubleLo);v1=(DoubleHi);
    const-wide/high16 v2, 0x4018

    #v2=(LongLo);v3=(LongHi);
    div-double/2addr v0, v2

    double-to-long v0, v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/google/android/gms/location/LocationRequest;->Ak:J

    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/google/android/gms/location/LocationRequest;->Al:Z

    const-wide v0, 0x7fffffffffffffffL

    #v0=(LongLo);
    iput-wide v0, p0, Lcom/google/android/gms/location/LocationRequest;->Am:J

    const v0, 0x7fffffff

    #v0=(Integer);
    iput v0, p0, Lcom/google/android/gms/location/LocationRequest;->An:I

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/google/android/gms/location/LocationRequest;->Ao:F

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 6

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    if-ne p0, p1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    :cond_1
    #v0=(One);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    instance-of v2, p1, Lcom/google/android/gms/location/LocationRequest;

    #v2=(Boolean);
    if-nez v2, :cond_2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(One);
    check-cast p1, Lcom/google/android/gms/location/LocationRequest;

    iget v2, p0, Lcom/google/android/gms/location/LocationRequest;->Ai:I

    #v2=(Integer);
    iget v3, p1, Lcom/google/android/gms/location/LocationRequest;->Ai:I

    #v3=(Integer);
    if-ne v2, v3, :cond_3

    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Aj:J

    #v2=(LongLo);v3=(LongHi);
    iget-wide v4, p1, Lcom/google/android/gms/location/LocationRequest;->Aj:J

    #v4=(LongLo);v5=(LongHi);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-nez v2, :cond_3

    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Ak:J

    #v2=(LongLo);
    iget-wide v4, p1, Lcom/google/android/gms/location/LocationRequest;->Ak:J

    cmp-long v2, v2, v4

    #v2=(Byte);
    if-nez v2, :cond_3

    iget-boolean v2, p0, Lcom/google/android/gms/location/LocationRequest;->Al:Z

    #v2=(Boolean);
    iget-boolean v3, p1, Lcom/google/android/gms/location/LocationRequest;->Al:Z

    #v3=(Boolean);
    if-ne v2, v3, :cond_3

    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Am:J

    #v2=(LongLo);v3=(LongHi);
    iget-wide v4, p1, Lcom/google/android/gms/location/LocationRequest;->Am:J

    cmp-long v2, v2, v4

    #v2=(Byte);
    if-nez v2, :cond_3

    iget v2, p0, Lcom/google/android/gms/location/LocationRequest;->An:I

    #v2=(Integer);
    iget v3, p1, Lcom/google/android/gms/location/LocationRequest;->An:I

    #v3=(Integer);
    if-ne v2, v3, :cond_3

    iget v2, p0, Lcom/google/android/gms/location/LocationRequest;->Ao:F

    iget v3, p1, Lcom/google/android/gms/location/LocationRequest;->Ao:F

    cmpl-float v2, v2, v3

    #v2=(Byte);
    if-eqz v2, :cond_0

    :cond_3
    #v2=(Integer);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public final hashCode()I
    .locals 4

    const/4 v0, 0x7

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/Object;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget v2, p0, Lcom/google/android/gms/location/LocationRequest;->Ai:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x1

    #v1=(One);
    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Aj:J

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x2

    #v1=(PosByte);
    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Ak:J

    #v2=(LongLo);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x3

    iget-boolean v2, p0, Lcom/google/android/gms/location/LocationRequest;->Al:Z

    #v2=(Boolean);
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x4

    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Am:J

    #v2=(LongLo);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x5

    iget v2, p0, Lcom/google/android/gms/location/LocationRequest;->An:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    const/4 v1, 0x6

    iget v2, p0, Lcom/google/android/gms/location/LocationRequest;->Ao:F

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    #v2=(Reference);
    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    #v0=(Integer);
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 6

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    #v1=(Reference);
    const-string v0, "Request["

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    #v2=(Reference);
    iget v0, p0, Lcom/google/android/gms/location/LocationRequest;->Ai:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    :pswitch_0
    const-string v0, "???"

    :goto_0
    #v0=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Lcom/google/android/gms/location/LocationRequest;->Ai:I

    #v0=(Integer);
    const/16 v2, 0x69

    #v2=(PosByte);
    if-eq v0, v2, :cond_0

    const-string v0, " requested="

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    #v0=(Reference);
    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Aj:J

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "ms"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    const-string v0, " fastest="

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    #v0=(Reference);
    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Ak:J

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "ms"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Am:J

    #v2=(LongLo);
    const-wide v4, 0x7fffffffffffffffL

    #v4=(LongLo);v5=(LongHi);
    cmp-long v0, v2, v4

    #v0=(Byte);
    if-eqz v0, :cond_1

    iget-wide v2, p0, Lcom/google/android/gms/location/LocationRequest;->Am:J

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const-string v0, " expireIn="

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    #v0=(Reference);
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "ms"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    #v0=(Conflicted);v2=(Conflicted);
    iget v0, p0, Lcom/google/android/gms/location/LocationRequest;->An:I

    #v0=(Integer);
    const v2, 0x7fffffff

    #v2=(Integer);
    if-eq v0, v2, :cond_2

    const-string v0, " num="

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v2, p0, Lcom/google/android/gms/location/LocationRequest;->An:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_2
    #v0=(Conflicted);
    const/16 v0, 0x5d

    #v0=(PosByte);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0

    :pswitch_1
    #v0=(Integer);v2=(Reference);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    const-string v0, "PRIORITY_HIGH_ACCURACY"

    #v0=(Reference);
    goto/16 :goto_0

    :pswitch_2
    #v0=(Integer);
    const-string v0, "PRIORITY_BALANCED_POWER_ACCURACY"

    #v0=(Reference);
    goto/16 :goto_0

    :pswitch_3
    #v0=(Integer);
    const-string v0, "PRIORITY_LOW_POWER"

    #v0=(Reference);
    goto/16 :goto_0

    :pswitch_4
    #v0=(Integer);
    const-string v0, "PRIORITY_NO_POWER"

    #v0=(Reference);
    goto/16 :goto_0

    :pswitch_data_0
    .packed-switch 0x64
        :pswitch_1
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    sget-object v0, Lcom/google/android/gms/location/LocationRequest;->Ap:Lcom/google/android/gms/location/c;

    #v0=(Reference);
    invoke-static {p0, p1}, Lcom/google/android/gms/location/c;->a(Lcom/google/android/gms/location/LocationRequest;Landroid/os/Parcel;)V

    return-void
.end method

*/}
