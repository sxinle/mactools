package com.android.internal.telephony; class SmsRawData$1 {/*

.class Lcom/android/internal/telephony/SmsRawData$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Lcom/android/internal/telephony/SmsRawData;
    .locals 2
    .parameter

    .prologue
    .line 34
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    .line 35
    #v0=(Integer);
    new-array v0, v0, [B

    .line 36
    #v0=(Reference);
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readByteArray([B)V

    .line 37
    new-instance v1, Lcom/android/internal/telephony/SmsRawData;

    #v1=(UninitRef);
    invoke-direct {v1, v0}, Lcom/android/internal/telephony/SmsRawData;-><init>([B)V

    #v1=(Reference);
    return-object v1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1
    .parameter

    .prologue
    .line 1
    invoke-virtual {p0, p1}, Lcom/android/internal/telephony/SmsRawData$1;->createFromParcel(Landroid/os/Parcel;)Lcom/android/internal/telephony/SmsRawData;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public newArray(I)[Lcom/android/internal/telephony/SmsRawData;
    .locals 1
    .parameter

    .prologue
    .line 41
    new-array v0, p1, [Lcom/android/internal/telephony/SmsRawData;

    #v0=(Reference);
    return-object v0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 1
    .parameter

    .prologue
    .line 1
    invoke-virtual {p0, p1}, Lcom/android/internal/telephony/SmsRawData$1;->newArray(I)[Lcom/android/internal/telephony/SmsRawData;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

*/}
