package com.tencent.mapapi.a; class c {/*

.class public interface abstract Lcom/tencent/mapapi/a/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(ILjava/lang/Integer;[BLjava/lang/String;)V
.end method

*/}
