package com.tencent.mapapi.a; class g {/*

.class public final Lcom/tencent/mapapi/a/g;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static ac(Ljava/lang/String;)Z
    .locals 1
    .parameter

    .prologue
    .line 16
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_0

    const/4 v0, 0x0

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Conflicted);
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

*/}
