package com.tencent.mapapi.a; class e {/*

.class public final Lcom/tencent/mapapi/a/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static Da:Z

.field private static a:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 41
    const/4 v0, 0x0

    #v0=(Null);
    sput v0, Lcom/tencent/mapapi/a/e;->a:I

    .line 18
    return-void
.end method

.method private static a(Ljava/net/HttpURLConnection;Z)Lcom/tencent/a/a/c;
    .locals 11
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x1

    #v2=(One);
    const/4 v0, 0x0

    .line 241
    #v0=(Null);
    const/4 v1, 0x0

    .line 243
    :try_start_0
    #v1=(Null);
    new-instance v5, Lcom/tencent/a/a/c;

    #v5=(UninitRef);
    invoke-direct {v5}, Lcom/tencent/a/a/c;-><init>()V

    .line 244
    #v5=(Reference);
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getContentType()Ljava/lang/String;

    move-result-object v6

    .line 245
    #v6=(Reference);
    const-string v3, "GBK"

    #v3=(Reference);
    if-eqz v6, :cond_0

    const-string v4, ";"

    #v4=(Reference);
    invoke-virtual {v6, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    array-length v8, v7

    #v8=(Integer);
    move v4, v0

    :goto_0
    #v4=(Integer);v9=(Conflicted);v10=(Conflicted);
    if-lt v4, v8, :cond_6

    :cond_0
    :goto_1
    #v4=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    iput-object v3, v5, Lcom/tencent/a/a/c;->GP:Ljava/lang/String;

    .line 246
    if-eqz p1, :cond_1

    .line 247
    if-eqz v6, :cond_8

    const-string v3, "vnd.wap.wml"

    invoke-virtual {v6, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    #v3=(Boolean);
    if-eqz v3, :cond_8

    :goto_2
    #v2=(Boolean);v3=(Conflicted);
    if-eqz v2, :cond_1

    .line 248
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 249
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->connect()V

    .line 253
    :cond_1
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    .line 254
    #v1=(Reference);
    if-eqz v1, :cond_4

    .line 256
    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [B

    #v2=(Reference);
    iput-object v2, v5, Lcom/tencent/a/a/c;->data:[B

    .line 258
    const/16 v2, 0x400

    #v2=(PosShort);
    new-array v2, v2, [B

    .line 261
    :cond_2
    #v0=(Integer);v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    .line 262
    #v3=(Integer);
    if-lez v3, :cond_3

    .line 263
    add-int/2addr v0, v3

    .line 264
    new-array v4, v0, [B

    .line 265
    #v4=(Reference);
    iget-object v6, v5, Lcom/tencent/a/a/c;->data:[B

    const/4 v7, 0x0

    #v7=(Null);
    const/4 v8, 0x0

    #v8=(Null);
    iget-object v9, v5, Lcom/tencent/a/a/c;->data:[B

    #v9=(Reference);
    array-length v9, v9

    #v9=(Integer);
    invoke-static {v6, v7, v4, v8, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 266
    const/4 v6, 0x0

    #v6=(Null);
    iget-object v7, v5, Lcom/tencent/a/a/c;->data:[B

    #v7=(Reference);
    array-length v7, v7

    #v7=(Integer);
    invoke-static {v2, v6, v4, v7, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 267
    iput-object v4, v5, Lcom/tencent/a/a/c;->data:[B
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 269
    :cond_3
    #v4=(Conflicted);v6=(Reference);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    if-gtz v3, :cond_2

    .line 273
    :cond_4
    #v2=(Conflicted);v3=(Conflicted);
    if-eqz v1, :cond_5

    .line 275
    :try_start_1
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    .line 271
    :cond_5
    :goto_3
    #v0=(Conflicted);
    return-object v5

    .line 245
    :cond_6
    :try_start_2
    #v0=(Null);v1=(Null);v2=(One);v3=(Reference);v4=(Integer);v7=(Reference);v8=(Integer);
    aget-object v9, v7, v4

    #v9=(Null);
    const-string v10, "charset"

    #v10=(Reference);
    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    #v10=(Boolean);
    if-eqz v10, :cond_7

    const-string v4, "="

    #v4=(Reference);
    invoke-virtual {v9, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    array-length v7, v4

    #v7=(Integer);
    if-le v7, v2, :cond_0

    const/4 v3, 0x1

    #v3=(One);
    aget-object v3, v4, v3

    #v3=(Null);
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-result-object v3

    #v3=(Reference);
    goto :goto_1

    :cond_7
    #v4=(Integer);v7=(Reference);
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_8
    #v3=(Conflicted);v4=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);
    move v2, v0

    .line 247
    #v2=(Null);
    goto :goto_2

    .line 272
    :catchall_0
    #v0=(Integer);v1=(Reference);v2=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    move-exception v0

    .line 273
    #v0=(Reference);
    if-eqz v1, :cond_9

    .line 275
    :try_start_3
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    .line 279
    :cond_9
    :goto_4
    throw v0

    :catch_0
    #v0=(Integer);v5=(Reference);v6=(Reference);
    move-exception v0

    #v0=(Reference);
    goto :goto_3

    :catch_1
    #v5=(Conflicted);v6=(Conflicted);
    move-exception v1

    goto :goto_4
.end method

.method public static a(ZLjava/lang/String;Ljava/lang/String;[B)Lcom/tencent/a/a/c;
    .locals 6
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x1

    #v2=(One);
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v1, 0x0

    .line 150
    #v1=(Null);
    invoke-static {}, Lcom/tencent/a/a/b;->iA()Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_0

    .line 153
    new-instance v0, Lcom/tencent/mapapi/a/f;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mapapi/a/f;-><init>()V

    #v0=(Reference);
    throw v0

    .line 159
    :cond_0
    :try_start_0
    #v0=(Null);
    invoke-static {p1}, Lcom/tencent/mapapi/a/e;->af(Ljava/lang/String;)Ljava/net/HttpURLConnection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2
    .catch Lcom/tencent/mapapi/a/d; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    move-result-object v3

    .line 161
    #v3=(Reference);
    const/4 v4, 0x0

    :try_start_1
    #v4=(Null);
    invoke-static {v4}, Lcom/tencent/mapapi/a/g;->ac(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_7

    .line 162
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getURL()Ljava/net/URL;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {v4}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v4

    .line 163
    invoke-static {v4}, Lcom/tencent/mapapi/a/g;->ac(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_1

    .line 170
    :cond_1
    :goto_0
    #v4=(Conflicted);v5=(Conflicted);
    if-eqz p0, :cond_a

    .line 171
    const-string v4, "GET"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 175
    :goto_1
    invoke-static {}, Lcom/tencent/a/a/d;->is()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 176
    invoke-static {}, Lcom/tencent/a/a/d;->it()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 177
    const-string v4, "User-Agent"

    #v4=(Reference);
    invoke-virtual {v3, v4, p2}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 178
    const/4 v4, 0x1

    #v4=(One);
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setDoInput(Z)V

    .line 179
    if-eqz p0, :cond_2

    move v2, v0

    :cond_2
    #v2=(Boolean);
    invoke-virtual {v3, v2}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    .line 180
    const/4 v2, 0x0

    #v2=(Null);
    invoke-virtual {v3, v2}, Ljava/net/HttpURLConnection;->setUseCaches(Z)V

    .line 181
    invoke-static {v3}, Lcom/tencent/a/a/d;->b(Ljava/net/HttpURLConnection;)V

    .line 186
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->connect()V

    .line 187
    invoke-static {}, Lcom/tencent/a/a/d;->in()V

    .line 189
    if-nez p0, :cond_3

    if-eqz p3, :cond_3

    array-length v2, p3

    #v2=(Integer);
    if-eqz v2, :cond_3

    .line 190
    new-instance v2, Ljava/io/DataOutputStream;

    #v2=(UninitRef);
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v4

    #v4=(Reference);
    invoke-direct {v2, v4}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1
    .catch Lcom/tencent/mapapi/a/d; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 191
    :try_start_2
    #v2=(Reference);
    invoke-virtual {v2, p3}, Ljava/io/DataOutputStream;->write([B)V

    .line 192
    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    .line 193
    invoke-virtual {v2}, Ljava/io/DataOutputStream;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3
    .catch Lcom/tencent/mapapi/a/d; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    .line 196
    :cond_3
    :try_start_3
    #v2=(Conflicted);v4=(Conflicted);
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v2

    .line 198
    #v2=(Integer);
    const/16 v4, 0xc8

    #v4=(PosShort);
    if-eq v2, v4, :cond_4

    .line 199
    const/16 v4, 0xce

    if-ne v2, v4, :cond_b

    .line 200
    :cond_4
    invoke-static {}, Lcom/tencent/a/a/d;->ie()V

    .line 201
    invoke-static {v3, p0}, Lcom/tencent/mapapi/a/e;->a(Ljava/net/HttpURLConnection;Z)Lcom/tencent/a/a/c;

    move-result-object v2

    .line 202
    #v2=(Reference);
    if-eqz v2, :cond_5

    iget-object v4, v2, Lcom/tencent/a/a/c;->data:[B

    #v4=(Reference);
    if-eqz v4, :cond_5

    iget-object v0, v2, Lcom/tencent/a/a/c;->data:[B

    #v0=(Reference);
    array-length v0, v0

    :cond_5
    #v0=(Integer);v4=(Conflicted);
    invoke-static {v0}, Lcom/tencent/a/a/d;->aj(I)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1
    .catch Lcom/tencent/mapapi/a/d; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 205
    if-eqz v3, :cond_6

    .line 231
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 205
    :cond_6
    return-object v2

    .line 167
    :cond_7
    :try_start_4
    #v0=(Null);v2=(One);v4=(Boolean);v5=(Uninit);
    const-string v4, "Host"

    #v4=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    invoke-virtual {v3, v4, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1
    .catch Lcom/tencent/mapapi/a/d; {:try_start_4 .. :try_end_4} :catch_0
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    goto :goto_0

    .line 220
    :catch_0
    #v0=(Conflicted);v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v2, v3

    .line 221
    :goto_2
    #v1=(Reference);v2=(Reference);v3=(Conflicted);
    const/4 v3, 0x1

    :try_start_5
    #v3=(One);
    invoke-static {v3}, Lcom/tencent/a/a/d;->d(Z)V

    .line 222
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 226
    :catchall_0
    move-exception v0

    move-object v3, v2

    .line 227
    :goto_3
    #v2=(Conflicted);v3=(Reference);
    if-eqz v1, :cond_8

    .line 228
    invoke-virtual {v1}, Ljava/io/DataOutputStream;->close()V

    .line 230
    :cond_8
    if-eqz v3, :cond_9

    .line 231
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 233
    :cond_9
    throw v0

    .line 173
    :cond_a
    :try_start_6
    #v0=(Null);v1=(Null);v2=(One);
    const-string v4, "POST"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1
    .catch Lcom/tencent/mapapi/a/d; {:try_start_6 .. :try_end_6} :catch_0
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    goto/16 :goto_1

    .line 223
    :catch_1
    #v0=(Conflicted);v2=(Conflicted);v4=(Conflicted);
    move-exception v0

    .line 224
    :goto_4
    #v0=(Reference);v1=(Reference);
    const/4 v2, 0x0

    :try_start_7
    #v2=(Null);
    invoke-static {v2}, Lcom/tencent/a/a/d;->d(Z)V

    .line 225
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 226
    :catchall_1
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    goto :goto_3

    .line 206
    :cond_b
    #v0=(Null);v1=(Null);v2=(Integer);v4=(PosShort);
    const/16 v0, 0xca

    #v0=(PosShort);
    if-eq v2, v0, :cond_c

    .line 207
    const/16 v0, 0xc9

    if-eq v2, v0, :cond_c

    .line 208
    const/16 v0, 0xcc

    if-eq v2, v0, :cond_c

    .line 209
    const/16 v0, 0xcd

    if-eq v2, v0, :cond_c

    .line 210
    const/16 v0, 0x130

    if-eq v2, v0, :cond_c

    .line 211
    const/16 v0, 0x131

    if-eq v2, v0, :cond_c

    .line 212
    const/16 v0, 0x198

    if-eq v2, v0, :cond_c

    .line 213
    const/16 v0, 0x1f6

    if-eq v2, v0, :cond_c

    .line 214
    const/16 v0, 0x1f8

    if-eq v2, v0, :cond_c

    .line 215
    const/16 v0, 0x1f7

    if-ne v2, v0, :cond_d

    .line 216
    :cond_c
    :try_start_8
    new-instance v0, Ljava/io/IOException;

    #v0=(UninitRef);
    const-string v2, "doGetOrPost retry"

    #v2=(Reference);
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    .line 218
    :cond_d
    #v0=(PosShort);v2=(Integer);
    new-instance v0, Lcom/tencent/mapapi/a/d;

    #v0=(UninitRef);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "response code is "

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/tencent/mapapi/a/d;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1
    .catch Lcom/tencent/mapapi/a/d; {:try_start_8 .. :try_end_8} :catch_0
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_1

    .line 226
    :catchall_2
    #v0=(Null);v2=(One);v3=(Boolean);v4=(Uninit);v5=(Uninit);
    move-exception v0

    #v0=(Reference);
    move-object v3, v1

    #v3=(Null);
    goto :goto_3

    :catchall_3
    #v0=(Null);v2=(Reference);v3=(Reference);v4=(Reference);v5=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v1, v2

    #v1=(Reference);
    goto :goto_3

    .line 223
    :catch_2
    #v0=(Null);v1=(Null);v2=(One);v3=(Boolean);v4=(Uninit);v5=(Uninit);
    move-exception v0

    #v0=(Reference);
    move-object v3, v1

    #v3=(Null);
    goto :goto_4

    :catch_3
    #v0=(Null);v2=(Reference);v3=(Reference);v4=(Reference);v5=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v1, v2

    #v1=(Reference);
    goto :goto_4

    .line 220
    :catch_4
    #v0=(Null);v1=(Null);v2=(One);v3=(Boolean);v4=(Uninit);v5=(Uninit);
    move-exception v0

    #v0=(Reference);
    move-object v2, v1

    #v2=(Null);
    goto :goto_2

    :catch_5
    #v0=(Null);v2=(Reference);v3=(Reference);v4=(Reference);v5=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v1, v2

    #v1=(Reference);
    move-object v2, v3

    goto :goto_2
.end method

.method private static a(Ljava/net/URL;Ljava/lang/String;)Ljava/net/HttpURLConnection;
    .locals 7
    .parameter
    .parameter

    .prologue
    const/16 v1, 0x50

    #v1=(PosByte);
    const/4 v6, -0x1

    .line 422
    #v6=(Byte);
    invoke-static {}, Landroid/net/Proxy;->getDefaultHost()Ljava/lang/String;

    move-result-object v3

    .line 423
    #v3=(Reference);
    invoke-static {}, Landroid/net/Proxy;->getDefaultPort()I

    move-result v0

    .line 424
    #v0=(Integer);
    if-ne v0, v6, :cond_0

    move v0, v1

    .line 428
    :cond_0
    invoke-virtual {p0}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v4

    .line 429
    #v4=(Reference);
    invoke-virtual {p0}, Ljava/net/URL;->getPort()I

    move-result v2

    .line 430
    #v2=(Integer);
    if-ne v2, v6, :cond_2

    .line 435
    :goto_0
    #v1=(Integer);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    #v5=(Reference);
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    const-string v5, ":"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v2

    #v2=(Integer);
    if-eq v2, v6, :cond_1

    .line 436
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    const-string v5, ":"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    const-string v3, ":"

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 443
    :goto_1
    :try_start_0
    new-instance v2, Ljava/net/URL;

    #v2=(UninitRef);
    invoke-direct {v2, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_0

    .line 448
    #v2=(Reference);
    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;

    .line 450
    const-string v2, "X-Online-Host"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    const-string v4, ":"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v2, v1}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 452
    :goto_2
    #v1=(Conflicted);v2=(Conflicted);
    return-object v0

    .line 438
    :cond_1
    #v0=(Integer);v1=(Integer);v2=(Integer);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v4, v0}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    .line 445
    :catch_0
    #v2=(Conflicted);
    move-exception v0

    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_2

    :cond_2
    #v0=(Integer);v1=(PosByte);v2=(Integer);v5=(Uninit);
    move v1, v2

    #v1=(Integer);
    goto/16 :goto_0
.end method

.method private static a(Ljava/net/HttpURLConnection;)Z
    .locals 3
    .parameter

    .prologue
    .line 387
    const/4 v1, 0x0

    .line 389
    :try_start_0
    #v1=(Null);
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    .line 390
    #v1=(Reference);
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getContentType()Ljava/lang/String;

    move-result-object v0

    .line 393
    #v0=(Reference);
    const-string v2, "text/html"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_2

    .line 406
    if-eqz v1, :cond_0

    .line 407
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    .line 394
    :cond_0
    const/4 v0, 0x0

    .line 404
    :cond_1
    :goto_0
    return v0

    .line 397
    :cond_2
    :try_start_1
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 398
    :goto_1
    #v0=(Reference);v2=(Conflicted);
    invoke-virtual {v1}, Ljava/io/InputStream;->available()I

    move-result v2

    #v2=(Integer);
    if-gtz v2, :cond_3

    .line 402
    new-instance v2, Ljava/lang/String;

    #v2=(UninitRef);
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/String;-><init>([B)V

    .line 403
    #v2=(Reference);
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v2, "1"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-result v0

    .line 404
    #v0=(Boolean);
    if-eqz v1, :cond_1

    .line 407
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    goto :goto_0

    .line 399
    :cond_3
    :try_start_2
    #v0=(Reference);v2=(Integer);
    invoke-virtual {v1}, Ljava/io/InputStream;->read()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/io/ByteArrayOutputStream;->write(I)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1

    .line 405
    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    .line 406
    #v0=(Reference);
    if-eqz v1, :cond_4

    .line 407
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    .line 409
    :cond_4
    throw v0
.end method

.method private static af(Ljava/lang/String;)Ljava/net/HttpURLConnection;
    .locals 8
    .parameter

    .prologue
    const/4 v6, -0x1

    #v6=(Byte);
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v3, 0x1

    #v3=(One);
    const/4 v2, 0x0

    .line 52
    :try_start_0
    #v2=(Null);
    new-instance v4, Ljava/net/URL;

    #v4=(UninitRef);
    invoke-direct {v4, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_0

    .line 59
    #v4=(Reference);
    invoke-static {}, Lcom/tencent/a/a/b;->isWifi()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    move v0, v2

    :goto_0
    if-nez v0, :cond_2

    .line 61
    :try_start_1
    invoke-virtual {v4}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    .line 84
    :goto_1
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    .line 54
    :catch_0
    #v0=(Uninit);v2=(Null);v3=(One);v5=(Uninit);
    move-exception v0

    #v0=(Reference);
    move-object v0, v1

    #v0=(Null);
    goto :goto_1

    .line 59
    :cond_0
    #v0=(Boolean);v4=(Reference);
    invoke-static {}, Lcom/tencent/a/a/f;->ir()I

    invoke-static {}, Landroid/net/Proxy;->getDefaultHost()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/a/g;->ac(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    move v0, v2

    #v0=(Null);
    goto :goto_0

    :cond_1
    #v0=(Boolean);
    move v0, v3

    #v0=(One);
    goto :goto_0

    .line 63
    :catch_1
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v0, v1

    #v0=(Null);
    goto :goto_1

    .line 69
    :cond_2
    #v0=(Boolean);
    sget v0, Lcom/tencent/mapapi/a/e;->a:I

    #v0=(Integer);
    if-nez v0, :cond_4

    .line 71
    sget-boolean v0, Lcom/tencent/mapapi/a/e;->Da:Z

    #v0=(Boolean);
    if-nez v0, :cond_4

    sput-boolean v3, Lcom/tencent/mapapi/a/e;->Da:Z

    :try_start_2
    new-instance v3, Ljava/net/URL;

    #v3=(UninitRef);
    const-string v0, "http://ls.map.soso.com/monitor/monitor.html"

    #v0=(Reference);
    invoke-direct {v3, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/net/MalformedURLException; {:try_start_2 .. :try_end_2} :catch_2

    #v3=(Reference);
    invoke-static {}, Landroid/net/Proxy;->getDefaultHost()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {}, Landroid/net/Proxy;->getDefaultPort()I

    move-result v0

    #v0=(Integer);
    if-ne v0, v6, :cond_3

    const/16 v0, 0x50

    :cond_3
    new-instance v5, Ljava/net/InetSocketAddress;

    #v5=(UninitRef);
    invoke-direct {v5, v2, v0}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    #v5=(Reference);
    new-instance v0, Ljava/net/Proxy;

    #v0=(UninitRef);
    sget-object v2, Ljava/net/Proxy$Type;->HTTP:Ljava/net/Proxy$Type;

    invoke-direct {v0, v2, v5}, Ljava/net/Proxy;-><init>(Ljava/net/Proxy$Type;Ljava/net/SocketAddress;)V

    :try_start_3
    #v0=(Reference);
    invoke-virtual {v3, v0}, Ljava/net/URL;->openConnection(Ljava/net/Proxy;)Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_5

    :try_start_4
    const-string v2, "GET"

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/16 v2, 0x3a98

    #v2=(PosShort);
    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const v2, 0xafc8

    #v2=(Char);
    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const-string v2, "User-Agent"

    #v2=(Reference);
    const-string v3, "QQ Map Mobile"

    invoke-virtual {v0, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    #v2=(One);
    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setDoInput(Z)V

    const/4 v2, 0x0

    #v2=(Null);
    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setUseCaches(Z)V

    invoke-static {v0}, Lcom/tencent/mapapi/a/e;->a(Ljava/net/HttpURLConnection;)Z

    move-result v2

    #v2=(Boolean);
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->connect()V

    if-eqz v2, :cond_6

    const/4 v2, 0x1

    #v2=(One);
    invoke-static {v2}, Lcom/tencent/mapapi/a/e;->aj(I)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    :goto_2
    #v2=(PosByte);
    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 76
    :cond_4
    :goto_3
    :try_start_5
    #v0=(Conflicted);v3=(Conflicted);v5=(Conflicted);
    sget v0, Lcom/tencent/mapapi/a/e;->a:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    .line 81
    invoke-static {}, Landroid/net/Proxy;->getDefaultHost()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {}, Landroid/net/Proxy;->getDefaultPort()I

    move-result v0

    if-ne v0, v6, :cond_5

    const/16 v0, 0x50

    :cond_5
    new-instance v3, Ljava/net/InetSocketAddress;

    #v3=(UninitRef);
    invoke-direct {v3, v2, v0}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    #v3=(Reference);
    new-instance v0, Ljava/net/Proxy;

    #v0=(UninitRef);
    sget-object v2, Ljava/net/Proxy$Type;->HTTP:Ljava/net/Proxy$Type;

    invoke-direct {v0, v2, v3}, Ljava/net/Proxy;-><init>(Ljava/net/Proxy$Type;Ljava/net/SocketAddress;)V

    #v0=(Reference);
    invoke-virtual {v4, v0}, Ljava/net/URL;->openConnection(Ljava/net/Proxy;)Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    goto/16 :goto_1

    .line 71
    :catch_2
    #v0=(Conflicted);v2=(Null);v3=(Conflicted);v5=(Uninit);
    move-exception v0

    #v0=(Reference);
    sput-boolean v2, Lcom/tencent/mapapi/a/e;->Da:Z

    goto :goto_3

    :cond_6
    #v2=(Boolean);v3=(Reference);v5=(Reference);
    const/4 v2, 0x2

    :try_start_6
    #v2=(PosByte);
    invoke-static {v2}, Lcom/tencent/mapapi/a/e;->aj(I)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    goto :goto_2

    :catch_3
    #v2=(Conflicted);
    move-exception v2

    :goto_4
    #v2=(Reference);
    const/4 v2, 0x2

    :try_start_7
    #v2=(PosByte);
    invoke-static {v2}, Lcom/tencent/mapapi/a/e;->aj(I)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_3

    :catchall_0
    #v2=(Reference);
    move-exception v0

    :goto_5
    #v1=(Reference);v2=(Conflicted);v7=(Conflicted);
    if-eqz v1, :cond_7

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_7
    throw v0

    .line 78
    :pswitch_0
    :try_start_8
    #v0=(Integer);v1=(Null);v2=(PosByte);v3=(Conflicted);v5=(Conflicted);v7=(Uninit);
    invoke-static {v4, p0}, Lcom/tencent/mapapi/a/e;->a(Ljava/net/URL;Ljava/lang/String;)Ljava/net/HttpURLConnection;
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_4

    move-result-object v0

    #v0=(Reference);
    goto/16 :goto_1

    .line 84
    :catch_4
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v0, v1

    #v0=(Null);
    goto/16 :goto_1

    .line 71
    :catchall_1
    #v0=(Reference);v3=(Reference);v5=(Reference);
    move-exception v1

    #v1=(Reference);
    move-object v7, v1

    #v7=(Reference);
    move-object v1, v0

    move-object v0, v7

    goto :goto_5

    :catch_5
    #v1=(Null);v2=(Reference);v7=(Uninit);
    move-exception v0

    move-object v0, v1

    #v0=(Null);
    goto :goto_4

    .line 76
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method private static aj(I)V
    .locals 1
    .parameter

    .prologue
    .line 310
    sget v0, Lcom/tencent/mapapi/a/e;->a:I

    #v0=(Integer);
    if-ne v0, p0, :cond_0

    .line 314
    :goto_0
    return-void

    .line 313
    :cond_0
    sput p0, Lcom/tencent/mapapi/a/e;->a:I

    goto :goto_0
.end method

*/}
