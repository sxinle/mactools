package com.tencent.mapapi.a; class f {/*

.class public final Lcom/tencent/mapapi/a/f;
.super Ljava/io/IOException;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 12
    invoke-direct {p0}, Ljava/io/IOException;-><init>()V

    .line 13
    #p0=(Reference);
    return-void
.end method

*/}
