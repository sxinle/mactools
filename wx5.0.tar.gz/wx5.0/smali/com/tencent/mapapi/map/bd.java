package com.tencent.mapapi.map; class bd {/*

.class final Lcom/tencent/mapapi/map/bd;
.super Lcom/tencent/mapapi/map/ay;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lcom/tencent/mapapi/map/bh;Landroid/graphics/Bitmap;)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 49
    invoke-direct {p0, p1, p2}, Lcom/tencent/mapapi/map/ay;-><init>(Lcom/tencent/mapapi/map/bh;Landroid/graphics/Bitmap;)V

    .line 50
    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final hC()V
    .locals 1

    .prologue
    .line 61
    iget-object v0, p0, Lcom/tencent/mapapi/map/bd;->Fu:Landroid/graphics/Bitmap;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 62
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bd;->Fu:Landroid/graphics/Bitmap;

    .line 64
    :cond_0
    #v0=(Reference);
    return-void
.end method

.method protected final ik()Landroid/graphics/Point;
    .locals 4

    .prologue
    .line 53
    iget-object v0, p0, Lcom/tencent/mapapi/map/bd;->Eb:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v0

    .line 55
    #v0=(Integer);
    new-instance v1, Landroid/graphics/Point;

    #v1=(UninitRef);
    const/4 v2, 0x2

    #v2=(PosByte);
    iget-object v3, p0, Lcom/tencent/mapapi/map/bd;->Fu:Landroid/graphics/Bitmap;

    #v3=(Reference);
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    #v3=(Integer);
    sub-int/2addr v0, v3

    add-int/lit8 v0, v0, -0x5

    invoke-direct {v1, v2, v0}, Landroid/graphics/Point;-><init>(II)V

    #v1=(Reference);
    return-object v1
.end method

*/}
