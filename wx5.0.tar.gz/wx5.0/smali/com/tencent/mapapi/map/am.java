package com.tencent.mapapi.map; class am {/*

.class abstract Lcom/tencent/mapapi/map/am;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field protected DA:Ljava/lang/String;

.field protected Fh:Ljava/lang/Object;

.field protected b:Ljava/lang/String;

.field protected d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 103
    #p0=(Reference);
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/am;->b:Ljava/lang/String;

    .line 104
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/am;->DA:Ljava/lang/String;

    .line 107
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/am;->d:Ljava/lang/String;

    .line 33
    iput-object p1, p0, Lcom/tencent/mapapi/map/am;->Fh:Ljava/lang/Object;

    .line 34
    iput-object p2, p0, Lcom/tencent/mapapi/map/am;->b:Ljava/lang/String;

    .line 35
    return-void
.end method


# virtual methods
.method protected abstract f([B)Ljava/lang/Object;
.end method

.method protected abstract hH()Ljava/lang/String;
.end method

.method public final ig()Ljava/lang/Object;
    .locals 3

    .prologue
    const/4 v0, 0x0

    .line 53
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mapapi/map/am;->Fh:Ljava/lang/Object;

    #v1=(Reference);
    if-nez v1, :cond_1

    .line 81
    :cond_0
    :goto_0
    #v0=(Reference);v2=(Conflicted);
    return-object v0

    .line 58
    :cond_1
    #v0=(Null);v2=(Uninit);
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/am;->hH()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/tencent/mapapi/map/am;->d:Ljava/lang/String;

    .line 59
    :try_start_0
    iget-object v1, p0, Lcom/tencent/mapapi/map/am;->d:Ljava/lang/String;

    const-string v2, "Android_SDK"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/a/a/a;->h(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/a/a/c;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    move-result-object v1

    .line 66
    if-eqz v1, :cond_0

    iget-object v2, v1, Lcom/tencent/a/a/c;->data:[B

    if-eqz v2, :cond_0

    .line 70
    iget-object v2, v1, Lcom/tencent/a/a/c;->GP:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/mapapi/map/am;->DA:Ljava/lang/String;

    .line 72
    :try_start_1
    iget-object v1, v1, Lcom/tencent/a/a/c;->data:[B

    invoke-virtual {p0, v1}, Lcom/tencent/mapapi/map/am;->f([B)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    move-result-object v0

    #v0=(Reference);
    goto :goto_0

    :catch_0
    #v0=(Null);
    move-exception v1

    goto :goto_0

    .line 75
    :catch_1
    move-exception v1

    goto :goto_0

    .line 64
    :catch_2
    #v2=(Conflicted);
    move-exception v1

    goto :goto_0
.end method

*/}
