package com.tencent.mapapi.map; class an {/*

.class final Lcom/tencent/mapapi/map/an;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private DD:Z

.field DE:J

.field Fi:Lcom/tencent/mapapi/map/ao;

.field protected final b:I


# direct methods
.method public constructor <init>(IZJ)V
    .locals 3
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x0

    .line 26
    #v2=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    #p0=(Reference);
    iput-object v2, p0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    .line 22
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/an;->DD:Z

    .line 23
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/an;->DE:J

    .line 27
    iput p1, p0, Lcom/tencent/mapapi/map/an;->b:I

    .line 28
    iput-boolean p2, p0, Lcom/tencent/mapapi/map/an;->DD:Z

    .line 29
    const-wide/32 v0, 0xf4240

    mul-long/2addr v0, p3

    iput-wide v0, p0, Lcom/tencent/mapapi/map/an;->DE:J

    .line 30
    iget v0, p0, Lcom/tencent/mapapi/map/an;->b:I

    #v0=(Integer);
    if-lez v0, :cond_0

    .line 31
    new-instance v0, Lcom/tencent/mapapi/map/ao;

    #v0=(UninitRef);
    iget v1, p0, Lcom/tencent/mapapi/map/an;->b:I

    #v1=(Integer);
    invoke-direct {v0, v1}, Lcom/tencent/mapapi/map/ao;-><init>(I)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    .line 35
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 33
    :cond_0
    #v0=(Integer);v1=(LongHi);
    iput-object v2, p0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    goto :goto_0
.end method


# virtual methods
.method protected final ag(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;
    .locals 6
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 38
    #v0=(Null);
    const-string v1, ""

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_1

    .line 58
    :cond_0
    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    .line 42
    :cond_1
    #v0=(Null);v1=(Boolean);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget-object v1, p0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    #v1=(Reference);
    invoke-virtual {v1, p1}, Lcom/tencent/mapapi/map/ao;->ag(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;

    move-result-object v1

    .line 43
    iget-boolean v2, p0, Lcom/tencent/mapapi/map/an;->DD:Z

    #v2=(Boolean);
    if-nez v2, :cond_2

    move-object v0, v1

    .line 45
    #v0=(Reference);
    goto :goto_0

    .line 47
    :cond_2
    #v0=(Null);
    if-eqz v1, :cond_0

    .line 51
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    .line 52
    #v2=(LongLo);v3=(LongHi);
    iget-wide v4, v1, Lcom/tencent/mapapi/map/ap;->Dw:J

    #v4=(LongLo);v5=(LongHi);
    sub-long/2addr v2, v4

    iget-wide v4, p0, Lcom/tencent/mapapi/map/an;->DE:J

    cmp-long v2, v2, v4

    #v2=(Byte);
    if-lez v2, :cond_3

    .line 54
    iget-object v1, p0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    invoke-virtual {v1, p1}, Lcom/tencent/mapapi/map/ao;->ah(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;

    goto :goto_0

    :cond_3
    move-object v0, v1

    .line 58
    #v0=(Reference);
    goto :goto_0
.end method

.method protected final b([BLjava/lang/String;)Z
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 64
    #v0=(Null);
    if-nez p1, :cond_0

    .line 91
    :goto_0
    #v0=(Boolean);v1=(Boolean);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 69
    :cond_0
    #v0=(Null);v1=(One);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    new-instance v2, Lcom/tencent/mapapi/map/ap;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mapapi/map/ap;-><init>()V

    .line 72
    #v2=(Reference);
    const/4 v3, 0x0

    :try_start_0
    #v3=(Null);
    array-length v4, p1

    #v4=(Integer);
    invoke-static {p1, v3, v4}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v3

    #v3=(Reference);
    iput-object v3, v2, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .line 77
    :goto_1
    #v4=(Conflicted);
    iget-object v3, v2, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    if-nez v3, :cond_1

    .line 81
    const/4 v1, 0x0

    #v1=(Null);
    iput-object v1, v2, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    goto :goto_0

    .line 85
    :cond_1
    #v1=(One);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/an;->DD:Z

    #v0=(Boolean);
    if-ne v0, v1, :cond_2

    .line 87
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    iput-wide v3, v2, Lcom/tencent/mapapi/map/ap;->Dw:J

    .line 90
    :cond_2
    #v3=(Conflicted);v4=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    #v0=(Reference);
    invoke-virtual {v0, p2, v2}, Lcom/tencent/mapapi/map/ao;->a(Ljava/lang/String;Lcom/tencent/mapapi/map/ap;)V

    move v0, v1

    .line 91
    #v0=(One);
    goto :goto_0

    :catch_0
    #v0=(Null);v3=(Reference);
    move-exception v3

    goto :goto_1
.end method

*/}
