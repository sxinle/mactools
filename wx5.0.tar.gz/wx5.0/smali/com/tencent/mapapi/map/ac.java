package com.tencent.mapapi.map; class ac {/*

.class final Lcom/tencent/mapapi/map/ac;
.super Lcom/tencent/mapapi/map/ab;
.source "SourceFile"


# instance fields
.field ER:Landroid/graphics/Bitmap;

.field ES:Z

.field h:F


# direct methods
.method public constructor <init>(III)V
    .locals 1
    .parameter
    .parameter
    .parameter

    .prologue
    .line 30
    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/mapapi/map/ab;-><init>(III)V

    .line 23
    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 25
    const/high16 v0, 0x3f80

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mapapi/map/ac;->h:F

    .line 26
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/ac;->ES:Z

    .line 31
    return-void
.end method

*/}
