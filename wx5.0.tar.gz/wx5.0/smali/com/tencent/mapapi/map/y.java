package com.tencent.mapapi.map; class y {/*

.class final Lcom/tencent/mapapi/map/y;
.super Lcom/tencent/mapapi/map/am;
.source "SourceFile"


# instance fields
.field private EM:Lcom/tencent/mapapi/map/ad;

.field public EN:Z

.field private EO:[B


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Ljava/lang/String;)V
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 22
    invoke-direct {p0, p1, p2}, Lcom/tencent/mapapi/map/am;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    .line 19
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/y;->EN:Z

    .line 23
    const/16 v0, 0x400

    #v0=(PosShort);
    new-array v0, v0, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    .line 24
    return-void
.end method

.method private a([BLcom/tencent/mapapi/map/aa;)Z
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v1, 0x1

    .line 228
    #v1=(One);
    if-nez p1, :cond_1

    .line 258
    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 231
    :cond_1
    #v0=(Null);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    array-length v2, p1

    #v2=(Integer);
    if-gtz v2, :cond_2

    move v0, v1

    .line 232
    #v0=(One);
    goto :goto_0

    .line 234
    :cond_2
    #v0=(Null);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 235
    #v2=(Reference);
    iget v3, p2, Lcom/tencent/mapapi/map/aa;->a:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 236
    const-string v3, "-"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 237
    iget v3, p2, Lcom/tencent/mapapi/map/aa;->b:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 238
    const-string v3, "-"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 239
    iget v3, p2, Lcom/tencent/mapapi/map/aa;->CR:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 240
    iget-object v3, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, p1, v2}, Lcom/tencent/mapapi/map/an;->b([BLjava/lang/String;)Z

    move-result v2

    .line 242
    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 247
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    #v0=(Reference);
    if-eqz v0, :cond_3

    .line 248
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    invoke-virtual {v0, p2}, Lcom/tencent/mapapi/map/ad;->a(Lcom/tencent/mapapi/map/aa;)V

    .line 250
    :cond_3
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    iget-boolean v0, v0, Lcom/tencent/mapapi/map/ad;->Fy:Z

    #v0=(Boolean);
    if-ne v0, v1, :cond_4

    .line 252
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    #v0=(Reference);
    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    iget-object v0, v0, Lcom/tencent/mapapi/map/ad;->EU:Lcom/tencent/mapapi/map/bc;

    if-eqz v0, :cond_4

    .line 254
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    iget-object v0, v0, Lcom/tencent/mapapi/map/ad;->EU:Lcom/tencent/mapapi/map/bc;

    iget v2, p2, Lcom/tencent/mapapi/map/aa;->a:I

    #v2=(Integer);
    iget v3, p2, Lcom/tencent/mapapi/map/aa;->b:I

    #v3=(Integer);
    iget v4, p2, Lcom/tencent/mapapi/map/aa;->CR:I

    #v4=(Integer);
    invoke-virtual {v0, p1, v2, v3, v4}, Lcom/tencent/mapapi/map/bc;->a([BIII)Z

    :cond_4
    #v0=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move v0, v1

    .line 258
    #v0=(One);
    goto :goto_0
.end method


# virtual methods
.method public final a(Lcom/tencent/mapapi/map/ad;)V
    .locals 0
    .parameter

    .prologue
    .line 32
    iput-object p1, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    .line 33
    return-void
.end method

.method protected final synthetic f([B)Ljava/lang/Object;
    .locals 10
    .parameter

    .prologue
    const/4 v6, 0x4

    #v6=(PosByte);
    const/4 v4, 0x1

    #v4=(One);
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x0

    .line 15
    #v3=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    if-nez v0, :cond_1

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Reference);v5=(Conflicted);v6=(Integer);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    return-object v2

    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Null);v5=(Uninit);v6=(PosByte);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    if-eqz p1, :cond_0

    if-nez p1, :cond_2

    move v0, v3

    :goto_1
    #v0=(Boolean);v1=(Conflicted);v5=(Conflicted);v6=(Integer);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    #v2=(Reference);
    goto :goto_0

    :cond_2
    #v0=(Reference);v1=(Uninit);v2=(Null);v5=(Uninit);v6=(PosByte);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/y;->EN:Z

    #v0=(Boolean);
    if-ne v0, v4, :cond_3

    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    invoke-direct {p0, p1, v0}, Lcom/tencent/mapapi/map/y;->a([BLcom/tencent/mapapi/map/aa;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_1

    :cond_3
    array-length v0, p1

    #v0=(Integer);
    if-gtz v0, :cond_4

    move v0, v3

    #v0=(Null);
    goto :goto_1

    :cond_4
    #v0=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v0=(Reference);
    invoke-static {p1, v3, v0, v3, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    aget-byte v0, v0, v3

    #v0=(Byte);
    add-int/lit16 v0, v0, 0x100

    #v0=(Integer);
    rem-int/lit16 v0, v0, 0x100

    iget-object v1, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v1=(Reference);
    aget-byte v1, v1, v4

    #v1=(Byte);
    add-int/lit16 v1, v1, 0x100

    #v1=(Integer);
    rem-int/lit16 v1, v1, 0x100

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    iget-object v1, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v1=(Reference);
    const/4 v5, 0x2

    #v5=(PosByte);
    aget-byte v1, v1, v5

    #v1=(Byte);
    add-int/lit16 v1, v1, 0x100

    #v1=(Integer);
    rem-int/lit16 v1, v1, 0x100

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    iget-object v1, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v1=(Reference);
    const/4 v5, 0x3

    aget-byte v1, v1, v5

    #v1=(Byte);
    add-int/lit16 v1, v1, 0x100

    #v1=(Integer);
    rem-int/lit16 v1, v1, 0x100

    shl-int/lit8 v1, v1, 0x18

    or-int v7, v0, v1

    #v7=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    #v0=(Integer);
    if-eq v7, v0, :cond_5

    move v0, v3

    #v0=(Null);
    goto :goto_1

    :cond_5
    #v0=(Integer);
    new-array v8, v7, [I

    #v8=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v0=(Reference);
    mul-int/lit8 v1, v7, 0x4

    invoke-static {p1, v6, v0, v6, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move v0, v3

    :goto_2
    #v0=(Integer);v5=(Integer);v6=(Conflicted);v9=(Conflicted);
    if-ge v0, v7, :cond_6

    mul-int/lit8 v1, v0, 0x4

    add-int/lit8 v1, v1, 0x4

    iget-object v5, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v5=(Reference);
    aget-byte v5, v5, v1

    #v5=(Byte);
    add-int/lit16 v5, v5, 0x100

    #v5=(Integer);
    rem-int/lit16 v5, v5, 0x100

    iget-object v6, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v6=(Reference);
    add-int/lit8 v9, v1, 0x1

    #v9=(Integer);
    aget-byte v6, v6, v9

    #v6=(Byte);
    add-int/lit16 v6, v6, 0x100

    #v6=(Integer);
    rem-int/lit16 v6, v6, 0x100

    shl-int/lit8 v6, v6, 0x8

    or-int/2addr v5, v6

    iget-object v6, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v6=(Reference);
    add-int/lit8 v9, v1, 0x2

    aget-byte v6, v6, v9

    #v6=(Byte);
    add-int/lit16 v6, v6, 0x100

    #v6=(Integer);
    rem-int/lit16 v6, v6, 0x100

    shl-int/lit8 v6, v6, 0x10

    or-int/2addr v5, v6

    iget-object v6, p0, Lcom/tencent/mapapi/map/y;->EO:[B

    #v6=(Reference);
    add-int/lit8 v1, v1, 0x3

    aget-byte v1, v6, v1

    #v1=(Byte);
    add-int/lit16 v1, v1, 0x100

    #v1=(Integer);
    rem-int/lit16 v1, v1, 0x100

    shl-int/lit8 v1, v1, 0x18

    or-int/2addr v1, v5

    aput v1, v8, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_6
    #v6=(Conflicted);v9=(Conflicted);
    add-int/lit8 v0, v7, 0x1

    mul-int/lit8 v0, v0, 0x4

    move v5, v3

    #v5=(Null);
    move v6, v0

    :goto_3
    #v1=(Conflicted);v5=(Integer);v6=(Integer);
    if-ge v5, v7, :cond_a

    aget v1, v8, v5

    #v1=(Integer);
    if-nez p1, :cond_7

    move-object v1, v2

    :goto_4
    #v0=(Conflicted);v1=(Reference);
    aget v0, v8, v5

    #v0=(Integer);
    add-int/2addr v6, v0

    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    invoke-direct {p0, v1, v0}, Lcom/tencent/mapapi/map/y;->a([BLcom/tencent/mapapi/map/aa;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_9

    move v0, v3

    #v0=(Null);
    goto/16 :goto_1

    :cond_7
    #v0=(Integer);v1=(Integer);
    if-gtz v1, :cond_8

    move-object v1, v2

    #v1=(Null);
    goto :goto_4

    :cond_8
    #v1=(Integer);
    new-array v0, v1, [B

    #v0=(Reference);
    invoke-static {p1, v6, v0, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v1, v0

    #v1=(Reference);
    goto :goto_4

    :cond_9
    #v0=(Boolean);
    add-int/lit8 v0, v5, 0x1

    #v0=(Integer);
    move v5, v0

    goto :goto_3

    :cond_a
    #v1=(Conflicted);
    move v0, v4

    #v0=(One);
    goto/16 :goto_1
.end method

.method protected final hH()Ljava/lang/String;
    .locals 5

    .prologue
    .line 209
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    .line 210
    #v2=(Integer);
    if-gtz v2, :cond_0

    .line 212
    const/4 v0, 0x0

    .line 222
    :goto_0
    #v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-object v0

    .line 214
    :cond_0
    #v1=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    #v0=(Integer);
    mul-int/lit8 v0, v0, 0x3

    new-array v3, v0, [I

    .line 215
    #v3=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_1
    #v0=(Integer);v1=(Integer);v4=(Conflicted);
    if-ge v1, v2, :cond_1

    .line 217
    mul-int/lit8 v4, v1, 0x3

    #v4=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    iget v0, v0, Lcom/tencent/mapapi/map/aa;->a:I

    #v0=(Integer);
    aput v0, v3, v4

    .line 218
    mul-int/lit8 v0, v1, 0x3

    add-int/lit8 v4, v0, 0x1

    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    iget v0, v0, Lcom/tencent/mapapi/map/aa;->b:I

    #v0=(Integer);
    aput v0, v3, v4

    .line 219
    mul-int/lit8 v0, v1, 0x3

    add-int/lit8 v4, v0, 0x2

    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->Fh:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    iget v0, v0, Lcom/tencent/mapapi/map/aa;->CR:I

    #v0=(Integer);
    aput v0, v3, v4

    .line 215
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_1

    .line 221
    :cond_1
    #v4=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/ad;->FD:Lcom/tencent/mapapi/map/ae;

    iget-object v1, p0, Lcom/tencent/mapapi/map/y;->EM:Lcom/tencent/mapapi/map/ad;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/ad;->id()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v0, v1, v3}, Lcom/tencent/mapapi/map/ae;->a(I[I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0
.end method

*/}
