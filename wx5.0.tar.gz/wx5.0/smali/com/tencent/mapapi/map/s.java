package com.tencent.mapapi.map; class s {/*

.class public interface abstract Lcom/tencent/mapapi/map/s;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(ILcom/tencent/mapapi/b/a;)V
.end method

*/}
