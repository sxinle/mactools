package com.tencent.mapapi.map; class l {/*

.class final Lcom/tencent/mapapi/map/l;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements Landroid/view/GestureDetector$OnDoubleTapListener;
.implements Landroid/view/GestureDetector$OnGestureListener;


# instance fields
.field CL:Z

.field private Dc:I

.field private Dd:I

.field private Er:Landroid/view/GestureDetector;

.field private Es:Landroid/widget/Scroller;

.field private Et:Lcom/tencent/mapapi/map/bt;

.field final synthetic Eu:Lcom/tencent/mapapi/map/MapView;


# direct methods
.method public constructor <init>(Lcom/tencent/mapapi/map/MapView;Landroid/content/Context;)V
    .locals 2
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 724
    #v1=(Null);
    iput-object p1, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    .line 725
    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 716
    #p0=(Reference);
    iput v1, p0, Lcom/tencent/mapapi/map/l;->Dc:I

    .line 717
    iput v1, p0, Lcom/tencent/mapapi/map/l;->Dd:I

    .line 719
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/l;->Et:Lcom/tencent/mapapi/map/bt;

    .line 752
    iput-boolean v1, p0, Lcom/tencent/mapapi/map/l;->CL:Z

    .line 728
    new-instance v0, Landroid/view/GestureDetector;

    #v0=(UninitRef);
    invoke-direct {v0, p2, p0}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/l;->Er:Landroid/view/GestureDetector;

    .line 729
    new-instance v0, Landroid/widget/Scroller;

    #v0=(UninitRef);
    invoke-direct {v0, p2}, Landroid/widget/Scroller;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/l;->Es:Landroid/widget/Scroller;

    .line 730
    return-void
.end method

.method static synthetic a(Lcom/tencent/mapapi/map/l;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 710
    iput p1, p0, Lcom/tencent/mapapi/map/l;->Dc:I

    return p1
.end method

.method static synthetic a(Lcom/tencent/mapapi/map/l;)Landroid/view/GestureDetector;
    .locals 1
    .parameter

    .prologue
    .line 710
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Er:Landroid/view/GestureDetector;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/mapapi/map/l;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 710
    iput p1, p0, Lcom/tencent/mapapi/map/l;->Dd:I

    return p1
.end method

.method static synthetic b(Lcom/tencent/mapapi/map/l;)Landroid/widget/Scroller;
    .locals 1
    .parameter

    .prologue
    .line 710
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Es:Landroid/widget/Scroller;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/tencent/mapapi/map/l;)Landroid/view/GestureDetector;
    .locals 1
    .parameter

    .prologue
    .line 710
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/l;->Er:Landroid/view/GestureDetector;

    return-object v0
.end method

.method static synthetic d(Lcom/tencent/mapapi/map/l;)Landroid/widget/Scroller;
    .locals 1
    .parameter

    .prologue
    .line 710
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/l;->Es:Landroid/widget/Scroller;

    return-object v0
.end method

.method static synthetic e(Lcom/tencent/mapapi/map/l;)I
    .locals 1
    .parameter

    .prologue
    .line 710
    iget v0, p0, Lcom/tencent/mapapi/map/l;->Dc:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic f(Lcom/tencent/mapapi/map/l;)I
    .locals 1
    .parameter

    .prologue
    .line 710
    iget v0, p0, Lcom/tencent/mapapi/map/l;->Dd:I

    #v0=(Integer);
    return v0
.end method


# virtual methods
.method public final a(Landroid/view/MotionEvent;)Z
    .locals 2
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 754
    .line 755
    #v0=(Null);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v1

    #v1=(Integer);
    and-int/lit16 v1, v1, 0xff

    sparse-switch v1, :sswitch_data_0

    .line 764
    :goto_0
    iget-object v1, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mapapi/map/MapView;->f(Lcom/tencent/mapapi/map/MapView;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/tencent/mapapi/map/l;->Et:Lcom/tencent/mapapi/map/bt;

    #v1=(Reference);
    if-eqz v1, :cond_0

    .line 765
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Et:Lcom/tencent/mapapi/map/bt;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/bt;->a(Landroid/view/MotionEvent;)Z

    move-result v0

    .line 771
    :cond_0
    #v0=(Boolean);v1=(Conflicted);
    return v0

    .line 758
    :sswitch_0
    #v0=(Null);v1=(Integer);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/l;->CL:Z

    goto :goto_0

    .line 761
    :sswitch_1
    const/4 v1, 0x1

    #v1=(One);
    iput-boolean v1, p0, Lcom/tencent/mapapi/map/l;->CL:Z

    goto :goto_0

    .line 755
    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_0
        0x5 -> :sswitch_1
    .end sparse-switch
.end method

.method public final hw()V
    .locals 2

    .prologue
    .line 734
    new-instance v0, Lcom/tencent/mapapi/map/bt;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mapapi/map/bt;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/l;->Et:Lcom/tencent/mapapi/map/bt;

    .line 735
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Et:Lcom/tencent/mapapi/map/bt;

    iget-object v1, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bt;->a(Lcom/tencent/mapapi/map/bh;)V

    .line 736
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Et:Lcom/tencent/mapapi/map/bt;

    iget-object v1, p0, Lcom/tencent/mapapi/map/l;->Er:Landroid/view/GestureDetector;

    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bt;->a(Landroid/view/GestureDetector;)V

    .line 737
    return-void
.end method

.method public final onDoubleTap(Landroid/view/MotionEvent;)Z
    .locals 3
    .parameter

    .prologue
    .line 849
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/MapView;->Eg:Lcom/tencent/mapapi/map/ah;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    #v1=(Float);
    float-to-int v1, v1

    #v1=(Integer);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    #v2=(Float);
    float-to-int v2, v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mapapi/map/ah;->i(II)Z

    .line 850
    const/4 v0, 0x1

    #v0=(One);
    return v0
.end method

.method public final onDoubleTapEvent(Landroid/view/MotionEvent;)Z
    .locals 1
    .parameter

    .prologue
    .line 855
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method public final onDown(Landroid/view/MotionEvent;)Z
    .locals 1
    .parameter

    .prologue
    .line 777
    const/4 v0, 0x1

    #v0=(One);
    return v0
.end method

.method protected final onDraw(Landroid/graphics/Canvas;)V
    .locals 1
    .parameter

    .prologue
    .line 742
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/bi;->a(Landroid/graphics/Canvas;)V

    .line 743
    return-void
.end method

.method public final onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .locals 10
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v9, 0x1

    #v9=(One);
    const/4 v1, 0x0

    .line 783
    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Es:Landroid/widget/Scroller;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 785
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Es:Landroid/widget/Scroller;

    #v0=(Reference);
    invoke-virtual {v0, v9}, Landroid/widget/Scroller;->forceFinished(Z)V

    .line 787
    :cond_0
    #v0=(Conflicted);
    iput v1, p0, Lcom/tencent/mapapi/map/l;->Dc:I

    .line 788
    iput v1, p0, Lcom/tencent/mapapi/map/l;->Dd:I

    .line 789
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v0

    #v0=(Integer);
    mul-int/lit8 v6, v0, 0x3

    .line 790
    #v6=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v0

    #v0=(Integer);
    mul-int/lit8 v8, v0, 0x3

    .line 791
    #v8=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Es:Landroid/widget/Scroller;

    #v0=(Reference);
    neg-float v2, p3

    #v2=(Float);
    float-to-int v2, v2

    #v2=(Integer);
    mul-int/lit8 v2, v2, 0x9

    div-int/lit8 v3, v2, 0x14

    #v3=(Integer);
    neg-float v2, p4

    #v2=(Float);
    float-to-int v2, v2

    #v2=(Integer);
    mul-int/lit8 v2, v2, 0x9

    div-int/lit8 v4, v2, 0x14

    #v4=(Integer);
    neg-int v5, v6

    #v5=(Integer);
    neg-int v7, v8

    #v7=(Integer);
    move v2, v1

    #v2=(Null);
    invoke-virtual/range {v0 .. v8}, Landroid/widget/Scroller;->fling(IIIIIIII)V

    .line 794
    return v9
.end method

.method public final onLongPress(Landroid/view/MotionEvent;)V
    .locals 5
    .parameter

    .prologue
    .line 799
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    if-nez v0, :cond_1

    .line 804
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 803
    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    #v2=(Reference);
    iget-object v0, v2, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FL:Lcom/tencent/mapapi/map/bn;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    #v1=(Float);
    float-to-int v1, v1

    #v1=(Integer);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    #v3=(Float);
    float-to-int v3, v3

    #v3=(Integer);
    invoke-virtual {v0, v1, v3}, Lcom/tencent/mapapi/map/bn;->h(II)Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v3

    #v3=(Reference);
    iget-object v0, v2, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_0
    #v4=(Conflicted);
    if-ltz v1, :cond_0

    iget-object v0, v2, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/m;

    if-eqz v0, :cond_2

    iget-object v4, v2, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-static {v4}, Lcom/tencent/mapapi/map/bm;->a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Lcom/tencent/mapapi/map/m;->b(Lcom/tencent/mapapi/map/GeoPoint;Lcom/tencent/mapapi/map/MapView;)Z

    :cond_2
    #v4=(Conflicted);
    add-int/lit8 v0, v1, -0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0
.end method

.method public final onScroll(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .locals 2
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 815
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iq()F

    move-result v0

    .line 816
    #v0=(Float);
    const/4 v1, 0x0

    #v1=(Null);
    cmpl-float v1, v0, v1

    #v1=(Byte);
    if-eqz v1, :cond_0

    .line 818
    div-float/2addr p3, v0

    .line 819
    div-float/2addr p4, v0

    .line 821
    :cond_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->e(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/f;

    move-result-object v0

    invoke-virtual {v0, p3, p4}, Lcom/tencent/mapapi/map/f;->k(FF)V

    .line 822
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->invalidate()V

    .line 823
    const/4 v0, 0x1

    #v0=(One);
    return v0
.end method

.method public final onShowPress(Landroid/view/MotionEvent;)V
    .locals 0
    .parameter

    .prologue
    .line 829
    return-void
.end method

.method public final onSingleTapConfirmed(Landroid/view/MotionEvent;)Z
    .locals 6
    .parameter

    .prologue
    .line 860
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    #v3=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v0, v3, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FL:Lcom/tencent/mapapi/map/bn;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    #v2=(Float);
    float-to-int v2, v2

    #v2=(Integer);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    #v4=(Float);
    float-to-int v4, v4

    #v4=(Integer);
    invoke-virtual {v0, v2, v4}, Lcom/tencent/mapapi/map/bn;->h(II)Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v4

    #v4=(Reference);
    iget-object v0, v3, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    add-int/lit8 v0, v0, -0x1

    move v2, v0

    :goto_0
    #v5=(Conflicted);
    if-ltz v2, :cond_0

    iget-object v0, v3, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/m;

    if-eqz v0, :cond_1

    iget-object v5, v3, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v5=(Reference);
    iget-object v5, v5, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-static {v5}, Lcom/tencent/mapapi/map/bm;->a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;

    move-result-object v5

    invoke-virtual {v0, v4, v5}, Lcom/tencent/mapapi/map/m;->a(Lcom/tencent/mapapi/map/GeoPoint;Lcom/tencent/mapapi/map/MapView;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    const/4 v0, 0x1

    #v0=(One);
    move v1, v0

    .line 862
    :cond_0
    #v0=(Integer);v1=(Boolean);v5=(Conflicted);
    if-nez v1, :cond_2

    .line 864
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FL:Lcom/tencent/mapapi/map/bn;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    #v2=(Float);
    float-to-int v2, v2

    #v2=(Integer);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    #v3=(Float);
    float-to-int v3, v3

    #v3=(Integer);
    invoke-virtual {v0, v2, v3}, Lcom/tencent/mapapi/map/bn;->h(II)Lcom/tencent/mapapi/map/GeoPoint;

    .line 866
    iget-object v0, p0, Lcom/tencent/mapapi/map/l;->Eu:Lcom/tencent/mapapi/map/MapView;

    invoke-static {v0}, Lcom/tencent/mapapi/map/MapView;->d(Lcom/tencent/mapapi/map/MapView;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    #v2=(Reference);
    iget-object v0, v2, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    add-int/lit8 v0, v0, -0x1

    :goto_1
    #v3=(Conflicted);
    if-ltz v0, :cond_2

    iget-object v3, v2, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    #v3=(Reference);
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    add-int/lit8 v0, v0, -0x1

    goto :goto_1

    .line 860
    :cond_1
    #v0=(Conflicted);v1=(Null);v2=(Integer);
    add-int/lit8 v0, v2, -0x1

    #v0=(Integer);
    move v2, v0

    goto :goto_0

    .line 869
    :cond_2
    #v1=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v1
.end method

.method public final onSingleTapUp(Landroid/view/MotionEvent;)Z
    .locals 1
    .parameter

    .prologue
    .line 844
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

*/}
