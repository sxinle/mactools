package com.tencent.mapapi.map; class bu {/*

.class public final Lcom/tencent/mapapi/map/bu;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static GM:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 63
    const-string v0, "content://telephony/carriers/preferapn"

    #v0=(Reference);
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lcom/tencent/mapapi/map/bu;->GM:Landroid/net/Uri;

    return-void
.end method

.method public static k(Landroid/content/Context;)Ljava/lang/String;
    .locals 4
    .parameter

    .prologue
    const/4 v2, 0x6

    #v2=(PosByte);
    const/4 v1, 0x1

    .line 71
    #v1=(One);
    const-string v0, "connectivity"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->isAvailable()Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_1

    :cond_0
    #v3=(Conflicted);
    const/4 v0, 0x0

    .line 72
    :goto_0
    #v0=(PosByte);v1=(Conflicted);
    const-string v1, "unknow"

    .line 73
    #v1=(Reference);
    packed-switch v0, :pswitch_data_0

    move-object v0, v1

    .line 91
    :goto_1
    #v0=(Reference);
    return-object v0

    .line 71
    :cond_1
    #v1=(One);v3=(Boolean);
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getType()I

    move-result v3

    #v3=(Integer);
    if-ne v3, v1, :cond_2

    const/4 v0, 0x5

    #v0=(PosByte);
    goto :goto_0

    :cond_2
    #v0=(Reference);
    if-nez v3, :cond_8

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getExtraInfo()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_3

    const-string v3, ""

    #v3=(Reference);
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    #v3=(Boolean);
    if-eqz v3, :cond_4

    :cond_3
    #v3=(Integer);
    move v0, v2

    #v0=(PosByte);
    goto :goto_0

    :cond_4
    #v0=(Reference);v3=(Boolean);
    const-string v3, "cmwap"

    #v3=(Reference);
    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    #v3=(Boolean);
    if-eqz v3, :cond_5

    move v0, v1

    #v0=(One);
    goto :goto_0

    :cond_5
    #v0=(Reference);
    const-string v1, "3gwap"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_6

    const/4 v0, 0x3

    #v0=(PosByte);
    goto :goto_0

    :cond_6
    #v0=(Reference);
    const-string v1, "uniwap"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_7

    const/4 v0, 0x2

    #v0=(PosByte);
    goto :goto_0

    :cond_7
    #v0=(Reference);
    const-string v1, "ctwap"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_8

    const/4 v0, 0x4

    #v0=(PosByte);
    goto :goto_0

    :cond_8
    #v0=(Conflicted);v1=(Conflicted);v3=(Integer);
    move v0, v2

    #v0=(PosByte);
    goto :goto_0

    .line 75
    :pswitch_0
    #v1=(Reference);v3=(Conflicted);
    const-string v0, "wifi"

    #v0=(Reference);
    goto :goto_1

    .line 78
    :pswitch_1
    #v0=(PosByte);
    const-string v0, "3gwap"

    #v0=(Reference);
    goto :goto_1

    .line 81
    :pswitch_2
    #v0=(PosByte);
    const-string v0, "uniwap"

    #v0=(Reference);
    goto :goto_1

    .line 84
    :pswitch_3
    #v0=(PosByte);
    const-string v0, "cmwap"

    #v0=(Reference);
    goto :goto_1

    .line 87
    :pswitch_4
    #v0=(PosByte);
    const-string v0, "ctwap"

    #v0=(Reference);
    goto :goto_1

    .line 73
    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);p0=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_4
        :pswitch_0
    .end packed-switch
.end method

*/}
