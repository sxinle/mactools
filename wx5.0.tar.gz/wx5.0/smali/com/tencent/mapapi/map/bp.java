package com.tencent.mapapi.map; class bp {/*

.class interface abstract Lcom/tencent/mapapi/map/bp;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract e(Z)V
.end method

*/}
