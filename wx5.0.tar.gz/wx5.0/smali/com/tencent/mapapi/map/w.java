package com.tencent.mapapi.map; class w {/*

.class final Lcom/tencent/mapapi/map/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic EL:Lcom/tencent/mapapi/map/v;


# direct methods
.method constructor <init>(Lcom/tencent/mapapi/map/v;)V
    .locals 0
    .parameter

    .prologue
    .line 387
    iput-object p1, p0, Lcom/tencent/mapapi/map/w;->EL:Lcom/tencent/mapapi/map/v;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .prologue
    .line 390
    :goto_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/w;->EL:Lcom/tencent/mapapi/map/v;

    #v0=(Reference);
    iget-boolean v0, v0, Lcom/tencent/mapapi/map/v;->c:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 392
    iget-object v0, p0, Lcom/tencent/mapapi/map/w;->EL:Lcom/tencent/mapapi/map/v;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/v;->hR()V

    goto :goto_0

    .line 395
    :cond_0
    #v0=(Boolean);
    return-void
.end method

*/}
