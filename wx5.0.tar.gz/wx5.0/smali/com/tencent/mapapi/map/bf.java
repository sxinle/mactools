package com.tencent.mapapi.map; class bf {/*

.class final Lcom/tencent/mapapi/map/bf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mapapi/map/x;


# instance fields
.field final synthetic FK:Lcom/tencent/mapapi/map/be;


# direct methods
.method constructor <init>(Lcom/tencent/mapapi/map/be;)V
    .locals 0
    .parameter

    .prologue
    .line 29
    iput-object p1, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final hw()V
    .locals 4

    .prologue
    .line 33
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    if-nez v0, :cond_1

    .line 81
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 37
    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    if-eqz v0, :cond_0

    .line 41
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    if-eqz v0, :cond_0

    .line 46
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v1, v0, Lcom/tencent/mapapi/map/bi;->FT:[B

    #v1=(Reference);
    monitor-enter v1

    .line 48
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    .line 49
    #v2=(Integer);
    if-gtz v2, :cond_2

    .line 50
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 52
    :catchall_0
    #v2=(Conflicted);
    move-exception v0

    monitor-exit v1

    throw v0

    :cond_2
    #v2=(Integer);
    monitor-exit v1

    .line 53
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_1
    #v0=(Integer);v1=(Integer);v3=(Conflicted);
    if-ge v1, v2, :cond_0

    .line 57
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    if-eqz v0, :cond_0

    .line 61
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v3, v0, Lcom/tencent/mapapi/map/bi;->FT:[B

    #v3=(Reference);
    monitor-enter v3

    .line 63
    :try_start_1
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 64
    #v0=(Integer);
    if-eq v0, v2, :cond_3

    .line 67
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/be;->im()V

    .line 68
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_0

    .line 71
    :catchall_1
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v3

    throw v0

    .line 70
    :cond_3
    :try_start_2
    #v0=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bf;->FK:Lcom/tencent/mapapi/map/be;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/be;->a(Lcom/tencent/mapapi/map/be;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    .line 71
    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 73
    if-eqz v0, :cond_4

    .line 74
    iget-boolean v3, v0, Lcom/tencent/mapapi/map/ba;->Fy:Z

    #v3=(Boolean);
    if-eqz v3, :cond_4

    .line 77
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/ba;->hC()V

    .line 55
    :cond_4
    #v3=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1
.end method

*/}
