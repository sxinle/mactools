package com.tencent.mapapi.map; class ay {/*

.class abstract Lcom/tencent/mapapi/map/ay;
.super Lcom/tencent/mapapi/map/az;
.source "SourceFile"


# instance fields
.field protected Eb:Lcom/tencent/mapapi/map/bh;

.field protected Fu:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>(Lcom/tencent/mapapi/map/bh;Landroid/graphics/Bitmap;)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 19
    invoke-direct {p0}, Lcom/tencent/mapapi/map/az;-><init>()V

    .line 20
    #p0=(Reference);
    iput-object p1, p0, Lcom/tencent/mapapi/map/ay;->Eb:Lcom/tencent/mapapi/map/bh;

    .line 21
    iput-object p2, p0, Lcom/tencent/mapapi/map/ay;->Fu:Landroid/graphics/Bitmap;

    .line 22
    return-void
.end method

.method private il()Landroid/graphics/Rect;
    .locals 6

    .prologue
    .line 28
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/ay;->ik()Landroid/graphics/Point;

    move-result-object v1

    .line 29
    #v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ay;->Fu:Landroid/graphics/Bitmap;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 30
    const/4 v0, 0x0

    .line 32
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    :cond_0
    #v1=(Reference);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    new-instance v0, Landroid/graphics/Rect;

    #v0=(UninitRef);
    iget v2, v1, Landroid/graphics/Point;->x:I

    #v2=(Integer);
    iget v3, v1, Landroid/graphics/Point;->y:I

    #v3=(Integer);
    iget v4, v1, Landroid/graphics/Point;->x:I

    #v4=(Integer);
    iget-object v5, p0, Lcom/tencent/mapapi/map/ay;->Fu:Landroid/graphics/Bitmap;

    #v5=(Reference);
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v5

    #v5=(Integer);
    add-int/2addr v4, v5

    iget v1, v1, Landroid/graphics/Point;->y:I

    #v1=(Integer);
    iget-object v5, p0, Lcom/tencent/mapapi/map/ay;->Fu:Landroid/graphics/Bitmap;

    #v5=(Reference);
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    #v5=(Integer);
    add-int/2addr v1, v5

    invoke-direct {v0, v2, v3, v4, v1}, Landroid/graphics/Rect;-><init>(IIII)V

    #v0=(Reference);
    goto :goto_0
.end method


# virtual methods
.method public final a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZJ)Z
    .locals 4
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 38
    iget-object v0, p0, Lcom/tencent/mapapi/map/ay;->Fu:Landroid/graphics/Bitmap;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 39
    const/4 v0, 0x0

    .line 42
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 41
    :cond_0
    #v0=(Reference);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ay;->Fu:Landroid/graphics/Bitmap;

    invoke-direct {p0}, Lcom/tencent/mapapi/map/ay;->il()Landroid/graphics/Rect;

    move-result-object v1

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/Rect;->left:I

    #v1=(Integer);
    int-to-float v1, v1

    #v1=(Float);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ay;->il()Landroid/graphics/Rect;

    move-result-object v2

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/Rect;->top:I

    #v2=(Integer);
    int-to-float v2, v2

    #v2=(Float);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 42
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method protected abstract ik()Landroid/graphics/Point;
.end method

*/}
