package com.tencent.mapapi.map; class bt {/*

.class final Lcom/tencent/mapapi/map/bt;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final Gj:F


# instance fields
.field CL:Z

.field DD:Z

.field Da:Z

.field private EN:Z

.field private FV:Z

.field private GD:Landroid/graphics/PointF;

.field private GE:Landroid/graphics/PointF;

.field private GF:Landroid/graphics/PointF;

.field private GG:Landroid/graphics/PointF;

.field private GH:Lcom/tencent/mapapi/map/bh;

.field private GI:Landroid/view/GestureDetector;

.field private GJ:J

.field private GK:Ljava/lang/reflect/Method;

.field private GL:Ljava/lang/reflect/Method;

.field c:Z

.field private g:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 125
    const-wide v0, 0x3f5c98710add7e36L

    #v0=(LongLo);v1=(LongHi);
    invoke-static {v0, v1}, Ljava/lang/Math;->cos(D)D

    move-result-wide v0

    #v0=(DoubleLo);v1=(DoubleHi);
    double-to-float v0, v0

    #v0=(Float);
    sput v0, Lcom/tencent/mapapi/map/bt;->Gj:F

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v1, 0x1

    .line 60
    #v1=(One);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    #p0=(Reference);
    iput-boolean v1, p0, Lcom/tencent/mapapi/map/bt;->EN:Z

    .line 31
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bt;->FV:Z

    .line 45
    new-instance v0, Landroid/graphics/PointF;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/PointF;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    new-instance v0, Landroid/graphics/PointF;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/PointF;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    new-instance v0, Landroid/graphics/PointF;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/PointF;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    new-instance v0, Landroid/graphics/PointF;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/PointF;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    .line 52
    iput-object v2, p0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    .line 53
    iput-object v2, p0, Lcom/tencent/mapapi/map/bt;->GI:Landroid/view/GestureDetector;

    .line 55
    iput-boolean v1, p0, Lcom/tencent/mapapi/map/bt;->CL:Z

    .line 56
    iput-boolean v1, p0, Lcom/tencent/mapapi/map/bt;->Da:Z

    .line 57
    iput-boolean v1, p0, Lcom/tencent/mapapi/map/bt;->c:Z

    .line 58
    iput-boolean v1, p0, Lcom/tencent/mapapi/map/bt;->DD:Z

    .line 76
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/bt;->GJ:J

    .line 64
    return-void
.end method

.method private a(Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/view/MotionEvent;)V
    .locals 8
    .parameter
    .parameter
    .parameter

    .prologue
    .line 334
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/bt;->GK:Ljava/lang/reflect/Method;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 335
    const-class v0, Landroid/view/MotionEvent;

    const-string v1, "getX"

    #v1=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    #v4=(Reference);
    aput-object v4, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mapapi/map/bt;->GK:Ljava/lang/reflect/Method;

    .line 336
    const-class v0, Landroid/view/MotionEvent;

    const-string v1, "getY"

    const/4 v2, 0x1

    #v2=(One);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    const/4 v3, 0x0

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v4, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mapapi/map/bt;->GL:Ljava/lang/reflect/Method;

    .line 338
    :cond_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bt;->GK:Ljava/lang/reflect/Method;

    const/4 v1, 0x1

    #v1=(One);
    new-array v1, v1, [Ljava/lang/Object;

    #v1=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    new-instance v3, Ljava/lang/Integer;

    #v3=(UninitRef);
    const/4 v4, 0x0

    #v4=(Null);
    invoke-direct {v3, v4}, Ljava/lang/Integer;-><init>(I)V

    #v3=(Reference);
    aput-object v3, v1, v2

    invoke-virtual {v0, p3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v1

    .line 339
    #v1=(Float);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bt;->GK:Ljava/lang/reflect/Method;

    const/4 v2, 0x1

    #v2=(One);
    new-array v2, v2, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    new-instance v4, Ljava/lang/Integer;

    #v4=(UninitRef);
    const/4 v5, 0x1

    #v5=(One);
    invoke-direct {v4, v5}, Ljava/lang/Integer;-><init>(I)V

    #v4=(Reference);
    aput-object v4, v2, v3

    invoke-virtual {v0, p3, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v2

    .line 340
    #v2=(Float);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bt;->GL:Ljava/lang/reflect/Method;

    const/4 v3, 0x1

    #v3=(One);
    new-array v3, v3, [Ljava/lang/Object;

    #v3=(Reference);
    const/4 v4, 0x0

    #v4=(Null);
    new-instance v5, Ljava/lang/Integer;

    #v5=(UninitRef);
    const/4 v6, 0x0

    #v6=(Null);
    invoke-direct {v5, v6}, Ljava/lang/Integer;-><init>(I)V

    #v5=(Reference);
    aput-object v5, v3, v4

    invoke-virtual {v0, p3, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v3

    .line 341
    #v3=(Float);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bt;->GL:Ljava/lang/reflect/Method;

    const/4 v4, 0x1

    #v4=(One);
    new-array v4, v4, [Ljava/lang/Object;

    #v4=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    new-instance v6, Ljava/lang/Integer;

    #v6=(UninitRef);
    const/4 v7, 0x1

    #v7=(One);
    invoke-direct {v6, v7}, Ljava/lang/Integer;-><init>(I)V

    #v6=(Reference);
    aput-object v6, v4, v5

    invoke-virtual {v0, p3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    .line 342
    #v0=(Float);
    invoke-virtual {p1, v1, v3}, Landroid/graphics/PointF;->set(FF)V

    .line 343
    invoke-virtual {p2, v2, v0}, Landroid/graphics/PointF;->set(FF)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 346
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-void

    :catch_0
    move-exception v0

    #v0=(Reference);
    goto :goto_0
.end method

.method private m(FF)Z
    .locals 3
    .parameter
    .parameter

    .prologue
    const/high16 v2, 0x4040

    .line 271
    #v2=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v0

    #v0=(Integer);
    int-to-float v0, v0

    #v0=(Float);
    div-float/2addr v0, v2

    .line 272
    iget-object v1, p0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v1}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v1

    #v1=(Integer);
    int-to-float v1, v1

    #v1=(Float);
    div-float/2addr v1, v2

    .line 275
    iget-object v2, p0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v2

    #v2=(Integer);
    div-int/lit8 v2, v2, 0x2

    int-to-float v2, v2

    #v2=(Float);
    sub-float v2, p1, v2

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    cmpg-float v0, v2, v0

    #v0=(Byte);
    if-gez v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v0

    #v0=(Integer);
    div-int/lit8 v0, v0, 0x2

    int-to-float v0, v0

    #v0=(Float);
    sub-float v0, p2, v0

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    cmpg-float v0, v0, v1

    #v0=(Byte);
    if-gez v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Byte);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method


# virtual methods
.method public final a(Landroid/view/GestureDetector;)V
    .locals 0
    .parameter

    .prologue
    .line 73
    iput-object p1, p0, Lcom/tencent/mapapi/map/bt;->GI:Landroid/view/GestureDetector;

    .line 74
    return-void
.end method

.method public final a(Lcom/tencent/mapapi/map/bh;)V
    .locals 0
    .parameter

    .prologue
    .line 68
    iput-object p1, p0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    .line 69
    return-void
.end method

.method public final a(Landroid/view/MotionEvent;)Z
    .locals 28
    .parameter

    .prologue
    .line 80
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    #v2=(Integer);
    and-int/lit16 v2, v2, 0xff

    packed-switch v2, :pswitch_data_0

    .line 119
    :cond_0
    :goto_0
    :pswitch_0
    #v0=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->EN:Z

    #v2=(Boolean);
    if-eqz v2, :cond_1

    .line 120
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GI:Landroid/view/GestureDetector;

    #v2=(Reference);
    move-object/from16 v0, p1

    invoke-virtual {v2, v0}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 122
    :cond_1
    #v2=(Conflicted);
    const/4 v2, 0x1

    :goto_1
    #v1=(Conflicted);v2=(One);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);v15=(Conflicted);v16=(Conflicted);v17=(Conflicted);v18=(Conflicted);v19=(Conflicted);v20=(Conflicted);v21=(Conflicted);v22=(Conflicted);v23=(Conflicted);v24=(Conflicted);v25=(Conflicted);v26=(Conflicted);v27=(Conflicted);
    return v2

    .line 82
    :pswitch_1
    #v0=(Uninit);v1=(Uninit);v2=(Integer);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);v10=(Uninit);v11=(Uninit);v12=(Uninit);v13=(Uninit);v14=(Uninit);v15=(Uninit);v16=(Uninit);v17=(Uninit);v18=(Uninit);v19=(Uninit);v20=(Uninit);v21=(Uninit);v22=(Uninit);v23=(Uninit);v24=(Uninit);v25=(Uninit);v26=(Uninit);v27=(Uninit);
    const-wide/16 v2, 0x0

    #v2=(LongLo);v3=(LongHi);
    move-object/from16 v0, p0

    #v0=(Reference);
    iput-wide v2, v0, Lcom/tencent/mapapi/map/bt;->GJ:J

    .line 83
    const/4 v2, 0x1

    #v2=(One);
    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->EN:Z

    goto :goto_0

    .line 87
    :pswitch_2
    #v0=(Uninit);v2=(Integer);v3=(Uninit);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    move-object/from16 v0, p0

    #v0=(Reference);
    iput-wide v2, v0, Lcom/tencent/mapapi/map/bt;->GJ:J

    .line 88
    const/4 v2, 0x1

    #v2=(One);
    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->FV:Z

    .line 89
    const/4 v2, 0x0

    #v2=(Null);
    move-object/from16 v0, p0

    iput v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    .line 90
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->EN:Z

    .line 91
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v3=(Reference);
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    #v1=(Reference);
    invoke-direct {v0, v2, v3, v1}, Lcom/tencent/mapapi/map/bt;->a(Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/view/MotionEvent;)V

    .line 92
    const/4 v2, 0x1

    #v2=(One);
    goto :goto_1

    .line 94
    :pswitch_3
    #v0=(Uninit);v1=(Uninit);v2=(Integer);v3=(Uninit);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->Da:Z

    #v2=(Boolean);
    const/4 v3, 0x1

    #v3=(One);
    if-ne v2, v3, :cond_2

    .line 96
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    move-object/from16 v0, p0

    iget-wide v4, v0, Lcom/tencent/mapapi/map/bt;->GJ:J

    #v4=(LongLo);v5=(LongHi);
    sub-long/2addr v2, v4

    .line 97
    move-object/from16 v0, p0

    iget v4, v0, Lcom/tencent/mapapi/map/bt;->g:I

    #v4=(Integer);
    if-nez v4, :cond_2

    const-wide/16 v4, 0x0

    #v4=(LongLo);
    cmp-long v4, v2, v4

    #v4=(Byte);
    if-lez v4, :cond_2

    const-wide/16 v4, 0xc8

    #v4=(LongLo);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-gez v2, :cond_2

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->y:F

    .line 104
    :cond_2
    :pswitch_4
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->FV:Z

    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 106
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {v2, v3}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    .line 107
    const/4 v2, 0x0

    #v2=(Null);
    move-object/from16 v0, p0

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->FV:Z

    .line 108
    const/4 v2, 0x1

    #v2=(One);
    goto/16 :goto_1

    .line 112
    :pswitch_5
    #v0=(Uninit);v2=(Integer);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->FV:Z

    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 113
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v2=(Reference);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v3=(Reference);
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    #v1=(Reference);
    invoke-direct {v0, v2, v3, v1}, Lcom/tencent/mapapi/map/bt;->a(Landroid/graphics/PointF;Landroid/graphics/PointF;Landroid/view/MotionEvent;)V

    .line 114
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v6, v2

    #v6=(DoubleLo);v7=(DoubleHi);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v8, v2

    #v8=(DoubleLo);v9=(DoubleHi);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v10, v2

    #v10=(DoubleLo);v11=(DoubleHi);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v12, v2

    #v12=(DoubleLo);v13=(DoubleHi);
    move-object/from16 v0, p0

    iget-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->c:Z

    #v2=(Boolean);
    const/4 v3, 0x1

    #v3=(One);
    if-ne v2, v3, :cond_7

    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    #v2=(Integer);
    if-eqz v2, :cond_3

    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_7

    :cond_3
    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    if-nez v2, :cond_6

    const-wide/high16 v2, 0x4038

    :goto_2
    #v2=(LongLo);v3=(LongHi);
    invoke-static {v6, v7}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    cmpl-double v4, v4, v2

    #v4=(Byte);
    if-gtz v4, :cond_4

    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);
    cmpl-double v4, v4, v2

    #v4=(Byte);
    if-gtz v4, :cond_4

    invoke-static {v10, v11}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);
    cmpl-double v4, v4, v2

    #v4=(Byte);
    if-gtz v4, :cond_4

    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);
    cmpl-double v2, v4, v2

    #v2=(Byte);
    if-lez v2, :cond_7

    :cond_4
    #v2=(Conflicted);v4=(Conflicted);
    mul-double v2, v8, v12

    #v2=(DoubleLo);v3=(DoubleHi);
    const-wide/16 v4, 0x0

    #v4=(LongLo);v5=(LongHi);
    cmpl-double v2, v2, v4

    #v2=(Byte);
    if-lez v2, :cond_7

    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    move-result-wide v2

    #v2=(DoubleLo);
    invoke-static {v6, v7}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    const-wide v14, 0x3ff3333333333333L

    #v14=(LongLo);v15=(LongHi);
    mul-double/2addr v4, v14

    cmpl-double v2, v2, v4

    #v2=(Byte);
    if-lez v2, :cond_7

    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    move-result-wide v2

    #v2=(DoubleLo);
    invoke-static {v10, v11}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    const-wide v14, 0x3ff3333333333333L

    mul-double/2addr v4, v14

    cmpl-double v2, v2, v4

    #v2=(Byte);
    if-lez v2, :cond_7

    const/4 v2, 0x1

    #v2=(One);
    move-object/from16 v0, p0

    iput v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    .line 115
    :cond_5
    :goto_3
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(LongHi);v16=(Conflicted);v17=(Conflicted);v18=(Conflicted);v19=(Conflicted);v20=(Conflicted);v21=(Conflicted);v22=(Conflicted);v23=(Conflicted);v24=(Conflicted);v25=(Conflicted);v26=(Conflicted);v27=(Conflicted);
    const/4 v2, 0x1

    #v2=(One);
    goto/16 :goto_1

    .line 114
    :cond_6
    #v1=(Reference);v2=(Integer);v3=(One);v4=(Uninit);v5=(Uninit);v14=(Uninit);v15=(Uninit);v16=(Uninit);v17=(Uninit);v18=(Uninit);v19=(Uninit);v20=(Uninit);v21=(Uninit);v22=(Uninit);v23=(Uninit);v24=(Uninit);v25=(Uninit);v26=(Uninit);v27=(Uninit);
    const-wide/high16 v2, 0x4020

    #v2=(LongLo);v3=(LongHi);
    goto/16 :goto_2

    :cond_7
    #v2=(Integer);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v14=(Conflicted);v15=(Conflicted);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v4, v2

    #v4=(DoubleLo);v5=(DoubleHi);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v14, v2

    #v14=(DoubleLo);v15=(DoubleHi);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v0, v2

    #v0=(DoubleLo);v1=(DoubleHi);
    move-wide/from16 v16, v0

    #v16=(DoubleLo);v17=(DoubleHi);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    sub-float/2addr v2, v3

    #v2=(Float);
    float-to-double v0, v2

    #v0=(DoubleLo);
    move-wide/from16 v18, v0

    #v18=(DoubleLo);v19=(DoubleHi);
    mul-double v2, v4, v4

    #v2=(DoubleLo);v3=(DoubleHi);
    mul-double v20, v14, v14

    #v20=(DoubleLo);v21=(DoubleHi);
    add-double v2, v2, v20

    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v20

    mul-double v2, v16, v16

    mul-double v22, v18, v18

    #v22=(DoubleLo);v23=(DoubleHi);
    add-double v2, v2, v22

    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v22

    move-object/from16 v0, p0

    #v0=(Reference);
    iget-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->DD:Z

    #v2=(Boolean);
    const/4 v3, 0x1

    #v3=(One);
    if-ne v2, v3, :cond_b

    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    #v2=(Integer);
    if-eqz v2, :cond_8

    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    const/4 v3, 0x2

    #v3=(PosByte);
    if-ne v2, v3, :cond_b

    :cond_8
    mul-double v2, v20, v22

    #v2=(DoubleLo);v3=(DoubleHi);
    const-wide/16 v24, 0x0

    #v24=(LongLo);v25=(LongHi);
    cmpl-double v2, v2, v24

    #v2=(Byte);
    if-lez v2, :cond_b

    mul-double v2, v4, v16

    #v2=(DoubleLo);
    mul-double v24, v14, v18

    #v24=(DoubleLo);v25=(DoubleHi);
    add-double v2, v2, v24

    mul-double v24, v20, v22

    div-double v2, v2, v24

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    move-result-wide v24

    sget v26, Lcom/tencent/mapapi/map/bt;->Gj:F

    #v26=(Integer);
    move/from16 v0, v26

    #v0=(Integer);
    float-to-double v0, v0

    #v0=(DoubleLo);
    move-wide/from16 v26, v0

    #v26=(DoubleLo);v27=(DoubleHi);
    cmpg-double v24, v24, v26

    #v24=(Byte);
    if-gez v24, :cond_b

    const-wide v24, 0x4066800000000000L

    #v24=(LongLo);v25=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Math;->acos(D)D

    move-result-wide v2

    mul-double v2, v2, v24

    const-wide v24, 0x400921fb54442d18L

    div-double v2, v2, v24

    mul-double v4, v4, v18

    mul-double v14, v14, v16

    sub-double/2addr v4, v14

    const-wide/16 v14, 0x0

    #v14=(LongLo);v15=(LongHi);
    cmpg-double v4, v4, v14

    #v4=(Byte);
    if-gez v4, :cond_9

    neg-double v2, v2

    :cond_9
    move-object/from16 v0, p0

    #v0=(Reference);
    iget v4, v0, Lcom/tencent/mapapi/map/bt;->g:I

    #v4=(Integer);
    if-nez v4, :cond_a

    const-wide/high16 v4, 0x402a

    :goto_4
    #v4=(LongLo);v5=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    move-result-wide v2

    cmpl-double v2, v2, v4

    #v2=(Byte);
    if-lez v2, :cond_b

    const/4 v2, 0x2

    #v2=(PosByte);
    move-object/from16 v0, p0

    iput v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    goto/16 :goto_3

    :cond_a
    #v2=(DoubleLo);v3=(DoubleHi);v5=(DoubleHi);
    const-wide/high16 v4, 0x3ff0

    #v4=(LongLo);v5=(LongHi);
    goto :goto_4

    :cond_b
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v24=(Conflicted);v25=(Conflicted);v26=(Conflicted);v27=(Conflicted);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-boolean v2, v0, Lcom/tencent/mapapi/map/bt;->Da:Z

    #v2=(Boolean);
    const/4 v3, 0x1

    #v3=(One);
    if-ne v2, v3, :cond_f

    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    #v2=(Integer);
    if-eqz v2, :cond_c

    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    const/4 v3, 0x3

    #v3=(PosByte);
    if-ne v2, v3, :cond_f

    :cond_c
    const-wide/16 v2, 0x0

    #v2=(LongLo);v3=(LongHi);
    cmpl-double v2, v20, v2

    #v2=(Byte);
    if-lez v2, :cond_f

    div-double v4, v22, v20

    #v4=(DoubleLo);v5=(DoubleHi);
    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    #v2=(Integer);
    if-nez v2, :cond_e

    const-wide v2, 0x3fb999999999999aL

    :goto_5
    #v2=(LongLo);
    const-wide/high16 v14, 0x3ff0

    sub-double v14, v4, v14

    #v14=(DoubleLo);v15=(DoubleHi);
    invoke-static {v14, v15}, Ljava/lang/Math;->abs(D)D

    move-result-wide v14

    cmpl-double v2, v14, v2

    #v2=(Byte);
    if-lez v2, :cond_f

    const/4 v2, 0x3

    #v2=(PosByte);
    move-object/from16 v0, p0

    iput v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GH:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2, v4, v5}, Lcom/tencent/mapapi/map/bm;->a(D)V

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    move-object/from16 v0, p0

    invoke-direct {v0, v2, v3}, Lcom/tencent/mapapi/map/bt;->m(FF)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_d

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    move-object/from16 v0, p0

    invoke-direct {v0, v2, v3}, Lcom/tencent/mapapi/map/bt;->m(FF)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_d

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    add-float/2addr v2, v3

    #v2=(Float);
    const/high16 v3, 0x4000

    div-float/2addr v2, v3

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    add-float/2addr v3, v4

    #v3=(Float);
    const/high16 v4, 0x4000

    div-float/2addr v3, v4

    move-object/from16 v0, p0

    invoke-direct {v0, v2, v3}, Lcom/tencent/mapapi/map/bt;->m(FF)Z

    :cond_d
    #v3=(Integer);v4=(Conflicted);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    goto/16 :goto_3

    :cond_e
    #v2=(Integer);v3=(LongHi);v4=(DoubleLo);v14=(LongLo);v15=(LongHi);
    const-wide v2, 0x3fa999999999999aL

    #v2=(LongLo);
    goto/16 :goto_5

    :cond_f
    #v2=(Integer);v3=(Conflicted);v4=(LongLo);v5=(LongHi);
    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    if-eqz v2, :cond_10

    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    const/4 v3, 0x4

    #v3=(PosByte);
    if-ne v2, v3, :cond_5

    :cond_10
    #v3=(Conflicted);
    move-object/from16 v0, p0

    iget v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    if-nez v2, :cond_12

    const-wide/high16 v2, 0x4054

    :goto_6
    #v2=(LongLo);v3=(LongHi);
    invoke-static {v6, v7}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    cmpl-double v4, v4, v2

    #v4=(Byte);
    if-gtz v4, :cond_11

    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);
    cmpl-double v4, v4, v2

    #v4=(Byte);
    if-gtz v4, :cond_11

    invoke-static {v10, v11}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);
    cmpl-double v4, v4, v2

    #v4=(Byte);
    if-gtz v4, :cond_11

    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    move-result-wide v4

    #v4=(DoubleLo);
    cmpl-double v2, v4, v2

    #v2=(Byte);
    if-lez v2, :cond_5

    :cond_11
    #v2=(Conflicted);v4=(Conflicted);
    const/4 v2, 0x4

    #v2=(PosByte);
    move-object/from16 v0, p0

    iput v2, v0, Lcom/tencent/mapapi/map/bt;->g:I

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GF:Landroid/graphics/PointF;

    #v2=(Reference);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GD:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/bt;->GG:Landroid/graphics/PointF;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/bt;->GE:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    invoke-virtual {v2, v3, v4}, Landroid/graphics/PointF;->set(FF)V

    goto/16 :goto_3

    :cond_12
    #v2=(Integer);v3=(Conflicted);v4=(LongLo);v5=(LongHi);
    const-wide/high16 v2, 0x4020

    #v2=(LongLo);v3=(LongHi);
    goto :goto_6

    .line 80
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_3
        :pswitch_5
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_4
    .end packed-switch
.end method

*/}
