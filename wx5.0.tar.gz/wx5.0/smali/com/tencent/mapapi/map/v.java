package com.tencent.mapapi.map; class v {/*

.class final Lcom/tencent/mapapi/map/v;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field protected Da:Z

.field protected EH:Ljava/util/concurrent/Semaphore;

.field EI:[Ljava/lang/Thread;

.field EJ:Lcom/tencent/mapapi/map/x;

.field private EK:Ljava/lang/Runnable;

.field protected volatile c:Z


# direct methods
.method public constructor <init>(ILcom/tencent/mapapi/map/x;)V
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v4, 0x1

    #v4=(One);
    const/4 v0, 0x0

    .line 375
    #v0=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 369
    #p0=(Reference);
    new-instance v1, Ljava/util/concurrent/Semaphore;

    #v1=(UninitRef);
    invoke-direct {v1, v0, v0}, Ljava/util/concurrent/Semaphore;-><init>(IZ)V

    #v1=(Reference);
    iput-object v1, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    .line 370
    iput-boolean v4, p0, Lcom/tencent/mapapi/map/v;->Da:Z

    .line 371
    iput-boolean v4, p0, Lcom/tencent/mapapi/map/v;->c:Z

    .line 372
    iput-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    .line 373
    iput-object v2, p0, Lcom/tencent/mapapi/map/v;->EJ:Lcom/tencent/mapapi/map/x;

    .line 387
    new-instance v1, Lcom/tencent/mapapi/map/w;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mapapi/map/w;-><init>(Lcom/tencent/mapapi/map/v;)V

    #v1=(Reference);
    iput-object v1, p0, Lcom/tencent/mapapi/map/v;->EK:Ljava/lang/Runnable;

    .line 376
    if-gtz p1, :cond_0

    .line 385
    :goto_0
    #v0=(Integer);v2=(Reference);v3=(Conflicted);
    return-void

    .line 379
    :cond_0
    #v0=(Null);v2=(Null);v3=(Uninit);
    new-array v1, p1, [Ljava/lang/Thread;

    iput-object v1, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    .line 380
    :goto_1
    #v0=(Integer);v2=(Reference);v3=(Conflicted);
    if-ge v0, p1, :cond_1

    .line 381
    iget-object v1, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    new-instance v2, Ljava/lang/Thread;

    #v2=(UninitRef);
    iget-object v3, p0, Lcom/tencent/mapapi/map/v;->EK:Ljava/lang/Runnable;

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    #v2=(Reference);
    aput-object v2, v1, v0

    .line 382
    iget-object v1, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    aget-object v1, v1, v0

    #v1=(Null);
    invoke-virtual {v1, v4}, Ljava/lang/Thread;->setDaemon(Z)V

    .line 380
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 384
    :cond_1
    #v1=(Reference);v3=(Conflicted);
    iput-object p2, p0, Lcom/tencent/mapapi/map/v;->EJ:Lcom/tencent/mapapi/map/x;

    goto :goto_0
.end method

.method private ia()V
    .locals 2

    .prologue
    .line 458
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/v;->Da:Z

    .line 459
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    #v0=(Reference);
    const/16 v1, 0x64

    #v1=(PosByte);
    invoke-virtual {v0, v1}, Ljava/util/concurrent/Semaphore;->release(I)V

    .line 460
    return-void
.end method


# virtual methods
.method protected final aj(I)V
    .locals 2
    .parameter

    .prologue
    .line 470
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/v;->Da:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 471
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->availablePermits()I

    move-result v0

    .line 472
    #v0=(Integer);
    const/16 v1, 0x64

    #v1=(PosByte);
    if-le v0, v1, :cond_1

    .line 478
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 476
    :cond_1
    #v0=(Integer);v1=(PosByte);
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/concurrent/Semaphore;->release(I)V

    goto :goto_0
.end method

.method public final hB()V
    .locals 4

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v3, 0x0

    .line 415
    #v3=(Null);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/v;->c:Z

    .line 416
    iget-object v1, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v1=(Reference);
    if-nez v1, :cond_1

    .line 429
    :cond_0
    :goto_0
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);
    return-void

    .line 419
    :cond_1
    #v0=(Null);v1=(Reference);v2=(Uninit);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/v;->ia()V

    .line 420
    iget-object v1, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    array-length v1, v1

    .line 421
    #v1=(Integer);
    if-eqz v1, :cond_0

    .line 424
    :goto_1
    #v0=(Integer);v2=(Conflicted);
    if-ge v0, v1, :cond_2

    .line 425
    iget-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v2=(Reference);
    aput-object v3, v2, v0

    .line 424
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 427
    :cond_2
    #v2=(Conflicted);
    iput-object v3, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    .line 428
    iput-object v3, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    goto :goto_0
.end method

.method public final hC()V
    .locals 4

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v3, 0x0

    .line 432
    #v3=(Null);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/v;->c:Z

    .line 433
    iget-object v1, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v1=(Reference);
    if-nez v1, :cond_1

    .line 455
    :cond_0
    :goto_0
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);
    return-void

    .line 436
    :cond_1
    #v0=(Null);v1=(Reference);v2=(Uninit);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/v;->ia()V

    .line 437
    iget-object v1, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    array-length v1, v1

    .line 438
    #v1=(Integer);
    if-eqz v1, :cond_0

    .line 441
    :goto_1
    #v0=(Integer);v2=(Conflicted);
    if-ge v0, v1, :cond_3

    .line 442
    iget-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v2=(Reference);
    aget-object v2, v2, v0

    #v2=(Null);
    if-eqz v2, :cond_2

    .line 443
    iget-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v2=(Reference);
    aget-object v2, v2, v0

    #v2=(Null);
    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 447
    :try_start_0
    iget-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v2=(Reference);
    aget-object v2, v2, v0

    #v2=(Null);
    invoke-virtual {v2}, Ljava/lang/Thread;->join()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 451
    :goto_2
    #v2=(Reference);
    iget-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    aput-object v3, v2, v0

    .line 441
    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 453
    :cond_3
    #v2=(Conflicted);
    iput-object v3, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    .line 454
    iput-object v3, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    goto :goto_0

    :catch_0
    #v2=(Reference);
    move-exception v2

    goto :goto_2
.end method

.method final hR()V
    .locals 1

    .prologue
    .line 481
    invoke-static {}, Ljava/lang/Thread;->yield()V

    .line 482
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    #v0=(Reference);
    if-nez v0, :cond_1

    .line 495
    :cond_0
    :goto_0
    return-void

    .line 486
    :cond_1
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EH:Ljava/util/concurrent/Semaphore;

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 491
    :goto_1
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EJ:Lcom/tencent/mapapi/map/x;

    if-eqz v0, :cond_0

    .line 492
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EJ:Lcom/tencent/mapapi/map/x;

    invoke-interface {v0}, Lcom/tencent/mapapi/map/x;->hw()V

    goto :goto_0

    :catch_0
    move-exception v0

    goto :goto_1
.end method

.method public final hw()V
    .locals 3

    .prologue
    .line 399
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v0=(Reference);
    if-nez v0, :cond_1

    .line 412
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);
    return-void

    .line 402
    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    array-length v1, v0

    .line 403
    #v1=(Integer);
    if-eqz v1, :cond_0

    .line 406
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v2=(Conflicted);
    if-ge v0, v1, :cond_0

    .line 408
    iget-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v2=(Reference);
    aget-object v2, v2, v0

    #v2=(Null);
    if-eqz v2, :cond_2

    .line 409
    iget-object v2, p0, Lcom/tencent/mapapi/map/v;->EI:[Ljava/lang/Thread;

    #v2=(Reference);
    aget-object v2, v2, v0

    #v2=(Null);
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 406
    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0
.end method

*/}
