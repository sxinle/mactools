package com.tencent.mapapi.map; class az {/*

.class abstract Lcom/tencent/mapapi/map/az;
.super Lcom/tencent/mapapi/map/m;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 67
    invoke-direct {p0}, Lcom/tencent/mapapi/map/m;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public abstract a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZJ)Z
.end method

.method public abstract hC()V
.end method

*/}
