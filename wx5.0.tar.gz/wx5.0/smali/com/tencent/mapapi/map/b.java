package com.tencent.mapapi.map; class b {/*

.class public abstract Lcom/tencent/mapapi/map/b;
.super Lcom/tencent/mapapi/map/m;
.source "SourceFile"


# static fields
.field private static CS:I


# instance fields
.field private CL:Z

.field private DP:Landroid/graphics/drawable/Drawable;

.field private DQ:Landroid/graphics/drawable/Drawable;

.field private DR:Lcom/tencent/mapapi/map/e;

.field private DS:Lcom/tencent/mapapi/map/c;

.field private DT:Lcom/tencent/mapapi/map/OverlayItem;

.field private De:I

.field private g:I

.field private j:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 32
    const/4 v0, -0x1

    #v0=(Byte);
    sput v0, Lcom/tencent/mapapi/map/b;->CS:I

    return-void
.end method

.method public constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .locals 5
    .parameter

    .prologue
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v4, 0x1

    #v4=(One);
    const/4 v0, -0x1

    #v0=(Byte);
    const/4 v3, 0x0

    .line 44
    #v3=(Null);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/m;-><init>()V

    .line 29
    #p0=(Reference);
    iput-boolean v4, p0, Lcom/tencent/mapapi/map/b;->CL:Z

    .line 33
    iput-object v1, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    .line 34
    iput-object v1, p0, Lcom/tencent/mapapi/map/b;->DS:Lcom/tencent/mapapi/map/c;

    .line 35
    iput v0, p0, Lcom/tencent/mapapi/map/b;->g:I

    .line 36
    iput v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    .line 38
    iput-boolean v3, p0, Lcom/tencent/mapapi/map/b;->j:Z

    .line 45
    iput-object p1, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    .line 48
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 50
    new-instance v0, Landroid/graphics/drawable/BitmapDrawable;

    #v0=(UninitRef);
    sget-object v1, Lcom/tencent/mapapi/map/bq;->Fu:Landroid/graphics/Bitmap;

    #v1=(Reference);
    invoke-direct {v0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    .line 53
    :cond_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    .line 54
    #v0=(Integer);
    iget-object v1, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v1

    .line 55
    #v1=(Integer);
    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v2=(Reference);
    invoke-virtual {v2, v3, v3, v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 57
    new-instance v0, Lcom/tencent/mapapi/map/u;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mapapi/map/u;-><init>()V

    .line 58
    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/u;->a(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mapapi/map/b;->DQ:Landroid/graphics/drawable/Drawable;

    .line 60
    sget v0, Lcom/tencent/mapapi/map/b;->CS:I

    #v0=(Integer);
    if-ne v4, v0, :cond_1

    .line 61
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/b;->boundCenterBottom(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 67
    :goto_0
    #v1=(Conflicted);
    return-void

    .line 62
    :cond_1
    #v0=(Integer);v1=(Reference);
    const/4 v0, 0x2

    #v0=(PosByte);
    sget v1, Lcom/tencent/mapapi/map/b;->CS:I

    #v1=(Integer);
    if-ne v0, v1, :cond_2

    .line 63
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/b;->boundCenter(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    goto :goto_0

    .line 65
    :cond_2
    #v0=(PosByte);
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/b;->boundCenterBottom(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    goto :goto_0
.end method

.method private static a(Landroid/graphics/drawable/Drawable;Lcom/tencent/mapapi/map/d;)Landroid/graphics/drawable/Drawable;
    .locals 4
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 91
    #v0=(Null);
    if-eqz p0, :cond_0

    sget-object v1, Lcom/tencent/mapapi/map/d;->DU:Lcom/tencent/mapapi/map/d;

    #v1=(Reference);
    if-ne v1, p1, :cond_1

    .line 92
    :cond_0
    #v1=(Conflicted);
    const/4 p0, 0x0

    .line 108
    :goto_0
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);
    return-object p0

    .line 95
    :cond_1
    #v0=(Null);v1=(Reference);v2=(Uninit);v3=(Uninit);
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p0, v0, v0, v1, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 98
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    .line 99
    #v1=(Reference);
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v2

    div-int/lit8 v2, v2, 0x2

    .line 100
    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v1

    #v1=(Integer);
    neg-int v1, v1

    .line 103
    sget-object v3, Lcom/tencent/mapapi/map/d;->DV:Lcom/tencent/mapapi/map/d;

    #v3=(Reference);
    if-ne p1, v3, :cond_2

    .line 104
    div-int/lit8 v1, v1, 0x2

    .line 105
    neg-int v0, v1

    .line 107
    :cond_2
    #v0=(Integer);
    neg-int v3, v2

    #v3=(Integer);
    invoke-virtual {p0, v3, v1, v2, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    goto :goto_0
.end method

.method static synthetic a(Lcom/tencent/mapapi/map/b;)Landroid/graphics/drawable/Drawable;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic a(Lcom/tencent/mapapi/map/b;Lcom/tencent/mapapi/map/OverlayItem;)Lcom/tencent/mapapi/map/OverlayItem;
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 18
    iput-object p1, p0, Lcom/tencent/mapapi/map/b;->DT:Lcom/tencent/mapapi/map/OverlayItem;

    return-object p1
.end method

.method private a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZLcom/tencent/mapapi/map/OverlayItem;I)V
    .locals 8
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x0

    .line 445
    #v2=(Null);
    invoke-virtual {p4, p5}, Lcom/tencent/mapapi/map/OverlayItem;->getMarker(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 448
    #v1=(Reference);
    if-eqz v1, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_4

    .line 449
    :cond_0
    #v0=(Conflicted);
    const/4 v0, 0x1

    .line 451
    :goto_0
    #v0=(Boolean);
    if-eqz v0, :cond_2

    .line 452
    if-eqz p3, :cond_1

    .line 453
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DQ:Landroid/graphics/drawable/Drawable;

    .line 454
    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mapapi/map/b;->DQ:Landroid/graphics/drawable/Drawable;

    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v2=(Reference);
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->copyBounds()Landroid/graphics/Rect;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 455
    iget-object v1, p0, Lcom/tencent/mapapi/map/b;->DQ:Landroid/graphics/drawable/Drawable;

    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    invoke-static {v1, v2}, Lcom/tencent/mapapi/map/u;->b(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 472
    :goto_1
    #v3=(Conflicted);
    invoke-virtual {p2}, Lcom/tencent/mapapi/map/MapView;->hN()Lcom/tencent/mapapi/map/o;

    move-result-object v1

    .line 473
    invoke-virtual {p4}, Lcom/tencent/mapapi/map/OverlayItem;->hX()Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v2

    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v3}, Lcom/tencent/mapapi/map/o;->a(Lcom/tencent/mapapi/map/GeoPoint;Landroid/graphics/Point;)Landroid/graphics/Point;

    move-result-object v1

    .line 477
    iget v2, v1, Landroid/graphics/Point;->x:I

    #v2=(Integer);
    iget v1, v1, Landroid/graphics/Point;->y:I

    #v1=(Integer);
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v3

    #v3=(Reference);
    iget v4, v3, Landroid/graphics/Rect;->left:I

    #v4=(Integer);
    add-int/2addr v4, v2

    iget v5, v3, Landroid/graphics/Rect;->top:I

    #v5=(Integer);
    add-int/2addr v5, v1

    iget v6, v3, Landroid/graphics/Rect;->right:I

    #v6=(Integer);
    add-int/2addr v6, v2

    iget v7, v3, Landroid/graphics/Rect;->bottom:I

    #v7=(Integer);
    add-int/2addr v7, v1

    invoke-virtual {v0, v4, v5, v6, v7}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    iget v4, v3, Landroid/graphics/Rect;->left:I

    sub-int/2addr v4, v2

    iget v5, v3, Landroid/graphics/Rect;->top:I

    sub-int/2addr v5, v1

    iget v6, v3, Landroid/graphics/Rect;->right:I

    sub-int v2, v6, v2

    iget v3, v3, Landroid/graphics/Rect;->bottom:I

    #v3=(Integer);
    sub-int v1, v3, v1

    invoke-virtual {v0, v4, v5, v2, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 492
    return-void

    .line 457
    :cond_1
    #v0=(Boolean);v1=(Reference);v2=(Null);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    goto :goto_1

    .line 460
    :cond_2
    #v0=(Boolean);
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v1, v2, v2, v0, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 462
    invoke-static {v1}, Lcom/tencent/mapapi/map/b;->boundCenterBottom(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 463
    if-eqz p3, :cond_3

    .line 464
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DQ:Landroid/graphics/drawable/Drawable;

    .line 465
    #v0=(Reference);
    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DQ:Landroid/graphics/drawable/Drawable;

    #v2=(Reference);
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->copyBounds()Landroid/graphics/Rect;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 466
    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DQ:Landroid/graphics/drawable/Drawable;

    invoke-static {v2, v1}, Lcom/tencent/mapapi/map/u;->b(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    goto :goto_1

    :cond_3
    #v0=(Integer);v2=(Null);v3=(Integer);
    move-object v0, v1

    .line 468
    #v0=(Reference);
    goto :goto_1

    :cond_4
    #v0=(Boolean);v3=(Uninit);
    move v0, v2

    #v0=(Null);
    goto :goto_0
.end method

.method protected static a(Landroid/graphics/drawable/Drawable;II)Z
    .locals 1
    .parameter
    .parameter
    .parameter

    .prologue
    .line 313
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    .line 314
    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Landroid/graphics/Rect;->contains(II)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method private ao(I)Lcom/tencent/mapapi/map/OverlayItem;
    .locals 1
    .parameter

    .prologue
    .line 157
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/e;->ap(I)Lcom/tencent/mapapi/map/OverlayItem;

    move-result-object v0

    return-object v0
.end method

.method public static boundCenter(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 1
    .parameter

    .prologue
    .line 86
    const/4 v0, 0x2

    #v0=(PosByte);
    sput v0, Lcom/tencent/mapapi/map/b;->CS:I

    .line 87
    sget-object v0, Lcom/tencent/mapapi/map/d;->DV:Lcom/tencent/mapapi/map/d;

    #v0=(Reference);
    invoke-static {p0, v0}, Lcom/tencent/mapapi/map/b;->a(Landroid/graphics/drawable/Drawable;Lcom/tencent/mapapi/map/d;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
.end method

.method private static boundCenterBottom(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 1
    .parameter

    .prologue
    .line 75
    const/4 v0, 0x1

    #v0=(One);
    sput v0, Lcom/tencent/mapapi/map/b;->CS:I

    .line 77
    sget-object v0, Lcom/tencent/mapapi/map/d;->DW:Lcom/tencent/mapapi/map/d;

    #v0=(Reference);
    invoke-static {p0, v0}, Lcom/tencent/mapapi/map/b;->a(Landroid/graphics/drawable/Drawable;Lcom/tencent/mapapi/map/d;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;Z)V
    .locals 12
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v11, 0x4

    #v11=(PosByte);
    const/4 v9, 0x1

    #v9=(One);
    const/4 v5, 0x0

    .line 421
    #v5=(Null);
    move v6, v5

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v6=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/e;->hJ()I

    move-result v0

    #v0=(Integer);
    if-ge v6, v0, :cond_1

    .line 422
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v0=(Reference);
    invoke-virtual {v0, v6}, Lcom/tencent/mapapi/map/e;->aq(I)I

    move-result v0

    .line 423
    #v0=(Integer);
    iget v1, p0, Lcom/tencent/mapapi/map/b;->De:I

    #v1=(Integer);
    if-eq v0, v1, :cond_0

    .line 424
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/b;->ao(I)Lcom/tencent/mapapi/map/OverlayItem;

    move-result-object v4

    #v4=(Reference);
    move-object v0, p0

    #v0=(Reference);
    move-object v1, p1

    #v1=(Reference);
    move-object v2, p2

    #v2=(Reference);
    move v3, p3

    .line 425
    #v3=(Boolean);
    invoke-direct/range {v0 .. v5}, Lcom/tencent/mapapi/map/b;->a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZLcom/tencent/mapapi/map/OverlayItem;I)V

    .line 421
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    add-int/lit8 v0, v6, 0x1

    #v0=(Integer);
    move v6, v0

    goto :goto_0

    .line 429
    :cond_1
    const/4 v10, 0x0

    #v10=(Null);
    iget v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    const/4 v1, -0x1

    #v1=(Byte);
    if-eq v0, v1, :cond_2

    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v0=(Reference);
    iget v1, p0, Lcom/tencent/mapapi/map/b;->De:I

    #v1=(Integer);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/e;->ap(I)Lcom/tencent/mapapi/map/OverlayItem;

    move-result-object v10

    .line 430
    :cond_2
    #v0=(Conflicted);v10=(Reference);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/b;->CL:Z

    #v0=(Boolean);
    if-eqz v0, :cond_4

    if-eqz v10, :cond_4

    .line 432
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/b;->hU()Z

    move-result v0

    if-ne v0, v9, :cond_3

    move-object v6, p0

    #v6=(Reference);
    move-object v7, p1

    #v7=(Reference);
    move-object v8, p2

    .line 434
    #v8=(Reference);
    invoke-direct/range {v6 .. v11}, Lcom/tencent/mapapi/map/b;->a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZLcom/tencent/mapapi/map/OverlayItem;I)V

    :cond_3
    #v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    move-object v6, p0

    #v6=(Reference);
    move-object v7, p1

    #v7=(Reference);
    move-object v8, p2

    #v8=(Reference);
    move v9, v5

    .line 438
    #v9=(Null);
    invoke-direct/range {v6 .. v11}, Lcom/tencent/mapapi/map/b;->a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZLcom/tencent/mapapi/map/OverlayItem;I)V

    .line 441
    :cond_4
    #v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Boolean);
    return-void
.end method

.method public final a(Lcom/tencent/mapapi/map/OverlayItem;)V
    .locals 3
    .parameter

    .prologue
    const/4 v2, -0x1

    .line 225
    #v2=(Byte);
    if-eqz p1, :cond_1

    iget v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    #v0=(Integer);
    iget-object v1, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v1=(Reference);
    invoke-virtual {v1, p1}, Lcom/tencent/mapapi/map/e;->b(Lcom/tencent/mapapi/map/OverlayItem;)I

    move-result v1

    #v1=(Integer);
    if-ne v0, v1, :cond_1

    .line 242
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 228
    :cond_1
    if-nez p1, :cond_3

    iget v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    #v0=(Integer);
    if-eq v0, v2, :cond_3

    .line 229
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DS:Lcom/tencent/mapapi/map/c;

    #v0=(Reference);
    if-eqz v0, :cond_2

    .line 230
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DS:Lcom/tencent/mapapi/map/c;

    .line 232
    :cond_2
    iput v2, p0, Lcom/tencent/mapapi/map/b;->De:I

    goto :goto_0

    .line 235
    :cond_3
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/e;->b(Lcom/tencent/mapapi/map/OverlayItem;)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    .line 236
    iget v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    if-eq v0, v2, :cond_0

    .line 237
    iget v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    iput v0, p0, Lcom/tencent/mapapi/map/b;->g:I

    .line 238
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DS:Lcom/tencent/mapapi/map/c;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 239
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DS:Lcom/tencent/mapapi/map/c;

    goto :goto_0
.end method

.method public final a(Landroid/view/MotionEvent;Lcom/tencent/mapapi/map/MapView;)Z
    .locals 4
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 350
    .line 352
    #v0=(Null);
    iget-boolean v2, p0, Lcom/tencent/mapapi/map/b;->j:Z

    #v2=(Boolean);
    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DT:Lcom/tencent/mapapi/map/OverlayItem;

    #v2=(Reference);
    if-eqz v2, :cond_0

    .line 353
    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DT:Lcom/tencent/mapapi/map/OverlayItem;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/OverlayItem;->hV()Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_1

    .line 379
    :cond_0
    :goto_0
    :pswitch_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 357
    :cond_1
    #v0=(Null);v2=(Boolean);v3=(Uninit);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    .line 359
    #v2=(Integer);
    packed-switch v2, :pswitch_data_0

    goto :goto_0

    .line 373
    :pswitch_1
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/b;->j:Z

    .line 374
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/tencent/mapapi/map/b;->DT:Lcom/tencent/mapapi/map/OverlayItem;

    move v0, v1

    .line 375
    #v0=(One);
    goto :goto_0

    .line 363
    :pswitch_2
    #v0=(Null);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    #v0=(Float);
    float-to-int v0, v0

    .line 364
    #v0=(Integer);
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    #v2=(Float);
    float-to-int v2, v2

    .line 365
    #v2=(Integer);
    invoke-virtual {p2}, Lcom/tencent/mapapi/map/MapView;->hN()Lcom/tencent/mapapi/map/o;

    move-result-object v3

    #v3=(Reference);
    invoke-interface {v3, v0, v2}, Lcom/tencent/mapapi/map/o;->h(II)Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v0

    .line 366
    #v0=(Reference);
    iget-object v2, p0, Lcom/tencent/mapapi/map/b;->DT:Lcom/tencent/mapapi/map/OverlayItem;

    #v2=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/mapapi/map/OverlayItem;->c(Lcom/tencent/mapapi/map/GeoPoint;)V

    .line 367
    invoke-virtual {p2}, Lcom/tencent/mapapi/map/MapView;->invalidate()V

    move v0, v1

    .line 369
    #v0=(One);
    goto :goto_0

    .line 359
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_1
        :pswitch_1
    .end packed-switch
.end method

.method public final a(Lcom/tencent/mapapi/map/GeoPoint;Lcom/tencent/mapapi/map/MapView;)Z
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 282
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Lcom/tencent/mapapi/map/e;->d(Lcom/tencent/mapapi/map/GeoPoint;Lcom/tencent/mapapi/map/MapView;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method protected abstract an(I)Lcom/tencent/mapapi/map/OverlayItem;
.end method

.method public final b(Lcom/tencent/mapapi/map/GeoPoint;Lcom/tencent/mapapi/map/MapView;)Z
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 297
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Lcom/tencent/mapapi/map/e;->c(Lcom/tencent/mapapi/map/GeoPoint;Lcom/tencent/mapapi/map/MapView;)Z

    .line 298
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/b;->j:Z

    .line 299
    iget-object v0, p0, Lcom/tencent/mapapi/map/b;->DT:Lcom/tencent/mapapi/map/OverlayItem;

    .line 301
    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method protected final onTap(I)Z
    .locals 1
    .parameter

    .prologue
    .line 388
    iget v0, p0, Lcom/tencent/mapapi/map/b;->De:I

    #v0=(Integer);
    if-eq p1, v0, :cond_0

    .line 389
    invoke-direct {p0, p1}, Lcom/tencent/mapapi/map/b;->ao(I)Lcom/tencent/mapapi/map/OverlayItem;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/b;->a(Lcom/tencent/mapapi/map/OverlayItem;)V

    .line 391
    :cond_0
    #v0=(Conflicted);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

.method protected final populate()V
    .locals 2

    .prologue
    const/4 v1, -0x1

    .line 128
    #v1=(Byte);
    new-instance v0, Lcom/tencent/mapapi/map/e;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mapapi/map/e;-><init>(Lcom/tencent/mapapi/map/b;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/b;->DR:Lcom/tencent/mapapi/map/e;

    .line 129
    iput v1, p0, Lcom/tencent/mapapi/map/b;->g:I

    .line 130
    iput v1, p0, Lcom/tencent/mapapi/map/b;->De:I

    .line 131
    return-void
.end method

.method public abstract size()I
.end method

*/}
