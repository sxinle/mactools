package com.tencent.mapapi.map; class a {/*

.class final Lcom/tencent/mapapi/map/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 97
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2
    .parameter

    .prologue
    .line 97
    new-instance v0, Lcom/tencent/mapapi/map/GeoPoint;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {v0, p1, v1}, Lcom/tencent/mapapi/map/GeoPoint;-><init>(Landroid/os/Parcel;B)V

    #v0=(Reference);
    return-object v0
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1
    .parameter

    .prologue
    .line 97
    new-array v0, p1, [Lcom/tencent/mapapi/map/GeoPoint;

    #v0=(Reference);
    return-object v0
.end method

*/}
