package com.tencent.mapapi.map; class ae {/*

.class abstract Lcom/tencent/mapapi/map/ae;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 860
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public varargs abstract a(I[I)Ljava/lang/String;
.end method

*/}
