package com.tencent.mapapi.map; class k {/*

.class interface abstract Lcom/tencent/mapapi/map/k;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract hT()V
.end method

*/}
