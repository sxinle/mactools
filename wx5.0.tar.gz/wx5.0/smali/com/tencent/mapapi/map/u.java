package com.tencent.mapapi.map; class u {/*

.class final Lcom/tencent/mapapi/map/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mapapi/map/at;


# instance fields
.field private DP:Landroid/graphics/drawable/Drawable;

.field private EG:Lcom/tencent/mapapi/map/as;


# direct methods
.method constructor <init>()V
    .locals 2

    .prologue
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    #p0=(Reference);
    new-instance v0, Lcom/tencent/mapapi/map/as;

    #v0=(UninitRef);
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_4444:Landroid/graphics/Bitmap$Config;

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/tencent/mapapi/map/as;-><init>(Landroid/graphics/Bitmap$Config;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/u;->EG:Lcom/tencent/mapapi/map/as;

    .line 17
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public static b(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 6
    .parameter
    .parameter

    .prologue
    .line 38
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    .line 39
    #v0=(Reference);
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v1

    #v1=(Integer);
    int-to-float v1, v1

    #v1=(Float);
    const/high16 v2, 0x3f00

    #v2=(Integer);
    mul-float/2addr v1, v2

    float-to-int v1, v1

    .line 40
    #v1=(Integer);
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v2

    int-to-float v2, v2

    #v2=(Float);
    const v3, 0x3f63d70a

    #v3=(Integer);
    mul-float/2addr v2, v3

    float-to-double v2, v2

    #v2=(DoubleLo);v3=(DoubleHi);
    const-wide/high16 v4, 0x3fe0

    #v4=(LongLo);v5=(LongHi);
    mul-double/2addr v2, v4

    double-to-int v2, v2

    .line 41
    #v2=(Integer);
    iget v3, v0, Landroid/graphics/Rect;->left:I

    #v3=(Integer);
    add-int/2addr v3, v2

    iget v4, v0, Landroid/graphics/Rect;->top:I

    #v4=(Integer);
    add-int/2addr v4, v1

    iget v5, v0, Landroid/graphics/Rect;->right:I

    #v5=(Integer);
    add-int/2addr v2, v5

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    #v0=(Integer);
    add-int/2addr v0, v1

    invoke-virtual {p0, v3, v4, v2, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 43
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 3
    .parameter

    .prologue
    .line 20
    iput-object p1, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    .line 21
    iget-object v0, p0, Lcom/tencent/mapapi/map/u;->EG:Lcom/tencent/mapapi/map/as;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    #v1=(Reference);
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v1

    #v1=(Integer);
    iget-object v2, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    #v2=(Reference);
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mapapi/map/as;->j(II)V

    .line 22
    iget-object v0, p0, Lcom/tencent/mapapi/map/u;->EG:Lcom/tencent/mapapi/map/as;

    invoke-virtual {v0, p0}, Lcom/tencent/mapapi/map/as;->a(Lcom/tencent/mapapi/map/at;)V

    .line 23
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    .line 24
    new-instance v0, Landroid/graphics/drawable/BitmapDrawable;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/mapapi/map/u;->EG:Lcom/tencent/mapapi/map/as;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/as;->ih()Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/graphics/Bitmap;)V

    #v0=(Reference);
    return-object v0
.end method

.method public final a(Landroid/graphics/Canvas;)V
    .locals 3
    .parameter

    .prologue
    .line 29
    iget-object v0, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    const/high16 v1, 0x7f00

    #v1=(Integer);
    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    .line 31
    const v0, -0x409c28f6

    #v0=(Integer);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->skew(FF)V

    .line 32
    const/high16 v0, 0x3f80

    const/high16 v1, 0x3f00

    #v1=(Integer);
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->scale(FF)V

    .line 33
    iget-object v0, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 34
    iget-object v0, p0, Lcom/tencent/mapapi/map/u;->DP:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->clearColorFilter()V

    .line 35
    return-void
.end method

*/}
