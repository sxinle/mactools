package com.tencent.mapapi.map; class bm {/*

.class public final Lcom/tencent/mapapi/map/bm;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mapapi/map/k;


# instance fields
.field CL:Z

.field public DD:Z

.field Da:Z

.field private EC:I

.field private Ge:Lcom/tencent/mapapi/map/MapView;

.field private Gf:Ljava/util/ArrayList;

.field private Gg:D

.field private final Gh:F

.field private final Gi:F

.field private Gj:F

.field private Gk:F

.field Gl:Lcom/tencent/mapapi/map/GeoPoint;

.field Gm:Lcom/tencent/mapapi/map/GeoPoint;

.field final synthetic Gn:Lcom/tencent/mapapi/map/bh;

.field c:Z

.field private k:I


# direct methods
.method public constructor <init>(Lcom/tencent/mapapi/map/bh;Lcom/tencent/mapapi/map/MapView;)V
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v4, 0x0

    #v4=(Null);
    const/4 v3, 0x0

    #v3=(Null);
    const/4 v2, 0x0

    .line 1141
    #v2=(Null);
    iput-object p1, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1121
    #p0=(Reference);
    iput v2, p0, Lcom/tencent/mapapi/map/bm;->EC:I

    .line 1122
    iput v2, p0, Lcom/tencent/mapapi/map/bm;->k:I

    .line 1124
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bm;->CL:Z

    .line 1125
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bm;->Da:Z

    .line 1127
    const-wide/high16 v0, 0x3ff0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/bm;->Gg:D

    .line 1128
    const v0, 0x3f19999a

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mapapi/map/bm;->Gh:F

    .line 1129
    const v0, 0x3f99999a

    iput v0, p0, Lcom/tencent/mapapi/map/bm;->Gi:F

    .line 1131
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bm;->c:Z

    .line 1132
    iput v3, p0, Lcom/tencent/mapapi/map/bm;->Gj:F

    .line 1133
    iput v3, p0, Lcom/tencent/mapapi/map/bm;->Gk:F

    .line 1135
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bm;->DD:Z

    .line 1138
    iput-object v4, p0, Lcom/tencent/mapapi/map/bm;->Gl:Lcom/tencent/mapapi/map/GeoPoint;

    .line 1139
    iput-object v4, p0, Lcom/tencent/mapapi/map/bm;->Gm:Lcom/tencent/mapapi/map/GeoPoint;

    .line 1142
    iput-object p2, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    .line 1143
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gf:Ljava/util/ArrayList;

    .line 1144
    return-void
.end method

.method static synthetic a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;
    .locals 1
    .parameter

    .prologue
    .line 1117
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    return-object v0
.end method

.method private a(Landroid/graphics/PointF;)V
    .locals 2
    .parameter

    .prologue
    .line 1268
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    iget v1, p1, Landroid/graphics/PointF;->x:F

    #v1=(Integer);
    iput v1, v0, Landroid/graphics/PointF;->x:F

    .line 1269
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    iget v1, p1, Landroid/graphics/PointF;->y:F

    iput v1, v0, Landroid/graphics/PointF;->y:F

    .line 1271
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bo;->ia()V

    .line 1272
    return-void
.end method

.method private a(Landroid/view/View;IIIII)V
    .locals 3
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v2, -0x1

    #v2=(Byte);
    const/4 v1, -0x2

    .line 1403
    #v1=(Byte);
    invoke-virtual {p1, p2, p3}, Landroid/view/View;->measure(II)V

    .line 1404
    if-ne p2, v1, :cond_4

    .line 1405
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredWidth()I

    move-result p2

    .line 1410
    :cond_0
    :goto_0
    #v0=(Conflicted);
    if-ne p3, v1, :cond_5

    .line 1411
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result p3

    .line 1415
    :cond_1
    :goto_1
    and-int/lit8 v0, p6, 0x7

    .line 1418
    #v0=(Integer);
    and-int/lit8 v1, p6, 0x70

    .line 1420
    #v1=(Integer);
    const/4 v2, 0x5

    #v2=(PosByte);
    if-ne v0, v2, :cond_6

    .line 1421
    sub-int/2addr p4, p2

    .line 1426
    :cond_2
    :goto_2
    const/16 v0, 0x50

    #v0=(PosByte);
    if-ne v1, v0, :cond_7

    .line 1427
    sub-int/2addr p5, p3

    .line 1432
    :cond_3
    :goto_3
    #v0=(Integer);
    add-int v0, p4, p2

    add-int v1, p5, p3

    invoke-virtual {p1, p4, p5, v0, v1}, Landroid/view/View;->layout(IIII)V

    .line 1433
    return-void

    .line 1406
    :cond_4
    #v0=(Uninit);v1=(Byte);v2=(Byte);
    if-ne p2, v2, :cond_0

    .line 1407
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->getMeasuredWidth()I

    move-result p2

    goto :goto_0

    .line 1412
    :cond_5
    #v0=(Conflicted);
    if-ne p3, v2, :cond_1

    .line 1413
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->getMeasuredHeight()I

    move-result p3

    goto :goto_1

    .line 1422
    :cond_6
    #v0=(Integer);v1=(Integer);v2=(PosByte);
    const/4 v2, 0x1

    #v2=(One);
    if-ne v0, v2, :cond_2

    .line 1423
    div-int/lit8 v0, p2, 0x2

    sub-int/2addr p4, v0

    goto :goto_2

    .line 1428
    :cond_7
    #v0=(PosByte);v2=(PosByte);
    const/16 v0, 0x10

    if-ne v1, v0, :cond_3

    .line 1429
    div-int/lit8 v0, p3, 0x2

    #v0=(Integer);
    sub-int/2addr p5, v0

    goto :goto_3
.end method


# virtual methods
.method public final a(D)V
    .locals 10
    .parameter

    .prologue
    .line 1191
    iget-wide v0, p0, Lcom/tencent/mapapi/map/bm;->Gg:D

    #v0=(DoubleLo);v1=(DoubleHi);
    mul-double v1, p1, v0

    .line 1192
    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v0

    .line 1193
    #v0=(Integer);
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/bm;->ir()I

    move-result v3

    .line 1194
    #v3=(Integer);
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/bm;->is()I

    move-result v4

    .line 1196
    #v4=(Integer);
    const-wide v5, 0x3ff3333340000000L

    #v5=(LongLo);v6=(LongHi);
    cmpl-double v5, v1, v5

    #v5=(Byte);
    if-lez v5, :cond_0

    .line 1197
    :goto_0
    #v5=(Conflicted);
    const-wide v5, 0x3ff3333340000000L

    #v5=(LongLo);
    cmpl-double v5, v1, v5

    #v5=(Byte);
    if-lez v5, :cond_1

    if-ge v0, v3, :cond_1

    .line 1198
    const-wide/high16 v5, 0x4000

    #v5=(LongLo);
    div-double/2addr v1, v5

    .line 1199
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 1201
    :cond_0
    #v5=(Byte);
    const-wide v5, 0x3fe3333340000000L

    #v5=(LongLo);
    cmpg-double v5, v1, v5

    #v5=(Byte);
    if-gez v5, :cond_1

    .line 1202
    :goto_1
    #v5=(Conflicted);
    const-wide v5, 0x3fe3333340000000L

    #v5=(LongLo);
    cmpg-double v5, v1, v5

    #v5=(Byte);
    if-gez v5, :cond_1

    if-le v0, v4, :cond_1

    .line 1203
    const-wide/high16 v5, 0x4000

    #v5=(LongLo);
    mul-double/2addr v1, v5

    .line 1204
    add-int/lit8 v0, v0, -0x1

    goto :goto_1

    :cond_1
    #v5=(Byte);
    move v7, v0

    #v7=(Integer);
    move-wide v8, v1

    #v8=(DoubleLo);v9=(DoubleHi);
    move-wide v0, v8

    #v0=(DoubleLo);v1=(DoubleHi);
    move v2, v7

    .line 1207
    #v2=(Integer);
    if-ne v2, v3, :cond_2

    const-wide/high16 v5, 0x3ff0

    #v5=(LongLo);
    cmpl-double v3, v0, v5

    #v3=(Byte);
    if-lez v3, :cond_2

    .line 1208
    const-wide/high16 v0, 0x3ff0

    .line 1210
    :cond_2
    #v0=(LongLo);v1=(LongHi);v3=(Integer);v5=(Conflicted);
    if-ne v2, v4, :cond_3

    const-wide/high16 v3, 0x3ff0

    #v3=(LongLo);v4=(LongHi);
    cmpg-double v3, v0, v3

    #v3=(Byte);
    if-gez v3, :cond_3

    .line 1211
    const-wide/high16 v0, 0x3ff0

    .line 1213
    :cond_3
    #v3=(Integer);v4=(Conflicted);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/bm;->Gg:D

    .line 1214
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v0

    .line 1215
    #v0=(Integer);
    if-eq v2, v0, :cond_4

    .line 1217
    invoke-virtual {p0, v2}, Lcom/tencent/mapapi/map/bm;->aj(I)V

    .line 1225
    :goto_2
    #v0=(Conflicted);
    return-void

    .line 1222
    :cond_4
    #v0=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->invalidate()V

    .line 1223
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FQ:Lcom/tencent/mapapi/map/k;

    invoke-interface {v0}, Lcom/tencent/mapapi/map/k;->hT()V

    goto :goto_2
.end method

.method final a(Lcom/tencent/mapapi/map/GeoPoint;Lcom/tencent/mapapi/map/GeoPoint;)V
    .locals 10
    .parameter
    .parameter

    .prologue
    const/4 v4, 0x0

    #v4=(Null);
    const-wide/high16 v8, 0x4000

    .line 1437
    #v8=(LongLo);v9=(LongHi);
    if-eqz p1, :cond_0

    if-nez p2, :cond_1

    .line 1501
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-void

    .line 1442
    :cond_1
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Null);v5=(Uninit);v6=(Uninit);v7=(Uninit);
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->k:I

    #v0=(Integer);
    if-eqz v0, :cond_2

    iget v0, p0, Lcom/tencent/mapapi/map/bm;->k:I

    if-nez v0, :cond_3

    .line 1444
    :cond_2
    iput-object p1, p0, Lcom/tencent/mapapi/map/bm;->Gl:Lcom/tencent/mapapi/map/GeoPoint;

    .line 1445
    iput-object p2, p0, Lcom/tencent/mapapi/map/bm;->Gm:Lcom/tencent/mapapi/map/GeoPoint;

    goto :goto_0

    .line 1449
    :cond_3
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->ir()I

    move-result v0

    .line 1450
    #v0=(Integer);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v1, p1, v0}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v1

    .line 1451
    iget-object v2, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v2, p2, v0}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v2

    .line 1453
    iget v0, v2, Landroid/graphics/PointF;->x:F

    iget v3, v1, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    sub-float/2addr v0, v3

    .line 1454
    #v0=(Float);
    cmpg-float v3, v0, v4

    #v3=(Byte);
    if-gez v3, :cond_4

    .line 1456
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    .line 1458
    :cond_4
    iget v2, v2, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    iget v1, v1, Landroid/graphics/PointF;->y:F

    #v1=(Integer);
    sub-float v1, v2, v1

    .line 1459
    #v1=(Float);
    cmpg-float v2, v1, v4

    #v2=(Byte);
    if-gez v2, :cond_5

    .line 1461
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    .line 1464
    :cond_5
    iget-wide v2, p0, Lcom/tencent/mapapi/map/bm;->Gg:D

    #v2=(DoubleLo);v3=(DoubleHi);
    double-to-float v2, v2

    .line 1465
    #v2=(Float);
    mul-float/2addr v0, v2

    .line 1466
    mul-float/2addr v1, v2

    .line 1468
    iget v2, p0, Lcom/tencent/mapapi/map/bm;->EC:I

    .line 1469
    #v2=(Integer);
    iget v3, p0, Lcom/tencent/mapapi/map/bm;->k:I

    .line 1470
    #v3=(Integer);
    int-to-float v2, v2

    #v2=(Float);
    div-float/2addr v0, v2

    float-to-double v4, v0

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-static {v4, v5}, Ljava/lang/Math;->log(D)D

    move-result-wide v4

    invoke-static {v8, v9}, Ljava/lang/Math;->log(D)D

    move-result-wide v6

    #v6=(DoubleLo);v7=(DoubleHi);
    div-double/2addr v4, v6

    .line 1471
    int-to-float v0, v3

    div-float v0, v1, v0

    float-to-double v0, v0

    #v0=(DoubleLo);v1=(DoubleHi);
    invoke-static {v0, v1}, Ljava/lang/Math;->log(D)D

    move-result-wide v0

    invoke-static {v8, v9}, Ljava/lang/Math;->log(D)D

    move-result-wide v2

    #v2=(DoubleLo);v3=(DoubleHi);
    div-double/2addr v0, v2

    .line 1473
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->max(DD)D

    move-result-wide v0

    .line 1474
    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v0

    double-to-int v0, v0

    .line 1475
    #v0=(Integer);
    if-eqz v0, :cond_0

    .line 1479
    new-instance v1, Lcom/tencent/mapapi/map/GeoPoint;

    #v1=(UninitRef);
    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLatitudeE6()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {p2}, Lcom/tencent/mapapi/map/GeoPoint;->getLatitudeE6()I

    move-result v3

    #v3=(Integer);
    add-int/2addr v2, v3

    div-int/lit8 v2, v2, 0x2

    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLongitudeE6()I

    move-result v3

    invoke-virtual {p2}, Lcom/tencent/mapapi/map/GeoPoint;->getLongitudeE6()I

    move-result v4

    #v4=(Integer);
    add-int/2addr v3, v4

    div-int/lit8 v3, v3, 0x2

    invoke-direct {v1, v2, v3}, Lcom/tencent/mapapi/map/GeoPoint;-><init>(II)V

    .line 1482
    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mapapi/map/MapView;->hM()Lcom/tencent/mapapi/map/f;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/tencent/mapapi/map/f;->b(Lcom/tencent/mapapi/map/GeoPoint;)V

    .line 1484
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/bm;->ir()I

    move-result v1

    #v1=(Integer);
    sub-int v0, v1, v0

    .line 1485
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v1

    .line 1486
    if-eq v1, v0, :cond_0

    .line 1491
    if-le v0, v1, :cond_6

    .line 1493
    sub-int/2addr v0, v1

    .line 1494
    iget-object v1, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/MapView;->Eg:Lcom/tencent/mapapi/map/ah;

    invoke-virtual {v1, v0}, Lcom/tencent/mapapi/map/ah;->as(I)Z

    goto/16 :goto_0

    .line 1498
    :cond_6
    #v1=(Integer);
    sub-int v0, v1, v0

    .line 1499
    iget-object v1, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/MapView;->Eg:Lcom/tencent/mapapi/map/ah;

    invoke-virtual {v1, v0}, Lcom/tencent/mapapi/map/ah;->at(I)Z

    goto/16 :goto_0
.end method

.method public final a(Lcom/tencent/mapapi/map/bp;)V
    .locals 1
    .parameter

    .prologue
    .line 1343
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gf:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1344
    return-void
.end method

.method public final aj(I)V
    .locals 4
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v2, 0x0

    .line 1228
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v0, v0, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v0=(Integer);
    if-eq p1, v0, :cond_2

    .line 1229
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v0, v0, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v0=(Integer);
    if-le p1, v0, :cond_0

    .line 1231
    invoke-virtual {p0, v2}, Lcom/tencent/mapapi/map/bm;->d(Z)V

    .line 1233
    :cond_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bo;->in()V

    .line 1234
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iput p1, v0, Lcom/tencent/mapapi/map/bo;->Dc:I

    .line 1235
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bo;->hB()V

    .line 1236
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->hR()V

    .line 1237
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    invoke-virtual {v0, v1, v1}, Lcom/tencent/mapapi/map/MapView;->b(ZZ)V

    .line 1239
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    move v1, v2

    :goto_0
    #v0=(Conflicted);v1=(Integer);
    if-ge v1, v3, :cond_2

    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/ba;->ie()V

    :cond_1
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 1241
    :cond_2
    #v0=(Conflicted);v3=(Conflicted);
    invoke-virtual {p0, v2}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    .line 1242
    return-void
.end method

.method public final b(Lcom/tencent/mapapi/map/bp;)V
    .locals 1
    .parameter

    .prologue
    .line 1347
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gf:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 1348
    return-void
.end method

.method final d(Z)V
    .locals 1
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 1148
    #v0=(Null);
    iput-boolean p1, p0, Lcom/tencent/mapapi/map/bm;->c:Z

    .line 1149
    if-nez p1, :cond_0

    .line 1151
    iput v0, p0, Lcom/tencent/mapapi/map/bm;->Gj:F

    .line 1152
    iput v0, p0, Lcom/tencent/mapapi/map/bm;->Gk:F

    .line 1154
    :cond_0
    return-void
.end method

.method public final e(Z)V
    .locals 2
    .parameter

    .prologue
    .line 1352
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gf:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    #v1=(Reference);
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/bp;

    .line 1353
    invoke-interface {v0, p1}, Lcom/tencent/mapapi/map/bp;->e(Z)V

    goto :goto_0

    .line 1356
    :cond_0
    #v0=(Boolean);
    return-void
.end method

.method public final f(Lcom/tencent/mapapi/map/GeoPoint;)V
    .locals 2
    .parameter

    .prologue
    .line 1275
    if-nez p1, :cond_0

    .line 1282
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 1278
    :cond_0
    #v0=(Uninit);v1=(Uninit);
    const/4 v0, 0x1

    #v0=(One);
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/bm;->d(Z)V

    .line 1279
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v1, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v1, v1, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v1=(Integer);
    invoke-virtual {v0, p1, v1}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v0

    .line 1280
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/bm;->a(Landroid/graphics/PointF;)V

    .line 1281
    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    goto :goto_0
.end method

.method public final g(Lcom/tencent/mapapi/map/GeoPoint;)V
    .locals 2
    .parameter

    .prologue
    .line 1285
    if-nez p1, :cond_0

    .line 1292
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 1289
    :cond_0
    #v0=(Uninit);v1=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v1, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v1, v1, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v1=(Integer);
    invoke-virtual {v0, p1, v1}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v0

    .line 1290
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/bm;->a(Landroid/graphics/PointF;)V

    .line 1291
    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    goto :goto_0
.end method

.method public final h(Lcom/tencent/mapapi/map/GeoPoint;)V
    .locals 2
    .parameter

    .prologue
    .line 1295
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iv()Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v0

    .line 1296
    if-eqz p1, :cond_0

    invoke-virtual {p1, v0}, Lcom/tencent/mapapi/map/GeoPoint;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 1297
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v1, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v1, v1, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v1=(Integer);
    invoke-virtual {v0, p1, v1}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v0

    .line 1298
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/bm;->a(Landroid/graphics/PointF;)V

    .line 1299
    const/4 v0, 0x1

    #v0=(One);
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    .line 1301
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void
.end method

.method public final hT()V
    .locals 9

    .prologue
    .line 1512
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->getChildCount()I

    move-result v8

    #v8=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v7, v0

    :goto_0
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Integer);
    if-ge v7, v8, :cond_2

    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    invoke-virtual {v0, v7}, Lcom/tencent/mapapi/map/MapView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    #v1=(Reference);
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;

    iget v2, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->mode:I

    #v2=(Integer);
    if-nez v2, :cond_1

    iget-object v2, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->Eq:Lcom/tencent/mapapi/map/GeoPoint;

    #v2=(Reference);
    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FL:Lcom/tencent/mapapi/map/bn;

    iget-object v3, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->Eq:Lcom/tencent/mapapi/map/GeoPoint;

    #v3=(Reference);
    const/4 v4, 0x0

    #v4=(Null);
    invoke-virtual {v2, v3, v4}, Lcom/tencent/mapapi/map/bn;->a(Lcom/tencent/mapapi/map/GeoPoint;Landroid/graphics/Point;)Landroid/graphics/Point;

    move-result-object v5

    #v5=(Reference);
    iget v2, v5, Landroid/graphics/Point;->x:I

    #v2=(Integer);
    iget v3, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->x:I

    #v3=(Integer);
    add-int/2addr v2, v3

    iput v2, v5, Landroid/graphics/Point;->x:I

    iget v2, v5, Landroid/graphics/Point;->y:I

    iget v3, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->y:I

    add-int/2addr v2, v3

    iput v2, v5, Landroid/graphics/Point;->y:I

    iget v2, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->width:I

    iget v3, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->height:I

    iget v4, v5, Landroid/graphics/Point;->x:I

    #v4=(Integer);
    iget v5, v5, Landroid/graphics/Point;->y:I

    #v5=(Integer);
    iget v6, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->alignment:I

    #v6=(Integer);
    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lcom/tencent/mapapi/map/bm;->a(Landroid/view/View;IIIII)V

    :cond_0
    :goto_1
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    add-int/lit8 v0, v7, 0x1

    #v0=(Integer);
    move v7, v0

    goto :goto_0

    :cond_1
    #v0=(Reference);v2=(Integer);
    iget v2, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->width:I

    iget v3, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->height:I

    #v3=(Integer);
    iget v4, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->x:I

    #v4=(Integer);
    iget v5, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->y:I

    #v5=(Integer);
    iget v6, v0, Lcom/tencent/mapapi/map/MapView$LayoutParams;->alignment:I

    #v6=(Integer);
    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lcom/tencent/mapapi/map/bm;->a(Landroid/view/View;IIIII)V

    goto :goto_1

    :cond_2
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->hC()V

    .line 1513
    :cond_3
    #v7=(Conflicted);v8=(Conflicted);
    return-void
.end method

.method final hw()V
    .locals 2

    .prologue
    .line 1181
    const-wide/high16 v0, 0x3ff0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/bm;->Gg:D

    .line 1182
    return-void
.end method

.method public final id()I
    .locals 1

    .prologue
    .line 1330
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->k:I

    #v0=(Integer);
    return v0
.end method

.method public final iq()F
    .locals 2

    .prologue
    .line 1186
    iget-wide v0, p0, Lcom/tencent/mapapi/map/bm;->Gg:D

    #v0=(DoubleLo);v1=(DoubleHi);
    double-to-float v0, v0

    #v0=(Float);
    return v0
.end method

.method public final ir()I
    .locals 1

    .prologue
    .line 1304
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v0, v0, Lcom/tencent/mapapi/map/bo;->CS:I

    #v0=(Integer);
    return v0
.end method

.method public final is()I
    .locals 1

    .prologue
    .line 1315
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v0, v0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v0=(Integer);
    return v0
.end method

.method public final it()I
    .locals 1

    .prologue
    .line 1326
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->EC:I

    #v0=(Integer);
    return v0
.end method

.method public final iu()I
    .locals 1

    .prologue
    .line 1334
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v0, v0, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v0=(Integer);
    return v0
.end method

.method public final iv()Lcom/tencent/mapapi/map/GeoPoint;
    .locals 3

    .prologue
    .line 1338
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v1, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v1, v1, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    iget-object v2, p0, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v2, v2, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mapapi/map/bo;->b(Landroid/graphics/PointF;I)Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v0

    .line 1339
    return-object v0
.end method

.method public final iw()Lcom/tencent/mapapi/map/MapView;
    .locals 1

    .prologue
    .line 1359
    iget-object v0, p0, Lcom/tencent/mapapi/map/bm;->Ge:Lcom/tencent/mapapi/map/MapView;

    #v0=(Reference);
    return-object v0
.end method

.method public final j(II)V
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 1259
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->EC:I

    #v0=(Integer);
    if-ne p1, v0, :cond_0

    iget v0, p0, Lcom/tencent/mapapi/map/bm;->k:I

    if-eq p2, v0, :cond_1

    .line 1260
    :cond_0
    iput p1, p0, Lcom/tencent/mapapi/map/bm;->EC:I

    .line 1261
    iput p2, p0, Lcom/tencent/mapapi/map/bm;->k:I

    .line 1262
    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    .line 1264
    :cond_1
    #v0=(Integer);
    return-void
.end method

.method final l(FF)V
    .locals 3
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x1

    .line 1158
    #v2=(One);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/bm;->c:Z

    #v0=(Boolean);
    if-ne v0, v2, :cond_1

    .line 1177
    :cond_0
    :goto_0
    #v0=(Integer);v1=(Conflicted);
    return-void

    .line 1162
    :cond_1
    #v0=(Boolean);v1=(Uninit);
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->Gj:F

    #v0=(Integer);
    add-float/2addr v0, p1

    #v0=(Float);
    iput v0, p0, Lcom/tencent/mapapi/map/bm;->Gj:F

    .line 1163
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->Gk:F

    #v0=(Integer);
    add-float/2addr v0, p2

    #v0=(Float);
    iput v0, p0, Lcom/tencent/mapapi/map/bm;->Gk:F

    .line 1165
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->Gj:F

    #v0=(Integer);
    float-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    .line 1166
    iget v1, p0, Lcom/tencent/mapapi/map/bm;->EC:I

    #v1=(Integer);
    if-lt v0, v1, :cond_2

    .line 1168
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bm;->c:Z

    goto :goto_0

    .line 1171
    :cond_2
    iget v0, p0, Lcom/tencent/mapapi/map/bm;->Gk:F

    float-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    .line 1172
    iget v1, p0, Lcom/tencent/mapapi/map/bm;->k:I

    if-lt v0, v1, :cond_0

    .line 1174
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bm;->c:Z

    goto :goto_0
.end method

*/}
