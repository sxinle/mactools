package com.tencent.mapapi.map; class f {/*

.class public final Lcom/tencent/mapapi/map/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private Eb:Lcom/tencent/mapapi/map/bh;


# direct methods
.method constructor <init>(Lcom/tencent/mapapi/map/bh;)V
    .locals 0
    .parameter

    .prologue
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    #p0=(Reference);
    iput-object p1, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    .line 15
    return-void
.end method


# virtual methods
.method public final a(Lcom/tencent/mapapi/map/GeoPoint;)V
    .locals 1
    .parameter

    .prologue
    .line 22
    if-nez p1, :cond_1

    .line 30
    :cond_0
    :goto_0
    #v0=(Conflicted);
    return-void

    .line 25
    :cond_1
    #v0=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    if-eqz v0, :cond_0

    .line 29
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/bm;->f(Lcom/tencent/mapapi/map/GeoPoint;)V

    goto :goto_0
.end method

.method public final b(Lcom/tencent/mapapi/map/GeoPoint;)V
    .locals 1
    .parameter

    .prologue
    .line 86
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iw()Lcom/tencent/mapapi/map/MapView;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/MapView;->Eg:Lcom/tencent/mapapi/map/ah;

    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/ah;->e(Lcom/tencent/mapapi/map/GeoPoint;)V

    .line 87
    return-void
.end method

.method public final k(FF)V
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 120
    #v1=(Null);
    cmpl-float v0, p1, v1

    #v0=(Byte);
    if-nez v0, :cond_0

    cmpl-float v0, p2, v1

    if-nez v0, :cond_0

    .line 126
    :goto_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 123
    :cond_0
    #v0=(Byte);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0, p1, p2}, Lcom/tencent/mapapi/map/bm;->l(FF)V

    .line 124
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    neg-float v1, p1

    #v1=(Float);
    neg-float v2, p2

    #v2=(Float);
    iget-object v3, v0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v4, v3, Landroid/graphics/PointF;->x:F

    #v4=(Integer);
    sub-float v1, v4, v1

    iput v1, v3, Landroid/graphics/PointF;->x:F

    iget-object v1, v0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v3, v1, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    add-float/2addr v2, v3

    iput v2, v1, Landroid/graphics/PointF;->y:F

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bo;->ia()V

    .line 125
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    goto :goto_0
.end method

.method public final setZoom(I)I
    .locals 2
    .parameter

    .prologue
    .line 38
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v1, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/bm;->is()I

    move-result v1

    #v1=(Integer);
    if-ge p1, v1, :cond_0

    iget-object v1, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/bm;->is()I

    move-result p1

    :cond_0
    #v1=(Conflicted);
    iget-object v1, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/bm;->ir()I

    move-result v1

    #v1=(Integer);
    if-le p1, v1, :cond_1

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->ir()I

    move-result p1

    .line 39
    :cond_1
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->hw()V

    .line 40
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/bm;->aj(I)V

    .line 41
    iget-object v0, p0, Lcom/tencent/mapapi/map/f;->Eb:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bm;->d(Z)V

    .line 42
    return p1
.end method

*/}
