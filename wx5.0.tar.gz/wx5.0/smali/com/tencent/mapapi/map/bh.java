package com.tencent.mapapi.map; class bh {/*

.class final Lcom/tencent/mapapi/map/bh;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public FL:Lcom/tencent/mapapi/map/bn;

.field public FM:Lcom/tencent/mapapi/map/bm;

.field public FN:Lcom/tencent/mapapi/map/bi;

.field public FO:Lcom/tencent/mapapi/map/bl;

.field public FP:Lcom/tencent/mapapi/map/bo;

.field public FQ:Lcom/tencent/mapapi/map/k;

.field private g:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/tencent/mapapi/map/MapView;Ljava/lang/String;)V
    .locals 3
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 49
    #v0=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    #p0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    .line 45
    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FQ:Lcom/tencent/mapapi/map/k;

    .line 47
    const/4 v0, 0x0

    iput v0, p0, Lcom/tencent/mapapi/map/bh;->g:I

    .line 50
    invoke-static {p1}, Lcom/tencent/mapapi/map/bq;->j(Landroid/content/Context;)V

    .line 51
    sget-object v0, Lcom/tencent/mapapi/map/bq;->DA:Ljava/lang/String;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 53
    invoke-static {p1}, Lcom/tencent/mapapi/map/bq;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/tencent/mapapi/map/bq;->DA:Ljava/lang/String;

    .line 55
    :cond_0
    sget-object v0, Lcom/tencent/mapapi/map/bq;->d:Ljava/lang/String;

    if-nez v0, :cond_1

    .line 57
    invoke-static {p1}, Lcom/tencent/mapapi/map/bq;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/tencent/mapapi/map/bq;->d:Ljava/lang/String;

    .line 59
    :cond_1
    sget-object v0, Lcom/tencent/mapapi/map/bq;->DB:Ljava/lang/String;

    if-nez v0, :cond_2

    .line 61
    invoke-static {p1}, Lcom/tencent/mapapi/map/bu;->k(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/tencent/mapapi/map/bq;->DB:Ljava/lang/String;

    .line 63
    :cond_2
    new-instance v0, Lcom/tencent/mapapi/map/bm;

    #v0=(UninitRef);
    invoke-direct {v0, p0, p2}, Lcom/tencent/mapapi/map/bm;-><init>(Lcom/tencent/mapapi/map/bh;Lcom/tencent/mapapi/map/MapView;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    .line 64
    iget-object v0, p0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FQ:Lcom/tencent/mapapi/map/k;

    .line 65
    new-instance v0, Lcom/tencent/mapapi/map/bo;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/tencent/mapapi/map/bo;-><init>(Lcom/tencent/mapapi/map/bm;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    .line 66
    iget-object v0, p0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bo;->hw()V

    .line 68
    new-instance v0, Lcom/tencent/mapapi/map/bl;

    #v0=(UninitRef);
    invoke-direct {v0, p0, p1, p3}, Lcom/tencent/mapapi/map/bl;-><init>(Lcom/tencent/mapapi/map/bh;Landroid/content/Context;Ljava/lang/String;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    .line 69
    new-instance v0, Lcom/tencent/mapapi/map/bi;

    #v0=(UninitRef);
    invoke-direct {v0, p0, p1}, Lcom/tencent/mapapi/map/bi;-><init>(Lcom/tencent/mapapi/map/bh;Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    .line 70
    new-instance v0, Lcom/tencent/mapapi/map/bn;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mapapi/map/bn;-><init>(Lcom/tencent/mapapi/map/bh;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bh;->FL:Lcom/tencent/mapapi/map/bn;

    .line 71
    const-string v0, "logo"

    invoke-static {v0}, Lcom/tencent/mapapi/map/bq;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    invoke-virtual {v1}, Lcom/tencent/mapapi/map/bl;->ip()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/tencent/mapapi/map/bq;->b(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    new-instance v1, Lcom/tencent/mapapi/map/bd;

    #v1=(UninitRef);
    invoke-direct {v1, p0, v0}, Lcom/tencent/mapapi/map/bd;-><init>(Lcom/tencent/mapapi/map/bh;Landroid/graphics/Bitmap;)V

    #v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bi;->a(Lcom/tencent/mapapi/map/az;)V

    .line 73
    const-string v0, "marker_small.png"

    .line 75
    sget v1, Lcom/tencent/mapapi/map/bq;->a:I

    #v1=(Integer);
    const/4 v2, 0x3

    #v2=(PosByte);
    if-ne v1, v2, :cond_4

    .line 77
    const-string v0, "marker_big.png"

    .line 83
    :cond_3
    :goto_0
    invoke-static {p1, v0}, Lcom/tencent/mapapi/map/bq;->b(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    sput-object v0, Lcom/tencent/mapapi/map/bq;->Fu:Landroid/graphics/Bitmap;

    .line 84
    return-void

    .line 79
    :cond_4
    sget v1, Lcom/tencent/mapapi/map/bq;->a:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_3

    .line 81
    const-string v0, "marker_big.png"

    goto :goto_0
.end method

.method static synthetic b(Lcom/tencent/mapapi/map/bh;)I
    .locals 2
    .parameter

    .prologue
    .line 32
    iget v0, p0, Lcom/tencent/mapapi/map/bh;->g:I

    #v0=(Integer);
    add-int/lit8 v1, v0, 0x1

    #v1=(Integer);
    iput v1, p0, Lcom/tencent/mapapi/map/bh;->g:I

    return v0
.end method

.method static synthetic c(Lcom/tencent/mapapi/map/bh;)I
    .locals 1
    .parameter

    .prologue
    .line 32
    iget v0, p0, Lcom/tencent/mapapi/map/bh;->g:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic d(Lcom/tencent/mapapi/map/bh;)I
    .locals 1
    .parameter

    .prologue
    .line 32
    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/tencent/mapapi/map/bh;->g:I

    return v0
.end method

*/}
