package com.tencent.mapapi.map; class ad {/*

.class Lcom/tencent/mapapi/map/ad;
.super Lcom/tencent/mapapi/map/ba;
.source "SourceFile"


# instance fields
.field protected ET:Lcom/tencent/mapapi/map/an;

.field protected EU:Lcom/tencent/mapapi/map/bc;

.field protected EV:Ljava/util/List;

.field protected EW:Ljava/util/List;

.field protected EX:Ljava/util/List;

.field protected EY:Ljava/util/List;

.field EZ:[B


# direct methods
.method constructor <init>()V
    .locals 1

    .prologue
    const/4 v0, 0x0

    .line 20
    #v0=(Null);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ba;-><init>()V

    .line 25
    #p0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    .line 30
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EU:Lcom/tencent/mapapi/map/bc;

    .line 35
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    .line 39
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    .line 42
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    .line 44
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    .line 48
    const/4 v0, 0x0

    new-array v0, v0, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EZ:[B

    return-void
.end method

.method protected static a(Ljava/util/List;Lcom/tencent/mapapi/map/aa;)Z
    .locals 4
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 286
    #v1=(Null);
    if-eqz p0, :cond_0

    if-nez p1, :cond_1

    .line 310
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v1

    .line 290
    :cond_1
    #v0=(Uninit);v1=(Null);v2=(Uninit);v3=(Uninit);
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    .line 291
    #v3=(Integer);
    if-lez v3, :cond_0

    move v2, v1

    .line 297
    :goto_1
    #v0=(Conflicted);v2=(Integer);
    if-ge v2, v3, :cond_3

    .line 299
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 300
    if-eqz v0, :cond_2

    .line 302
    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/aa;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_2

    .line 306
    const/4 v0, 0x1

    :goto_2
    move v1, v0

    .line 310
    #v1=(Boolean);
    goto :goto_0

    .line 297
    :cond_2
    #v0=(Conflicted);v1=(Null);
    add-int/lit8 v0, v2, 0x1

    #v0=(Integer);
    move v2, v0

    goto :goto_1

    :cond_3
    #v0=(Conflicted);
    move v0, v1

    #v0=(Null);
    goto :goto_2
.end method

.method protected static b(Ljava/util/List;)V
    .locals 5
    .parameter

    .prologue
    const/4 v2, 0x0

    .line 568
    #v2=(Null);
    if-nez p0, :cond_1

    .line 583
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 572
    :cond_1
    #v0=(Uninit);v1=(Uninit);v3=(Uninit);v4=(Uninit);
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    move v1, v2

    .line 573
    :goto_0
    #v0=(Conflicted);v1=(Integer);v4=(Conflicted);
    if-ge v1, v3, :cond_0

    .line 576
    invoke-interface {p0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/ac;

    .line 577
    if-eqz v0, :cond_2

    .line 579
    const/4 v4, 0x0

    #v4=(Null);
    iput-object v4, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 581
    :cond_2
    #v4=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0
.end method

.method private b(Lcom/tencent/mapapi/map/aa;)Z
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 503
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mapapi/map/ad;->EZ:[B

    #v1=(Reference);
    monitor-enter v1

    .line 505
    :try_start_0
    iget-object v2, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v2=(Reference);
    if-nez v2, :cond_0

    .line 507
    monitor-exit v1

    .line 513
    :goto_0
    #v0=(Boolean);v2=(Conflicted);
    return v0

    .line 509
    :cond_0
    #v0=(Null);v2=(Reference);
    iget-object v2, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    invoke-interface {v2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_1

    .line 511
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 514
    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    .line 513
    :cond_1
    :try_start_1
    #v0=(Null);v2=(Boolean);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0
.end method

.method private ib()Ljava/util/ArrayList;
    .locals 7

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v3, 0x0

    .line 397
    .line 398
    #v3=(Null);
    iget-object v4, p0, Lcom/tencent/mapapi/map/ad;->EZ:[B

    #v4=(Reference);
    monitor-enter v4

    .line 401
    :try_start_0
    iget-object v1, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v1=(Reference);
    if-nez v1, :cond_0

    .line 402
    monitor-exit v4

    .line 456
    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Integer);v5=(Conflicted);v6=(Conflicted);
    return-object v0

    .line 404
    :cond_0
    #v0=(Null);v1=(Reference);v2=(Uninit);v3=(Null);v5=(Uninit);v6=(Uninit);
    iget-object v1, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    .line 405
    #v1=(Integer);
    if-gtz v1, :cond_1

    .line 406
    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 454
    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Integer);v5=(Conflicted);v6=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v4

    throw v0

    .line 409
    :cond_1
    :try_start_1
    #v0=(Null);v1=(Integer);v2=(Uninit);v3=(Null);v5=(Uninit);v6=(Uninit);
    new-instance v2, Ljava/util/ArrayList;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 410
    #v2=(Reference);
    iget v0, p0, Lcom/tencent/mapapi/map/ad;->r:I

    .line 411
    #v0=(Integer);
    if-le v1, v0, :cond_2

    move v1, v0

    .line 412
    :cond_2
    :goto_1
    #v3=(Integer);v5=(Conflicted);v6=(Conflicted);
    if-ge v3, v1, :cond_4

    .line 414
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v0=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    invoke-interface {v0, v5}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 416
    if-eqz v0, :cond_3

    .line 418
    iget-boolean v5, p0, Lcom/tencent/mapapi/map/ad;->FC:Z

    #v5=(Boolean);
    iput-boolean v5, v0, Lcom/tencent/mapapi/map/aa;->DD:Z

    .line 446
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 447
    iget-object v5, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v5=(Reference);
    if-eqz v5, :cond_3

    iget-object v5, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    invoke-interface {v5, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    #v5=(Boolean);
    const/4 v6, 0x1

    #v6=(One);
    if-eq v5, v6, :cond_3

    iget-object v5, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v5=(Reference);
    invoke-interface {v5, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 412
    :cond_3
    #v5=(Conflicted);v6=(Conflicted);
    add-int/lit8 v0, v3, 0x1

    #v0=(Integer);
    move v3, v0

    goto :goto_1

    .line 450
    :cond_4
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 451
    #v0=(Integer);
    if-lez v0, :cond_5

    .line 452
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ad;->ic()V

    .line 454
    :cond_5
    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v0, v2

    .line 456
    #v0=(Reference);
    goto :goto_0
.end method

.method private ic()V
    .locals 2

    .prologue
    .line 482
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bl;->FK:Lcom/tencent/mapapi/map/be;

    if-eqz v0, :cond_0

    .line 485
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bl;->FK:Lcom/tencent/mapapi/map/be;

    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/be;->aj(I)V

    .line 487
    :cond_0
    #v1=(Conflicted);
    return-void
.end method


# virtual methods
.method protected a(Landroid/graphics/Canvas;)V
    .locals 6
    .parameter

    .prologue
    .line 122
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    .line 123
    #v3=(Integer);
    if-gtz v3, :cond_1

    .line 158
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-void

    .line 130
    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Uninit);v4=(Uninit);v5=(Uninit);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_0
    #v0=(Integer);v1=(Integer);v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    if-ge v1, v3, :cond_0

    .line 131
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    .line 132
    if-eqz v0, :cond_3

    .line 133
    iget-object v2, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 136
    #v2=(Reference);
    if-nez v2, :cond_2

    .line 140
    :try_start_0
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/ad;->a(Lcom/tencent/mapapi/map/ac;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_0} :catch_1

    .line 150
    iget-object v2, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 152
    :cond_2
    if-eqz v2, :cond_3

    .line 153
    iget v4, v0, Lcom/tencent/mapapi/map/ac;->EP:F

    #v4=(Integer);
    iget v0, v0, Lcom/tencent/mapapi/map/ac;->EQ:F

    #v0=(Integer);
    const/4 v5, 0x0

    #v5=(Null);
    invoke-virtual {p1, v2, v4, v0, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 154
    :cond_3
    :goto_1
    #v0=(Conflicted);v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 144
    :catch_0
    #v0=(Reference);v2=(Reference);
    move-exception v0

    goto :goto_1

    .line 148
    :catch_1
    move-exception v0

    goto :goto_1
.end method

.method final a(Lcom/tencent/mapapi/map/aa;)V
    .locals 1
    .parameter

    .prologue
    .line 273
    if-nez p1, :cond_1

    .line 282
    :cond_0
    :goto_0
    #v0=(Conflicted);
    return-void

    .line 276
    :cond_1
    #v0=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 279
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 280
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bi;->ia()V

    .line 281
    :cond_2
    invoke-static {}, Ljava/lang/Thread;->yield()V

    goto :goto_0
.end method

.method protected final a(Lcom/tencent/mapapi/map/aa;Ljava/util/ArrayList;)V
    .locals 5
    .parameter
    .parameter

    .prologue
    .line 350
    iget-object v2, p0, Lcom/tencent/mapapi/map/ad;->EZ:[B

    #v2=(Reference);
    monitor-enter v2

    .line 352
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 353
    monitor-exit v2

    .line 388
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 355
    :cond_0
    #v0=(Reference);v1=(Uninit);v3=(Uninit);v4=(Uninit);
    if-eqz p2, :cond_2

    .line 361
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v3

    .line 362
    #v3=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_1
    #v0=(Integer);v1=(Integer);v4=(Conflicted);
    if-ge v1, v3, :cond_2

    .line 364
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 365
    if-eqz v0, :cond_1

    .line 367
    iget-object v4, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v4=(Reference);
    invoke-static {v4, v0}, Lcom/tencent/mapapi/map/ad;->a(Ljava/util/List;Lcom/tencent/mapapi/map/aa;)Z

    move-result v4

    #v4=(Boolean);
    if-nez v4, :cond_1

    .line 371
    iget-object v4, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v4=(Reference);
    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 362
    :cond_1
    #v4=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    .line 375
    :cond_2
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);
    if-eqz p1, :cond_3

    .line 380
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v0=(Reference);
    invoke-static {v0, p1}, Lcom/tencent/mapapi/map/ad;->a(Ljava/util/List;Lcom/tencent/mapapi/map/aa;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_3

    .line 382
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 385
    :cond_3
    #v0=(Conflicted);
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 387
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ad;->ic()V

    goto :goto_0

    .line 385
    :catchall_0
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0
.end method

.method protected final a(Lcom/tencent/mapapi/map/ac;)V
    .locals 5
    .parameter

    .prologue
    .line 171
    if-nez p1, :cond_1

    .line 207
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 174
    :cond_1
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 177
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    .line 181
    #v2=(Integer);
    if-lez v2, :cond_0

    .line 184
    const/4 v1, 0x0

    :goto_0
    #v0=(Conflicted);v1=(Integer);v3=(Conflicted);v4=(Conflicted);
    if-ge v1, v2, :cond_0

    .line 187
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 188
    if-eqz v0, :cond_0

    .line 192
    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/aa;->equals(Ljava/lang/Object;)Z

    move-result v3

    #v3=(Boolean);
    if-eqz v3, :cond_2

    .line 194
    iget-object v3, p0, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    #v3=(Reference);
    invoke-virtual {p1}, Lcom/tencent/mapapi/map/ac;->toString()Ljava/lang/String;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {v3, v4}, Lcom/tencent/mapapi/map/an;->ag(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;

    move-result-object v3

    iget-object v3, v3, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    iput-object v3, p1, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 198
    iget-object v3, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    .line 199
    #v0=(Boolean);
    const/4 v3, 0x1

    #v3=(One);
    if-ne v0, v3, :cond_2

    .line 201
    add-int/lit8 v0, v1, -0x1

    .line 202
    #v0=(Integer);
    add-int/lit8 v1, v2, -0x1

    .line 204
    :goto_1
    #v3=(Boolean);v4=(Conflicted);
    add-int/lit8 v0, v0, 0x1

    move v2, v1

    move v1, v0

    goto :goto_0

    :cond_2
    #v0=(Conflicted);
    move v0, v1

    #v0=(Integer);
    move v1, v2

    goto :goto_1
.end method

.method protected a(Ljava/util/ArrayList;Z)V
    .locals 10
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 526
    #v1=(Null);
    if-nez p1, :cond_1

    .line 562
    :cond_0
    :goto_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    return-void

    .line 529
    :cond_1
    #v0=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/ad;->b(Ljava/util/List;)V

    .line 531
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 532
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v0

    .line 533
    #v0=(Integer);
    iget v2, p0, Lcom/tencent/mapapi/map/ad;->EB:I

    #v2=(Integer);
    if-gt v0, v2, :cond_0

    iget v2, p0, Lcom/tencent/mapapi/map/ad;->EC:I

    if-lt v0, v2, :cond_0

    .line 537
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-nez v2, :cond_2

    .line 538
    iget-object v2, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget-object v3, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v3

    #v3=(Integer);
    iget-object v4, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v4

    #v4=(Integer);
    iget-object v5, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    #v5=(Reference);
    iget-object v5, v5, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v5}, Lcom/tencent/mapapi/map/bm;->iq()F

    move-result v5

    #v5=(Float);
    invoke-virtual {v2, v0, v3, v4, v5}, Lcom/tencent/mapapi/map/bo;->a(IIIF)Ljava/util/ArrayList;

    move-result-object p1

    .line 544
    :cond_2
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v0

    #v0=(Integer);
    if-nez p1, :cond_4

    move-object v0, v1

    .line 548
    :goto_1
    #v0=(Reference);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    if-eqz v0, :cond_3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    #v2=(Integer);
    if-lez v2, :cond_3

    .line 550
    iget-boolean v2, p0, Lcom/tencent/mapapi/map/ad;->Fy:Z

    #v2=(Boolean);
    const/4 v3, 0x1

    #v3=(One);
    if-ne v2, v3, :cond_c

    .line 552
    invoke-virtual {p0, v1}, Lcom/tencent/mapapi/map/ad;->c(Ljava/util/List;)V

    .line 560
    :cond_3
    :goto_2
    #v2=(Conflicted);v3=(Conflicted);
    if-eqz v0, :cond_0

    .line 561
    invoke-interface {v0}, Ljava/util/List;->clear()V

    goto :goto_0

    .line 544
    :cond_4
    #v0=(Integer);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    iget-boolean v2, p0, Lcom/tencent/mapapi/map/ad;->Em:Z

    #v2=(Boolean);
    if-nez v2, :cond_5

    move-object v0, v1

    #v0=(Null);
    goto :goto_1

    :cond_5
    #v0=(Integer);
    iget v2, p0, Lcom/tencent/mapapi/map/ad;->EB:I

    #v2=(Integer);
    if-gt v0, v2, :cond_6

    iget v2, p0, Lcom/tencent/mapapi/map/ad;->EC:I

    if-ge v0, v2, :cond_7

    :cond_6
    move-object v0, v1

    #v0=(Null);
    goto :goto_1

    :cond_7
    #v0=(Integer);
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v4

    #v4=(Integer);
    if-gtz v4, :cond_8

    move-object v0, v1

    #v0=(Null);
    goto :goto_1

    :cond_8
    #v0=(Integer);
    new-instance v2, Ljava/util/ArrayList;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    #v2=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    move v3, v0

    :goto_3
    #v0=(Integer);v3=(Integer);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    if-ge v3, v4, :cond_b

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/ab;

    if-eqz v0, :cond_a

    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    #v5=(Reference);
    iget v6, v0, Lcom/tencent/mapapi/map/ab;->a:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "-"

    #v6=(Reference);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, v0, Lcom/tencent/mapapi/map/ab;->b:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "-"

    #v6=(Reference);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, v0, Lcom/tencent/mapapi/map/ab;->CR:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object v6, p0, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    #v6=(Reference);
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Lcom/tencent/mapapi/map/an;->ag(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;

    move-result-object v5

    new-instance v6, Lcom/tencent/mapapi/map/ac;

    #v6=(UninitRef);
    iget v7, v0, Lcom/tencent/mapapi/map/ab;->a:I

    #v7=(Integer);
    iget v8, v0, Lcom/tencent/mapapi/map/ab;->b:I

    #v8=(Integer);
    iget v9, v0, Lcom/tencent/mapapi/map/ab;->CR:I

    #v9=(Integer);
    invoke-direct {v6, v7, v8, v9}, Lcom/tencent/mapapi/map/ac;-><init>(III)V

    #v6=(Reference);
    iget v7, v0, Lcom/tencent/mapapi/map/ab;->EP:F

    iput v7, v6, Lcom/tencent/mapapi/map/ac;->EP:F

    iget v7, v0, Lcom/tencent/mapapi/map/ab;->EQ:F

    iput v7, v6, Lcom/tencent/mapapi/map/ac;->EQ:F

    if-eqz v5, :cond_9

    iget-object v5, v5, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    iput-object v5, v6, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    :cond_9
    iget-object v5, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    invoke-interface {v5, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    if-nez p2, :cond_a

    iget-object v5, v6, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    if-nez v5, :cond_a

    new-instance v5, Lcom/tencent/mapapi/map/aa;

    #v5=(UninitRef);
    iget v6, v0, Lcom/tencent/mapapi/map/ab;->a:I

    #v6=(Integer);
    iget v7, v0, Lcom/tencent/mapapi/map/ab;->b:I

    iget v0, v0, Lcom/tencent/mapapi/map/ab;->CR:I

    #v0=(Integer);
    invoke-direct {v5, v6, v7, v0}, Lcom/tencent/mapapi/map/aa;-><init>(III)V

    #v5=(Reference);
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    #v0=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    add-int/lit8 v0, v3, 0x1

    #v0=(Integer);
    move v3, v0

    goto :goto_3

    :cond_b
    move-object v0, v2

    #v0=(Reference);
    goto/16 :goto_1

    .line 557
    :cond_c
    #v2=(Boolean);v3=(One);v4=(Conflicted);
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/ad;->c(Ljava/util/List;)V

    goto/16 :goto_2
.end method

.method protected b(Landroid/graphics/Canvas;)V
    .locals 0
    .parameter

    .prologue
    .line 163
    return-void
.end method

.method protected final c(Landroid/graphics/Canvas;)V
    .locals 1
    .parameter

    .prologue
    .line 77
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 83
    :goto_0
    return-void

    .line 81
    :cond_0
    invoke-virtual {p0, p1}, Lcom/tencent/mapapi/map/ad;->b(Landroid/graphics/Canvas;)V

    .line 82
    invoke-virtual {p0, p1}, Lcom/tencent/mapapi/map/ad;->a(Landroid/graphics/Canvas;)V

    goto :goto_0
.end method

.method protected final c(Ljava/util/List;)V
    .locals 5
    .parameter

    .prologue
    .line 316
    iget-object v2, p0, Lcom/tencent/mapapi/map/ad;->EZ:[B

    #v2=(Reference);
    monitor-enter v2

    .line 318
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 319
    monitor-exit v2

    .line 346
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 321
    :cond_0
    #v0=(Reference);v1=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 324
    if-nez p1, :cond_1

    .line 325
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 343
    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0

    .line 329
    :cond_1
    :try_start_1
    #v1=(Uninit);v3=(Uninit);v4=(Uninit);
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    .line 330
    #v3=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_1
    #v0=(Integer);v1=(Integer);v4=(Conflicted);
    if-ge v1, v3, :cond_3

    .line 332
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 333
    if-eqz v0, :cond_2

    .line 335
    iget-object v4, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v4=(Reference);
    invoke-static {v4, v0}, Lcom/tencent/mapapi/map/ad;->a(Ljava/util/List;Lcom/tencent/mapapi/map/aa;)Z

    move-result v4

    #v4=(Boolean);
    if-nez v4, :cond_2

    .line 339
    iget-object v4, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    #v4=(Reference);
    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 330
    :cond_2
    #v4=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    .line 343
    :cond_3
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 345
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ad;->ic()V

    goto :goto_0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2
    .parameter

    .prologue
    .line 52
    if-ne p0, p1, :cond_0

    .line 53
    const/4 v0, 0x1

    .line 60
    :goto_0
    #v0=(Boolean);v1=(Conflicted);
    return v0

    .line 55
    :cond_0
    #v0=(Uninit);v1=(Uninit);
    instance-of v0, p1, Lcom/tencent/mapapi/map/ad;

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 56
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0

    .line 58
    :cond_1
    #v0=(Boolean);
    check-cast p1, Lcom/tencent/mapapi/map/ad;

    .line 60
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Fw:Ljava/lang/String;

    #v0=(Reference);
    iget-object v1, p1, Lcom/tencent/mapapi/map/ad;->Fw:Ljava/lang/String;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method protected final gx()V
    .locals 7

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x0

    .line 216
    #v3=(Null);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/ad;->Fv:Z

    #v0=(Boolean);
    const/4 v1, 0x1

    #v1=(One);
    if-ne v0, v1, :cond_1

    .line 258
    :cond_0
    :goto_0
    #v1=(Conflicted);v3=(Integer);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return-void

    .line 219
    :cond_1
    #v1=(One);v3=(Null);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ad;->ib()Ljava/util/ArrayList;

    move-result-object v4

    .line 220
    #v4=(Reference);
    if-eqz v4, :cond_0

    .line 224
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    .line 225
    #v5=(Integer);
    if-lez v5, :cond_0

    .line 228
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/aa;

    iget-boolean v0, v0, Lcom/tencent/mapapi/map/aa;->DD:Z

    .line 230
    #v0=(Boolean);
    iget-object v1, p0, Lcom/tencent/mapapi/map/ad;->FD:Lcom/tencent/mapapi/map/ae;

    #v1=(Reference);
    if-eqz v1, :cond_5

    .line 231
    new-instance v1, Lcom/tencent/mapapi/map/y;

    #v1=(UninitRef);
    iget-object v6, p0, Lcom/tencent/mapapi/map/ad;->Ec:Lcom/tencent/mapapi/map/bh;

    #v6=(Reference);
    iget-object v6, v6, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    invoke-virtual {v6}, Lcom/tencent/mapapi/map/bl;->io()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v1, v4, v6}, Lcom/tencent/mapapi/map/y;-><init>(Ljava/util/ArrayList;Ljava/lang/String;)V

    .line 233
    #v1=(Reference);
    iput-boolean v0, v1, Lcom/tencent/mapapi/map/y;->EN:Z

    .line 234
    invoke-virtual {v1, p0}, Lcom/tencent/mapapi/map/y;->a(Lcom/tencent/mapapi/map/ad;)V

    .line 235
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/y;->ig()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/Boolean;

    .line 236
    if-nez v0, :cond_2

    .line 238
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    .line 240
    :cond_2
    invoke-virtual {v1, v2}, Lcom/tencent/mapapi/map/y;->a(Lcom/tencent/mapapi/map/ad;)V

    move-object v1, v0

    .line 245
    :goto_1
    #v0=(Conflicted);v3=(Integer);v6=(Conflicted);
    if-ge v3, v5, :cond_4

    .line 247
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 248
    if-eqz v0, :cond_3

    .line 250
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/ad;->b(Lcom/tencent/mapapi/map/aa;)Z

    .line 245
    :cond_3
    add-int/lit8 v0, v3, 0x1

    #v0=(Integer);
    move v3, v0

    goto :goto_1

    .line 254
    :cond_4
    #v0=(Conflicted);
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 256
    invoke-virtual {p0, v2, v4}, Lcom/tencent/mapapi/map/ad;->a(Lcom/tencent/mapapi/map/aa;Ljava/util/ArrayList;)V

    goto :goto_0

    :cond_5
    #v3=(Null);v6=(Uninit);
    move-object v1, v2

    #v1=(Null);
    goto :goto_1
.end method

.method protected hB()V
    .locals 5

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v4, 0x0

    .line 87
    #v4=(Null);
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/ad;->Fv:Z

    .line 89
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/ao;->hw()V

    .line 92
    iget-object v1, p0, Lcom/tencent/mapapi/map/ad;->EZ:[B

    #v1=(Reference);
    monitor-enter v1

    .line 94
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 96
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 97
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    .line 98
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 99
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    .line 100
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 102
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_2

    .line 104
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    move v1, v2

    .line 106
    :goto_0
    #v0=(Conflicted);v1=(Integer);
    if-ge v1, v3, :cond_1

    .line 108
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    .line 109
    if-eqz v0, :cond_0

    .line 111
    iput-object v4, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 113
    :cond_0
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 100
    :catchall_0
    #v0=(Reference);v1=(Reference);v3=(Uninit);
    move-exception v0

    monitor-exit v1

    throw v0

    .line 115
    :cond_1
    #v0=(Conflicted);v1=(Integer);v3=(Integer);
    iput-object v4, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    .line 117
    :cond_2
    #v1=(Conflicted);v3=(Conflicted);
    return-void
.end method

.method protected hC()V
    .locals 0

    .prologue
    .line 212
    return-void
.end method

.method public hashCode()I
    .locals 1

    .prologue
    .line 66
    iget v0, p0, Lcom/tencent/mapapi/map/ad;->p:I

    #v0=(Integer);
    return v0
.end method

.method protected hw()V
    .locals 5

    .prologue
    const/4 v2, 0x0

    .line 674
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/an;->Fi:Lcom/tencent/mapapi/map/ao;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/ao;->hw()V

    .line 676
    iget-object v1, p0, Lcom/tencent/mapapi/map/ad;->EZ:[B

    #v1=(Reference);
    monitor-enter v1

    .line 678
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 680
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 681
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 682
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 684
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    if-eqz v0, :cond_1

    .line 686
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    move v1, v2

    .line 688
    :goto_0
    #v0=(Conflicted);v1=(Integer);v4=(Conflicted);
    if-ge v1, v3, :cond_1

    .line 690
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    .line 691
    if-eqz v0, :cond_0

    .line 693
    const/4 v4, 0x0

    #v4=(Null);
    iput-object v4, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 695
    :cond_0
    #v4=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 682
    :catchall_0
    #v0=(Reference);v1=(Reference);v3=(Uninit);v4=(Uninit);
    move-exception v0

    monitor-exit v1

    throw v0

    .line 698
    :cond_1
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void
.end method

.method protected ia()V
    .locals 1

    .prologue
    .line 651
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EV:Ljava/util/List;

    .line 652
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EW:Ljava/util/List;

    .line 654
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EX:Ljava/util/List;

    .line 655
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ad;->EY:Ljava/util/List;

    .line 657
    return-void
.end method

.method protected id()I
    .locals 1

    .prologue
    .line 662
    const/16 v0, 0xa

    #v0=(PosByte);
    return v0
.end method

.method protected ie()V
    .locals 0

    .prologue
    .line 669
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    .prologue
    .line 72
    iget-object v0, p0, Lcom/tencent/mapapi/map/ad;->Fw:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

*/}
