package com.tencent.mapapi.map; class n {/*

.class final Lcom/tencent/mapapi/map/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 52
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 1
    .parameter

    .prologue
    .line 52
    new-instance v0, Lcom/tencent/mapapi/map/OverlayItem;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Lcom/tencent/mapapi/map/OverlayItem;-><init>(Landroid/os/Parcel;)V

    #v0=(Reference);
    return-object v0
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 1
    .parameter

    .prologue
    .line 52
    new-array v0, p1, [Lcom/tencent/mapapi/map/OverlayItem;

    #v0=(Reference);
    return-object v0
.end method

*/}
