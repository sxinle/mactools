package com.tencent.mapapi.map; class bk {/*

.class final Lcom/tencent/mapapi/map/bk;
.super Lcom/tencent/mapapi/map/ae;
.source "SourceFile"


# instance fields
.field final synthetic Gb:Lcom/tencent/mapapi/map/bi;


# direct methods
.method constructor <init>(Lcom/tencent/mapapi/map/bi;)V
    .locals 0
    .parameter

    .prologue
    .line 457
    iput-object p1, p0, Lcom/tencent/mapapi/map/bk;->Gb:Lcom/tencent/mapapi/map/bi;

    invoke-direct {p0}, Lcom/tencent/mapapi/map/ae;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final varargs a(I[I)Ljava/lang/String;
    .locals 10
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v1, 0x0

    .line 460
    #v1=(Null);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bk;->Gb:Lcom/tencent/mapapi/map/bi;

    #v2=(Reference);
    if-nez p2, :cond_1

    .line 464
    :cond_0
    :goto_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    const-string v2, "http://pwh.map.qq.com/ih?dt=tile&rt=m256&c=%s"

    #v2=(Reference);
    const/4 v3, 0x1

    #v3=(One);
    new-array v3, v3, [Ljava/lang/Object;

    #v3=(Reference);
    aput-object v0, v3, v1

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 491
    return-object v0

    .line 460
    :cond_1
    #v0=(Null);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    array-length v2, p2

    #v2=(Integer);
    const/4 v3, 0x3

    #v3=(PosByte);
    if-lt v2, v3, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    #v3=(Reference);
    div-int/lit8 v2, v2, 0x3

    move v0, v1

    :goto_1
    #v0=(Integer);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    if-ge v0, v2, :cond_3

    if-eqz v0, :cond_2

    const-string v4, ","

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    #v4=(Conflicted);
    mul-int/lit8 v4, v0, 0x3

    #v4=(Integer);
    aget v4, p2, v4

    mul-int/lit8 v5, v0, 0x3

    #v5=(Integer);
    add-int/lit8 v5, v5, 0x1

    aget v5, p2, v5

    mul-int/lit8 v6, v0, 0x3

    #v6=(Integer);
    add-int/lit8 v6, v6, 0x2

    aget v6, p2, v6

    div-int v7, v4, p1

    #v7=(Integer);
    int-to-double v7, v7

    #v7=(DoubleLo);v8=(DoubleHi);
    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    move-result-wide v7

    double-to-int v7, v7

    #v7=(Integer);
    div-int v8, v5, p1

    #v8=(Integer);
    int-to-double v8, v8

    #v8=(DoubleLo);v9=(DoubleHi);
    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    move-result-wide v8

    double-to-int v8, v8

    #v8=(Integer);
    new-instance v9, Ljava/lang/StringBuffer;

    #v9=(UninitRef);
    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    #v9=(Reference);
    invoke-virtual {v9, v6}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v6

    #v6=(Reference);
    const-string v9, "/"

    invoke-virtual {v6, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v6

    const-string v7, "/"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v6

    const-string v7, "/"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    #v4=(Reference);
    const-string v6, "_"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    #v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    goto :goto_0
.end method

*/}
