package com.tencent.mapapi.map; class bs {/*

.class public final enum Lcom/tencent/mapapi/map/bs;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum GA:Lcom/tencent/mapapi/map/bs;

.field public static final enum GB:Lcom/tencent/mapapi/map/bs;

.field private static final synthetic GC:[Lcom/tencent/mapapi/map/bs;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .prologue
    const/4 v3, 0x1

    #v3=(One);
    const/4 v2, 0x0

    .line 64
    #v2=(Null);
    new-instance v0, Lcom/tencent/mapapi/map/bs;

    #v0=(UninitRef);
    const-string v1, "GOOGLE"

    #v1=(Reference);
    invoke-direct {v0, v1, v2}, Lcom/tencent/mapapi/map/bs;-><init>(Ljava/lang/String;I)V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mapapi/map/bs;->GA:Lcom/tencent/mapapi/map/bs;

    .line 65
    new-instance v0, Lcom/tencent/mapapi/map/bs;

    #v0=(UninitRef);
    const-string v1, "SOSO"

    invoke-direct {v0, v1, v3}, Lcom/tencent/mapapi/map/bs;-><init>(Ljava/lang/String;I)V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mapapi/map/bs;->GB:Lcom/tencent/mapapi/map/bs;

    .line 62
    const/4 v0, 0x2

    #v0=(PosByte);
    new-array v0, v0, [Lcom/tencent/mapapi/map/bs;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mapapi/map/bs;->GA:Lcom/tencent/mapapi/map/bs;

    aput-object v1, v0, v2

    sget-object v1, Lcom/tencent/mapapi/map/bs;->GB:Lcom/tencent/mapapi/map/bs;

    aput-object v1, v0, v3

    sput-object v0, Lcom/tencent/mapapi/map/bs;->GC:[Lcom/tencent/mapapi/map/bs;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 62
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    #p0=(Reference);
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/mapapi/map/bs;
    .locals 1
    .parameter

    .prologue
    .line 62
    const-class v0, Lcom/tencent/mapapi/map/bs;

    #v0=(Reference);
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/bs;

    return-object v0
.end method

.method public static values()[Lcom/tencent/mapapi/map/bs;
    .locals 1

    .prologue
    .line 62
    sget-object v0, Lcom/tencent/mapapi/map/bs;->GC:[Lcom/tencent/mapapi/map/bs;

    #v0=(Reference);
    invoke-virtual {v0}, [Lcom/tencent/mapapi/map/bs;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/tencent/mapapi/map/bs;

    return-object v0
.end method

*/}
