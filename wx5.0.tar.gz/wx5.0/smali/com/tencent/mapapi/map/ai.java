package com.tencent.mapapi.map; class ai {/*

.class final Lcom/tencent/mapapi/map/ai;
.super Lcom/tencent/mapapi/map/ag;
.source "SourceFile"


# instance fields
.field private Fd:Lcom/tencent/mapapi/map/GeoPoint;

.field protected Fe:Lcom/tencent/mapapi/map/ah;

.field private Ff:Landroid/os/Message;

.field private Fg:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Lcom/tencent/mapapi/map/ah;)V
    .locals 1
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 367
    #v0=(Null);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ag;-><init>()V

    .line 362
    #p0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fd:Lcom/tencent/mapapi/map/GeoPoint;

    .line 363
    iput-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fe:Lcom/tencent/mapapi/map/ah;

    .line 364
    iput-object v0, p0, Lcom/tencent/mapapi/map/ai;->Ff:Landroid/os/Message;

    .line 365
    iput-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fg:Ljava/lang/Runnable;

    .line 369
    iput-object p1, p0, Lcom/tencent/mapapi/map/ai;->Fe:Lcom/tencent/mapapi/map/ah;

    .line 370
    return-void
.end method


# virtual methods
.method final hB()V
    .locals 1

    .prologue
    const/4 v0, 0x0

    .line 427
    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fd:Lcom/tencent/mapapi/map/GeoPoint;

    .line 428
    iput-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fe:Lcom/tencent/mapapi/map/ah;

    .line 429
    return-void
.end method

.method public final j(II)V
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 384
    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fd:Lcom/tencent/mapapi/map/GeoPoint;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 386
    new-instance v0, Lcom/tencent/mapapi/map/GeoPoint;

    #v0=(UninitRef);
    invoke-direct {v0, p1, p2}, Lcom/tencent/mapapi/map/GeoPoint;-><init>(II)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fd:Lcom/tencent/mapapi/map/GeoPoint;

    .line 393
    :goto_0
    return-void

    .line 390
    :cond_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fd:Lcom/tencent/mapapi/map/GeoPoint;

    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/GeoPoint;->am(I)V

    .line 391
    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fd:Lcom/tencent/mapapi/map/GeoPoint;

    invoke-virtual {v0, p2}, Lcom/tencent/mapapi/map/GeoPoint;->al(I)V

    goto :goto_0
.end method

.method public final run()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 398
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fe:Lcom/tencent/mapapi/map/ah;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/ah;->a(Lcom/tencent/mapapi/map/ah;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fe:Lcom/tencent/mapapi/map/ah;

    invoke-static {v0}, Lcom/tencent/mapapi/map/ah;->a(Lcom/tencent/mapapi/map/ah;)Lcom/tencent/mapapi/map/bh;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iw()Lcom/tencent/mapapi/map/MapView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->hM()Lcom/tencent/mapapi/map/f;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/mapapi/map/ai;->Fd:Lcom/tencent/mapapi/map/GeoPoint;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/f;->a(Lcom/tencent/mapapi/map/GeoPoint;)V

    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fe:Lcom/tencent/mapapi/map/ah;

    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/ah;->d(Z)V

    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fg:Ljava/lang/Runnable;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Fg:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    iput-object v2, p0, Lcom/tencent/mapapi/map/ai;->Fg:Ljava/lang/Runnable;

    :cond_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Ff:Landroid/os/Message;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/mapapi/map/ai;->Ff:Landroid/os/Message;

    invoke-virtual {v0}, Landroid/os/Message;->getTarget()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/mapapi/map/ai;->Ff:Landroid/os/Message;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    iput-object v2, p0, Lcom/tencent/mapapi/map/ai;->Ff:Landroid/os/Message;

    :cond_1
    invoke-virtual {p0}, Lcom/tencent/mapapi/map/ai;->hB()V

    .line 399
    :cond_2
    #v1=(Conflicted);
    return-void
.end method

*/}
