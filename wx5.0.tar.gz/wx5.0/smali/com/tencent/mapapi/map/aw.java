package com.tencent.mapapi.map; class aw {/*

.class final Lcom/tencent/mapapi/map/aw;
.super Lcom/tencent/mapapi/map/ad;
.source "SourceFile"


# instance fields
.field CS:I

.field CY:[B

.field Da:Z

.field EN:Z

.field private Fp:Ljava/util/List;

.field private Fq:Ljava/util/List;

.field private Fr:Ljava/util/List;

.field private Fs:Ljava/util/List;

.field Ft:Landroid/graphics/PaintFlagsDrawFilter;


# direct methods
.method constructor <init>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v1, 0x0

    .line 25
    #v1=(Null);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/ad;-><init>()V

    .line 28
    #p0=(Reference);
    iput-object v1, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    .line 29
    iput-object v1, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    .line 30
    iput-object v1, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    .line 31
    iput-object v1, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    .line 33
    new-array v0, v2, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->CY:[B

    .line 34
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/aw;->Da:Z

    .line 35
    iput-object v1, p0, Lcom/tencent/mapapi/map/aw;->Ft:Landroid/graphics/PaintFlagsDrawFilter;

    .line 37
    iput v2, p0, Lcom/tencent/mapapi/map/aw;->CS:I

    .line 38
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/aw;->EN:Z

    return-void
.end method

.method private a(Ljava/util/List;Ljava/util/List;IZ)V
    .locals 9
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x0

    .line 597
    #v2=(Null);
    if-eqz p1, :cond_0

    if-nez p2, :cond_1

    .line 654
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-void

    .line 601
    :cond_1
    #v0=(Uninit);v1=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/aw;->Em:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 604
    iget v0, p0, Lcom/tencent/mapapi/map/aw;->EB:I

    #v0=(Integer);
    if-gt p3, v0, :cond_0

    iget v0, p0, Lcom/tencent/mapapi/map/aw;->EC:I

    if-lt p3, v0, :cond_0

    .line 608
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    .line 609
    #v3=(Integer);
    if-lez v3, :cond_0

    move v1, v2

    .line 618
    :goto_0
    #v1=(Integer);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    if-ge v1, v3, :cond_0

    .line 619
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/ab;

    .line 620
    if-eqz v0, :cond_3

    .line 621
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 624
    #v4=(Reference);
    iget v5, v0, Lcom/tencent/mapapi/map/ab;->a:I

    #v5=(Integer);
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 625
    const-string v5, "-"

    #v5=(Reference);
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 626
    iget v5, v0, Lcom/tencent/mapapi/map/ab;->b:I

    #v5=(Integer);
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 627
    const-string v5, "-"

    #v5=(Reference);
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 628
    iget v5, v0, Lcom/tencent/mapapi/map/ab;->CR:I

    #v5=(Integer);
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 630
    iget-object v5, p0, Lcom/tencent/mapapi/map/aw;->ET:Lcom/tencent/mapapi/map/an;

    #v5=(Reference);
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Lcom/tencent/mapapi/map/an;->ag(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;

    move-result-object v4

    .line 631
    new-instance v5, Lcom/tencent/mapapi/map/ac;

    #v5=(UninitRef);
    iget v6, v0, Lcom/tencent/mapapi/map/ab;->a:I

    #v6=(Integer);
    iget v7, v0, Lcom/tencent/mapapi/map/ab;->b:I

    #v7=(Integer);
    iget v8, v0, Lcom/tencent/mapapi/map/ab;->CR:I

    #v8=(Integer);
    invoke-direct {v5, v6, v7, v8}, Lcom/tencent/mapapi/map/ac;-><init>(III)V

    .line 634
    #v5=(Reference);
    if-eqz v4, :cond_2

    .line 636
    iget-object v4, v4, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    iput-object v4, v5, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 637
    :cond_2
    iget v4, v0, Lcom/tencent/mapapi/map/ab;->EP:F

    #v4=(Integer);
    iput v4, v5, Lcom/tencent/mapapi/map/ac;->EP:F

    .line 640
    iget v4, v0, Lcom/tencent/mapapi/map/ab;->EQ:F

    iput v4, v5, Lcom/tencent/mapapi/map/ac;->EQ:F

    .line 641
    iget-object v4, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    #v4=(Reference);
    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 643
    if-nez p4, :cond_3

    iget-object v4, v5, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    if-nez v4, :cond_3

    .line 644
    new-instance v4, Lcom/tencent/mapapi/map/aa;

    #v4=(UninitRef);
    iget v5, v0, Lcom/tencent/mapapi/map/ab;->a:I

    #v5=(Integer);
    iget v6, v0, Lcom/tencent/mapapi/map/ab;->b:I

    iget v0, v0, Lcom/tencent/mapapi/map/ab;->CR:I

    #v0=(Integer);
    invoke-direct {v4, v5, v6, v0}, Lcom/tencent/mapapi/map/aa;-><init>(III)V

    .line 648
    #v4=(Reference);
    invoke-interface {p2, v2, v4}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 649
    :cond_3
    #v0=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0
.end method

.method private c(Lcom/tencent/mapapi/map/aa;)Z
    .locals 2
    .parameter

    .prologue
    .line 356
    iget-object v1, p0, Lcom/tencent/mapapi/map/aw;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    .line 358
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 360
    const/4 v0, 0x0

    #v0=(Null);
    monitor-exit v1

    .line 362
    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 363
    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method private d(Ljava/util/List;)V
    .locals 5
    .parameter

    .prologue
    .line 278
    if-nez p1, :cond_0

    .line 305
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 281
    :cond_0
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v2, p0, Lcom/tencent/mapapi/map/aw;->CY:[B

    #v2=(Reference);
    monitor-enter v2

    .line 283
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_1

    .line 284
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 305
    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0

    .line 286
    :cond_1
    :try_start_1
    #v1=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 290
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    .line 292
    #v3=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_1
    #v0=(Integer);v1=(Integer);v4=(Conflicted);
    if-ge v1, v3, :cond_3

    .line 294
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 295
    if-eqz v0, :cond_2

    .line 297
    iget-object v4, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    #v4=(Reference);
    invoke-static {v4, v0}, Lcom/tencent/mapapi/map/aw;->a(Ljava/util/List;Lcom/tencent/mapapi/map/aa;)Z

    move-result v4

    #v4=(Boolean);
    if-nez v4, :cond_2

    .line 301
    iget-object v4, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    #v4=(Reference);
    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 292
    :cond_2
    #v4=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    .line 304
    :cond_3
    invoke-direct {p0}, Lcom/tencent/mapapi/map/aw;->hR()V

    .line 305
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0
.end method

.method private hR()V
    .locals 1

    .prologue
    .line 336
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bl;->FK:Lcom/tencent/mapapi/map/be;

    if-eqz v0, :cond_0

    .line 338
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bl;->FK:Lcom/tencent/mapapi/map/be;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/be;->im()V

    .line 339
    :cond_0
    return-void
.end method

.method private ij()Lcom/tencent/mapapi/map/aa;
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 309
    .line 311
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mapapi/map/aw;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    .line 313
    :try_start_0
    iget-object v2, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    #v2=(Reference);
    if-nez v2, :cond_1

    .line 314
    monitor-exit v1

    .line 328
    :cond_0
    :goto_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);
    return-object v0

    .line 316
    :cond_1
    #v0=(Null);v2=(Reference);v3=(Uninit);
    iget-object v2, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    .line 317
    #v2=(Integer);
    if-gtz v2, :cond_2

    .line 318
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 323
    :catchall_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);
    move-exception v0

    monitor-exit v1

    throw v0

    .line 320
    :cond_2
    :try_start_1
    #v0=(Null);v2=(Integer);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    #v0=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/aa;

    .line 321
    iget-object v2, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    #v2=(Reference);
    if-eqz v2, :cond_3

    iget-object v2, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    const/4 v3, 0x1

    #v3=(One);
    if-eq v2, v3, :cond_3

    iget-object v2, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 322
    :cond_3
    #v2=(Conflicted);v3=(Conflicted);
    iget-object v2, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    .line 323
    #v2=(Integer);
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 325
    if-lez v2, :cond_0

    .line 326
    invoke-direct {p0}, Lcom/tencent/mapapi/map/aw;->hR()V

    goto :goto_0
.end method


# virtual methods
.method protected final a(Landroid/graphics/Canvas;)V
    .locals 3
    .parameter

    .prologue
    .line 125
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ft:Landroid/graphics/PaintFlagsDrawFilter;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 127
    new-instance v0, Landroid/graphics/PaintFlagsDrawFilter;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v2, 0x2

    #v2=(PosByte);
    invoke-direct {v0, v1, v2}, Landroid/graphics/PaintFlagsDrawFilter;-><init>(II)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ft:Landroid/graphics/PaintFlagsDrawFilter;

    .line 130
    :cond_0
    #v1=(Conflicted);v2=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ft:Landroid/graphics/PaintFlagsDrawFilter;

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->setDrawFilter(Landroid/graphics/DrawFilter;)V

    .line 131
    invoke-super {p0, p1}, Lcom/tencent/mapapi/map/ad;->a(Landroid/graphics/Canvas;)V

    .line 132
    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->setDrawFilter(Landroid/graphics/DrawFilter;)V

    .line 133
    return-void
.end method

.method protected final a(Ljava/util/ArrayList;Z)V
    .locals 20
    .parameter
    .parameter

    .prologue
    .line 369
    if-nez p1, :cond_1

    .line 421
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);v15=(Conflicted);v16=(Conflicted);v17=(Conflicted);v18=(Conflicted);v19=(Conflicted);
    return-void

    .line 372
    :cond_1
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);v10=(Uninit);v11=(Uninit);v12=(Uninit);v13=(Uninit);v14=(Uninit);v15=(Uninit);v16=(Uninit);v17=(Uninit);v18=(Uninit);v19=(Uninit);
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    #v2=(Integer);
    if-nez v2, :cond_2

    .line 373
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v3

    #v3=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v4

    #v4=(Integer);
    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v5=(Reference);
    iget-object v5, v5, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v5}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v5

    #v5=(Integer);
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v6=(Reference);
    iget-object v6, v6, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v6}, Lcom/tencent/mapapi/map/bm;->iq()F

    move-result v6

    #v6=(Float);
    invoke-virtual {v2, v3, v4, v5, v6}, Lcom/tencent/mapapi/map/bo;->a(IIIF)Ljava/util/ArrayList;

    move-result-object p1

    .line 380
    :cond_2
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->EV:Ljava/util/List;

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mapapi/map/aw;->b(Ljava/util/List;)V

    .line 381
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    invoke-static {v2}, Lcom/tencent/mapapi/map/aw;->b(Ljava/util/List;)V

    .line 382
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->EY:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->clear()V

    .line 384
    const/4 v2, 0x0

    #v2=(Null);
    move-object/from16 v0, p0

    iput v2, v0, Lcom/tencent/mapapi/map/aw;->CS:I

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    #v2=(Reference);
    if-eqz v2, :cond_b

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v14

    #v14=(Integer);
    if-lez v14, :cond_b

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->iq()F

    move-result v15

    #v15=(Float);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bo;->ix()Landroid/graphics/Point;

    move-result-object v16

    #v16=(Reference);
    const/4 v9, -0x1

    #v9=(Byte);
    const/4 v7, 0x0

    #v7=(Null);
    const/4 v6, -0x1

    #v6=(Byte);
    const/4 v10, -0x1

    #v10=(Byte);
    const/4 v5, 0x0

    #v5=(Null);
    const/4 v3, 0x0

    #v3=(Null);
    const/4 v4, 0x0

    #v4=(Null);
    const/4 v8, 0x0

    :goto_1
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Float);v4=(Integer);v5=(Float);v6=(Integer);v7=(Reference);v8=(Integer);v9=(Integer);v10=(Integer);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v17=(Conflicted);v18=(Conflicted);v19=(Conflicted);
    if-ge v8, v14, :cond_b

    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v2, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/tencent/mapapi/map/ac;

    if-eqz v2, :cond_1c

    iget v11, v2, Lcom/tencent/mapapi/map/ac;->CR:I

    #v11=(Integer);
    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v12=(Reference);
    iget-object v12, v12, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v12, v12, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v12=(Integer);
    if-ne v11, v12, :cond_3

    const/4 v11, 0x0

    #v11=(Null);
    iput-object v11, v2, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    invoke-interface {v2, v8}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    add-int/lit8 v2, v8, -0x1

    #v2=(Integer);
    add-int/lit8 v8, v14, -0x1

    move/from16 v19, v9

    #v19=(Integer);
    move v9, v8

    move/from16 v8, v19

    :goto_2
    #v0=(Conflicted);v11=(Conflicted);v12=(Conflicted);v19=(Conflicted);
    add-int/lit8 v2, v2, 0x1

    move v14, v9

    move v9, v8

    move v8, v2

    goto :goto_1

    :cond_3
    #v0=(Reference);v2=(Reference);v11=(Integer);v12=(Integer);
    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/tencent/mapapi/map/aw;->ET:Lcom/tencent/mapapi/map/an;

    #v11=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mapapi/map/ac;->toString()Ljava/lang/String;

    move-result-object v12

    #v12=(Reference);
    invoke-virtual {v11, v12}, Lcom/tencent/mapapi/map/an;->ag(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;

    move-result-object v11

    if-nez v11, :cond_4

    const/4 v11, 0x0

    #v11=(Null);
    iput-object v11, v2, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    invoke-interface {v2, v8}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    add-int/lit8 v2, v8, -0x1

    #v2=(Integer);
    add-int/lit8 v8, v14, -0x1

    move/from16 v19, v9

    #v19=(Integer);
    move v9, v8

    move/from16 v8, v19

    goto :goto_2

    :cond_4
    #v2=(Reference);v11=(Reference);v19=(Conflicted);
    iget-object v11, v11, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    iput-object v11, v2, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    iget v11, v2, Lcom/tencent/mapapi/map/ac;->CR:I

    #v11=(Integer);
    if-eq v9, v11, :cond_1b

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bo;->iy()Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v4

    iget v5, v2, Lcom/tencent/mapapi/map/ac;->CR:I

    #v5=(Integer);
    invoke-virtual {v3, v4, v5}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v12

    iget v3, v12, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    const/high16 v4, 0x4380

    #v4=(Integer);
    div-float/2addr v3, v4

    #v3=(Float);
    float-to-double v3, v3

    #v3=(DoubleLo);v4=(DoubleHi);
    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v11, v3

    iget v3, v12, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    const/high16 v4, 0x4380

    #v4=(Integer);
    div-float/2addr v3, v4

    #v3=(Float);
    float-to-double v3, v3

    #v3=(DoubleLo);v4=(DoubleHi);
    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v5, v3

    move-object/from16 v0, v16

    iget v3, v0, Landroid/graphics/Point;->x:I

    #v3=(Integer);
    int-to-float v3, v3

    #v3=(Float);
    iget v4, v12, Landroid/graphics/PointF;->x:F

    #v4=(Integer);
    const/high16 v6, 0x4380

    rem-float/2addr v4, v6

    #v4=(Float);
    sub-float v10, v3, v4

    #v10=(Float);
    move-object/from16 v0, v16

    iget v3, v0, Landroid/graphics/Point;->y:I

    #v3=(Integer);
    int-to-float v3, v3

    #v3=(Float);
    const/high16 v4, 0x4380

    #v4=(Integer);
    iget v6, v12, Landroid/graphics/PointF;->y:F

    const/high16 v7, 0x4380

    #v7=(Integer);
    rem-float/2addr v6, v7

    #v6=(Float);
    sub-float/2addr v4, v6

    #v4=(Float);
    sub-float v9, v3, v4

    #v9=(Float);
    iget v13, v2, Lcom/tencent/mapapi/map/ac;->CR:I

    #v13=(Integer);
    const-wide/high16 v3, 0x4000

    #v3=(LongLo);v4=(LongHi);
    iget v6, v2, Lcom/tencent/mapapi/map/ac;->CR:I

    #v6=(Integer);
    add-int/lit8 v6, v6, 0x1

    int-to-double v6, v6

    #v6=(DoubleLo);v7=(DoubleHi);
    invoke-static {v3, v4, v6, v7}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v3

    #v3=(DoubleLo);v4=(DoubleHi);
    double-to-int v4, v3

    :goto_3
    #v3=(Conflicted);v4=(Integer);v6=(Conflicted);v7=(Conflicted);
    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    if-eqz v2, :cond_5

    if-eqz v12, :cond_5

    if-nez v11, :cond_20

    move v6, v4

    :goto_4
    #v6=(Integer);
    if-nez v5, :cond_1f

    move v3, v4

    :goto_5
    #v3=(Integer);
    iget v7, v2, Lcom/tencent/mapapi/map/ab;->a:I

    #v7=(Integer);
    sub-int/2addr v7, v6

    if-gez v7, :cond_1e

    add-int v6, v7, v4

    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v17

    #v17=(Integer);
    move/from16 v0, v17

    #v0=(Integer);
    if-ge v6, v0, :cond_1e

    :goto_6
    #v0=(Conflicted);v17=(Conflicted);
    iget v7, v2, Lcom/tencent/mapapi/map/ab;->b:I

    sub-int/2addr v7, v3

    if-gez v7, :cond_1d

    add-int v3, v7, v4

    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v17

    #v17=(Integer);
    move/from16 v0, v17

    #v0=(Integer);
    if-ge v3, v0, :cond_1d

    :goto_7
    #v0=(Conflicted);v17=(Conflicted);
    mul-int/lit16 v6, v6, 0x100

    int-to-float v6, v6

    #v6=(Float);
    add-float/2addr v6, v10

    iput v6, v2, Lcom/tencent/mapapi/map/ab;->EP:F

    mul-int/lit16 v3, v3, 0x100

    int-to-float v3, v3

    #v3=(Float);
    sub-float v3, v9, v3

    iput v3, v2, Lcom/tencent/mapapi/map/ab;->EQ:F

    :cond_5
    #v3=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    iget v3, v2, Lcom/tencent/mapapi/map/ac;->CR:I

    #v3=(Integer);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v6, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v6=(Reference);
    iget-object v6, v6, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v6, v6, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v6=(Integer);
    sub-int v3, v6, v3

    const-wide/high16 v6, 0x4000

    #v6=(LongLo);v7=(LongHi);
    int-to-double v0, v3

    #v0=(DoubleLo);v1=(DoubleHi);
    move-wide/from16 v17, v0

    #v17=(DoubleLo);v18=(DoubleHi);
    move-wide/from16 v0, v17

    invoke-static {v6, v7, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v6

    #v6=(DoubleLo);v7=(DoubleHi);
    double-to-float v6, v6

    #v6=(Float);
    iget v3, v2, Lcom/tencent/mapapi/map/ac;->EP:F

    iget v7, v2, Lcom/tencent/mapapi/map/ac;->EQ:F

    #v7=(Integer);
    mul-float v17, v15, v6

    #v17=(Float);
    move-object/from16 v0, v16

    #v0=(Reference);
    iget v0, v0, Landroid/graphics/Point;->x:I

    #v0=(Integer);
    move/from16 v18, v0

    #v18=(Integer);
    move/from16 v0, v18

    int-to-float v0, v0

    #v0=(Float);
    move/from16 v18, v0

    #v18=(Float);
    sub-float v3, v3, v18

    #v3=(Float);
    mul-float v3, v3, v17

    move-object/from16 v0, v16

    #v0=(Reference);
    iget v0, v0, Landroid/graphics/Point;->x:I

    #v0=(Integer);
    move/from16 v17, v0

    #v17=(Integer);
    move/from16 v0, v17

    int-to-float v0, v0

    #v0=(Float);
    move/from16 v17, v0

    #v17=(Float);
    add-float v3, v3, v17

    mul-float v17, v15, v6

    move-object/from16 v0, v16

    #v0=(Reference);
    iget v0, v0, Landroid/graphics/Point;->y:I

    #v0=(Integer);
    move/from16 v18, v0

    #v18=(Integer);
    move/from16 v0, v18

    int-to-float v0, v0

    #v0=(Float);
    move/from16 v18, v0

    #v18=(Float);
    sub-float v7, v7, v18

    #v7=(Float);
    mul-float v7, v7, v17

    move-object/from16 v0, v16

    #v0=(Reference);
    iget v0, v0, Landroid/graphics/Point;->y:I

    #v0=(Integer);
    move/from16 v17, v0

    #v17=(Integer);
    move/from16 v0, v17

    int-to-float v0, v0

    #v0=(Float);
    move/from16 v17, v0

    #v17=(Float);
    add-float v7, v7, v17

    const/high16 v17, 0x4380

    #v17=(Integer);
    mul-float v17, v17, v15

    #v17=(Float);
    mul-float v17, v17, v6

    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    move-object/from16 v18, v0

    #v18=(Reference);
    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    move-object/from16 v18, v0

    invoke-virtual/range {v18 .. v18}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v18

    #v18=(Integer);
    move/from16 v0, v18

    #v0=(Integer);
    int-to-float v0, v0

    #v0=(Float);
    move/from16 v18, v0

    #v18=(Float);
    cmpl-float v18, v3, v18

    #v18=(Byte);
    if-gtz v18, :cond_6

    move/from16 v0, v17

    neg-float v0, v0

    move/from16 v18, v0

    #v18=(Float);
    cmpg-float v3, v3, v18

    #v3=(Byte);
    if-gez v3, :cond_7

    :cond_6
    #v3=(Float);
    const/4 v3, 0x0

    :goto_8
    #v0=(Conflicted);v3=(Boolean);
    iput v6, v2, Lcom/tencent/mapapi/map/ac;->h:F

    iput-boolean v3, v2, Lcom/tencent/mapapi/map/ac;->ES:Z

    iget-boolean v3, v2, Lcom/tencent/mapapi/map/ac;->ES:Z

    if-nez v3, :cond_a

    const/4 v3, 0x0

    #v3=(Null);
    iput-object v3, v2, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    move v2, v8

    #v2=(Integer);
    move v3, v9

    #v3=(Float);
    move v6, v11

    #v6=(Integer);
    move-object v7, v12

    #v7=(Reference);
    move v8, v13

    move v9, v14

    #v9=(Integer);
    move/from16 v19, v10

    #v19=(Float);
    move v10, v5

    #v10=(Integer);
    move/from16 v5, v19

    #v5=(Float);
    goto/16 :goto_2

    :cond_7
    #v0=(Float);v2=(Reference);v3=(Byte);v5=(Integer);v6=(Float);v7=(Float);v9=(Float);v10=(Float);v19=(Conflicted);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v3, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v3

    #v3=(Integer);
    int-to-float v3, v3

    #v3=(Float);
    cmpl-float v3, v7, v3

    #v3=(Byte);
    if-gtz v3, :cond_8

    move/from16 v0, v17

    #v0=(Float);
    neg-float v3, v0

    #v3=(Float);
    cmpg-float v3, v7, v3

    #v3=(Byte);
    if-gez v3, :cond_9

    :cond_8
    #v0=(Conflicted);
    const/4 v3, 0x0

    #v3=(Null);
    goto :goto_8

    :cond_9
    #v0=(Float);v3=(Byte);
    const/4 v3, 0x1

    #v3=(One);
    goto :goto_8

    :cond_a
    #v0=(Conflicted);v3=(Boolean);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget v2, v0, Lcom/tencent/mapapi/map/aw;->CS:I

    #v2=(Integer);
    add-int/lit8 v2, v2, 0x1

    move-object/from16 v0, p0

    iput v2, v0, Lcom/tencent/mapapi/map/aw;->CS:I

    move v2, v8

    move v3, v9

    #v3=(Float);
    move v6, v11

    #v6=(Integer);
    move-object v7, v12

    #v7=(Reference);
    move v8, v13

    move v9, v14

    #v9=(Integer);
    move/from16 v19, v10

    #v19=(Float);
    move v10, v5

    #v10=(Integer);
    move/from16 v5, v19

    #v5=(Float);
    goto/16 :goto_2

    .line 385
    :cond_b
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);v15=(Conflicted);v16=(Conflicted);v17=(Conflicted);v18=(Conflicted);v19=(Conflicted);
    move-object/from16 v0, p0

    #v0=(Reference);
    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    iget-boolean v6, v2, Lcom/tencent/mapapi/map/bm;->c:Z

    .line 387
    #v6=(Boolean);
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v2

    #v2=(Integer);
    const/4 v3, 0x0

    #v3=(Null);
    move-object/from16 v0, p0

    iput-boolean v3, v0, Lcom/tencent/mapapi/map/aw;->Da:Z

    const/4 v3, 0x1

    #v3=(One);
    move-object/from16 v0, p0

    iput-boolean v3, v0, Lcom/tencent/mapapi/map/aw;->EN:Z

    if-nez p1, :cond_10

    const/4 v2, 0x0

    #v2=(Null);
    move-object v3, v2

    .line 390
    :cond_c
    :goto_9
    #v2=(Integer);v3=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    if-ne v6, v2, :cond_e

    .line 392
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v2

    #v2=(Integer);
    add-int/lit8 v2, v2, -0x2

    .line 393
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bm;->is()I

    move-result v4

    #v4=(Integer);
    if-ge v2, v4, :cond_d

    .line 395
    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->is()I

    move-result v2

    .line 397
    :cond_d
    #v2=(Integer);
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v4

    #v4=(Integer);
    if-eq v2, v4, :cond_e

    .line 399
    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v5=(Reference);
    iget-object v5, v5, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v5}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v5

    #v5=(Integer);
    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v6=(Reference);
    iget-object v6, v6, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v6}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v6

    #v6=(Integer);
    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v7=(Reference);
    iget-object v7, v7, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v7}, Lcom/tencent/mapapi/map/bm;->iq()F

    invoke-virtual {v4, v2, v5, v6}, Lcom/tencent/mapapi/map/bo;->f(III)Ljava/util/ArrayList;

    move-result-object v4

    .line 403
    move-object/from16 v0, p0

    move/from16 v1, p2

    #v1=(Boolean);
    invoke-direct {v0, v4, v3, v2, v1}, Lcom/tencent/mapapi/map/aw;->a(Ljava/util/List;Ljava/util/List;IZ)V

    .line 407
    :cond_e
    #v1=(Conflicted);v4=(Conflicted);v5=(Conflicted);v7=(Conflicted);
    if-eqz v3, :cond_f

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_f

    .line 409
    move-object/from16 v0, p0

    iget-boolean v2, v0, Lcom/tencent/mapapi/map/aw;->Fy:Z

    #v2=(Boolean);
    const/4 v4, 0x1

    #v4=(One);
    if-ne v2, v4, :cond_1a

    .line 411
    const/4 v2, 0x0

    #v2=(Null);
    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lcom/tencent/mapapi/map/aw;->c(Ljava/util/List;)V

    .line 412
    move-object/from16 v0, p0

    invoke-direct {v0, v3}, Lcom/tencent/mapapi/map/aw;->d(Ljava/util/List;)V

    .line 419
    :cond_f
    :goto_a
    #v2=(Integer);v4=(Conflicted);
    if-eqz v3, :cond_0

    .line 420
    invoke-interface {v3}, Ljava/util/List;->clear()V

    goto/16 :goto_0

    .line 387
    :cond_10
    #v3=(One);v6=(Boolean);
    move-object/from16 v0, p0

    iget-boolean v3, v0, Lcom/tencent/mapapi/map/aw;->Em:Z

    #v3=(Boolean);
    if-nez v3, :cond_11

    const/4 v2, 0x0

    #v2=(Null);
    move-object v3, v2

    #v3=(Null);
    goto/16 :goto_9

    :cond_11
    #v2=(Integer);v3=(Boolean);
    move-object/from16 v0, p0

    iget v3, v0, Lcom/tencent/mapapi/map/aw;->EB:I

    #v3=(Integer);
    if-gt v2, v3, :cond_12

    move-object/from16 v0, p0

    iget v3, v0, Lcom/tencent/mapapi/map/aw;->EC:I

    if-ge v2, v3, :cond_13

    :cond_12
    const/4 v2, 0x0

    #v2=(Null);
    move-object v3, v2

    #v3=(Null);
    goto/16 :goto_9

    :cond_13
    #v2=(Integer);v3=(Integer);
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v7

    #v7=(Integer);
    if-gtz v7, :cond_14

    const/4 v2, 0x0

    #v2=(Null);
    move-object v3, v2

    #v3=(Null);
    goto/16 :goto_9

    :cond_14
    #v2=(Integer);v3=(Integer);
    new-instance v3, Ljava/util/ArrayList;

    #v3=(UninitRef);
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    #v3=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    move v4, v2

    :goto_b
    #v2=(Integer);v4=(Integer);
    if-ge v4, v7, :cond_c

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    #v2=(Reference);
    check-cast v2, Lcom/tencent/mapapi/map/ab;

    if-eqz v2, :cond_17

    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    #v5=(Reference);
    iget v8, v2, Lcom/tencent/mapapi/map/ab;->a:I

    #v8=(Integer);
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, "-"

    #v8=(Reference);
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v8, v2, Lcom/tencent/mapapi/map/ab;->b:I

    #v8=(Integer);
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, "-"

    #v8=(Reference);
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v8, v2, Lcom/tencent/mapapi/map/ab;->CR:I

    #v8=(Integer);
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/tencent/mapapi/map/aw;->ET:Lcom/tencent/mapapi/map/an;

    #v8=(Reference);
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5}, Lcom/tencent/mapapi/map/an;->ag(Ljava/lang/String;)Lcom/tencent/mapapi/map/ap;

    move-result-object v5

    new-instance v8, Lcom/tencent/mapapi/map/ac;

    #v8=(UninitRef);
    iget v9, v2, Lcom/tencent/mapapi/map/ab;->a:I

    #v9=(Integer);
    iget v10, v2, Lcom/tencent/mapapi/map/ab;->b:I

    #v10=(Integer);
    iget v11, v2, Lcom/tencent/mapapi/map/ab;->CR:I

    #v11=(Integer);
    invoke-direct {v8, v9, v10, v11}, Lcom/tencent/mapapi/map/ac;-><init>(III)V

    #v8=(Reference);
    iget v9, v2, Lcom/tencent/mapapi/map/ab;->EP:F

    iput v9, v8, Lcom/tencent/mapapi/map/ac;->EP:F

    iget v9, v2, Lcom/tencent/mapapi/map/ab;->EQ:F

    iput v9, v8, Lcom/tencent/mapapi/map/ac;->EQ:F

    if-eqz v5, :cond_18

    iget-object v5, v5, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    iput-object v5, v8, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    :cond_15
    :goto_c
    #v5=(Conflicted);
    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/tencent/mapapi/map/aw;->EV:Ljava/util/List;

    #v5=(Reference);
    invoke-interface {v5, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v5, v8, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    if-nez v5, :cond_19

    const/4 v5, 0x1

    :goto_d
    #v5=(Boolean);
    const/4 v8, 0x1

    #v8=(One);
    if-ne v5, v8, :cond_16

    const/4 v8, 0x1

    move-object/from16 v0, p0

    iput-boolean v8, v0, Lcom/tencent/mapapi/map/aw;->Da:Z

    :cond_16
    if-nez p2, :cond_17

    const/4 v8, 0x1

    if-ne v5, v8, :cond_17

    new-instance v5, Lcom/tencent/mapapi/map/aa;

    #v5=(UninitRef);
    iget v8, v2, Lcom/tencent/mapapi/map/ab;->a:I

    #v8=(Integer);
    iget v9, v2, Lcom/tencent/mapapi/map/ab;->b:I

    iget v2, v2, Lcom/tencent/mapapi/map/ab;->CR:I

    #v2=(Integer);
    invoke-direct {v5, v8, v9, v2}, Lcom/tencent/mapapi/map/aa;-><init>(III)V

    #v5=(Reference);
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_17
    #v2=(Conflicted);v5=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);
    add-int/lit8 v2, v4, 0x1

    #v2=(Integer);
    move v4, v2

    goto :goto_b

    :cond_18
    #v2=(Reference);v5=(Reference);v8=(Reference);v9=(Integer);v10=(Integer);v11=(Integer);
    move-object/from16 v0, p0

    iget-boolean v5, v0, Lcom/tencent/mapapi/map/aw;->EN:Z

    #v5=(Boolean);
    const/4 v9, 0x1

    #v9=(One);
    if-ne v5, v9, :cond_15

    const/4 v5, 0x0

    #v5=(Null);
    move-object/from16 v0, p0

    iput-boolean v5, v0, Lcom/tencent/mapapi/map/aw;->EN:Z

    goto :goto_c

    :cond_19
    #v5=(Reference);v9=(Integer);
    const/4 v5, 0x0

    #v5=(Null);
    goto :goto_d

    .line 416
    :cond_1a
    #v2=(Boolean);v4=(One);v5=(Conflicted);v6=(Integer);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);
    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lcom/tencent/mapapi/map/aw;->c(Ljava/util/List;)V

    goto/16 :goto_a

    :cond_1b
    #v2=(Reference);v3=(Float);v4=(Integer);v5=(Float);v7=(Reference);v8=(Integer);v9=(Integer);v10=(Integer);v11=(Integer);v12=(Reference);v14=(Integer);v15=(Float);v16=(Reference);
    move v11, v6

    move-object v12, v7

    move v13, v9

    #v13=(Integer);
    move v9, v3

    #v9=(Float);
    move/from16 v19, v5

    #v19=(Float);
    move v5, v10

    #v5=(Integer);
    move/from16 v10, v19

    #v10=(Float);
    goto/16 :goto_3

    :cond_1c
    #v5=(Float);v9=(Integer);v10=(Integer);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v19=(Conflicted);
    move v2, v8

    #v2=(Integer);
    move v8, v9

    move v9, v14

    goto/16 :goto_2

    :cond_1d
    #v0=(Conflicted);v2=(Reference);v3=(Integer);v5=(Integer);v7=(Integer);v9=(Float);v10=(Float);v11=(Integer);v12=(Reference);v13=(Integer);
    move v3, v7

    goto/16 :goto_7

    :cond_1e
    move v6, v7

    goto/16 :goto_6

    :cond_1f
    #v0=(Reference);v3=(Reference);v7=(Conflicted);
    move v3, v5

    #v3=(Integer);
    goto/16 :goto_5

    :cond_20
    #v3=(Reference);v6=(Conflicted);
    move v6, v11

    #v6=(Integer);
    goto/16 :goto_4
.end method

.method protected final b(Landroid/graphics/Canvas;)V
    .locals 11
    .parameter

    .prologue
    const/4 v10, 0x0

    #v10=(Null);
    const/4 v1, 0x0

    .line 138
    #v1=(Null);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/aw;->EN:Z

    #v0=(Boolean);
    const/4 v2, 0x1

    #v2=(One);
    if-ne v0, v2, :cond_1

    .line 187
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Integer);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    return-void

    .line 142
    :cond_1
    #v0=(Boolean);v1=(Null);v2=(One);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    if-lez v3, :cond_3

    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bo;->ix()Landroid/graphics/Point;

    move-result-object v4

    #v4=(Reference);
    move v2, v1

    :goto_1
    #v0=(Conflicted);v2=(Integer);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    if-ge v2, v3, :cond_3

    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    if-eqz v0, :cond_2

    iget-boolean v5, v0, Lcom/tencent/mapapi/map/ac;->ES:Z

    #v5=(Boolean);
    if-eqz v5, :cond_2

    iget-object v5, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    #v5=(Reference);
    if-eqz v5, :cond_2

    iget v6, v0, Lcom/tencent/mapapi/map/ac;->h:F

    #v6=(Integer);
    new-instance v7, Landroid/graphics/Matrix;

    #v7=(UninitRef);
    invoke-direct {v7}, Landroid/graphics/Matrix;-><init>()V

    #v7=(Reference);
    iget v8, v4, Landroid/graphics/Point;->x:I

    #v8=(Integer);
    int-to-float v8, v8

    #v8=(Float);
    iget v9, v4, Landroid/graphics/Point;->y:I

    #v9=(Integer);
    int-to-float v9, v9

    #v9=(Float);
    invoke-virtual {v7, v6, v6, v8, v9}, Landroid/graphics/Matrix;->setScale(FFFF)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p1, v7}, Landroid/graphics/Canvas;->concat(Landroid/graphics/Matrix;)V

    iget v6, v0, Lcom/tencent/mapapi/map/ac;->EP:F

    iget v0, v0, Lcom/tencent/mapapi/map/ac;->EQ:F

    #v0=(Integer);
    invoke-virtual {p1, v5, v6, v0, v10}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    :cond_2
    #v0=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    add-int/lit8 v0, v2, 0x1

    #v0=(Integer);
    move v2, v0

    goto :goto_1

    .line 143
    :cond_3
    #v0=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/aw;->Da:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 147
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    .line 148
    #v3=(Integer);
    if-lez v3, :cond_0

    .line 153
    new-instance v2, Landroid/graphics/Matrix;

    #v2=(UninitRef);
    invoke-direct {v2}, Landroid/graphics/Matrix;-><init>()V

    .line 154
    #v2=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    iget v0, v0, Lcom/tencent/mapapi/map/ac;->CR:I

    .line 155
    #v0=(Integer);
    iget-object v4, p0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iget v4, v4, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v4=(Integer);
    sub-int v0, v4, v0

    .line 156
    const-wide/high16 v4, 0x4000

    #v4=(LongLo);v5=(LongHi);
    int-to-double v6, v0

    #v6=(DoubleLo);v7=(DoubleHi);
    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    double-to-float v0, v4

    .line 158
    #v0=(Float);
    iget-object v4, p0, Lcom/tencent/mapapi/map/aw;->Ec:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bo;->ix()Landroid/graphics/Point;

    move-result-object v4

    .line 159
    iget v5, v4, Landroid/graphics/Point;->x:I

    #v5=(Integer);
    int-to-float v5, v5

    #v5=(Float);
    iget v4, v4, Landroid/graphics/Point;->y:I

    #v4=(Integer);
    int-to-float v4, v4

    #v4=(Float);
    invoke-virtual {v2, v0, v0, v5, v4}, Landroid/graphics/Matrix;->setScale(FFFF)V

    .line 160
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 161
    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->concat(Landroid/graphics/Matrix;)V

    .line 167
    :goto_2
    #v0=(Integer);v1=(Integer);v4=(Integer);
    if-ge v1, v3, :cond_6

    .line 168
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    .line 169
    if-eqz v0, :cond_5

    .line 170
    iget-object v2, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 173
    if-nez v2, :cond_4

    .line 175
    invoke-virtual {p0, v0}, Lcom/tencent/mapapi/map/aw;->a(Lcom/tencent/mapapi/map/ac;)V

    .line 176
    iget-object v2, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    .line 178
    :cond_4
    if-eqz v2, :cond_5

    .line 180
    iget v4, v0, Lcom/tencent/mapapi/map/ac;->EP:F

    iget v0, v0, Lcom/tencent/mapapi/map/ac;->EQ:F

    #v0=(Integer);
    invoke-virtual {p1, v2, v4, v0, v10}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 181
    :cond_5
    #v0=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_2

    .line 186
    :cond_6
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    goto/16 :goto_0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2
    .parameter

    .prologue
    .line 42
    if-ne p0, p1, :cond_0

    .line 43
    const/4 v0, 0x1

    .line 50
    :goto_0
    #v0=(Boolean);v1=(Conflicted);
    return v0

    .line 45
    :cond_0
    #v0=(Uninit);v1=(Uninit);
    instance-of v0, p1, Lcom/tencent/mapapi/map/aw;

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 46
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0

    .line 48
    :cond_1
    #v0=(Boolean);
    check-cast p1, Lcom/tencent/mapapi/map/aw;

    .line 50
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fw:Ljava/lang/String;

    #v0=(Reference);
    iget-object v1, p1, Lcom/tencent/mapapi/map/aw;->Fw:Ljava/lang/String;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method protected final hB()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 78
    #v1=(Null);
    invoke-super {p0}, Lcom/tencent/mapapi/map/ad;->hB()V

    .line 79
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->EU:Lcom/tencent/mapapi/map/bc;

    #v0=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bc;->a(Lcom/tencent/mapapi/map/an;)V

    .line 81
    iget-object v1, p0, Lcom/tencent/mapapi/map/aw;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    .line 83
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 84
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    .line 85
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 86
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    .line 87
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Reference);
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method protected final hC()V
    .locals 3

    .prologue
    const/4 v2, 0x1

    .line 191
    #v2=(One);
    iget-boolean v0, p0, Lcom/tencent/mapapi/map/aw;->Fv:Z

    #v0=(Boolean);
    if-ne v0, v2, :cond_1

    .line 204
    :cond_0
    :goto_0
    #v1=(Conflicted);
    return-void

    .line 194
    :cond_1
    #v1=(Uninit);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/aw;->ij()Lcom/tencent/mapapi/map/aa;

    move-result-object v1

    .line 195
    #v1=(Reference);
    if-eqz v1, :cond_0

    .line 198
    if-nez v1, :cond_2

    const/4 v0, 0x0

    .line 199
    :goto_1
    if-ne v0, v2, :cond_3

    .line 200
    invoke-virtual {p0, v1}, Lcom/tencent/mapapi/map/aw;->a(Lcom/tencent/mapapi/map/aa;)V

    goto :goto_0

    .line 198
    :cond_2
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->EU:Lcom/tencent/mapapi/map/bc;

    #v0=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bc;->d(Lcom/tencent/mapapi/map/aa;)Z

    move-result v0

    #v0=(Boolean);
    invoke-direct {p0, v1}, Lcom/tencent/mapapi/map/aw;->c(Lcom/tencent/mapapi/map/aa;)Z

    goto :goto_1

    .line 202
    :cond_3
    const/4 v0, 0x0

    #v0=(Null);
    invoke-virtual {p0, v1, v0}, Lcom/tencent/mapapi/map/aw;->a(Lcom/tencent/mapapi/map/aa;Ljava/util/ArrayList;)V

    goto :goto_0
.end method

.method public final hashCode()I
    .locals 1

    .prologue
    .line 56
    iget v0, p0, Lcom/tencent/mapapi/map/aw;->p:I

    #v0=(Integer);
    return v0
.end method

.method protected final hw()V
    .locals 2

    .prologue
    .line 68
    invoke-super {p0}, Lcom/tencent/mapapi/map/ad;->hw()V

    .line 69
    iget-object v1, p0, Lcom/tencent/mapapi/map/aw;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    .line 71
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 72
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 73
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method protected final ia()V
    .locals 1

    .prologue
    .line 659
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->EV:Ljava/util/List;

    .line 661
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    .line 662
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    .line 663
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fr:Ljava/util/List;

    .line 664
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->EW:Ljava/util/List;

    .line 666
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fs:Ljava/util/List;

    .line 667
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->EX:Ljava/util/List;

    .line 668
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->EY:Ljava/util/List;

    .line 670
    const/4 v0, 0x0

    #v0=(Null);
    new-array v0, v0, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/aw;->CY:[B

    .line 671
    return-void
.end method

.method protected final id()I
    .locals 1

    .prologue
    .line 676
    const/16 v0, 0x10

    #v0=(PosByte);
    return v0
.end method

.method protected final ie()V
    .locals 5

    .prologue
    const/4 v1, 0x0

    .line 682
    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 726
    :goto_0
    #v1=(Integer);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 687
    :cond_0
    #v1=(Null);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    .line 688
    #v3=(Integer);
    if-lez v3, :cond_2

    move v2, v1

    .line 690
    :goto_1
    #v0=(Conflicted);v2=(Integer);v4=(Conflicted);
    if-ge v2, v3, :cond_2

    .line 691
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    .line 692
    if-eqz v0, :cond_1

    .line 693
    iget-object v4, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    #v4=(Reference);
    if-eqz v4, :cond_1

    .line 697
    iget-object v4, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    invoke-interface {v4, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v4

    #v4=(Boolean);
    if-nez v4, :cond_1

    .line 701
    iget-object v4, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    #v4=(Reference);
    invoke-interface {v4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 690
    :cond_1
    #v4=(Conflicted);
    add-int/lit8 v0, v2, 0x1

    #v0=(Integer);
    move v2, v0

    goto :goto_1

    .line 706
    :cond_2
    #v0=(Conflicted);v2=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    .line 707
    #v2=(Integer);
    if-lez v2, :cond_4

    .line 709
    :goto_2
    #v0=(Conflicted);v1=(Integer);v3=(Conflicted);
    if-ge v1, v2, :cond_4

    .line 710
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ac;

    .line 711
    if-eqz v0, :cond_3

    .line 712
    iget-object v3, v0, Lcom/tencent/mapapi/map/ac;->ER:Landroid/graphics/Bitmap;

    #v3=(Reference);
    if-eqz v3, :cond_3

    .line 716
    iget-object v3, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_3

    .line 720
    iget-object v3, p0, Lcom/tencent/mapapi/map/aw;->Fp:Ljava/util/List;

    #v3=(Reference);
    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 709
    :cond_3
    #v3=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_2

    .line 724
    :cond_4
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->EV:Ljava/util/List;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mapapi/map/aw;->b(Ljava/util/List;)V

    .line 725
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fq:Ljava/util/List;

    invoke-static {v0}, Lcom/tencent/mapapi/map/aw;->b(Ljava/util/List;)V

    goto :goto_0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .prologue
    .line 62
    iget-object v0, p0, Lcom/tencent/mapapi/map/aw;->Fw:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

*/}
