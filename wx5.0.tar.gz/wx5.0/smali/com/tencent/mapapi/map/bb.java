package com.tencent.mapapi.map; class bb {/*

.class Lcom/tencent/mapapi/map/bb;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public EB:I

.field public EC:I

.field public Em:Z

.field public FA:J

.field public FB:Ljava/lang/String;

.field protected FC:Z

.field public FD:Lcom/tencent/mapapi/map/ae;

.field public Fw:Ljava/lang/String;

.field public Fx:Z

.field public Fy:Z

.field public Fz:Z

.field public p:I

.field public r:I


# direct methods
.method public constructor <init>()V
    .locals 4

    .prologue
    const/4 v3, 0x3

    #v3=(PosByte);
    const/4 v2, 0x0

    .line 713
    #v2=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 739
    #p0=(Reference);
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    .line 744
    const/16 v0, 0x14

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mapapi/map/bb;->EB:I

    .line 749
    iput v3, p0, Lcom/tencent/mapapi/map/bb;->EC:I

    .line 754
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bb;->Fx:Z

    .line 759
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bb;->Em:Z

    .line 764
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bb;->Fy:Z

    .line 769
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bb;->Fz:Z

    .line 775
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/bb;->FA:J

    .line 780
    const/4 v0, -0x1

    #v0=(Byte);
    iput v0, p0, Lcom/tencent/mapapi/map/bb;->p:I

    .line 785
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bb;->FB:Ljava/lang/String;

    .line 787
    iput v3, p0, Lcom/tencent/mapapi/map/bb;->r:I

    .line 789
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bb;->FC:Z

    .line 794
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bb;->FD:Lcom/tencent/mapapi/map/ae;

    .line 714
    return-void
.end method


# virtual methods
.method final a(Lcom/tencent/mapapi/map/bb;)V
    .locals 3
    .parameter

    .prologue
    .line 717
    iget-object v0, p1, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    .line 718
    iget v0, p1, Lcom/tencent/mapapi/map/bb;->EB:I

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mapapi/map/bb;->EB:I

    .line 719
    iget v0, p1, Lcom/tencent/mapapi/map/bb;->EC:I

    iput v0, p0, Lcom/tencent/mapapi/map/bb;->EC:I

    .line 720
    iget-boolean v0, p1, Lcom/tencent/mapapi/map/bb;->Fx:Z

    #v0=(Boolean);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bb;->Fx:Z

    .line 721
    iget-boolean v0, p1, Lcom/tencent/mapapi/map/bb;->Em:Z

    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bb;->Em:Z

    .line 722
    iget-boolean v0, p1, Lcom/tencent/mapapi/map/bb;->Fy:Z

    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bb;->Fy:Z

    .line 723
    iget-boolean v0, p1, Lcom/tencent/mapapi/map/bb;->Fz:Z

    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bb;->Fz:Z

    .line 724
    iget-wide v0, p1, Lcom/tencent/mapapi/map/bb;->FA:J

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/bb;->FA:J

    .line 725
    iget v0, p1, Lcom/tencent/mapapi/map/bb;->p:I

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mapapi/map/bb;->p:I

    .line 726
    iget-object v0, p1, Lcom/tencent/mapapi/map/bb;->FB:Ljava/lang/String;

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bb;->FB:Ljava/lang/String;

    .line 727
    iget v0, p1, Lcom/tencent/mapapi/map/bb;->r:I

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mapapi/map/bb;->r:I

    .line 728
    iget-boolean v0, p1, Lcom/tencent/mapapi/map/bb;->FC:Z

    #v0=(Boolean);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/bb;->FC:Z

    .line 730
    iget-object v0, p1, Lcom/tencent/mapapi/map/bb;->FD:Lcom/tencent/mapapi/map/ae;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 731
    iget-object v0, p1, Lcom/tencent/mapapi/map/bb;->FD:Lcom/tencent/mapapi/map/ae;

    iget-object v1, p1, Lcom/tencent/mapapi/map/bb;->FD:Lcom/tencent/mapapi/map/ae;

    #v1=(Reference);
    new-instance v2, Lcom/tencent/mapapi/map/af;

    #v2=(UninitRef);
    invoke-direct {v2, v0, v1}, Lcom/tencent/mapapi/map/af;-><init>(Lcom/tencent/mapapi/map/ae;Lcom/tencent/mapapi/map/ae;)V

    #v2=(Reference);
    iput-object v2, p0, Lcom/tencent/mapapi/map/bb;->FD:Lcom/tencent/mapapi/map/ae;

    .line 734
    :cond_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void
.end method

*/}
