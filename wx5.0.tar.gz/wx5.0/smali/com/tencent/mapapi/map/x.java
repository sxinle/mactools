package com.tencent.mapapi.map; class x {/*

.class interface abstract Lcom/tencent/mapapi/map/x;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract hw()V
.end method

*/}
