package com.tencent.mapapi.map; class av {/*

.class interface abstract Lcom/tencent/mapapi/map/av;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract hC()V
.end method

.method public abstract ii()Ljava/lang/Boolean;
.end method

*/}
