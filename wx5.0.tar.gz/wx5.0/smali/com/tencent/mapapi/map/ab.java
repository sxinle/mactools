package com.tencent.mapapi.map; class ab {/*

.class Lcom/tencent/mapapi/map/ab;
.super Lcom/tencent/mapapi/map/aa;
.source "SourceFile"


# instance fields
.field public EP:F

.field public EQ:F


# direct methods
.method public constructor <init>(III)V
    .locals 1
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 41
    #v0=(Null);
    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/mapapi/map/aa;-><init>(III)V

    .line 36
    #p0=(Reference);
    iput v0, p0, Lcom/tencent/mapapi/map/ab;->EP:F

    .line 37
    iput v0, p0, Lcom/tencent/mapapi/map/ab;->EQ:F

    .line 42
    return-void
.end method

*/}
