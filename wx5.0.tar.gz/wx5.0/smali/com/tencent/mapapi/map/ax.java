package com.tencent.mapapi.map; class ax {/*

.class interface abstract Lcom/tencent/mapapi/map/ax;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract onDestroy()V
.end method

.method public abstract onPause()V
.end method

.method public abstract onRestart()V
.end method

.method public abstract onResume()V
.end method

.method public abstract onStop()V
.end method

*/}
