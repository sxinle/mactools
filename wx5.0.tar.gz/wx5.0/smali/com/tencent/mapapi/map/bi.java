package com.tencent.mapapi.map; class bi {/*

.class public final Lcom/tencent/mapapi/map/bi;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public CP:Ljava/util/List;

.field public CQ:Ljava/util/List;

.field public FR:Ljava/util/List;

.field private FS:Ljava/util/List;

.field FT:[B

.field FU:[B

.field public FV:Z

.field public FW:Lcom/tencent/mapapi/map/bs;

.field private final FX:Ljava/lang/String;

.field private final FY:Ljava/lang/String;

.field private FZ:Landroid/graphics/Matrix;

.field public Fv:Z

.field final synthetic Ga:Lcom/tencent/mapapi/map/bh;

.field private m:I


# direct methods
.method public constructor <init>(Lcom/tencent/mapapi/map/bh;Landroid/content/Context;)V
    .locals 8
    .parameter
    .parameter

    .prologue
    const/high16 v7, 0x4380

    #v7=(Integer);
    const v6, 0x3f19999a

    #v6=(Integer);
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v1, 0x1

    .line 281
    #v1=(One);
    iput-object p1, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 263
    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    .line 264
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    .line 265
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    .line 266
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FS:Ljava/util/List;

    .line 268
    new-array v0, v2, [B

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FT:[B

    .line 269
    new-array v0, v2, [B

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FU:[B

    .line 270
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bi;->FV:Z

    .line 271
    iput-boolean v2, p0, Lcom/tencent/mapapi/map/bi;->Fv:Z

    .line 272
    sget-object v0, Lcom/tencent/mapapi/map/bs;->GB:Lcom/tencent/mapapi/map/bs;

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FW:Lcom/tencent/mapapi/map/bs;

    .line 274
    const-string v0, "http://pwh.map.qq.com/ih?dt=tile&rt=m256&c=%s"

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FX:Ljava/lang/String;

    .line 277
    const-string v0, "http://rtt.map.soso.com/m?c=%s&sp=128x2"

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FY:Ljava/lang/String;

    .line 319
    iput v2, p0, Lcom/tencent/mapapi/map/bi;->m:I

    .line 907
    new-instance v0, Landroid/graphics/Matrix;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FZ:Landroid/graphics/Matrix;

    .line 282
    if-nez p2, :cond_0

    .line 317
    :goto_0
    #v1=(PosByte);v2=(Reference);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-void

    .line 285
    :cond_0
    #v1=(One);v2=(Null);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    new-instance v3, Landroid/util/DisplayMetrics;

    #v3=(UninitRef);
    invoke-direct {v3}, Landroid/util/DisplayMetrics;-><init>()V

    .line 286
    #v3=(Reference);
    const-string v0, "window"

    invoke-virtual {p2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    .line 288
    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V

    .line 293
    iget v0, v3, Landroid/util/DisplayMetrics;->widthPixels:I

    #v0=(Integer);
    iget v3, v3, Landroid/util/DisplayMetrics;->heightPixels:I

    #v3=(Integer);
    int-to-float v4, v0

    #v4=(Float);
    div-float/2addr v4, v6

    div-float/2addr v4, v7

    float-to-int v4, v4

    #v4=(Integer);
    add-int/lit8 v4, v4, 0x2

    int-to-float v5, v3

    #v5=(Float);
    div-float/2addr v5, v6

    div-float/2addr v5, v7

    float-to-int v5, v5

    #v5=(Integer);
    add-int/lit8 v5, v5, 0x2

    mul-int/2addr v4, v5

    div-int/lit16 v0, v0, 0x100

    add-int/lit8 v0, v0, 0x1

    div-int/lit16 v3, v3, 0x100

    add-int/lit8 v3, v3, 0x1

    mul-int/2addr v0, v3

    add-int/2addr v0, v4

    iput v0, p0, Lcom/tencent/mapapi/map/bi;->m:I

    .line 294
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_1

    .line 297
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    .line 299
    :cond_1
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    if-nez v0, :cond_2

    .line 301
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    .line 303
    :cond_2
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    if-eqz v0, :cond_3

    sget-object v0, Lcom/tencent/mapapi/map/bq;->EA:Lcom/tencent/mapapi/map/br;

    sget-object v3, Lcom/tencent/mapapi/map/br;->Gw:Lcom/tencent/mapapi/map/br;

    #v3=(Reference);
    if-eq v0, v3, :cond_3

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    invoke-static {v0}, Lcom/tencent/mapapi/map/bl;->a(Lcom/tencent/mapapi/map/bl;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mapapi/map/bq;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Lcom/tencent/mapapi/map/au;

    #v3=(UninitRef);
    invoke-direct {v3, v0}, Lcom/tencent/mapapi/map/au;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    iput-object v0, v3, Lcom/tencent/mapapi/map/au;->Fo:Lcom/tencent/mapapi/map/bl;

    iget-object v4, p0, Lcom/tencent/mapapi/map/bi;->FU:[B

    #v4=(Reference);
    monitor-enter v4

    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 305
    :cond_3
    #v3=(Conflicted);v4=(Conflicted);
    iget-object v0, p1, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bl;->FK:Lcom/tencent/mapapi/map/be;

    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/be;->aj(I)V

    .line 310
    sget-object v0, Lcom/tencent/mapapi/map/bq;->Gv:Lcom/tencent/mapapi/map/bs;

    sget-object v3, Lcom/tencent/mapapi/map/bs;->GA:Lcom/tencent/mapapi/map/bs;

    #v3=(Reference);
    if-ne v0, v3, :cond_5

    move v0, v1

    .line 314
    :goto_1
    #v0=(Boolean);
    if-ne v0, v1, :cond_4

    iget-object v1, p0, Lcom/tencent/mapapi/map/bi;->FT:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_1
    const-string v0, "map_raster"

    #v0=(Reference);
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/bi;->ac(Ljava/lang/String;)Z

    new-instance v0, Lcom/tencent/mapapi/map/bb;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mapapi/map/bb;-><init>()V

    #v0=(Reference);
    new-instance v2, Lcom/tencent/mapapi/map/bj;

    #v2=(UninitRef);
    invoke-direct {v2, p0}, Lcom/tencent/mapapi/map/bj;-><init>(Lcom/tencent/mapapi/map/bi;)V

    #v2=(Reference);
    iput-object v2, v0, Lcom/tencent/mapapi/map/bb;->FD:Lcom/tencent/mapapi/map/ae;

    const-string v2, "map_google"

    iput-object v2, v0, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    const/4 v2, 0x1

    #v2=(One);
    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->Fx:Z

    const/4 v2, 0x1

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->Em:Z

    const/4 v2, 0x1

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->Fy:Z

    const/16 v2, 0x12

    #v2=(PosByte);
    iput v2, v0, Lcom/tencent/mapapi/map/bb;->EB:I

    const/4 v2, 0x2

    iput v2, v0, Lcom/tencent/mapapi/map/bb;->EC:I

    const/4 v2, 0x1

    #v2=(One);
    iput v2, v0, Lcom/tencent/mapapi/map/bb;->r:I

    const/4 v2, 0x1

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->FC:Z

    iget-object v2, p0, Lcom/tencent/mapapi/map/bi;->FT:[B

    #v2=(Reference);
    monitor-enter v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/bi;->b(Lcom/tencent/mapapi/map/bb;)Z

    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    sget-object v0, Lcom/tencent/mapapi/map/bs;->GA:Lcom/tencent/mapapi/map/bs;

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FW:Lcom/tencent/mapapi/map/bs;

    .line 316
    :goto_2
    iget-object v0, p1, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bl;->FK:Lcom/tencent/mapapi/map/be;

    const/16 v1, 0xa

    #v1=(PosByte);
    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/be;->aj(I)V

    goto/16 :goto_0

    .line 303
    :catchall_0
    #v1=(One);v2=(Null);v4=(Reference);
    move-exception v0

    monitor-exit v4

    throw v0

    .line 314
    :catchall_1
    #v1=(Reference);v2=(Reference);v4=(Conflicted);
    move-exception v0

    :try_start_4
    monitor-exit v2

    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :catchall_2
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    :cond_4
    #v0=(Boolean);v1=(One);v2=(Null);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bi;->FT:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_5
    const-string v0, "map_google"

    #v0=(Reference);
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/bi;->ac(Ljava/lang/String;)Z

    new-instance v0, Lcom/tencent/mapapi/map/bb;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mapapi/map/bb;-><init>()V

    #v0=(Reference);
    new-instance v2, Lcom/tencent/mapapi/map/bk;

    #v2=(UninitRef);
    invoke-direct {v2, p0}, Lcom/tencent/mapapi/map/bk;-><init>(Lcom/tencent/mapapi/map/bi;)V

    #v2=(Reference);
    iput-object v2, v0, Lcom/tencent/mapapi/map/bb;->FD:Lcom/tencent/mapapi/map/ae;

    const-string v2, "map_raster"

    iput-object v2, v0, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    const/4 v2, 0x1

    #v2=(One);
    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->Fx:Z

    const/4 v2, 0x1

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->Em:Z

    const/4 v2, 0x1

    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->Fy:Z

    const/16 v2, 0x12

    #v2=(PosByte);
    iput v2, v0, Lcom/tencent/mapapi/map/bb;->EB:I

    const/4 v2, 0x2

    iput v2, v0, Lcom/tencent/mapapi/map/bb;->EC:I

    const/4 v2, 0x3

    iput v2, v0, Lcom/tencent/mapapi/map/bb;->r:I

    const/4 v2, 0x0

    #v2=(Null);
    iput-boolean v2, v0, Lcom/tencent/mapapi/map/bb;->FC:Z

    iget-object v2, p0, Lcom/tencent/mapapi/map/bi;->FT:[B

    #v2=(Reference);
    monitor-enter v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    :try_start_6
    invoke-direct {p0, v0}, Lcom/tencent/mapapi/map/bi;->b(Lcom/tencent/mapapi/map/bb;)Z

    monitor-exit v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :try_start_7
    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    sget-object v0, Lcom/tencent/mapapi/map/bs;->GB:Lcom/tencent/mapapi/map/bs;

    iput-object v0, p0, Lcom/tencent/mapapi/map/bi;->FW:Lcom/tencent/mapapi/map/bs;

    goto :goto_2

    :catchall_3
    move-exception v0

    :try_start_8
    monitor-exit v2

    throw v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    :catchall_4
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    :cond_5
    #v1=(One);v2=(Null);
    move v0, v2

    #v0=(Null);
    goto/16 :goto_1
.end method

.method private ac(Ljava/lang/String;)Z
    .locals 6
    .parameter

    .prologue
    const/4 v2, 0x1

    #v2=(One);
    const/4 v1, 0x0

    .line 681
    #v1=(Null);
    const-string v0, ""

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-ne v0, v2, :cond_0

    move v0, v1

    .line 703
    :goto_0
    #v1=(Reference);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    .line 684
    :cond_0
    #v1=(Null);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-direct {p0, p1, v1}, Lcom/tencent/mapapi/map/bi;->b(Ljava/lang/String;Z)Z

    .line 686
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    #v4=(Integer);
    move v3, v1

    .line 687
    :goto_1
    #v0=(Conflicted);v3=(Integer);v5=(Conflicted);
    if-ge v3, v4, :cond_2

    .line 689
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    .line 690
    if-eqz v0, :cond_1

    .line 691
    iget-object v5, v0, Lcom/tencent/mapapi/map/ba;->Fw:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v5, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    #v5=(Boolean);
    if-eqz v5, :cond_1

    .line 694
    iput-boolean v1, v0, Lcom/tencent/mapapi/map/ba;->Em:Z

    .line 695
    iget-object v1, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v1=(Reference);
    invoke-interface {v1, v0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 696
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/ba;->hB()V

    .line 697
    invoke-direct {p0}, Lcom/tencent/mapapi/map/bi;->in()V

    move v0, v2

    .line 698
    #v0=(One);
    goto :goto_0

    .line 687
    :cond_1
    #v0=(Reference);v1=(Null);v5=(Conflicted);
    add-int/lit8 v0, v3, 0x1

    #v0=(Integer);
    move v3, v0

    goto :goto_1

    :cond_2
    #v0=(Conflicted);
    move v0, v1

    .line 703
    #v0=(Null);
    goto :goto_0
.end method

.method private b(Lcom/tencent/mapapi/map/bb;)Z
    .locals 8
    .parameter

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x1

    .line 620
    #v3=(One);
    if-nez p1, :cond_1

    move v0, v2

    .line 677
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Boolean);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return v0

    .line 624
    :cond_1
    #v0=(Uninit);v1=(Uninit);v2=(Null);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);
    iget-object v0, p1, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    #v0=(Reference);
    const-string v1, ""

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-ne v0, v3, :cond_2

    move v0, v2

    .line 625
    #v0=(Null);
    goto :goto_0

    .line 627
    :cond_2
    #v0=(Boolean);
    iget-object v4, p1, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    #v4=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    #v5=(Integer);
    move v1, v2

    :goto_1
    #v0=(Conflicted);v1=(Integer);
    if-ge v1, v5, :cond_4

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    if-eqz v0, :cond_3

    iget-object v0, v0, Lcom/tencent/mapapi/map/ba;->Fw:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-ne v0, v3, :cond_3

    move v0, v3

    .line 628
    :goto_2
    #v1=(Conflicted);v5=(Conflicted);
    if-ne v0, v3, :cond_5

    move v0, v2

    .line 629
    #v0=(Null);
    goto :goto_0

    .line 627
    :cond_3
    #v0=(Conflicted);v1=(Integer);v5=(Integer);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    :cond_4
    #v0=(Conflicted);v1=(Conflicted);v5=(Conflicted);
    move v0, v2

    #v0=(Null);
    goto :goto_2

    .line 632
    :cond_5
    #v0=(Boolean);
    iget-object v0, p1, Lcom/tencent/mapapi/map/bb;->Fw:Ljava/lang/String;

    #v0=(Reference);
    const-string v1, "trafficmap_raster"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_8

    .line 635
    new-instance v0, Lcom/tencent/mapapi/map/aw;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mapapi/map/aw;-><init>()V

    #v0=(Reference);
    move-object v1, v0

    .line 641
    :goto_3
    invoke-virtual {v1, p1}, Lcom/tencent/mapapi/map/ad;->a(Lcom/tencent/mapapi/map/bb;)V

    .line 642
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    invoke-virtual {v1, v0}, Lcom/tencent/mapapi/map/ad;->a(Lcom/tencent/mapapi/map/bh;)V

    .line 643
    new-instance v0, Lcom/tencent/mapapi/map/an;

    #v0=(UninitRef);
    iget v4, p0, Lcom/tencent/mapapi/map/bi;->m:I

    #v4=(Integer);
    iget-boolean v5, v1, Lcom/tencent/mapapi/map/ad;->Fz:Z

    #v5=(Boolean);
    iget-wide v6, v1, Lcom/tencent/mapapi/map/ad;->FA:J

    #v6=(LongLo);v7=(LongHi);
    invoke-direct {v0, v4, v5, v6, v7}, Lcom/tencent/mapapi/map/an;-><init>(IZJ)V

    #v0=(Reference);
    iput-object v0, v1, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    .line 646
    new-instance v0, Lcom/tencent/mapapi/map/bc;

    #v0=(UninitRef);
    iget-object v4, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bl;->ip()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v0, v4, v1}, Lcom/tencent/mapapi/map/bc;-><init>(Landroid/content/Context;Lcom/tencent/mapapi/map/bb;)V

    #v0=(Reference);
    iput-object v0, v1, Lcom/tencent/mapapi/map/ad;->EU:Lcom/tencent/mapapi/map/bc;

    .line 649
    iget-object v0, v1, Lcom/tencent/mapapi/map/ad;->EU:Lcom/tencent/mapapi/map/bc;

    iget-object v4, v1, Lcom/tencent/mapapi/map/ad;->ET:Lcom/tencent/mapapi/map/an;

    invoke-virtual {v0, v4}, Lcom/tencent/mapapi/map/bc;->a(Lcom/tencent/mapapi/map/an;)V

    .line 651
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/ad;->ia()V

    .line 653
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 654
    #v0=(Integer);
    iget-boolean v4, v1, Lcom/tencent/mapapi/map/ad;->Fx:Z

    #v4=(Boolean);
    if-eqz v4, :cond_6

    if-nez v0, :cond_9

    .line 655
    :cond_6
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v0

    .line 673
    :cond_7
    :goto_4
    #v0=(Boolean);v4=(Integer);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/bi;->in()V

    .line 674
    iget-boolean v2, v1, Lcom/tencent/mapapi/map/ad;->Em:Z

    #v2=(Boolean);
    if-ne v2, v3, :cond_0

    .line 675
    iget-object v1, v1, Lcom/tencent/mapapi/map/ad;->Fw:Ljava/lang/String;

    invoke-direct {p0, v1, v3}, Lcom/tencent/mapapi/map/bi;->b(Ljava/lang/String;Z)Z

    goto/16 :goto_0

    .line 639
    :cond_8
    #v2=(Null);v4=(Reference);v5=(Conflicted);v6=(Uninit);v7=(Uninit);
    new-instance v0, Lcom/tencent/mapapi/map/ad;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mapapi/map/ad;-><init>()V

    #v0=(Reference);
    move-object v1, v0

    goto :goto_3

    .line 658
    :cond_9
    #v0=(Integer);v4=(Boolean);v5=(Boolean);v6=(LongLo);v7=(LongHi);
    add-int/lit8 v0, v0, -0x1

    move v4, v0

    :goto_5
    #v4=(Integer);
    if-ltz v4, :cond_b

    .line 659
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    .line 660
    if-eqz v0, :cond_a

    .line 661
    iget-boolean v0, v0, Lcom/tencent/mapapi/map/ba;->Fx:Z

    #v0=(Boolean);
    if-nez v0, :cond_a

    .line 664
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v4, v1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    move v0, v3

    .line 669
    :goto_6
    #v0=(Boolean);
    if-nez v0, :cond_7

    .line 670
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_4

    .line 658
    :cond_a
    #v0=(Conflicted);
    add-int/lit8 v0, v4, -0x1

    #v0=(Integer);
    move v4, v0

    goto :goto_5

    :cond_b
    move v0, v2

    #v0=(Null);
    goto :goto_6
.end method

.method private b(Ljava/lang/String;Z)Z
    .locals 6
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v2, 0x1

    .line 537
    #v2=(One);
    const-string v0, ""

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-ne v0, v2, :cond_0

    move v0, v1

    .line 577
    :goto_0
    #v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    .line 541
    :cond_0
    #v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    #v4=(Integer);
    move v3, v1

    .line 542
    :goto_1
    #v0=(Conflicted);v3=(Integer);v5=(Conflicted);
    if-ge v3, v4, :cond_9

    .line 543
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    .line 544
    if-eqz v0, :cond_8

    .line 545
    iget-object v5, v0, Lcom/tencent/mapapi/map/ba;->Fw:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v5, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    #v5=(Boolean);
    if-ne v5, v2, :cond_8

    .line 548
    iput-boolean p2, v0, Lcom/tencent/mapapi/map/ba;->Em:Z

    .line 549
    iget-boolean v5, v0, Lcom/tencent/mapapi/map/ba;->Fx:Z

    if-nez v5, :cond_1

    move v0, v2

    .line 550
    #v0=(One);
    goto :goto_0

    .line 553
    :cond_1
    #v0=(Reference);
    if-ne p2, v2, :cond_8

    .line 554
    iget v3, v0, Lcom/tencent/mapapi/map/ba;->EB:I

    iget v4, v0, Lcom/tencent/mapapi/map/ba;->EC:I

    if-le v3, v4, :cond_5

    .line 556
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    iget v4, v0, Lcom/tencent/mapapi/map/ba;->EB:I

    if-lez v4, :cond_2

    iget-object v3, v3, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iput v4, v3, Lcom/tencent/mapapi/map/bo;->CS:I

    .line 558
    :cond_2
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    iget v4, v0, Lcom/tencent/mapapi/map/ba;->EC:I

    if-lez v4, :cond_3

    iget-object v3, v3, Lcom/tencent/mapapi/map/bm;->Gn:Lcom/tencent/mapapi/map/bh;

    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    iput v4, v3, Lcom/tencent/mapapi/map/bo;->CR:I

    .line 560
    :cond_3
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bo;->hB()V

    .line 561
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v3

    #v3=(Integer);
    iget v4, v0, Lcom/tencent/mapapi/map/ba;->EB:I

    if-le v3, v4, :cond_4

    .line 563
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    iget v4, v0, Lcom/tencent/mapapi/map/ba;->EB:I

    invoke-virtual {v3, v4}, Lcom/tencent/mapapi/map/bm;->aj(I)V

    .line 565
    :cond_4
    #v3=(Conflicted);
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v3

    #v3=(Integer);
    iget v4, v0, Lcom/tencent/mapapi/map/ba;->EC:I

    if-ge v3, v4, :cond_5

    .line 567
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    iget v0, v0, Lcom/tencent/mapapi/map/ba;->EC:I

    #v0=(Integer);
    invoke-virtual {v3, v0}, Lcom/tencent/mapapi/map/bm;->aj(I)V

    .line 570
    :cond_5
    #v0=(Conflicted);v3=(Conflicted);
    const-string v0, ""

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eq v0, v2, :cond_7

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    move v3, v1

    :goto_2
    #v0=(Conflicted);v3=(Integer);
    if-ge v3, v4, :cond_7

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    if-eqz v0, :cond_6

    iget-object v5, v0, Lcom/tencent/mapapi/map/ba;->Fw:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v5, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    #v5=(Boolean);
    if-nez v5, :cond_6

    iget-boolean v5, v0, Lcom/tencent/mapapi/map/ba;->Fx:Z

    if-ne v5, v2, :cond_6

    iget-boolean v5, v0, Lcom/tencent/mapapi/map/ba;->Em:Z

    if-ne v5, v2, :cond_6

    iput-boolean v1, v0, Lcom/tencent/mapapi/map/ba;->Em:Z

    :cond_6
    add-int/lit8 v0, v3, 0x1

    #v0=(Integer);
    move v3, v0

    goto :goto_2

    .line 571
    :cond_7
    #v0=(Conflicted);v3=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    move v0, v2

    .line 573
    #v0=(One);
    goto/16 :goto_0

    .line 542
    :cond_8
    #v0=(Reference);v3=(Integer);v5=(Conflicted);
    add-int/lit8 v0, v3, 0x1

    #v0=(Integer);
    move v3, v0

    goto/16 :goto_1

    :cond_9
    #v0=(Conflicted);
    move v0, v1

    .line 577
    #v0=(Null);
    goto/16 :goto_0
.end method

.method private in()V
    .locals 3

    .prologue
    .line 707
    .line 708
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    .line 709
    #v2=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_0
    #v0=(Integer);v1=(Integer);
    if-ge v1, v2, :cond_1

    .line 710
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    .line 711
    if-eqz v0, :cond_0

    .line 712
    iput v1, v0, Lcom/tencent/mapapi/map/ba;->p:I

    .line 709
    :cond_0
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 716
    :cond_1
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Canvas;)V
    .locals 12
    .parameter

    .prologue
    const/4 v3, 0x1

    #v3=(One);
    const/high16 v6, 0x3f80

    #v6=(Integer);
    const/4 v9, 0x0

    .line 910
    #v9=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iq()F

    move-result v2

    .line 911
    #v2=(Float);
    cmpl-float v0, v2, v6

    #v0=(Byte);
    if-eqz v0, :cond_0

    .line 913
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 914
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FZ:Landroid/graphics/Matrix;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 915
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FZ:Landroid/graphics/Matrix;

    iget-object v1, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v1}, Lcom/tencent/mapapi/map/bo;->ix()Landroid/graphics/Point;

    move-result-object v1

    iget v1, v1, Landroid/graphics/Point;->x:I

    #v1=(Integer);
    int-to-float v1, v1

    #v1=(Float);
    iget-object v4, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bo;->ix()Landroid/graphics/Point;

    move-result-object v4

    iget v4, v4, Landroid/graphics/Point;->y:I

    #v4=(Integer);
    int-to-float v4, v4

    #v4=(Float);
    invoke-virtual {v0, v2, v2, v1, v4}, Landroid/graphics/Matrix;->postScale(FFFF)Z

    .line 918
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FZ:Landroid/graphics/Matrix;

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->concat(Landroid/graphics/Matrix;)V

    .line 920
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v4=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    #v4=(Integer);
    move v1, v9

    :goto_0
    #v0=(Conflicted);v1=(Integer);v5=(Conflicted);
    if-ge v1, v4, :cond_2

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    if-eqz v0, :cond_1

    iget-boolean v5, v0, Lcom/tencent/mapapi/map/ba;->Em:Z

    #v5=(Boolean);
    if-eqz v5, :cond_1

    invoke-virtual {v0, p1}, Lcom/tencent/mapapi/map/ba;->c(Landroid/graphics/Canvas;)V

    :cond_1
    #v5=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 921
    :cond_2
    #v0=(Conflicted);
    cmpl-float v0, v2, v6

    #v0=(Byte);
    if-eqz v0, :cond_3

    .line 923
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 926
    :cond_3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_4
    :goto_1
    #v1=(Conflicted);v2=(Conflicted);v6=(Reference);
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_5

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mapapi/map/m;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/m;->hU()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_4

    if-eqz v0, :cond_4

    iget-object v1, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-static {v1}, Lcom/tencent/mapapi/map/bm;->a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;

    move-result-object v2

    #v2=(Reference);
    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/mapapi/map/m;->a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZJ)Z

    goto :goto_1

    :cond_5
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    :goto_2
    #v7=(Conflicted);v8=(Conflicted);v10=(Conflicted);v11=(Conflicted);
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/tencent/mapapi/map/m;

    if-eqz v6, :cond_6

    iget-object v1, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-static {v1}, Lcom/tencent/mapapi/map/bm;->a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;

    move-result-object v8

    #v8=(Reference);
    move-object v7, p1

    #v7=(Reference);
    move-wide v10, v4

    #v10=(LongLo);v11=(LongHi);
    invoke-virtual/range {v6 .. v11}, Lcom/tencent/mapapi/map/m;->a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZJ)Z

    goto :goto_2

    :cond_7
    #v1=(Boolean);v7=(Conflicted);v8=(Conflicted);v10=(Conflicted);v11=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FN:Lcom/tencent/mapapi/map/bi;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bi;->FW:Lcom/tencent/mapapi/map/bs;

    sget-object v1, Lcom/tencent/mapapi/map/bs;->GA:Lcom/tencent/mapapi/map/bs;

    #v1=(Reference);
    if-eq v0, v1, :cond_8

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FS:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/tencent/mapapi/map/az;

    iget-object v1, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-static {v1}, Lcom/tencent/mapapi/map/bm;->a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;

    move-result-object v8

    #v8=(Reference);
    move-object v7, p1

    #v7=(Reference);
    move-wide v10, v4

    #v10=(LongLo);v11=(LongHi);
    invoke-virtual/range {v6 .. v11}, Lcom/tencent/mapapi/map/az;->a(Landroid/graphics/Canvas;Lcom/tencent/mapapi/map/MapView;ZJ)Z

    goto :goto_3

    .line 927
    :cond_8
    #v1=(Conflicted);v7=(Conflicted);v8=(Conflicted);v10=(Conflicted);v11=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FO:Lcom/tencent/mapapi/map/bl;

    sget-object v0, Lcom/tencent/mapapi/map/bq;->EA:Lcom/tencent/mapapi/map/br;

    sget-object v1, Lcom/tencent/mapapi/map/br;->Gx:Lcom/tencent/mapapi/map/br;

    #v1=(Reference);
    if-ne v0, v1, :cond_a

    :goto_4
    #v3=(Boolean);
    if-eqz v3, :cond_9

    new-instance v0, Landroid/graphics/Paint;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    #v0=(Reference);
    const/high16 v1, -0x1

    #v1=(Integer);
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x41f0

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    new-instance v1, Landroid/graphics/Rect;

    #v1=(UninitRef);
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    #v1=(Reference);
    const-string v2, "\u9274\u6743\u5931\u8d25\uff0c\u8bf7\u5230soso"

    #v2=(Reference);
    const-string v3, "\u5730\u56fe\u5b98\u7f51\u7533\u8bf7\u5bc6\u94a5"

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v4

    #v4=(Integer);
    iget-object v5, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v5=(Reference);
    iget-object v5, v5, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v5}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v5

    #v5=(Integer);
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v6

    #v6=(Integer);
    invoke-virtual {v0, v2, v9, v6, v1}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    div-int/lit8 v6, v4, 0x2

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v7

    #v7=(Integer);
    div-int/lit8 v7, v7, 0x2

    sub-int/2addr v6, v7

    int-to-float v6, v6

    #v6=(Float);
    div-int/lit8 v7, v5, 0x2

    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v8

    #v8=(Integer);
    sub-int/2addr v7, v8

    int-to-float v7, v7

    #v7=(Float);
    invoke-virtual {p1, v2, v6, v7, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v3, v9, v2, v1}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    div-int/lit8 v2, v4, 0x2

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    #v1=(Integer);
    div-int/lit8 v1, v1, 0x2

    sub-int v1, v2, v1

    int-to-float v1, v1

    #v1=(Float);
    div-int/lit8 v2, v5, 0x2

    add-int/lit8 v2, v2, 0x2

    int-to-float v2, v2

    #v2=(Float);
    invoke-virtual {p1, v3, v1, v2, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 929
    :cond_9
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-void

    :cond_a
    #v1=(Reference);v3=(One);v4=(LongLo);v5=(LongHi);v6=(Reference);
    move v3, v9

    .line 927
    #v3=(Null);
    goto :goto_4
.end method

.method public final a(Lcom/tencent/mapapi/map/az;)V
    .locals 1
    .parameter

    .prologue
    .line 900
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FS:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 903
    return-void
.end method

.method public final hB()V
    .locals 4

    .prologue
    const/4 v2, 0x0

    .line 783
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    #v1=(Integer);
    move v0, v2

    .line 784
    :goto_0
    #v0=(Integer);v3=(Conflicted);
    if-ge v0, v1, :cond_0

    .line 787
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->FR:Ljava/util/List;

    #v3=(Reference);
    invoke-interface {v3, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 788
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 795
    :cond_0
    #v3=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FS:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    move v1, v2

    .line 797
    :goto_1
    #v0=(Conflicted);
    if-ge v1, v3, :cond_2

    .line 799
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->FS:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/az;

    .line 800
    if-eqz v0, :cond_1

    .line 802
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/az;->hC()V

    .line 803
    :cond_1
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    .line 806
    :cond_2
    #v0=(Conflicted);
    return-void
.end method

.method public final hC()V
    .locals 6

    .prologue
    const/4 v1, 0x0

    .line 809
    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_2

    .line 811
    iget-object v3, p0, Lcom/tencent/mapapi/map/bi;->FU:[B

    #v3=(Reference);
    monitor-enter v3

    .line 813
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    #v4=(Integer);
    move v2, v1

    .line 815
    :goto_0
    #v0=(Conflicted);v2=(Integer);v5=(Conflicted);
    if-ge v2, v4, :cond_1

    .line 817
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CQ:Ljava/util/List;

    #v0=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    invoke-interface {v0, v5}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/av;

    .line 818
    if-eqz v0, :cond_0

    .line 820
    invoke-interface {v0}, Lcom/tencent/mapapi/map/av;->hC()V

    .line 823
    :cond_0
    add-int/lit8 v0, v2, 0x1

    #v0=(Integer);
    move v2, v0

    goto :goto_0

    .line 825
    :cond_1
    #v0=(Conflicted);v5=(Conflicted);
    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 829
    :cond_2
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_5

    .line 831
    iget-object v2, p0, Lcom/tencent/mapapi/map/bi;->FT:[B

    #v2=(Reference);
    monitor-enter v2

    .line 834
    :try_start_1
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    .line 835
    :goto_1
    #v0=(Conflicted);v1=(Integer);v3=(Integer);
    if-ge v1, v3, :cond_4

    .line 837
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->CP:Ljava/util/List;

    #v0=(Reference);
    const/4 v4, 0x0

    #v4=(Null);
    invoke-interface {v0, v4}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ba;

    .line 838
    if-eqz v0, :cond_3

    .line 840
    invoke-virtual {v0}, Lcom/tencent/mapapi/map/ba;->hB()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 843
    :cond_3
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    .line 825
    :catchall_0
    #v0=(Conflicted);v1=(Null);v2=(Conflicted);v3=(Reference);v4=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v3

    throw v0

    .line 845
    :cond_4
    :try_start_2
    #v0=(Conflicted);v1=(Integer);v2=(Reference);v3=(Integer);
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 848
    :cond_5
    #v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 845
    :catchall_1
    #v2=(Reference);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0
.end method

.method public final ia()V
    .locals 1

    .prologue
    .line 893
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-static {v0}, Lcom/tencent/mapapi/map/bm;->a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;

    move-result-object v0

    if-nez v0, :cond_1

    .line 897
    :cond_0
    :goto_0
    return-void

    .line 896
    :cond_1
    iget-object v0, p0, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-static {v0}, Lcom/tencent/mapapi/map/bm;->a(Lcom/tencent/mapapi/map/bm;)Lcom/tencent/mapapi/map/MapView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->postInvalidate()V

    goto :goto_0
.end method

*/}
