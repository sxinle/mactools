package com.tencent.mapapi.map; class t {/*

.class public interface abstract Lcom/tencent/mapapi/map/t;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract aj(I)V
.end method

.method public abstract hF()Z
.end method

.method public abstract hH()Ljava/lang/String;
.end method

.method public abstract hZ()Z
.end method

*/}
