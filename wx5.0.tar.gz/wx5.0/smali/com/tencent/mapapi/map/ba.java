package com.tencent.mapapi.map; class ba {/*

.class abstract Lcom/tencent/mapapi/map/ba;
.super Lcom/tencent/mapapi/map/bb;
.source "SourceFile"


# instance fields
.field protected Ec:Lcom/tencent/mapapi/map/bh;

.field protected Fv:Z


# direct methods
.method constructor <init>()V
    .locals 1

    .prologue
    .line 812
    invoke-direct {p0}, Lcom/tencent/mapapi/map/bb;-><init>()V

    .line 845
    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/mapapi/map/ba;->Fv:Z

    return-void
.end method


# virtual methods
.method final a(Lcom/tencent/mapapi/map/bh;)V
    .locals 0
    .parameter

    .prologue
    .line 848
    iput-object p1, p0, Lcom/tencent/mapapi/map/ba;->Ec:Lcom/tencent/mapapi/map/bh;

    .line 849
    return-void
.end method

.method protected abstract a(Ljava/util/ArrayList;Z)V
.end method

.method protected abstract c(Landroid/graphics/Canvas;)V
.end method

.method protected abstract gx()V
.end method

.method protected abstract hB()V
.end method

.method protected abstract hC()V
.end method

.method protected abstract hw()V
.end method

.method protected abstract ie()V
.end method

*/}
