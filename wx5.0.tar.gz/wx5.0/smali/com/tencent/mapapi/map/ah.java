package com.tencent.mapapi.map; class ah {/*

.class final Lcom/tencent/mapapi/map/ah;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private CQ:Ljava/util/List;

.field private final CS:I

.field private DF:Landroid/os/Handler;

.field private final Dc:I

.field private final Dd:I

.field private Fc:Lcom/tencent/mapapi/map/bh;


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    const/4 v0, 0x0

    .line 21
    #v0=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    #p0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    .line 13
    iput-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    .line 15
    iput-object v0, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    .line 16
    const/16 v0, 0x10

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mapapi/map/ah;->CS:I

    .line 17
    const/16 v0, 0xa

    iput v0, p0, Lcom/tencent/mapapi/map/ah;->Dc:I

    .line 18
    const/16 v0, 0xf

    iput v0, p0, Lcom/tencent/mapapi/map/ah;->Dd:I

    .line 22
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 24
    new-instance v0, Landroid/os/Handler;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    .line 26
    :cond_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    if-nez v0, :cond_1

    .line 28
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    .line 30
    :cond_1
    return-void
.end method

.method static synthetic a(Lcom/tencent/mapapi/map/ah;)Lcom/tencent/mapapi/map/bh;
    .locals 1
    .parameter

    .prologue
    .line 10
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    return-object v0
.end method

.method private ar(I)V
    .locals 9
    .parameter

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/16 v8, 0x10

    .line 34
    #v8=(PosByte);
    new-array v6, v8, [D

    .line 37
    #v6=(Reference);
    const-wide/high16 v1, 0x4000

    #v1=(LongLo);v2=(LongHi);
    int-to-double v3, p1

    #v3=(DoubleLo);v4=(DoubleHi);
    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    .line 38
    #v1=(DoubleLo);v2=(DoubleHi);
    const/4 v3, 0x1

    #v3=(One);
    move v5, v3

    :goto_0
    #v3=(Conflicted);v5=(Integer);v7=(Conflicted);
    if-ge v5, v8, :cond_0

    .line 39
    mul-int/lit8 v3, v5, 0xa

    #v3=(Integer);
    int-to-long v3, v3

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v1, v2, v3, v4}, Lcom/tencent/mapapi/map/bq;->a(DJ)D

    move-result-wide v3

    .line 41
    #v3=(DoubleLo);v4=(DoubleHi);
    div-double/2addr v1, v3

    .line 43
    rsub-int/lit8 v7, v5, 0x10

    #v7=(Integer);
    aput-wide v1, v6, v7

    .line 38
    add-int/lit8 v1, v5, 0x1

    #v1=(Integer);
    move v5, v1

    move-wide v1, v3

    #v1=(DoubleLo);
    goto :goto_0

    .line 45
    :cond_0
    #v3=(Conflicted);v7=(Conflicted);
    aput-wide v1, v6, v0

    .line 47
    :goto_1
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);
    if-ge v0, v8, :cond_1

    .line 48
    new-instance v1, Lcom/tencent/mapapi/map/aj;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mapapi/map/aj;-><init>(Lcom/tencent/mapapi/map/ah;)V

    .line 49
    #v1=(Reference);
    aget-wide v2, v6, v0

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v1, v2, v3}, Lcom/tencent/mapapi/map/aj;->a(Lcom/tencent/mapapi/map/aj;D)D

    .line 50
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 47
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 52
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void
.end method


# virtual methods
.method public final a(Lcom/tencent/mapapi/map/bh;)V
    .locals 0
    .parameter

    .prologue
    .line 236
    iput-object p1, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    .line 237
    return-void
.end method

.method public final as(I)Z
    .locals 4
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 77
    #v0=(Null);
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v2=(Reference);
    if-nez v2, :cond_1

    .line 89
    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 81
    :cond_1
    #v0=(Null);v2=(Reference);v3=(Uninit);
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v2

    .line 82
    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->ir()I

    move-result v3

    .line 83
    #v3=(Integer);
    if-eq v3, v2, :cond_0

    .line 87
    invoke-direct {p0, p1}, Lcom/tencent/mapapi/map/ah;->ar(I)V

    .line 88
    invoke-virtual {p0, v1}, Lcom/tencent/mapapi/map/ah;->d(Z)V

    move v0, v1

    .line 89
    #v0=(One);
    goto :goto_0
.end method

.method public final at(I)Z
    .locals 10
    .parameter

    .prologue
    const/16 v9, 0x10

    #v9=(PosByte);
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 150
    #v0=(Null);
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v2=(Reference);
    if-nez v2, :cond_1

    .line 162
    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return v0

    .line 154
    :cond_1
    #v0=(Null);v2=(Reference);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v2

    .line 155
    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->is()I

    move-result v3

    .line 156
    #v3=(Integer);
    if-eq v3, v2, :cond_0

    .line 160
    new-array v7, v9, [D

    #v7=(Reference);
    const-wide/high16 v2, 0x3fe0

    #v2=(LongLo);v3=(LongHi);
    int-to-double v4, p1

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    #v2=(DoubleLo);v3=(DoubleHi);
    move v6, v1

    :goto_1
    #v6=(Integer);v8=(Conflicted);
    if-ge v6, v9, :cond_2

    mul-int/lit8 v4, v6, 0xa

    #v4=(Integer);
    int-to-long v4, v4

    #v4=(LongLo);v5=(LongHi);
    invoke-static {v2, v3, v4, v5}, Lcom/tencent/mapapi/map/bq;->a(DJ)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    div-double/2addr v2, v4

    rsub-int/lit8 v8, v6, 0x10

    #v8=(Integer);
    aput-wide v2, v7, v8

    add-int/lit8 v2, v6, 0x1

    #v2=(Integer);
    move v6, v2

    move-wide v2, v4

    #v2=(DoubleLo);
    goto :goto_1

    :cond_2
    #v8=(Conflicted);
    aput-wide v2, v7, v0

    :goto_2
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    if-ge v0, v9, :cond_3

    new-instance v2, Lcom/tencent/mapapi/map/aj;

    #v2=(UninitRef);
    invoke-direct {v2, p0}, Lcom/tencent/mapapi/map/aj;-><init>(Lcom/tencent/mapapi/map/ah;)V

    #v2=(Reference);
    aget-wide v3, v7, v0

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v2, v3, v4}, Lcom/tencent/mapapi/map/aj;->a(Lcom/tencent/mapapi/map/aj;D)D

    iget-object v3, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v3=(Reference);
    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    .line 161
    :cond_3
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    invoke-virtual {p0, v1}, Lcom/tencent/mapapi/map/ah;->d(Z)V

    move v0, v1

    .line 162
    #v0=(One);
    goto :goto_0
.end method

.method public final d(Z)V
    .locals 4
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 241
    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_1

    .line 265
    :cond_0
    :goto_0
    #v1=(Reference);v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 245
    :cond_1
    #v1=(Null);v2=(Uninit);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 247
    #v0=(Integer);
    if-gtz v0, :cond_2

    .line 249
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0, v1}, Lcom/tencent/mapapi/map/bm;->e(Z)V

    goto :goto_0

    .line 252
    :cond_2
    #v0=(Integer);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ag;

    .line 253
    if-eqz v0, :cond_0

    .line 255
    const/4 v1, 0x1

    #v1=(One);
    if-ne p1, v1, :cond_3

    .line 257
    iget-object v1, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    #v1=(Reference);
    invoke-virtual {v1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_0

    .line 261
    :cond_3
    #v1=(One);
    iget-object v1, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    #v1=(Reference);
    const-wide/16 v2, 0xa

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0
.end method

.method public final e(Lcom/tencent/mapapi/map/GeoPoint;)V
    .locals 9
    .parameter

    .prologue
    const/4 v4, 0x0

    #v4=(Null);
    const/16 v1, 0x10

    #v1=(PosByte);
    const/4 v2, 0x1

    .line 167
    #v2=(One);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_1

    .line 232
    :cond_0
    :goto_0
    #v1=(Conflicted);v3=(Conflicted);v4=(Integer);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-void

    .line 171
    :cond_1
    #v1=(PosByte);v3=(Uninit);v4=(Null);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    if-eqz p1, :cond_0

    .line 175
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 176
    #v0=(Integer);
    if-lez v0, :cond_2

    .line 178
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 180
    :cond_2
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    #v0=(Reference);
    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 181
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iv()Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v3

    .line 182
    #v3=(Reference);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->iw()Lcom/tencent/mapapi/map/MapView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/MapView;->hN()Lcom/tencent/mapapi/map/o;

    move-result-object v0

    invoke-interface {v0, p1, v4}, Lcom/tencent/mapapi/map/o;->a(Lcom/tencent/mapapi/map/GeoPoint;Landroid/graphics/Point;)Landroid/graphics/Point;

    move-result-object v0

    .line 183
    iget-object v4, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mapapi/map/bh;->FP:Lcom/tencent/mapapi/map/bo;

    invoke-virtual {v4}, Lcom/tencent/mapapi/map/bo;->ix()Landroid/graphics/Point;

    move-result-object v4

    .line 185
    iget v5, v0, Landroid/graphics/Point;->x:I

    #v5=(Integer);
    iget v6, v4, Landroid/graphics/Point;->x:I

    #v6=(Integer);
    sub-int/2addr v5, v6

    .line 186
    iget v0, v0, Landroid/graphics/Point;->y:I

    #v0=(Integer);
    iget v4, v4, Landroid/graphics/Point;->y:I

    #v4=(Integer);
    sub-int/2addr v0, v4

    .line 188
    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    move-result v4

    .line 189
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    .line 191
    if-le v4, v0, :cond_4

    int-to-float v0, v4

    .line 192
    :goto_1
    #v0=(Float);
    const/high16 v4, 0x4170

    div-float/2addr v0, v4

    .line 193
    float-to-double v4, v0

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-static {v4, v5}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v4

    double-to-int v0, v4

    .line 195
    #v0=(Integer);
    if-le v0, v1, :cond_3

    move v0, v1

    .line 200
    :cond_3
    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLatitudeE6()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v3}, Lcom/tencent/mapapi/map/GeoPoint;->getLatitudeE6()I

    move-result v4

    #v4=(Integer);
    sub-int/2addr v1, v4

    int-to-float v1, v1

    .line 201
    #v1=(Float);
    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLongitudeE6()I

    move-result v4

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/GeoPoint;->getLongitudeE6()I

    move-result v5

    #v5=(Integer);
    sub-int/2addr v4, v5

    int-to-float v4, v4

    .line 203
    #v4=(Float);
    int-to-float v5, v0

    #v5=(Float);
    div-float/2addr v1, v5

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v5

    .line 204
    #v5=(Integer);
    int-to-float v1, v0

    div-float v1, v4, v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v4

    #v4=(Integer);
    move v1, v2

    .line 209
    :goto_2
    #v1=(Integer);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    if-ge v1, v0, :cond_5

    .line 211
    invoke-virtual {v3}, Lcom/tencent/mapapi/map/GeoPoint;->getLatitudeE6()I

    move-result v6

    #v6=(Integer);
    mul-int v7, v5, v1

    #v7=(Integer);
    add-int/2addr v6, v7

    .line 212
    invoke-virtual {v3}, Lcom/tencent/mapapi/map/GeoPoint;->getLongitudeE6()I

    move-result v7

    mul-int v8, v4, v1

    #v8=(Integer);
    add-int/2addr v7, v8

    .line 213
    new-instance v8, Lcom/tencent/mapapi/map/ai;

    #v8=(UninitRef);
    invoke-direct {v8, p0}, Lcom/tencent/mapapi/map/ai;-><init>(Lcom/tencent/mapapi/map/ah;)V

    .line 214
    #v8=(Reference);
    invoke-virtual {v8, v6, v7}, Lcom/tencent/mapapi/map/ai;->j(II)V

    .line 216
    iget-object v6, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v6=(Reference);
    invoke-interface {v6, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 209
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 191
    :cond_4
    #v1=(PosByte);v6=(Integer);v7=(Uninit);v8=(Uninit);
    int-to-float v0, v0

    #v0=(Float);
    goto :goto_1

    .line 219
    :cond_5
    #v0=(Integer);v1=(Integer);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    new-instance v0, Lcom/tencent/mapapi/map/ai;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mapapi/map/ai;-><init>(Lcom/tencent/mapapi/map/ah;)V

    .line 220
    #v0=(Reference);
    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLatitudeE6()I

    move-result v1

    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLongitudeE6()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v0, v1, v3}, Lcom/tencent/mapapi/map/ai;->j(II)V

    .line 221
    iget-object v1, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v1=(Reference);
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 231
    invoke-virtual {p0, v2}, Lcom/tencent/mapapi/map/ah;->d(Z)V

    goto/16 :goto_0
.end method

.method public final hB()V
    .locals 5

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v4, 0x0

    .line 289
    #v4=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    move v1, v2

    :goto_0
    #v0=(Conflicted);v1=(Integer);
    if-ge v1, v3, :cond_1

    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mapapi/map/ag;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/ag;->hB()V

    :cond_0
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 290
    :cond_1
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);
    iput-object v4, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    .line 291
    iput-object v4, p0, Lcom/tencent/mapapi/map/ah;->DF:Landroid/os/Handler;

    .line 292
    iput-object v4, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    .line 293
    return-void
.end method

.method public final i(II)Z
    .locals 4
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v1, 0x1

    .line 94
    #v1=(One);
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v2=(Reference);
    if-nez v2, :cond_1

    .line 117
    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 98
    :cond_1
    #v0=(Null);v2=(Reference);v3=(Uninit);
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->iu()I

    move-result v2

    .line 99
    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    #v3=(Reference);
    iget-object v3, v3, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v3}, Lcom/tencent/mapapi/map/bm;->ir()I

    move-result v3

    .line 100
    #v3=(Integer);
    if-eq v3, v2, :cond_0

    .line 104
    new-instance v0, Lcom/tencent/mapapi/map/ak;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mapapi/map/ak;-><init>(Lcom/tencent/mapapi/map/ah;)V

    .line 105
    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Lcom/tencent/mapapi/map/ak;->j(II)V

    .line 106
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 108
    invoke-direct {p0, v1}, Lcom/tencent/mapapi/map/ah;->ar(I)V

    .line 110
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    iget-object v0, v0, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v0}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v0

    #v0=(Integer);
    div-int/lit8 v0, v0, 0x2

    .line 111
    iget-object v2, p0, Lcom/tencent/mapapi/map/ah;->Fc:Lcom/tencent/mapapi/map/bh;

    iget-object v2, v2, Lcom/tencent/mapapi/map/bh;->FM:Lcom/tencent/mapapi/map/bm;

    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v2

    #v2=(Integer);
    div-int/lit8 v2, v2, 0x2

    .line 112
    new-instance v3, Lcom/tencent/mapapi/map/ak;

    #v3=(UninitRef);
    invoke-direct {v3, p0}, Lcom/tencent/mapapi/map/ak;-><init>(Lcom/tencent/mapapi/map/ah;)V

    .line 113
    #v3=(Reference);
    invoke-virtual {v3, v0, v2}, Lcom/tencent/mapapi/map/ak;->j(II)V

    .line 114
    iget-object v0, p0, Lcom/tencent/mapapi/map/ah;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 115
    invoke-virtual {p0, v1}, Lcom/tencent/mapapi/map/ah;->d(Z)V

    move v0, v1

    .line 117
    #v0=(One);
    goto :goto_0
.end method

*/}
