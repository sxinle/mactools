package com.tencent.mapapi.map; class bo {/*

.class final Lcom/tencent/mapapi/map/bo;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public CR:I

.field public CS:I

.field public Dc:I

.field FM:Lcom/tencent/mapapi/map/bm;

.field public Go:Landroid/graphics/PointF;

.field private Gp:Landroid/graphics/Point;

.field private Gq:Lcom/tencent/mapapi/map/GeoPoint;

.field Gr:[F

.field Gs:[D

.field Gt:[D

.field Gu:[D


# direct methods
.method public constructor <init>(Lcom/tencent/mapapi/map/bm;)V
    .locals 4
    .parameter

    .prologue
    const/4 v3, 0x0

    .line 37
    #v3=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    #p0=(Reference);
    iput-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    .line 24
    iput-object v3, p0, Lcom/tencent/mapapi/map/bo;->FM:Lcom/tencent/mapapi/map/bm;

    .line 25
    new-instance v0, Lcom/tencent/mapapi/map/GeoPoint;

    #v0=(UninitRef);
    const v1, 0x260f56c

    #v1=(Integer);
    const v2, 0x6f015d9

    #v2=(Integer);
    invoke-direct {v0, v1, v2}, Lcom/tencent/mapapi/map/GeoPoint;-><init>(II)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gq:Lcom/tencent/mapapi/map/GeoPoint;

    .line 28
    const/4 v0, 0x2

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    .line 29
    const/16 v0, 0x14

    iput v0, p0, Lcom/tencent/mapapi/map/bo;->CS:I

    .line 30
    const/16 v0, 0xa

    iput v0, p0, Lcom/tencent/mapapi/map/bo;->Dc:I

    .line 32
    iput-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gr:[F

    .line 33
    iput-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    .line 34
    iput-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gt:[D

    .line 35
    iput-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gu:[D

    .line 38
    iput-object p1, p0, Lcom/tencent/mapapi/map/bo;->FM:Lcom/tencent/mapapi/map/bm;

    .line 39
    return-void
.end method

.method private gx()V
    .locals 2

    .prologue
    .line 77
    iget-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gq:Lcom/tencent/mapapi/map/GeoPoint;

    #v0=(Reference);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v1=(Integer);
    invoke-virtual {p0, v0, v1}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    .line 78
    return-void
.end method

.method private static k(II)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 189
    if-gez p1, :cond_1

    .line 191
    add-int/2addr p1, p0

    .line 197
    :cond_0
    :goto_0
    return p1

    .line 193
    :cond_1
    if-lt p1, p0, :cond_0

    .line 195
    sub-int/2addr p1, p0

    goto :goto_0
.end method


# virtual methods
.method final a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;
    .locals 10
    .parameter
    .parameter

    .prologue
    const-wide v6, 0x412e848000000000L

    #v6=(LongLo);v7=(LongHi);
    const-wide/high16 v8, 0x3ff0

    .line 98
    #v8=(LongLo);v9=(LongHi);
    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLatitudeE6()I

    move-result v0

    #v0=(Integer);
    int-to-double v0, v0

    #v0=(DoubleLo);v1=(DoubleHi);
    div-double/2addr v0, v6

    const-wide v2, 0x3f91df46a2529d39L

    #v2=(LongLo);v3=(LongHi);
    mul-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    move-result-wide v0

    const-wide v2, -0x401000d1b71758e2L

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(DD)D

    move-result-wide v0

    const-wide v2, 0x3fefff2e48e8a71eL

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->min(DD)D

    move-result-wide v0

    .line 102
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    #v2=(Reference);
    iget v3, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v3=(Integer);
    sub-int v3, p2, v3

    aget-wide v2, v2, v3

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {p1}, Lcom/tencent/mapapi/map/GeoPoint;->getLongitudeE6()I

    move-result v4

    #v4=(Integer);
    int-to-double v4, v4

    #v4=(DoubleLo);v5=(DoubleHi);
    div-double/2addr v4, v6

    iget-object v6, p0, Lcom/tencent/mapapi/map/bo;->Gt:[D

    #v6=(Reference);
    iget v7, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v7=(Integer);
    sub-int v7, p2, v7

    aget-wide v6, v6, v7

    #v6=(LongLo);v7=(LongHi);
    mul-double/2addr v4, v6

    add-double/2addr v2, v4

    .line 106
    #v2=(DoubleLo);v3=(DoubleHi);
    iget-object v4, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    #v4=(Reference);
    iget v5, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v5=(Integer);
    sub-int v5, p2, v5

    aget-wide v4, v4, v5

    #v4=(LongLo);v5=(LongHi);
    add-double v6, v8, v0

    #v6=(DoubleLo);v7=(DoubleHi);
    sub-double v0, v8, v0

    div-double v0, v6, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->log(D)D

    move-result-wide v0

    iget-object v6, p0, Lcom/tencent/mapapi/map/bo;->Gu:[D

    #v6=(Reference);
    iget v7, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v7=(Integer);
    sub-int v7, p2, v7

    aget-wide v6, v6, v7

    #v6=(LongLo);v7=(LongHi);
    mul-double/2addr v0, v6

    const-wide/high16 v6, 0x3fe0

    mul-double/2addr v0, v6

    add-double/2addr v0, v4

    .line 108
    new-instance v4, Landroid/graphics/PointF;

    #v4=(UninitRef);
    double-to-float v2, v2

    #v2=(Float);
    double-to-float v0, v0

    #v0=(Float);
    invoke-direct {v4, v2, v0}, Landroid/graphics/PointF;-><init>(FF)V

    #v4=(Reference);
    return-object v4
.end method

.method public final a(Landroid/graphics/PointF;I)Lcom/tencent/mapapi/map/GeoPoint;
    .locals 5
    .parameter
    .parameter

    .prologue
    .line 112
    new-instance v0, Landroid/graphics/PointF;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/PointF;->x:F

    #v1=(Integer);
    iget v2, p1, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/Point;->x:I

    #v3=(Integer);
    int-to-float v3, v3

    #v3=(Float);
    sub-float/2addr v2, v3

    #v2=(Float);
    add-float/2addr v1, v2

    #v1=(Float);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    iget v3, p1, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    iget-object v4, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/Point;->y:I

    #v4=(Integer);
    int-to-float v4, v4

    #v4=(Float);
    sub-float/2addr v3, v4

    #v3=(Float);
    sub-float/2addr v2, v3

    #v2=(Float);
    invoke-direct {v0, v1, v2}, Landroid/graphics/PointF;-><init>(FF)V

    .line 114
    #v0=(Reference);
    invoke-virtual {p0, v0, p2}, Lcom/tencent/mapapi/map/bo;->b(Landroid/graphics/PointF;I)Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v0

    return-object v0
.end method

.method public final a(IIIF)Ljava/util/ArrayList;
    .locals 15
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 253
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/PointF;->x:F

    #v1=(Integer);
    const/high16 v2, 0x4380

    #v2=(Integer);
    div-float/2addr v1, v2

    #v1=(Float);
    float-to-double v1, v1

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v9, v1

    .line 254
    #v9=(Integer);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/PointF;->y:F

    #v1=(Integer);
    const/high16 v2, 0x4380

    #v2=(Integer);
    div-float/2addr v1, v2

    #v1=(Float);
    float-to-double v1, v1

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v10, v1

    .line 257
    #v10=(Integer);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/Point;->x:I

    #v1=(Integer);
    int-to-float v1, v1

    #v1=(Float);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    const/high16 v3, 0x4380

    #v3=(Integer);
    rem-float/2addr v2, v3

    #v2=(Float);
    sub-float v11, v1, v2

    .line 259
    #v11=(Float);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/Point;->y:I

    #v1=(Integer);
    int-to-float v1, v1

    #v1=(Float);
    const/high16 v2, 0x4380

    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/PointF;->y:F

    #v3=(Integer);
    const/high16 v4, 0x4380

    #v4=(Integer);
    rem-float/2addr v3, v4

    #v3=(Float);
    sub-float/2addr v2, v3

    #v2=(Float);
    sub-float v12, v1, v2

    .line 270
    #v12=(Float);
    move/from16 v0, p2

    #v0=(Integer);
    int-to-double v1, v0

    #v1=(DoubleLo);v2=(DoubleHi);
    const-wide/high16 v3, 0x3ff0

    #v3=(LongLo);v4=(LongHi);
    move/from16 v0, p4

    #v0=(Float);
    float-to-double v5, v0

    #v5=(DoubleLo);v6=(DoubleHi);
    div-double/2addr v3, v5

    #v3=(DoubleLo);v4=(DoubleHi);
    const-wide/high16 v5, 0x3ff0

    #v5=(LongLo);v6=(LongHi);
    sub-double/2addr v3, v5

    mul-double/2addr v1, v3

    const-wide/high16 v3, 0x4000

    #v3=(LongLo);v4=(LongHi);
    div-double v3, v1, v3

    .line 271
    #v3=(DoubleLo);v4=(DoubleHi);
    float-to-double v1, v11

    add-double/2addr v1, v3

    .line 272
    const-wide/16 v5, 0x0

    cmpg-double v5, v1, v5

    #v5=(Byte);
    if-gez v5, :cond_5

    .line 274
    const-wide/16 v1, 0x0

    #v1=(LongLo);v2=(LongHi);
    move-wide v7, v1

    .line 276
    :goto_0
    #v7=(LongLo);v8=(LongHi);
    move/from16 v0, p2

    #v0=(Integer);
    int-to-float v1, v0

    #v1=(Float);
    const/high16 v2, 0x3f80

    #v2=(Integer);
    mul-float/2addr v1, v2

    sub-float/2addr v1, v11

    const/high16 v2, 0x4380

    sub-float/2addr v1, v2

    float-to-double v1, v1

    #v1=(DoubleLo);v2=(DoubleHi);
    add-double/2addr v1, v3

    .line 277
    const-wide/16 v3, 0x0

    #v3=(LongLo);v4=(LongHi);
    cmpg-double v3, v1, v3

    #v3=(Byte);
    if-gez v3, :cond_4

    .line 279
    const-wide/16 v1, 0x0

    #v1=(LongLo);v2=(LongHi);
    move-wide v5, v1

    .line 282
    :goto_1
    #v5=(LongLo);
    move/from16 v0, p3

    int-to-double v1, v0

    #v1=(DoubleLo);v2=(DoubleHi);
    const-wide/high16 v3, 0x3ff0

    #v3=(LongLo);
    move/from16 v0, p4

    #v0=(Float);
    float-to-double v13, v0

    #v13=(DoubleLo);v14=(DoubleHi);
    div-double/2addr v3, v13

    #v3=(DoubleLo);v4=(DoubleHi);
    const-wide/high16 v13, 0x3ff0

    #v13=(LongLo);v14=(LongHi);
    sub-double/2addr v3, v13

    mul-double/2addr v1, v3

    const-wide/high16 v3, 0x4000

    #v3=(LongLo);v4=(LongHi);
    div-double v13, v1, v3

    .line 283
    #v13=(DoubleLo);v14=(DoubleHi);
    float-to-double v1, v12

    add-double/2addr v1, v13

    .line 284
    const-wide/16 v3, 0x0

    cmpg-double v3, v1, v3

    #v3=(Byte);
    if-gez v3, :cond_3

    .line 286
    const-wide/16 v1, 0x0

    #v1=(LongLo);v2=(LongHi);
    move-wide v3, v1

    .line 289
    :goto_2
    #v3=(LongLo);
    move/from16 v0, p3

    #v0=(Integer);
    int-to-float v1, v0

    #v1=(Float);
    const/high16 v2, 0x3f80

    #v2=(Integer);
    mul-float/2addr v1, v2

    sub-float/2addr v1, v12

    const/high16 v2, 0x4380

    sub-float/2addr v1, v2

    float-to-double v1, v1

    #v1=(DoubleLo);v2=(DoubleHi);
    add-double/2addr v1, v13

    .line 290
    const-wide/16 v13, 0x0

    #v13=(LongLo);v14=(LongHi);
    cmpg-double v13, v1, v13

    #v13=(Byte);
    if-gez v13, :cond_0

    .line 292
    const-wide/16 v1, 0x0

    .line 295
    :cond_0
    #v1=(LongLo);v2=(LongHi);
    const-wide/high16 v13, 0x4070

    #v13=(LongLo);
    div-double/2addr v7, v13

    #v7=(DoubleLo);v8=(DoubleHi);
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v7

    double-to-int v7, v7

    .line 296
    #v7=(Integer);
    const-wide/high16 v13, 0x4070

    div-double/2addr v5, v13

    #v5=(DoubleLo);v6=(DoubleHi);
    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    double-to-int v5, v5

    .line 297
    #v5=(Integer);
    const-wide/high16 v13, 0x4070

    div-double/2addr v3, v13

    #v3=(DoubleLo);v4=(DoubleHi);
    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v3

    double-to-int v3, v3

    .line 298
    #v3=(Integer);
    const-wide/high16 v13, 0x4070

    div-double/2addr v1, v13

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    double-to-int v4, v1

    .line 300
    #v4=(Integer);
    new-instance v6, Ljava/util/ArrayList;

    #v6=(UninitRef);
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 301
    #v6=(Reference);
    const-wide/high16 v1, 0x4000

    #v1=(LongLo);v2=(LongHi);
    add-int/lit8 v8, p1, 0x1

    #v8=(Integer);
    int-to-double v13, v8

    #v13=(DoubleLo);v14=(DoubleHi);
    invoke-static {v1, v2, v13, v14}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    #v1=(DoubleLo);v2=(DoubleHi);
    double-to-int v8, v1

    .line 305
    neg-int v1, v7

    #v1=(Integer);
    move v2, v1

    :goto_3
    #v2=(Integer);v13=(Conflicted);v14=(Conflicted);
    if-gt v2, v5, :cond_2

    .line 307
    neg-int v1, v4

    :goto_4
    if-gt v1, v3, :cond_1

    .line 309
    add-int v7, v9, v2

    invoke-static {v8, v7}, Lcom/tencent/mapapi/map/bo;->k(II)I

    move-result v7

    .line 310
    add-int v13, v10, v1

    #v13=(Integer);
    invoke-static {v8, v13}, Lcom/tencent/mapapi/map/bo;->k(II)I

    move-result v13

    .line 311
    new-instance v14, Lcom/tencent/mapapi/map/ab;

    #v14=(UninitRef);
    move/from16 v0, p1

    invoke-direct {v14, v7, v13, v0}, Lcom/tencent/mapapi/map/ab;-><init>(III)V

    .line 312
    #v14=(Reference);
    mul-int/lit16 v7, v2, 0x100

    int-to-float v7, v7

    #v7=(Float);
    add-float/2addr v7, v11

    iput v7, v14, Lcom/tencent/mapapi/map/ab;->EP:F

    .line 313
    mul-int/lit16 v7, v1, 0x100

    #v7=(Integer);
    int-to-float v7, v7

    #v7=(Float);
    sub-float v7, v12, v7

    iput v7, v14, Lcom/tencent/mapapi/map/ab;->EQ:F

    .line 314
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 307
    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    .line 305
    :cond_1
    #v7=(Integer);v13=(Conflicted);v14=(Conflicted);
    add-int/lit8 v1, v2, 0x1

    move v2, v1

    goto :goto_3

    .line 318
    :cond_2
    return-object v6

    :cond_3
    #v0=(Float);v1=(DoubleLo);v2=(DoubleHi);v3=(Byte);v4=(LongHi);v5=(LongLo);v6=(LongHi);v7=(LongLo);v8=(LongHi);v13=(DoubleLo);v14=(DoubleHi);
    move-wide v3, v1

    #v3=(DoubleLo);v4=(DoubleHi);
    goto :goto_2

    :cond_4
    #v0=(Integer);v3=(Byte);v4=(LongHi);v5=(Byte);v13=(Uninit);v14=(Uninit);
    move-wide v5, v1

    #v5=(DoubleLo);v6=(DoubleHi);
    goto/16 :goto_1

    :cond_5
    #v0=(Float);v3=(DoubleLo);v4=(DoubleHi);v5=(Byte);v6=(LongHi);v7=(Uninit);v8=(Uninit);
    move-wide v7, v1

    #v7=(DoubleLo);v8=(DoubleHi);
    goto/16 :goto_0
.end method

.method public final a(Landroid/graphics/Point;)V
    .locals 2
    .parameter

    .prologue
    .line 82
    iget-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 84
    new-instance v0, Landroid/graphics/Point;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    .line 86
    :cond_0
    iget-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    iget v1, p1, Landroid/graphics/Point;->x:I

    #v1=(Integer);
    iput v1, v0, Landroid/graphics/Point;->x:I

    .line 87
    iget-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    iget v1, p1, Landroid/graphics/Point;->y:I

    iput v1, v0, Landroid/graphics/Point;->y:I

    .line 88
    return-void
.end method

.method public final b(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;
    .locals 5
    .parameter
    .parameter

    .prologue
    .line 118
    invoke-virtual {p0, p1, p2}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v0

    .line 119
    #v0=(Reference);
    new-instance v1, Landroid/graphics/PointF;

    #v1=(UninitRef);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/Point;->x:I

    #v2=(Integer);
    int-to-float v2, v2

    #v2=(Float);
    iget v3, v0, Landroid/graphics/PointF;->x:F

    #v3=(Integer);
    iget-object v4, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->x:F

    #v4=(Integer);
    sub-float/2addr v3, v4

    #v3=(Float);
    add-float/2addr v2, v3

    iget-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v3=(Reference);
    iget v3, v3, Landroid/graphics/Point;->y:I

    #v3=(Integer);
    int-to-float v3, v3

    #v3=(Float);
    iget v0, v0, Landroid/graphics/PointF;->y:F

    #v0=(Integer);
    iget-object v4, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v4=(Reference);
    iget v4, v4, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    sub-float/2addr v0, v4

    #v0=(Float);
    sub-float v0, v3, v0

    invoke-direct {v1, v2, v0}, Landroid/graphics/PointF;-><init>(FF)V

    #v1=(Reference);
    return-object v1
.end method

.method final b(Landroid/graphics/PointF;I)Lcom/tencent/mapapi/map/GeoPoint;
    .locals 12
    .parameter
    .parameter

    .prologue
    const-wide v10, 0x412e848000000000L

    #v10=(LongLo);v11=(LongHi);
    const-wide/high16 v8, 0x3ff0

    .line 125
    #v8=(LongLo);v9=(LongHi);
    iget v0, p1, Landroid/graphics/PointF;->x:F

    #v0=(Integer);
    float-to-double v0, v0

    #v0=(DoubleLo);v1=(DoubleHi);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    #v2=(Reference);
    iget v3, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v3=(Integer);
    sub-int v3, p2, v3

    aget-wide v2, v2, v3

    #v2=(LongLo);v3=(LongHi);
    sub-double/2addr v0, v2

    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Gt:[D

    #v2=(Reference);
    iget v3, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v3=(Integer);
    sub-int v3, p2, v3

    aget-wide v2, v2, v3

    #v2=(LongLo);v3=(LongHi);
    div-double/2addr v0, v2

    .line 126
    const-wide v2, 0x4005bf0a8b145769L

    iget v4, p1, Landroid/graphics/PointF;->y:F

    #v4=(Integer);
    float-to-double v4, v4

    #v4=(DoubleLo);v5=(DoubleHi);
    iget-object v6, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    #v6=(Reference);
    iget v7, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v7=(Integer);
    sub-int v7, p2, v7

    aget-wide v6, v6, v7

    #v6=(LongLo);v7=(LongHi);
    sub-double/2addr v4, v6

    const-wide/high16 v6, 0x3fe0

    div-double/2addr v4, v6

    iget-object v6, p0, Lcom/tencent/mapapi/map/bo;->Gu:[D

    #v6=(Reference);
    iget v7, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v7=(Integer);
    sub-int v7, p2, v7

    aget-wide v6, v6, v7

    #v6=(LongLo);v7=(LongHi);
    div-double/2addr v4, v6

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    .line 128
    #v2=(DoubleLo);v3=(DoubleHi);
    const-wide/high16 v4, 0x4000

    #v4=(LongLo);v5=(LongHi);
    add-double/2addr v2, v8

    div-double v2, v4, v2

    sub-double v2, v8, v2

    invoke-static {v2, v3}, Ljava/lang/Math;->asin(D)D

    move-result-wide v2

    const-wide v4, 0x4066800000000000L

    mul-double/2addr v2, v4

    const-wide v4, 0x400921fb54442d18L

    div-double/2addr v2, v4

    .line 129
    new-instance v4, Lcom/tencent/mapapi/map/GeoPoint;

    #v4=(UninitRef);
    mul-double/2addr v2, v10

    double-to-int v2, v2

    #v2=(Integer);
    mul-double/2addr v0, v10

    double-to-int v0, v0

    #v0=(Integer);
    invoke-direct {v4, v2, v0}, Lcom/tencent/mapapi/map/GeoPoint;-><init>(II)V

    #v4=(Reference);
    return-object v4
.end method

.method public final f(III)Ljava/util/ArrayList;
    .locals 15
    .parameter
    .parameter
    .parameter

    .prologue
    .line 323
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Gq:Lcom/tencent/mapapi/map/GeoPoint;

    #v1=(Reference);
    move/from16 v0, p1

    #v0=(Integer);
    invoke-virtual {p0, v1, v0}, Lcom/tencent/mapapi/map/bo;->a(Lcom/tencent/mapapi/map/GeoPoint;I)Landroid/graphics/PointF;

    move-result-object v1

    .line 325
    iget v2, v1, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    const/high16 v3, 0x4380

    #v3=(Integer);
    div-float/2addr v2, v3

    #v2=(Float);
    float-to-double v2, v2

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {v2, v3}, Ljava/lang/Math;->floor(D)D

    move-result-wide v2

    double-to-int v3, v2

    .line 326
    #v3=(Integer);
    iget v2, v1, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    const/high16 v4, 0x4380

    #v4=(Integer);
    div-float/2addr v2, v4

    #v2=(Float);
    float-to-double v4, v2

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    .line 327
    #v4=(Integer);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/Point;->x:I

    #v2=(Integer);
    int-to-float v2, v2

    #v2=(Float);
    iget v5, v1, Landroid/graphics/PointF;->x:F

    #v5=(Integer);
    const/high16 v6, 0x4380

    #v6=(Integer);
    rem-float/2addr v5, v6

    #v5=(Float);
    sub-float v5, v2, v5

    .line 329
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/Point;->y:I

    #v2=(Integer);
    int-to-float v2, v2

    #v2=(Float);
    const/high16 v6, 0x4380

    iget v1, v1, Landroid/graphics/PointF;->y:F

    #v1=(Integer);
    const/high16 v7, 0x4380

    #v7=(Integer);
    rem-float/2addr v1, v7

    #v1=(Float);
    sub-float v1, v6, v1

    sub-float v6, v2, v1

    .line 332
    #v6=(Float);
    const/high16 v1, 0x4380

    #v1=(Integer);
    div-float v1, v5, v1

    #v1=(Float);
    float-to-double v1, v1

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    double-to-int v1, v1

    .line 333
    #v1=(Integer);
    move/from16 v0, p2

    int-to-float v2, v0

    #v2=(Float);
    const/high16 v7, 0x3f80

    mul-float/2addr v2, v7

    sub-float/2addr v2, v5

    const/high16 v7, 0x4380

    sub-float/2addr v2, v7

    const/high16 v7, 0x4380

    div-float/2addr v2, v7

    float-to-double v7, v2

    #v7=(DoubleLo);v8=(DoubleHi);
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v7

    double-to-int v7, v7

    .line 336
    #v7=(Integer);
    const/high16 v2, 0x4380

    #v2=(Integer);
    div-float v2, v6, v2

    #v2=(Float);
    float-to-double v8, v2

    #v8=(DoubleLo);v9=(DoubleHi);
    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v8

    double-to-int v8, v8

    .line 337
    #v8=(Integer);
    move/from16 v0, p3

    int-to-float v2, v0

    const/high16 v9, 0x3f80

    #v9=(Integer);
    mul-float/2addr v2, v9

    sub-float/2addr v2, v6

    const/high16 v9, 0x4380

    sub-float/2addr v2, v9

    const/high16 v9, 0x4380

    div-float/2addr v2, v9

    float-to-double v9, v2

    #v9=(DoubleLo);v10=(DoubleHi);
    invoke-static {v9, v10}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v9

    double-to-int v9, v9

    .line 370
    #v9=(Integer);
    new-instance v10, Ljava/util/ArrayList;

    #v10=(UninitRef);
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 371
    #v10=(Reference);
    const-wide/high16 v11, 0x4000

    #v11=(LongLo);v12=(LongHi);
    add-int/lit8 v2, p1, 0x1

    #v2=(Integer);
    int-to-double v13, v2

    #v13=(DoubleLo);v14=(DoubleHi);
    invoke-static {v11, v12, v13, v14}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v11

    #v11=(DoubleLo);v12=(DoubleHi);
    double-to-int v11, v11

    .line 377
    #v11=(Integer);
    neg-int v1, v1

    move v2, v1

    :goto_0
    #v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);
    if-gt v2, v7, :cond_1

    .line 379
    neg-int v1, v9

    :goto_1
    if-gt v1, v8, :cond_0

    .line 381
    add-int v12, v3, v2

    #v12=(Integer);
    invoke-static {v11, v12}, Lcom/tencent/mapapi/map/bo;->k(II)I

    move-result v12

    .line 382
    add-int v13, v4, v1

    #v13=(Integer);
    invoke-static {v11, v13}, Lcom/tencent/mapapi/map/bo;->k(II)I

    move-result v13

    .line 383
    new-instance v14, Lcom/tencent/mapapi/map/ac;

    #v14=(UninitRef);
    move/from16 v0, p1

    invoke-direct {v14, v12, v13, v0}, Lcom/tencent/mapapi/map/ac;-><init>(III)V

    .line 389
    #v14=(Reference);
    mul-int/lit16 v12, v2, 0x100

    int-to-float v12, v12

    #v12=(Float);
    add-float/2addr v12, v5

    iput v12, v14, Lcom/tencent/mapapi/map/ab;->EP:F

    .line 390
    mul-int/lit16 v12, v1, 0x100

    #v12=(Integer);
    int-to-float v12, v12

    #v12=(Float);
    sub-float v12, v6, v12

    iput v12, v14, Lcom/tencent/mapapi/map/ab;->EQ:F

    .line 391
    invoke-virtual {v10, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 379
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 377
    :cond_0
    #v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);
    add-int/lit8 v1, v2, 0x1

    move v2, v1

    goto :goto_0

    .line 394
    :cond_1
    return-object v10
.end method

.method public final hB()V
    .locals 0

    .prologue
    .line 68
    invoke-direct {p0}, Lcom/tencent/mapapi/map/bo;->gx()V

    .line 69
    return-void
.end method

.method public final hw()V
    .locals 9

    .prologue
    const-wide/high16 v7, 0x4000

    .line 46
    #v7=(LongLo);v8=(LongHi);
    new-instance v0, Landroid/graphics/Point;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->FM:Lcom/tencent/mapapi/map/bm;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mapapi/map/bm;->it()I

    move-result v1

    #v1=(Integer);
    div-int/lit8 v1, v1, 0x2

    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->FM:Lcom/tencent/mapapi/map/bm;

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mapapi/map/bm;->id()I

    move-result v2

    #v2=(Integer);
    div-int/lit8 v2, v2, 0x2

    invoke-direct {v0, v1, v2}, Landroid/graphics/Point;-><init>(II)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    .line 49
    iget v0, p0, Lcom/tencent/mapapi/map/bo;->CS:I

    #v0=(Integer);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x1

    new-array v0, v0, [F

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gr:[F

    .line 50
    iget v0, p0, Lcom/tencent/mapapi/map/bo;->CS:I

    #v0=(Integer);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x1

    new-array v0, v0, [D

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    .line 51
    iget v0, p0, Lcom/tencent/mapapi/map/bo;->CS:I

    #v0=(Integer);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x1

    new-array v0, v0, [D

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gt:[D

    .line 52
    iget v0, p0, Lcom/tencent/mapapi/map/bo;->CS:I

    #v0=(Integer);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x1

    new-array v0, v0, [D

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gu:[D

    .line 55
    iget v0, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    :goto_0
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->CS:I

    #v1=(Integer);
    if-gt v0, v1, :cond_0

    .line 57
    add-int/lit8 v1, v0, 0x1

    int-to-double v1, v1

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    const-wide/high16 v3, 0x4070

    #v3=(LongLo);v4=(LongHi);
    mul-double/2addr v1, v3

    .line 58
    iget-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gr:[F

    #v3=(Reference);
    iget v4, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v4=(Integer);
    sub-int v4, v0, v4

    const-wide v5, 0x41831c0da0000000L

    #v5=(LongLo);v6=(LongHi);
    div-double v5, v1, v5

    #v5=(DoubleLo);v6=(DoubleHi);
    double-to-float v5, v5

    #v5=(Float);
    aput v5, v3, v4

    .line 59
    iget-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    iget v4, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    sub-int v4, v0, v4

    div-double v5, v1, v7

    #v5=(DoubleLo);
    aput-wide v5, v3, v4

    .line 60
    iget-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gt:[D

    iget v4, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    sub-int v4, v0, v4

    const-wide v5, 0x4076800000000000L

    #v5=(LongLo);v6=(LongHi);
    div-double v5, v1, v5

    #v5=(DoubleLo);v6=(DoubleHi);
    aput-wide v5, v3, v4

    .line 61
    iget-object v3, p0, Lcom/tencent/mapapi/map/bo;->Gu:[D

    iget v4, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    sub-int v4, v0, v4

    const-wide v5, 0x401921fb54442d18L

    #v5=(LongLo);v6=(LongHi);
    div-double/2addr v1, v5

    aput-wide v1, v3, v4

    .line 55
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 63
    :cond_0
    #v1=(Integer);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    invoke-direct {p0}, Lcom/tencent/mapapi/map/bo;->gx()V

    .line 64
    return-void
.end method

.method public final ia()V
    .locals 5

    .prologue
    const/4 v4, 0x0

    .line 139
    #v4=(Null);
    iget-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gs:[D

    #v0=(Reference);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v1=(Integer);
    iget v2, p0, Lcom/tencent/mapapi/map/bo;->CR:I

    #v2=(Integer);
    sub-int/2addr v1, v2

    aget-wide v0, v0, v1

    #v0=(LongLo);v1=(LongHi);
    double-to-int v0, v0

    #v0=(Integer);
    mul-int/lit8 v0, v0, 0x2

    .line 140
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/PointF;->x:F

    #v1=(Integer);
    cmpg-float v1, v1, v4

    #v1=(Byte);
    if-gez v1, :cond_2

    .line 142
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v2, v1, Landroid/graphics/PointF;->x:F

    int-to-float v3, v0

    #v3=(Float);
    add-float/2addr v2, v3

    #v2=(Float);
    iput v2, v1, Landroid/graphics/PointF;->x:F

    .line 148
    :cond_0
    :goto_0
    #v1=(Conflicted);v3=(Conflicted);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/PointF;->y:F

    #v1=(Integer);
    cmpg-float v1, v1, v4

    #v1=(Byte);
    if-gez v1, :cond_3

    .line 150
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v2, v1, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    int-to-float v0, v0

    #v0=(Float);
    add-float/2addr v0, v2

    iput v0, v1, Landroid/graphics/PointF;->y:F

    .line 156
    :cond_1
    :goto_1
    #v0=(Integer);v1=(Conflicted);
    return-void

    .line 144
    :cond_2
    #v1=(Byte);v3=(Uninit);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/PointF;->x:F

    #v1=(Integer);
    int-to-float v2, v0

    #v2=(Float);
    cmpl-float v1, v1, v2

    #v1=(Byte);
    if-lez v1, :cond_0

    .line 146
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v2, v1, Landroid/graphics/PointF;->x:F

    #v2=(Integer);
    int-to-float v3, v0

    #v3=(Float);
    sub-float/2addr v2, v3

    #v2=(Float);
    iput v2, v1, Landroid/graphics/PointF;->x:F

    goto :goto_0

    .line 152
    :cond_3
    #v1=(Byte);v3=(Conflicted);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/PointF;->y:F

    #v1=(Integer);
    int-to-float v2, v0

    cmpl-float v1, v1, v2

    #v1=(Byte);
    if-lez v1, :cond_1

    .line 154
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v1=(Reference);
    iget v2, v1, Landroid/graphics/PointF;->y:F

    #v2=(Integer);
    int-to-float v0, v0

    #v0=(Float);
    sub-float v0, v2, v0

    iput v0, v1, Landroid/graphics/PointF;->y:F

    goto :goto_1
.end method

.method public final in()V
    .locals 2

    .prologue
    .line 170
    iget-object v0, p0, Lcom/tencent/mapapi/map/bo;->Go:Landroid/graphics/PointF;

    #v0=(Reference);
    iget v1, p0, Lcom/tencent/mapapi/map/bo;->Dc:I

    #v1=(Integer);
    invoke-virtual {p0, v0, v1}, Lcom/tencent/mapapi/map/bo;->b(Landroid/graphics/PointF;I)Lcom/tencent/mapapi/map/GeoPoint;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gq:Lcom/tencent/mapapi/map/GeoPoint;

    .line 171
    return-void
.end method

.method public final ix()Landroid/graphics/Point;
    .locals 3

    .prologue
    .line 92
    new-instance v0, Landroid/graphics/Point;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v1=(Reference);
    iget v1, v1, Landroid/graphics/Point;->x:I

    #v1=(Integer);
    iget-object v2, p0, Lcom/tencent/mapapi/map/bo;->Gp:Landroid/graphics/Point;

    #v2=(Reference);
    iget v2, v2, Landroid/graphics/Point;->y:I

    #v2=(Integer);
    invoke-direct {v0, v1, v2}, Landroid/graphics/Point;-><init>(II)V

    .line 93
    #v0=(Reference);
    return-object v0
.end method

.method final iy()Lcom/tencent/mapapi/map/GeoPoint;
    .locals 1

    .prologue
    .line 134
    iget-object v0, p0, Lcom/tencent/mapapi/map/bo;->Gq:Lcom/tencent/mapapi/map/GeoPoint;

    #v0=(Reference);
    return-object v0
.end method

*/}
