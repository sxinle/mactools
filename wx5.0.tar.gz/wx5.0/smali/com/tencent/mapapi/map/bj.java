package com.tencent.mapapi.map; class bj {/*

.class final Lcom/tencent/mapapi/map/bj;
.super Lcom/tencent/mapapi/map/ae;
.source "SourceFile"


# instance fields
.field final synthetic Gb:Lcom/tencent/mapapi/map/bi;


# direct methods
.method constructor <init>(Lcom/tencent/mapapi/map/bi;)V
    .locals 0
    .parameter

    .prologue
    .line 413
    iput-object p1, p0, Lcom/tencent/mapapi/map/bj;->Gb:Lcom/tencent/mapapi/map/bi;

    invoke-direct {p0}, Lcom/tencent/mapapi/map/ae;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final varargs a(I[I)Ljava/lang/String;
    .locals 8
    .parameter
    .parameter

    .prologue
    const/4 v6, 0x2

    #v6=(PosByte);
    const/4 v0, 0x3

    .line 416
    #v0=(PosByte);
    if-eqz p2, :cond_0

    array-length v1, p2

    #v1=(Integer);
    if-eq v1, v0, :cond_1

    .line 418
    :cond_0
    #v1=(Conflicted);
    const/4 v0, 0x0

    .line 437
    :goto_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-object v0

    .line 420
    :cond_1
    #v0=(PosByte);v1=(Integer);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(PosByte);v7=(Uninit);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bj;->Gb:Lcom/tencent/mapapi/map/bi;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    invoke-static {v1}, Lcom/tencent/mapapi/map/bh;->b(Lcom/tencent/mapapi/map/bh;)I

    .line 421
    iget-object v1, p0, Lcom/tencent/mapapi/map/bj;->Gb:Lcom/tencent/mapapi/map/bi;

    iget-object v1, v1, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    invoke-static {v1}, Lcom/tencent/mapapi/map/bh;->c(Lcom/tencent/mapapi/map/bh;)I

    move-result v1

    #v1=(Integer);
    if-le v1, v0, :cond_2

    .line 423
    iget-object v1, p0, Lcom/tencent/mapapi/map/bj;->Gb:Lcom/tencent/mapapi/map/bi;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    invoke-static {v1}, Lcom/tencent/mapapi/map/bh;->d(Lcom/tencent/mapapi/map/bh;)I

    .line 425
    :cond_2
    #v1=(Conflicted);
    iget-object v1, p0, Lcom/tencent/mapapi/map/bj;->Gb:Lcom/tencent/mapapi/map/bi;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mapapi/map/bi;->Ga:Lcom/tencent/mapapi/map/bh;

    invoke-static {v1}, Lcom/tencent/mapapi/map/bh;->c(Lcom/tencent/mapapi/map/bh;)I

    move-result v1

    .line 426
    #v1=(Integer);
    if-le v1, v0, :cond_3

    .line 430
    :goto_1
    #v0=(Integer);
    const/4 v1, 0x0

    #v1=(Null);
    aget v1, p2, v1

    .line 431
    #v1=(Integer);
    const/4 v2, 0x1

    #v2=(One);
    aget v2, p2, v2

    .line 432
    #v2=(Integer);
    aget v3, p2, v6

    #v3=(Integer);
    add-int/lit8 v3, v3, 0x1

    .line 434
    const-wide/high16 v4, 0x4000

    #v4=(LongLo);v5=(LongHi);
    aget v6, p2, v6

    #v6=(Integer);
    add-int/lit8 v6, v6, 0x1

    int-to-double v6, v6

    #v6=(DoubleLo);v7=(DoubleHi);
    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    double-to-int v4, v4

    #v4=(Integer);
    add-int/lit8 v4, v4, -0x1

    sub-int v2, v4, v2

    .line 436
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "http://mt"

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    const-string v4, ".google.com/vt/lyrs=m@159000000&hl=zh-CN&gl=cn&x="

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "&y="

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "&z="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "&s=Gali"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_3
    #v0=(PosByte);v1=(Integer);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(PosByte);v7=(Uninit);
    move v0, v1

    #v0=(Integer);
    goto :goto_1
.end method

*/}
