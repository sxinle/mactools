package com.tencent.mapapi.map; class ap {/*

.class final Lcom/tencent/mapapi/map/ap;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field Dw:J

.field Fk:Landroid/graphics/Bitmap;


# direct methods
.method constructor <init>()V
    .locals 2

    .prologue
    .line 126
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 128
    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mapapi/map/ap;->Fk:Landroid/graphics/Bitmap;

    .line 129
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mapapi/map/ap;->Dw:J

    return-void
.end method

*/}
