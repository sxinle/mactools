package com.tencent.mapapi.map; class o {/*

.class public interface abstract Lcom/tencent/mapapi/map/o;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lcom/tencent/mapapi/map/GeoPoint;Landroid/graphics/Point;)Landroid/graphics/Point;
.end method

.method public abstract h(II)Lcom/tencent/mapapi/map/GeoPoint;
.end method

.method public abstract metersToEquatorPixels(F)F
.end method

*/}
