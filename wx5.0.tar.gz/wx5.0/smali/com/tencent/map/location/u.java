package com.tencent.map.location; class u {/*

.class final Lcom/tencent/map/location/u;
.super Landroid/content/BroadcastReceiver;


# instance fields
.field private synthetic Dv:Lcom/tencent/map/location/s;


# direct methods
.method constructor <init>(Lcom/tencent/map/location/s;)V
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/u;->Dv:Lcom/tencent/map/location/s;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const-string v0, "noConnectivity"

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/u;->Dv:Lcom/tencent/map/location/s;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/s;->d(Lcom/tencent/map/location/s;)Lcom/tencent/map/location/x;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/u;->Dv:Lcom/tencent/map/location/s;

    invoke-static {v0}, Lcom/tencent/map/location/s;->d(Lcom/tencent/map/location/s;)Lcom/tencent/map/location/x;

    move-result-object v0

    const/16 v1, 0x100

    #v1=(PosShort);
    invoke-virtual {v0, v1}, Lcom/tencent/map/location/x;->sendEmptyMessage(I)Z

    :cond_0
    #v0=(Conflicted);
    return-void
.end method

*/}
