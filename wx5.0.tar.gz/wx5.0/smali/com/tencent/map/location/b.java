package com.tencent.map.location; class b {/*

.class final Lcom/tencent/map/location/b;
.super Ljava/lang/Object;


# instance fields
.field final synthetic CB:Lcom/tencent/map/location/a;


# direct methods
.method private constructor <init>(Lcom/tencent/map/location/a;)V
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/b;->CB:Lcom/tencent/map/location/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/map/location/a;B)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/tencent/map/location/b;-><init>(Lcom/tencent/map/location/a;)V

    #p0=(Reference);
    return-void
.end method

*/}
