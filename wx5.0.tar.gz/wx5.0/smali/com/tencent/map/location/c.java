package com.tencent.map.location; class c {/*

.class public final Lcom/tencent/map/location/c;
.super Ljava/lang/Object;


# static fields
.field private static CC:Lcom/tencent/map/location/c;


# instance fields
.field private CD:D

.field private CE:D

.field private CF:D

.field private CG:D

.field private CH:D

.field private CI:D

.field private CJ:Lcom/tencent/map/location/d;

.field private CK:Lcom/tencent/map/location/e;

.field private CL:Z

.field public CM:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-wide v0, p0, Lcom/tencent/map/location/c;->CD:D

    iput-wide v0, p0, Lcom/tencent/map/location/c;->CE:D

    iput-wide v0, p0, Lcom/tencent/map/location/c;->CF:D

    iput-wide v0, p0, Lcom/tencent/map/location/c;->CG:D

    iput-wide v0, p0, Lcom/tencent/map/location/c;->CH:D

    iput-wide v0, p0, Lcom/tencent/map/location/c;->CI:D

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/c;->CK:Lcom/tencent/map/location/e;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tencent/map/location/c;->CL:Z

    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/c;->CM:Ljava/lang/String;

    return-void
.end method

.method static synthetic a(Lcom/tencent/map/location/c;)Lcom/tencent/map/location/d;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic a(Lcom/tencent/map/location/c;[BLjava/lang/String;)V
    .locals 9

    const-wide v7, 0x4076800000000000L

    #v7=(LongLo);v8=(LongHi);
    new-instance v0, Ljava/lang/StringBuffer;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    :try_start_0
    #v0=(Reference);
    new-instance v1, Ljava/lang/String;

    #v1=(UninitRef);
    invoke-direct {v1, p1, p2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    :goto_0
    :try_start_1
    new-instance v1, Lorg/json/JSONObject;

    #v1=(UninitRef);
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    const-string v0, "location"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "latitude"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v1

    #v1=(DoubleLo);v2=(DoubleHi);
    const-string v3, "longitude"

    #v3=(Reference);
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v3

    #v3=(DoubleLo);v4=(DoubleHi);
    iget-wide v5, p0, Lcom/tencent/map/location/c;->CF:D

    #v5=(DoubleLo);v6=(DoubleHi);
    sub-double v5, v1, v5

    iput-wide v5, p0, Lcom/tencent/map/location/c;->CH:D

    iget-wide v5, p0, Lcom/tencent/map/location/c;->CG:D

    sub-double v5, v3, v5

    iput-wide v5, p0, Lcom/tencent/map/location/c;->CI:D

    iget-wide v5, p0, Lcom/tencent/map/location/c;->CF:D

    iput-wide v5, p0, Lcom/tencent/map/location/c;->CD:D

    iget-wide v5, p0, Lcom/tencent/map/location/c;->CG:D

    iput-wide v5, p0, Lcom/tencent/map/location/c;->CE:D

    iget-object v0, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/map/location/d;->a(DD)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    :cond_1
    :goto_1
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return-void

    :catch_0
    #v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    move-exception v1

    #v1=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    invoke-interface {v1, v7, v8, v7, v8}, Lcom/tencent/map/location/d;->a(DD)V

    goto :goto_0

    :catch_1
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    move-exception v0

    iget-object v0, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    invoke-interface {v0, v7, v8, v7, v8}, Lcom/tencent/map/location/d;->a(DD)V

    goto :goto_1
.end method

.method static synthetic a(Lcom/tencent/map/location/c;Z)Z
    .locals 0

    iput-boolean p1, p0, Lcom/tencent/map/location/c;->CL:Z

    return p1
.end method

.method public static hu()Lcom/tencent/map/location/c;
    .locals 1

    sget-object v0, Lcom/tencent/map/location/c;->CC:Lcom/tencent/map/location/c;

    #v0=(Reference);
    if-nez v0, :cond_0

    new-instance v0, Lcom/tencent/map/location/c;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/location/c;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/map/location/c;->CC:Lcom/tencent/map/location/c;

    :cond_0
    sget-object v0, Lcom/tencent/map/location/c;->CC:Lcom/tencent/map/location/c;

    return-object v0
.end method


# virtual methods
.method public final a(DDLcom/tencent/map/location/d;)V
    .locals 9

    const-wide/16 v2, 0x0

    #v2=(LongLo);v3=(LongHi);
    iput-object p5, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    iget-wide v0, p0, Lcom/tencent/map/location/c;->CH:D

    #v0=(DoubleLo);v1=(DoubleHi);
    cmpl-double v0, v0, v2

    #v0=(Byte);
    if-eqz v0, :cond_1

    iget-wide v0, p0, Lcom/tencent/map/location/c;->CI:D

    #v0=(DoubleLo);
    cmpl-double v0, v0, v2

    #v0=(Byte);
    if-eqz v0, :cond_1

    const/16 v0, 0xa

    #v0=(PosByte);
    new-array v8, v0, [F

    #v8=(Reference);
    iget-wide v4, p0, Lcom/tencent/map/location/c;->CD:D

    #v4=(DoubleLo);v5=(DoubleHi);
    iget-wide v6, p0, Lcom/tencent/map/location/c;->CE:D

    #v6=(DoubleLo);v7=(DoubleHi);
    move-wide v0, p1

    #v0=(DoubleLo);
    move-wide v2, p3

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static/range {v0 .. v8}, Landroid/location/Location;->distanceBetween(DDDD[F)V

    const/4 v0, 0x0

    #v0=(Null);
    aget v0, v8, v0

    #v0=(Integer);
    const v1, 0x44bb8000

    #v1=(Integer);
    cmpg-float v0, v0, v1

    #v0=(Byte);
    if-gez v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/c;->CJ:Lcom/tencent/map/location/d;

    #v0=(Reference);
    iget-wide v1, p0, Lcom/tencent/map/location/c;->CH:D

    #v1=(DoubleLo);v2=(DoubleHi);
    add-double/2addr v1, p1

    iget-wide v3, p0, Lcom/tencent/map/location/c;->CI:D

    #v3=(DoubleLo);v4=(DoubleHi);
    add-double/2addr v3, p3

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/map/location/d;->a(DD)V

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-void

    :cond_1
    #v0=(Byte);v2=(LongLo);v3=(LongHi);
    iget-boolean v0, p0, Lcom/tencent/map/location/c;->CL:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "{\"source\":101,\"access_token\":\"160e7bd42dec9428721034e0146fc6dd\",\"location\":{\"latitude\":"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ",\"longitude\":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3, p4}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "}\t}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/map/location/c;->CM:Ljava/lang/String;

    iput-wide p1, p0, Lcom/tencent/map/location/c;->CF:D

    iput-wide p3, p0, Lcom/tencent/map/location/c;->CG:D

    new-instance v0, Lcom/tencent/map/location/e;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/map/location/e;-><init>(Lcom/tencent/map/location/c;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/c;->CK:Lcom/tencent/map/location/e;

    iget-object v0, p0, Lcom/tencent/map/location/c;->CK:Lcom/tencent/map/location/e;

    invoke-virtual {v0}, Lcom/tencent/map/location/e;->start()V

    goto :goto_0
.end method

*/}
