package com.tencent.map.location; class ab {/*

.class public final Lcom/tencent/map/location/ab;
.super Ljava/lang/Object;


# static fields
.field private static CL:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    sput-boolean v0, Lcom/tencent/map/location/ab;->CL:Z

    return-void
.end method

.method public static hG()V
    .locals 0

    return-void
.end method

*/}
