package com.tencent.map.location; class p {/*

.class final Lcom/tencent/map/location/p;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/location/GpsStatus$Listener;
.implements Landroid/location/LocationListener;


# instance fields
.field private synthetic Do:Lcom/tencent/map/location/o;


# direct methods
.method private constructor <init>(Lcom/tencent/map/location/o;)V
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/map/location/o;B)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/tencent/map/location/p;-><init>(Lcom/tencent/map/location/o;)V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final onGpsStatusChanged(I)V
    .locals 2

    packed-switch p1, :pswitch_data_0

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;)V

    return-void

    :pswitch_0
    #v0=(Uninit);v1=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    const/4 v1, 0x1

    #v1=(One);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;I)I

    goto :goto_0

    :pswitch_1
    #v0=(Uninit);v1=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;I)I

    goto :goto_0

    :pswitch_2
    #v0=(Uninit);v1=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;I)I

    goto :goto_0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method public final onLocationChanged(Landroid/location/Location;)V
    .locals 9

    const-wide v7, 0x3e45798ee2308c3aL

    #v7=(LongLo);v8=(LongHi);
    const/4 v0, 0x0

    #v0=(Null);
    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v1

    #v1=(DoubleLo);v2=(DoubleHi);
    invoke-virtual {p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v3

    #v3=(DoubleLo);v4=(DoubleHi);
    const-wide v5, 0x403dffffe2000000L

    #v5=(LongLo);v6=(LongHi);
    cmpl-double v5, v1, v5

    #v5=(Byte);
    if-eqz v5, :cond_0

    const-wide v5, 0x4059fffffc800000L

    #v5=(LongLo);
    cmpl-double v5, v3, v5

    #v5=(Byte);
    if-nez v5, :cond_2

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(LongHi);v5=(Conflicted);
    if-nez v0, :cond_3

    :cond_1
    :goto_1
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v6=(Conflicted);
    return-void

    :cond_2
    #v0=(Null);v1=(DoubleLo);v2=(DoubleHi);v3=(DoubleLo);v4=(DoubleHi);v5=(Byte);v6=(LongHi);
    invoke-static {v1, v2}, Ljava/lang/Math;->abs(D)D

    move-result-wide v5

    #v5=(DoubleLo);v6=(DoubleHi);
    cmpg-double v5, v5, v7

    #v5=(Byte);
    if-ltz v5, :cond_0

    invoke-static {v3, v4}, Ljava/lang/Math;->abs(D)D

    move-result-wide v5

    #v5=(DoubleLo);
    cmpg-double v5, v5, v7

    #v5=(Byte);
    if-ltz v5, :cond_0

    const-wide v5, -0x3fa9800000000000L

    #v5=(LongLo);v6=(LongHi);
    cmpg-double v5, v1, v5

    #v5=(Byte);
    if-ltz v5, :cond_0

    const-wide v5, 0x4056800000000000L

    #v5=(LongLo);
    cmpl-double v1, v1, v5

    #v1=(Byte);
    if-gtz v1, :cond_0

    const-wide v1, -0x3f99800000000000L

    #v1=(LongLo);v2=(LongHi);
    cmpg-double v1, v3, v1

    #v1=(Byte);
    if-ltz v1, :cond_0

    const-wide v1, 0x4066800000000000L

    #v1=(LongLo);
    cmpl-double v1, v3, v1

    #v1=(Byte);
    if-gtz v1, :cond_0

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0

    :cond_3
    #v0=(Boolean);v1=(Conflicted);v5=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    #v1=(LongLo);
    invoke-static {v0, v1, v2}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;J)J

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v0}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;)V

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    const/4 v1, 0x2

    #v1=(PosByte);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;I)I

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    new-instance v1, Lcom/tencent/map/location/q;

    #v1=(UninitRef);
    iget-object v2, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v2=(Reference);
    iget-object v2, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v2}, Lcom/tencent/map/location/o;->b(Lcom/tencent/map/location/o;)I

    iget-object v2, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v2}, Lcom/tencent/map/location/o;->c(Lcom/tencent/map/location/o;)I

    move-result v2

    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v3=(Reference);
    invoke-static {v3}, Lcom/tencent/map/location/o;->d(Lcom/tencent/map/location/o;)I

    iget-object v3, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v3}, Lcom/tencent/map/location/o;->e(Lcom/tencent/map/location/o;)J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    invoke-direct {v1, p1, v2, v3, v4}, Lcom/tencent/map/location/q;-><init>(Landroid/location/Location;IJ)V

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/o;Lcom/tencent/map/location/q;)Lcom/tencent/map/location/q;

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v0}, Lcom/tencent/map/location/o;->f(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/r;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v0}, Lcom/tencent/map/location/o;->f(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/r;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v1}, Lcom/tencent/map/location/o;->g(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/q;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/tencent/map/location/r;->a(Lcom/tencent/map/location/q;)V

    goto/16 :goto_1
.end method

.method public final onProviderDisabled(Ljava/lang/String;)V
    .locals 2

    if-eqz p1, :cond_0

    :try_start_0
    const-string v0, "gps"

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :cond_1
    #v0=(Boolean);v1=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/map/location/o;->h(Lcom/tencent/map/location/o;)I

    move-result v1

    #v1=(Integer);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->b(Lcom/tencent/map/location/o;I)I

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->c(Lcom/tencent/map/location/o;I)I

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v0}, Lcom/tencent/map/location/o;->f(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/r;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v0}, Lcom/tencent/map/location/o;->f(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/r;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/map/location/o;->d(Lcom/tencent/map/location/o;)I

    move-result v1

    #v1=(Integer);
    invoke-interface {v0, v1}, Lcom/tencent/map/location/r;->aj(I)V

    goto :goto_0

    :catch_0
    #v0=(Conflicted);v1=(Uninit);
    move-exception v0

    #v0=(Reference);
    goto :goto_0
.end method

.method public final onProviderEnabled(Ljava/lang/String;)V
    .locals 2

    if-eqz p1, :cond_0

    :try_start_0
    const-string v0, "gps"

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :cond_1
    #v0=(Boolean);v1=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    const/4 v1, 0x4

    #v1=(PosByte);
    invoke-static {v0, v1}, Lcom/tencent/map/location/o;->c(Lcom/tencent/map/location/o;I)I

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v0}, Lcom/tencent/map/location/o;->f(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/r;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    invoke-static {v0}, Lcom/tencent/map/location/o;->f(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/r;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/p;->Do:Lcom/tencent/map/location/o;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/map/location/o;->d(Lcom/tencent/map/location/o;)I

    move-result v1

    #v1=(Integer);
    invoke-interface {v0, v1}, Lcom/tencent/map/location/r;->aj(I)V

    goto :goto_0

    :catch_0
    #v0=(Conflicted);v1=(Uninit);
    move-exception v0

    #v0=(Reference);
    goto :goto_0
.end method

.method public final onStatusChanged(Ljava/lang/String;ILandroid/os/Bundle;)V
    .locals 0

    return-void
.end method

*/}
