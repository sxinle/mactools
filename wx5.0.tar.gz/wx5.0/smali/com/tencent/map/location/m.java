package com.tencent.map.location; class m {/*

.class public final Lcom/tencent/map/location/m;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public CR:I

.field public CS:I

.field public Dc:I

.field public Dd:I

.field public De:I

.field public a:I

.field public b:I

.field public g:I


# direct methods
.method public constructor <init>(IIIIIIII)V
    .locals 2

    const v1, 0x7fffffff

    #v1=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput v0, p0, Lcom/tencent/map/location/m;->a:I

    iput v0, p0, Lcom/tencent/map/location/m;->b:I

    iput v0, p0, Lcom/tencent/map/location/m;->CR:I

    iput v0, p0, Lcom/tencent/map/location/m;->CS:I

    iput v0, p0, Lcom/tencent/map/location/m;->Dc:I

    iput v0, p0, Lcom/tencent/map/location/m;->Dd:I

    iput v1, p0, Lcom/tencent/map/location/m;->g:I

    iput v1, p0, Lcom/tencent/map/location/m;->De:I

    iput p1, p0, Lcom/tencent/map/location/m;->a:I

    iput p2, p0, Lcom/tencent/map/location/m;->b:I

    iput p3, p0, Lcom/tencent/map/location/m;->CR:I

    iput p4, p0, Lcom/tencent/map/location/m;->CS:I

    iput p5, p0, Lcom/tencent/map/location/m;->Dc:I

    iput p6, p0, Lcom/tencent/map/location/m;->Dd:I

    iput p7, p0, Lcom/tencent/map/location/m;->g:I

    iput p8, p0, Lcom/tencent/map/location/m;->De:I

    return-void
.end method


# virtual methods
.method public final clone()Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    :try_start_0
    #v1=(Null);
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/map/location/m;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return-object v0

    :catch_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v0, v1

    #v0=(Null);
    goto :goto_0
.end method

*/}
