package com.tencent.map.location; class l {/*

.class public final Lcom/tencent/map/location/l;
.super Landroid/telephony/PhoneStateListener;


# instance fields
.field private CR:I

.field private CS:I

.field private synthetic Db:Lcom/tencent/map/location/j;

.field private Dc:I

.field private Dd:I

.field private De:I

.field private Df:Ljava/lang/reflect/Method;

.field private Dg:Ljava/lang/reflect/Method;

.field private Dh:Ljava/lang/reflect/Method;

.field private Di:Ljava/lang/reflect/Method;

.field private Dj:Ljava/lang/reflect/Method;

.field private a:I

.field private b:I

.field private g:I


# direct methods
.method public constructor <init>(Lcom/tencent/map/location/j;II)V
    .locals 3

    const v2, 0x7fffffff

    #v2=(Integer);
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object p1, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    invoke-direct {p0}, Landroid/telephony/PhoneStateListener;-><init>()V

    #p0=(Reference);
    iput v0, p0, Lcom/tencent/map/location/l;->a:I

    iput v0, p0, Lcom/tencent/map/location/l;->b:I

    iput v0, p0, Lcom/tencent/map/location/l;->CR:I

    iput v0, p0, Lcom/tencent/map/location/l;->CS:I

    iput v0, p0, Lcom/tencent/map/location/l;->Dc:I

    const/4 v0, -0x1

    #v0=(Byte);
    iput v0, p0, Lcom/tencent/map/location/l;->Dd:I

    iput v2, p0, Lcom/tencent/map/location/l;->g:I

    iput v2, p0, Lcom/tencent/map/location/l;->De:I

    iput-object v1, p0, Lcom/tencent/map/location/l;->Df:Ljava/lang/reflect/Method;

    iput-object v1, p0, Lcom/tencent/map/location/l;->Dg:Ljava/lang/reflect/Method;

    iput-object v1, p0, Lcom/tencent/map/location/l;->Dh:Ljava/lang/reflect/Method;

    iput-object v1, p0, Lcom/tencent/map/location/l;->Di:Ljava/lang/reflect/Method;

    iput-object v1, p0, Lcom/tencent/map/location/l;->Dj:Ljava/lang/reflect/Method;

    iput p2, p0, Lcom/tencent/map/location/l;->b:I

    iput p3, p0, Lcom/tencent/map/location/l;->a:I

    return-void
.end method


# virtual methods
.method public final onCellLocationChanged(Landroid/telephony/CellLocation;)V
    .locals 10

    const v5, 0x7fffffff

    #v5=(Integer);
    const/4 v4, 0x3

    #v4=(PosByte);
    const/4 v3, -0x1

    #v3=(Byte);
    const/4 v1, 0x0

    #v1=(Null);
    iput v3, p0, Lcom/tencent/map/location/l;->Dd:I

    iput v3, p0, Lcom/tencent/map/location/l;->Dc:I

    iput v3, p0, Lcom/tencent/map/location/l;->CS:I

    iput v3, p0, Lcom/tencent/map/location/l;->CR:I

    if-eqz p1, :cond_0

    iget v0, p0, Lcom/tencent/map/location/l;->a:I

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);
    iget-object v9, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v9=(Reference);
    new-instance v0, Lcom/tencent/map/location/m;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v1=(Reference);
    iget v1, p0, Lcom/tencent/map/location/l;->a:I

    #v1=(Integer);
    iget v2, p0, Lcom/tencent/map/location/l;->b:I

    #v2=(Integer);
    iget v3, p0, Lcom/tencent/map/location/l;->CR:I

    #v3=(Integer);
    iget v4, p0, Lcom/tencent/map/location/l;->CS:I

    #v4=(Integer);
    iget v5, p0, Lcom/tencent/map/location/l;->Dc:I

    iget v6, p0, Lcom/tencent/map/location/l;->Dd:I

    #v6=(Integer);
    iget v7, p0, Lcom/tencent/map/location/l;->g:I

    #v7=(Integer);
    iget v8, p0, Lcom/tencent/map/location/l;->De:I

    #v8=(Integer);
    invoke-direct/range {v0 .. v8}, Lcom/tencent/map/location/m;-><init>(IIIIIIII)V

    #v0=(Reference);
    invoke-static {v9, v0}, Lcom/tencent/map/location/j;->a(Lcom/tencent/map/location/j;Lcom/tencent/map/location/m;)Lcom/tencent/map/location/m;

    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    invoke-static {v0}, Lcom/tencent/map/location/j;->a(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/n;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    invoke-static {v0}, Lcom/tencent/map/location/j;->a(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/n;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/map/location/j;->b(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/m;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/tencent/map/location/n;->a(Lcom/tencent/map/location/m;)V

    :cond_1
    #v1=(Conflicted);
    return-void

    :pswitch_0
    #v0=(Integer);v1=(Null);v2=(Uninit);v3=(Byte);v4=(PosByte);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    const/4 v0, 0x0

    :try_start_0
    #v0=(Null);
    check-cast p1, Landroid/telephony/gsm/GsmCellLocation;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {p1}, Landroid/telephony/gsm/GsmCellLocation;->getLac()I

    move-result v0

    #v0=(Integer);
    if-gtz v0, :cond_2

    invoke-virtual {p1}, Landroid/telephony/gsm/GsmCellLocation;->getCid()I

    move-result v0

    if-gtz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/j;->d(Lcom/tencent/map/location/j;)Landroid/telephony/TelephonyManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getCellLocation()Landroid/telephony/CellLocation;

    move-result-object v0

    check-cast v0, Landroid/telephony/gsm/GsmCellLocation;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    move-object p1, v0

    :cond_2
    #v0=(Conflicted);
    const/4 v0, 0x1

    :goto_1
    #v0=(Boolean);v2=(Conflicted);
    if-eqz v0, :cond_0

    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/j;->d(Lcom/tencent/map/location/j;)Landroid/telephony/TelephonyManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getNetworkOperator()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_3

    :try_start_2
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-le v1, v4, :cond_3

    const/4 v1, 0x3

    #v1=(PosByte);
    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/l;->CR:I

    :cond_3
    #v0=(Conflicted);v1=(Integer);
    invoke-virtual {p1}, Landroid/telephony/gsm/GsmCellLocation;->getLac()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/l;->CS:I

    invoke-virtual {p1}, Landroid/telephony/gsm/GsmCellLocation;->getCid()I

    move-result v0

    iput v0, p0, Lcom/tencent/map/location/l;->Dc:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :goto_2
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/j;->c(Lcom/tencent/map/location/j;)V

    goto/16 :goto_0

    :catch_0
    #v0=(Null);v1=(Null);v2=(Uninit);
    move-exception v2

    #v2=(Reference);
    move-object p1, v0

    :goto_3
    #v0=(Reference);v2=(Conflicted);
    move v0, v1

    #v0=(Null);
    goto :goto_1

    :catch_1
    #v0=(Conflicted);v1=(Integer);
    move-exception v0

    #v0=(Reference);
    iput v3, p0, Lcom/tencent/map/location/l;->Dc:I

    iput v3, p0, Lcom/tencent/map/location/l;->CS:I

    iput v3, p0, Lcom/tencent/map/location/l;->CR:I

    goto :goto_2

    :pswitch_1
    #v0=(Integer);v1=(Null);v2=(Uninit);
    if-eqz p1, :cond_0

    :try_start_3
    iget-object v0, p0, Lcom/tencent/map/location/l;->Df:Ljava/lang/reflect/Method;

    #v0=(Reference);
    if-nez v0, :cond_4

    const-string v0, "android.telephony.cdma.CdmaCellLocation"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "getBaseStationId"

    #v1=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/map/location/l;->Df:Ljava/lang/reflect/Method;

    const-string v0, "android.telephony.cdma.CdmaCellLocation"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "getSystemId"

    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/map/location/l;->Dg:Ljava/lang/reflect/Method;

    const-string v0, "android.telephony.cdma.CdmaCellLocation"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "getNetworkId"

    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/map/location/l;->Dh:Ljava/lang/reflect/Method;

    const-string v0, "android.telephony.cdma.CdmaCellLocation"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "getBaseStationLatitude"

    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/map/location/l;->Di:Ljava/lang/reflect/Method;

    const-string v0, "android.telephony.cdma.CdmaCellLocation"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "getBaseStationLongitude"

    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/Class;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/map/location/l;->Dj:Ljava/lang/reflect/Method;

    :cond_4
    #v2=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/l;->Dg:Ljava/lang/reflect/Method;

    const/4 v1, 0x0

    #v1=(Null);
    new-array v1, v1, [Ljava/lang/Object;

    #v1=(Reference);
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/l;->CR:I

    iget-object v0, p0, Lcom/tencent/map/location/l;->Dh:Ljava/lang/reflect/Method;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    new-array v1, v1, [Ljava/lang/Object;

    #v1=(Reference);
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/l;->CS:I

    iget-object v0, p0, Lcom/tencent/map/location/l;->Df:Ljava/lang/reflect/Method;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    new-array v1, v1, [Ljava/lang/Object;

    #v1=(Reference);
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/l;->Dc:I

    iget-object v0, p0, Lcom/tencent/map/location/l;->Di:Ljava/lang/reflect/Method;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    new-array v1, v1, [Ljava/lang/Object;

    #v1=(Reference);
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/l;->g:I

    iget-object v0, p0, Lcom/tencent/map/location/l;->Dj:Ljava/lang/reflect/Method;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    new-array v1, v1, [Ljava/lang/Object;

    #v1=(Reference);
    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/l;->De:I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    goto/16 :goto_0

    :catch_2
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    iput v3, p0, Lcom/tencent/map/location/l;->Dc:I

    iput v3, p0, Lcom/tencent/map/location/l;->CS:I

    iput v3, p0, Lcom/tencent/map/location/l;->CR:I

    iput v5, p0, Lcom/tencent/map/location/l;->g:I

    iput v5, p0, Lcom/tencent/map/location/l;->De:I

    goto/16 :goto_0

    :catch_3
    #v0=(Conflicted);v1=(Null);v2=(Uninit);
    move-exception v0

    #v0=(Reference);
    goto/16 :goto_3

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public final onSignalStrengthChanged(I)V
    .locals 10

    iget v0, p0, Lcom/tencent/map/location/l;->a:I

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/j;->c(Lcom/tencent/map/location/j;)V

    :cond_0
    #v0=(Conflicted);
    iget v0, p0, Lcom/tencent/map/location/l;->Dd:I

    #v0=(Integer);
    add-int/lit8 v0, v0, 0x71

    div-int/lit8 v0, v0, 0x2

    sub-int v0, p1, v0

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    const/4 v1, 0x3

    #v1=(PosByte);
    if-le v0, v1, :cond_1

    iget v0, p0, Lcom/tencent/map/location/l;->Dd:I

    const/4 v1, -0x1

    #v1=(Byte);
    if-ne v0, v1, :cond_2

    shl-int/lit8 v0, p1, 0x1

    add-int/lit8 v0, v0, -0x71

    iput v0, p0, Lcom/tencent/map/location/l;->Dd:I

    :cond_1
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    return-void

    :cond_2
    #v0=(Integer);v1=(Byte);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    shl-int/lit8 v0, p1, 0x1

    add-int/lit8 v0, v0, -0x71

    iput v0, p0, Lcom/tencent/map/location/l;->Dd:I

    iget-object v9, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v9=(Reference);
    new-instance v0, Lcom/tencent/map/location/m;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v1=(Reference);
    iget v1, p0, Lcom/tencent/map/location/l;->a:I

    #v1=(Integer);
    iget v2, p0, Lcom/tencent/map/location/l;->b:I

    #v2=(Integer);
    iget v3, p0, Lcom/tencent/map/location/l;->CR:I

    #v3=(Integer);
    iget v4, p0, Lcom/tencent/map/location/l;->CS:I

    #v4=(Integer);
    iget v5, p0, Lcom/tencent/map/location/l;->Dc:I

    #v5=(Integer);
    iget v6, p0, Lcom/tencent/map/location/l;->Dd:I

    #v6=(Integer);
    iget v7, p0, Lcom/tencent/map/location/l;->g:I

    #v7=(Integer);
    iget v8, p0, Lcom/tencent/map/location/l;->De:I

    #v8=(Integer);
    invoke-direct/range {v0 .. v8}, Lcom/tencent/map/location/m;-><init>(IIIIIIII)V

    #v0=(Reference);
    invoke-static {v9, v0}, Lcom/tencent/map/location/j;->a(Lcom/tencent/map/location/j;Lcom/tencent/map/location/m;)Lcom/tencent/map/location/m;

    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    invoke-static {v0}, Lcom/tencent/map/location/j;->a(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/n;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    invoke-static {v0}, Lcom/tencent/map/location/j;->a(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/n;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/l;->Db:Lcom/tencent/map/location/j;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/map/location/j;->b(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/m;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/tencent/map/location/n;->a(Lcom/tencent/map/location/m;)V

    goto :goto_0
.end method

*/}
