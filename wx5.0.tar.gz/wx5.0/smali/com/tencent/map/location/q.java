package com.tencent.map.location; class q {/*

.class public final Lcom/tencent/map/location/q;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field private CO:J

.field private Dp:Landroid/location/Location;

.field private a:I


# direct methods
.method public constructor <init>(Landroid/location/Location;IJ)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/q;->Dp:Landroid/location/Location;

    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/q;->CO:J

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/tencent/map/location/q;->a:I

    if-eqz p1, :cond_0

    new-instance v0, Landroid/location/Location;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Landroid/location/Location;-><init>(Landroid/location/Location;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/q;->Dp:Landroid/location/Location;

    iput p2, p0, Lcom/tencent/map/location/q;->a:I

    iput-wide p3, p0, Lcom/tencent/map/location/q;->CO:J

    :cond_0
    return-void
.end method


# virtual methods
.method public final clone()Ljava/lang/Object;
    .locals 3

    const/4 v1, 0x0

    :try_start_0
    #v1=(Null);
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/map/location/q;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iget-object v1, p0, Lcom/tencent/map/location/q;->Dp:Landroid/location/Location;

    #v1=(Reference);
    if-eqz v1, :cond_0

    new-instance v1, Landroid/location/Location;

    #v1=(UninitRef);
    iget-object v2, p0, Lcom/tencent/map/location/q;->Dp:Landroid/location/Location;

    #v2=(Reference);
    invoke-direct {v1, v2}, Landroid/location/Location;-><init>(Landroid/location/Location;)V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/map/location/q;->Dp:Landroid/location/Location;

    :cond_0
    #v2=(Conflicted);
    return-object v0

    :catch_0
    #v0=(Conflicted);v1=(Null);v2=(Uninit);
    move-exception v0

    #v0=(Reference);
    move-object v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public final hy()Z
    .locals 5

    const/4 v0, 0x0

    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/map/location/q;->Dp:Landroid/location/Location;

    #v1=(Reference);
    if-nez v1, :cond_1

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v1=(Reference);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget v1, p0, Lcom/tencent/map/location/q;->a:I

    #v1=(Integer);
    if-lez v1, :cond_2

    iget v1, p0, Lcom/tencent/map/location/q;->a:I

    const/4 v2, 0x3

    #v2=(PosByte);
    if-lt v1, v2, :cond_0

    :cond_2
    #v2=(Conflicted);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    iget-wide v3, p0, Lcom/tencent/map/location/q;->CO:J

    #v3=(LongLo);v4=(LongHi);
    sub-long/2addr v1, v3

    const-wide/16 v3, 0x7530

    cmp-long v1, v1, v3

    #v1=(Byte);
    if-gtz v1, :cond_0

    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final hz()Landroid/location/Location;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/q;->Dp:Landroid/location/Location;

    #v0=(Reference);
    return-object v0
.end method

*/}
