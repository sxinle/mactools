package com.tencent.map.location; class n {/*

.class public interface abstract Lcom/tencent/map/location/n;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/tencent/map/location/m;)V
.end method

*/}
