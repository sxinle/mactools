package com.tencent.map.location; class i {/*

.class final Lcom/tencent/map/location/i;
.super Ljava/lang/Object;


# instance fields
.field public CM:Ljava/lang/String;


# direct methods
.method private constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/i;->CM:Ljava/lang/String;

    return-void
.end method

.method synthetic constructor <init>(B)V
    .locals 0

    invoke-direct {p0}, Lcom/tencent/map/location/i;-><init>()V

    #p0=(Reference);
    return-void
.end method

*/}
