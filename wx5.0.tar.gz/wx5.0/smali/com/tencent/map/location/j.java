package com.tencent.map.location; class j {/*

.class public final Lcom/tencent/map/location/j;
.super Ljava/lang/Object;


# instance fields
.field private CL:Z

.field private CP:Ljava/util/List;

.field private CT:Landroid/content/Context;

.field private CU:Landroid/telephony/TelephonyManager;

.field private CV:Lcom/tencent/map/location/l;

.field private CW:Lcom/tencent/map/location/n;

.field private CX:Lcom/tencent/map/location/m;

.field private CY:[B

.field private CZ:[B

.field private Da:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    #v1=(Null);
    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/j;->CT:Landroid/content/Context;

    iput-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    iput-object v0, p0, Lcom/tencent/map/location/j;->CV:Lcom/tencent/map/location/l;

    iput-object v0, p0, Lcom/tencent/map/location/j;->CW:Lcom/tencent/map/location/n;

    iput-object v0, p0, Lcom/tencent/map/location/j;->CX:Lcom/tencent/map/location/m;

    iput-boolean v1, p0, Lcom/tencent/map/location/j;->CL:Z

    new-instance v0, Ljava/util/LinkedList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/j;->CP:Ljava/util/List;

    new-array v0, v1, [B

    iput-object v0, p0, Lcom/tencent/map/location/j;->CY:[B

    new-array v0, v1, [B

    iput-object v0, p0, Lcom/tencent/map/location/j;->CZ:[B

    iput-boolean v1, p0, Lcom/tencent/map/location/j;->Da:Z

    return-void
.end method

.method static synthetic a(Lcom/tencent/map/location/j;Lcom/tencent/map/location/m;)Lcom/tencent/map/location/m;
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/j;->CX:Lcom/tencent/map/location/m;

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/n;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/j;->CW:Lcom/tencent/map/location/n;

    #v0=(Reference);
    return-object v0
.end method

.method private ai(I)I
    .locals 5

    const/4 v4, 0x3

    #v4=(PosByte);
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v2, -0x1

    #v2=(Byte);
    iget-object v1, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    #v1=(Reference);
    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getNetworkOperator()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    #v3=(Integer);
    if-lt v3, v4, :cond_0

    const/4 v3, 0x0

    #v3=(Null);
    const/4 v4, 0x3

    :try_start_0
    invoke-virtual {v1, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v1

    :goto_0
    #v1=(Integer);v3=(Conflicted);
    const/4 v3, 0x2

    #v3=(PosByte);
    if-ne p1, v3, :cond_1

    if-ne v1, v2, :cond_1

    :goto_1
    #v0=(Integer);
    return v0

    :catch_0
    #v0=(Null);v1=(Reference);v3=(Null);
    move-exception v1

    :cond_0
    #v3=(Conflicted);
    move v1, v2

    #v1=(Byte);
    goto :goto_0

    :cond_1
    #v1=(Integer);v3=(PosByte);
    move v0, v1

    #v0=(Integer);
    goto :goto_1
.end method

.method static synthetic b(Lcom/tencent/map/location/j;)Lcom/tencent/map/location/m;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/j;->CX:Lcom/tencent/map/location/m;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/tencent/map/location/j;)V
    .locals 2

    const/4 v1, 0x1

    #v1=(One);
    iget-boolean v0, p0, Lcom/tencent/map/location/j;->Da:Z

    #v0=(Boolean);
    if-eq v0, v1, :cond_0

    iput-boolean v1, p0, Lcom/tencent/map/location/j;->Da:Z

    new-instance v0, Lcom/tencent/map/location/k;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/map/location/k;-><init>(Lcom/tencent/map/location/j;)V

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/map/location/k;->start()V

    :cond_0
    #v0=(Conflicted);
    return-void
.end method

.method static synthetic d(Lcom/tencent/map/location/j;)Landroid/telephony/TelephonyManager;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic e(Lcom/tencent/map/location/j;)[B
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/j;->CZ:[B

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic f(Lcom/tencent/map/location/j;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/j;->CP:Ljava/util/List;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic g(Lcom/tencent/map/location/j;)Z
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/map/location/j;->Da:Z

    return v0
.end method


# virtual methods
.method public final a(Landroid/content/Context;Lcom/tencent/map/location/n;)Z
    .locals 5

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v2, p0, Lcom/tencent/map/location/j;->CY:[B

    #v2=(Reference);
    monitor-enter v2

    :try_start_0
    iget-boolean v3, p0, Lcom/tencent/map/location/j;->CL:Z

    #v3=(Boolean);
    if-eqz v3, :cond_0

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    #v0=(Boolean);v3=(Conflicted);v4=(Conflicted);
    return v0

    :cond_0
    #v0=(One);v3=(Boolean);v4=(Uninit);
    if-eqz p1, :cond_1

    if-nez p2, :cond_2

    :cond_1
    monitor-exit v2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    :try_start_1
    #v0=(One);
    iput-object p1, p0, Lcom/tencent/map/location/j;->CT:Landroid/content/Context;

    iput-object p2, p0, Lcom/tencent/map/location/j;->CW:Lcom/tencent/map/location/n;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    iget-object v0, p0, Lcom/tencent/map/location/j;->CT:Landroid/content/Context;

    #v0=(Reference);
    const-string v3, "phone"

    #v3=(Reference);
    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    iput-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    iget-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    if-nez v0, :cond_3

    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_3
    :try_start_4
    #v0=(Reference);
    iget-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getPhoneType()I

    move-result v0

    #v0=(Integer);
    invoke-direct {p0, v0}, Lcom/tencent/map/location/j;->ai(I)I

    move-result v3

    #v3=(Integer);
    new-instance v4, Lcom/tencent/map/location/l;

    #v4=(UninitRef);
    invoke-direct {v4, p0, v3, v0}, Lcom/tencent/map/location/l;-><init>(Lcom/tencent/map/location/j;II)V

    #v4=(Reference);
    iput-object v4, p0, Lcom/tencent/map/location/j;->CV:Lcom/tencent/map/location/l;

    iget-object v0, p0, Lcom/tencent/map/location/j;->CV:Lcom/tencent/map/location/l;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    #v0=(Reference);
    if-nez v0, :cond_4

    :try_start_5
    monitor-exit v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_4
    :try_start_6
    #v0=(Reference);
    iget-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    iget-object v3, p0, Lcom/tencent/map/location/j;->CV:Lcom/tencent/map/location/l;

    #v3=(Reference);
    const/16 v4, 0x12

    #v4=(PosByte);
    invoke-virtual {v0, v3, v4}, Landroid/telephony/TelephonyManager;->listen(Landroid/telephony/PhoneStateListener;I)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    const/4 v0, 0x1

    :try_start_7
    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/map/location/j;->CL:Z

    monitor-exit v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    iget-boolean v0, p0, Lcom/tencent/map/location/j;->CL:Z

    #v0=(Boolean);
    goto :goto_0

    :catch_0
    #v0=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    :try_start_8
    #v0=(Reference);
    monitor-exit v2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0
.end method

.method public final hw()V
    .locals 4

    iget-object v1, p0, Lcom/tencent/map/location/j;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-boolean v0, p0, Lcom/tencent/map/location/j;->CL:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    monitor-exit v1

    :goto_0
    #v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_0
    #v2=(Uninit);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/j;->CV:Lcom/tencent/map/location/l;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_1

    :try_start_1
    iget-object v0, p0, Lcom/tencent/map/location/j;->CU:Landroid/telephony/TelephonyManager;

    iget-object v2, p0, Lcom/tencent/map/location/j;->CV:Lcom/tencent/map/location/l;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {v0, v2, v3}, Landroid/telephony/TelephonyManager;->listen(Landroid/telephony/PhoneStateListener;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :cond_1
    :goto_1
    #v2=(Conflicted);v3=(Conflicted);
    const/4 v0, 0x0

    :try_start_2
    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/map/location/j;->CL:Z

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    :catch_0
    move-exception v0

    const/4 v0, 0x0

    :try_start_3
    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/map/location/j;->CL:Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1
.end method

.method public final hx()Ljava/util/List;
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/map/location/j;->CZ:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v2, p0, Lcom/tencent/map/location/j;->CP:Ljava/util/List;

    #v2=(Reference);
    if-eqz v2, :cond_0

    new-instance v0, Ljava/util/LinkedList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    #v0=(Reference);
    iget-object v2, p0, Lcom/tencent/map/location/j;->CP:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_0
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

*/}
