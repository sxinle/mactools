package com.tencent.map.location; class h {/*

.class final Lcom/tencent/map/location/h;
.super Ljava/lang/Object;


# instance fields
.field public CR:I

.field public CS:I

.field public a:I

.field public b:I


# direct methods
.method private constructor <init>()V
    .locals 1

    const/4 v0, -0x1

    #v0=(Byte);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput v0, p0, Lcom/tencent/map/location/h;->a:I

    iput v0, p0, Lcom/tencent/map/location/h;->b:I

    iput v0, p0, Lcom/tencent/map/location/h;->CR:I

    iput v0, p0, Lcom/tencent/map/location/h;->CS:I

    return-void
.end method

.method synthetic constructor <init>(B)V
    .locals 0

    invoke-direct {p0}, Lcom/tencent/map/location/h;-><init>()V

    #p0=(Reference);
    return-void
.end method

*/}
