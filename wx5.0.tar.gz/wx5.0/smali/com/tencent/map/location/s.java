package com.tencent.map.location; class s {/*

.class public final Lcom/tencent/map/location/s;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/map/location/aa;
.implements Lcom/tencent/map/location/d;
.implements Lcom/tencent/map/location/n;
.implements Lcom/tencent/map/location/r;


# static fields
.field private static Da:Z

.field private static Dv:Lcom/tencent/map/location/s;


# instance fields
.field private CC:Lcom/tencent/map/location/c;

.field private CL:Z

.field private CM:Ljava/lang/String;

.field private CN:Lcom/tencent/map/location/f;

.field private CO:J

.field private CR:I

.field private CS:I

.field private CT:Landroid/content/Context;

.field private CX:Lcom/tencent/map/location/m;

.field private CY:[B

.field private CZ:[B

.field private DA:Ljava/lang/String;

.field private DB:Ljava/lang/String;

.field private DC:Ljava/lang/String;

.field private DD:Z

.field private DE:J

.field private DF:Landroid/os/Handler;

.field private DG:Ljava/lang/Runnable;

.field private final DH:Landroid/content/BroadcastReceiver;

.field private Db:Lcom/tencent/map/location/j;

.field private Dc:I

.field private Dd:I

.field private De:I

.field private Dn:Lcom/tencent/map/location/q;

.field private Do:Lcom/tencent/map/location/o;

.field private Dq:Lcom/tencent/map/location/g;

.field private Dr:Lcom/tencent/map/a/a/b;

.field private Ds:Lcom/tencent/map/location/x;

.field private Dt:Lcom/tencent/map/location/w;

.field private Du:Lcom/tencent/map/location/v;

.field private Dw:J

.field private Dx:Lcom/tencent/map/location/z;

.field private Dy:Lcom/tencent/map/a/a/d;

.field private Dz:Lcom/tencent/map/a/a/d;

.field private a:I

.field private b:I

.field private b:Ljava/lang/String;

.field private c:Z

.field private d:Ljava/lang/String;

.field private g:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    sput-boolean v0, Lcom/tencent/map/location/s;->Da:Z

    const/4 v0, 0x0

    sput-object v0, Lcom/tencent/map/location/s;->Dv:Lcom/tencent/map/location/s;

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const-wide/16 v0, 0x1388

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/s;->CO:J

    iput-object v2, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Do:Lcom/tencent/map/location/o;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Db:Lcom/tencent/map/location/j;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    const/16 v0, 0x400

    #v0=(PosShort);
    iput v0, p0, Lcom/tencent/map/location/s;->a:I

    const/4 v0, 0x4

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/map/location/s;->b:I

    iput-object v2, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    iput-object v2, p0, Lcom/tencent/map/location/s;->CC:Lcom/tencent/map/location/c;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    new-array v0, v3, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->CY:[B

    new-array v0, v3, [B

    iput-object v0, p0, Lcom/tencent/map/location/s;->CZ:[B

    iput-boolean v3, p0, Lcom/tencent/map/location/s;->CL:Z

    iput-object v2, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Dt:Lcom/tencent/map/location/w;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Du:Lcom/tencent/map/location/v;

    const-wide/16 v0, -0x1

    #v0=(LongLo);
    iput-wide v0, p0, Lcom/tencent/map/location/s;->Dw:J

    iput-object v2, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    iput-object v2, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput-object v2, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iput v3, p0, Lcom/tencent/map/location/s;->Dd:I

    iput v3, p0, Lcom/tencent/map/location/s;->g:I

    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/map/location/s;->De:I

    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->CM:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/map/location/s;->b:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/map/location/s;->DA:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/map/location/s;->d:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/map/location/s;->DB:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/map/location/s;->DC:Ljava/lang/String;

    iput-boolean v3, p0, Lcom/tencent/map/location/s;->c:Z

    iput-boolean v3, p0, Lcom/tencent/map/location/s;->DD:Z

    const-wide/16 v0, 0x0

    #v0=(LongLo);
    iput-wide v0, p0, Lcom/tencent/map/location/s;->DE:J

    iput-object v2, p0, Lcom/tencent/map/location/s;->DF:Landroid/os/Handler;

    new-instance v0, Lcom/tencent/map/location/t;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/map/location/t;-><init>(Lcom/tencent/map/location/s;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->DG:Ljava/lang/Runnable;

    new-instance v0, Lcom/tencent/map/location/u;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/map/location/u;-><init>(Lcom/tencent/map/location/s;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->DH:Landroid/content/BroadcastReceiver;

    new-instance v0, Lcom/tencent/map/location/o;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/location/o;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Do:Lcom/tencent/map/location/o;

    new-instance v0, Lcom/tencent/map/location/j;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/location/j;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Db:Lcom/tencent/map/location/j;

    new-instance v0, Lcom/tencent/map/location/g;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/location/g;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    return-void
.end method

.method static synthetic a(Lcom/tencent/map/location/s;)J
    .locals 2

    iget-wide v0, p0, Lcom/tencent/map/location/s;->DE:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic a(Lcom/tencent/map/location/s;J)J
    .locals 0

    iput-wide p1, p0, Lcom/tencent/map/location/s;->DE:J

    return-wide p1
.end method

.method private static a(Lorg/json/JSONArray;)Ljava/util/ArrayList;
    .locals 13

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v11

    #v11=(Integer);
    new-instance v12, Ljava/util/ArrayList;

    #v12=(UninitRef);
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    #v12=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    move v10, v0

    :goto_0
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Integer);
    if-ge v10, v11, :cond_0

    invoke-virtual {p0, v10}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "name"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "addr"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "catalog"

    #v3=(Reference);
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "dist"

    #v4=(Reference);
    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v4

    #v4=(DoubleLo);v5=(DoubleHi);
    const-string v6, "latitude"

    #v6=(Reference);
    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v6

    #v6=(DoubleLo);v7=(DoubleHi);
    const-string v8, "longitude"

    #v8=(Reference);
    invoke-virtual {v0, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v8

    #v8=(DoubleLo);v9=(DoubleHi);
    new-instance v0, Lcom/tencent/map/a/a/c;

    #v0=(UninitRef);
    invoke-direct/range {v0 .. v9}, Lcom/tencent/map/a/a/c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDD)V

    #v0=(Reference);
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v10, 0x1

    #v0=(Integer);
    move v10, v0

    goto :goto_0

    :cond_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    return-object v12
.end method

.method static synthetic a(Lcom/tencent/map/location/s;I)V
    .locals 1

    if-nez p1, :cond_0

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    :cond_0
    #v0=(Conflicted);
    if-nez p1, :cond_2

    const/4 v0, 0x1

    :goto_0
    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/map/location/s;->a:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    iget v0, p0, Lcom/tencent/map/location/s;->a:I

    :cond_1
    #v0=(Conflicted);
    return-void

    :cond_2
    const/4 v0, 0x2

    #v0=(PosByte);
    goto :goto_0
.end method

.method static synthetic a(Lcom/tencent/map/location/s;Landroid/location/Location;)V
    .locals 8

    const/4 v7, 0x3

    #v7=(PosByte);
    const-wide v2, 0x4076700000000000L

    #v2=(LongLo);v3=(LongHi);
    const/4 v6, 0x4

    #v6=(PosByte);
    const/4 v5, 0x0

    #v5=(Null);
    const/4 v4, 0x1

    #v4=(One);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v0

    #v0=(DoubleLo);v1=(DoubleHi);
    cmpl-double v0, v0, v2

    #v0=(Byte);
    if-gtz v0, :cond_0

    invoke-virtual {p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v0

    #v0=(DoubleLo);
    cmpl-double v0, v0, v2

    #v0=(Byte);
    if-lez v0, :cond_1

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v0=(Reference);
    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    invoke-virtual {v0}, Lcom/tencent/map/location/q;->hy()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_5

    invoke-direct {p0, v4}, Lcom/tencent/map/location/s;->d(Z)V

    :cond_1
    :goto_0
    #v0=(Conflicted);
    new-instance v0, Lcom/tencent/map/a/a/d;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/a/a/d;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v5, v0, Lcom/tencent/map/a/a/d;->Cz:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v5, v0, Lcom/tencent/map/a/a/d;->Cy:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v1

    #v1=(DoubleLo);v2=(DoubleHi);
    const/4 v3, 0x6

    #v3=(PosByte);
    invoke-static {v1, v2, v3}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/tencent/map/a/a/d;->Ca:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v1

    const/4 v3, 0x6

    invoke-static {v1, v2, v3}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/tencent/map/a/a/d;->Cb:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    invoke-virtual {v0}, Lcom/tencent/map/location/q;->hy()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/map/location/q;->hz()Landroid/location/Location;

    move-result-object v1

    invoke-virtual {v1}, Landroid/location/Location;->getAccuracy()F

    move-result v1

    #v1=(Float);
    float-to-double v1, v1

    #v1=(DoubleLo);
    invoke-static {v1, v2, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/tencent/map/a/a/d;->Ce:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/map/location/q;->hz()Landroid/location/Location;

    move-result-object v1

    invoke-virtual {v1}, Landroid/location/Location;->getAltitude()D

    move-result-wide v1

    #v1=(DoubleLo);
    invoke-static {v1, v2, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/tencent/map/a/a/d;->Cd:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/map/location/q;->hz()Landroid/location/Location;

    move-result-object v1

    invoke-virtual {v1}, Landroid/location/Location;->getSpeed()F

    move-result v1

    #v1=(Float);
    float-to-double v1, v1

    #v1=(DoubleLo);
    invoke-static {v1, v2, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/tencent/map/a/a/d;->Cf:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/map/location/q;->hz()Landroid/location/Location;

    move-result-object v1

    invoke-virtual {v1}, Landroid/location/Location;->getBearing()F

    move-result v1

    #v1=(Float);
    float-to-double v1, v1

    #v1=(DoubleLo);
    invoke-static {v1, v2, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v1

    iput-wide v1, v0, Lcom/tencent/map/a/a/d;->Cg:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v5, v0, Lcom/tencent/map/a/a/d;->Cc:I

    :cond_2
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iput-boolean v4, v0, Lcom/tencent/map/a/a/d;->Cx:Z

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    #v0=(Integer);
    if-eqz v0, :cond_8

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    if-eqz v0, :cond_8

    iget v0, p0, Lcom/tencent/map/location/s;->Dd:I

    #v0=(Integer);
    if-nez v0, :cond_8

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    if-eq v0, v7, :cond_3

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    if-ne v0, v6, :cond_4

    :cond_3
    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/map/a/a/d;->Cz:I

    #v1=(Integer);
    if-ne v0, v1, :cond_4

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v7, v0, Lcom/tencent/map/a/a/d;->Cz:I

    :cond_4
    #v0=(Conflicted);v1=(Conflicted);
    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    #v0=(Integer);
    if-ne v0, v6, :cond_7

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/map/a/a/d;->Cz:I

    #v1=(Integer);
    if-ne v0, v1, :cond_7

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    if-eqz v0, :cond_7

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    new-instance v1, Ljava/util/ArrayList;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v0, v0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    #v2=(Conflicted);v3=(Conflicted);
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/map/a/a/c;

    iget-object v2, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    new-instance v3, Lcom/tencent/map/a/a/c;

    #v3=(UninitRef);
    invoke-direct {v3, v0}, Lcom/tencent/map/a/a/c;-><init>(Lcom/tencent/map/a/a/c;)V

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_5
    #v0=(Conflicted);v1=(Conflicted);v2=(LongLo);v3=(LongHi);
    invoke-direct {p0}, Lcom/tencent/map/location/s;->hC()V

    goto/16 :goto_0

    :cond_6
    #v0=(Boolean);v1=(Reference);v2=(Conflicted);v3=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iput v6, v0, Lcom/tencent/map/a/a/d;->Cz:I

    :cond_7
    #v0=(Conflicted);v1=(Conflicted);
    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    #v0=(Integer);
    const/4 v1, 0x7

    #v1=(PosByte);
    if-ne v0, v1, :cond_8

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/map/a/a/d;->Cz:I

    #v1=(Integer);
    if-ne v0, v1, :cond_8

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    const/4 v1, 0x7

    #v1=(PosByte);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/map/a/a/d;->Ch:I

    #v1=(Integer);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Ch:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget v0, v0, Lcom/tencent/map/a/a/d;->Ch:I

    #v0=(Integer);
    if-nez v0, :cond_c

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    :cond_8
    :goto_2
    #v0=(Conflicted);v1=(Conflicted);
    iget v0, p0, Lcom/tencent/map/location/s;->Dd:I

    #v0=(Integer);
    if-nez v0, :cond_9

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    if-eqz v0, :cond_b

    :cond_9
    #v0=(Conflicted);
    iget v0, p0, Lcom/tencent/map/location/s;->Dd:I

    #v0=(Integer);
    if-eqz v0, :cond_a

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iget v1, p0, Lcom/tencent/map/location/s;->Dd:I

    #v1=(Integer);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cy:I

    :cond_a
    #v0=(Conflicted);v1=(Conflicted);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iget-wide v2, p0, Lcom/tencent/map/location/s;->Dw:J

    #v2=(LongLo);v3=(LongHi);
    sub-long/2addr v0, v2

    iget-wide v2, p0, Lcom/tencent/map/location/s;->CO:J

    cmp-long v0, v0, v2

    #v0=(Byte);
    if-ltz v0, :cond_b

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_b

    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    #v0=(Integer);
    if-ne v0, v4, :cond_b

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/map/a/a/b;->a(Lcom/tencent/map/a/a/d;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/s;->Dw:J

    :cond_b
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_c
    #v0=(Integer);v1=(Reference);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iget-object v1, v1, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;

    iput-object v1, v0, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;

    goto :goto_2
.end method

.method static synthetic a(Lcom/tencent/map/location/s;Lcom/tencent/map/location/m;)V
    .locals 5

    iput-object p1, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    invoke-virtual {v0}, Lcom/tencent/map/location/g;->hy()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/map/location/g;->hF()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    const-wide/16 v1, 0x0

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/map/location/g;->f(J)V

    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    :cond_0
    #v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget v0, p0, Lcom/tencent/map/location/s;->g:I

    #v0=(Integer);
    if-lez v0, :cond_1

    iget v0, p1, Lcom/tencent/map/location/m;->a:I

    iget v1, p1, Lcom/tencent/map/location/m;->b:I

    #v1=(Integer);
    iget v2, p1, Lcom/tencent/map/location/m;->CR:I

    #v2=(Integer);
    iget v3, p1, Lcom/tencent/map/location/m;->CS:I

    #v3=(Integer);
    iget v4, p1, Lcom/tencent/map/location/m;->Dc:I

    #v4=(Integer);
    invoke-static {v0, v1, v2, v3, v4}, Lcom/tencent/map/location/ac;->a(IIIII)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    iget v0, p0, Lcom/tencent/map/location/s;->g:I

    #v0=(Integer);
    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/tencent/map/location/s;->g:I

    :cond_1
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    invoke-direct {p0}, Lcom/tencent/map/location/s;->hB()V

    goto :goto_0
.end method

.method static synthetic a(Lcom/tencent/map/location/s;Lcom/tencent/map/location/q;)V
    .locals 6

    const/4 v1, 0x1

    #v1=(One);
    if-eqz p1, :cond_0

    iput-object p1, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    #v0=(Integer);
    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    invoke-virtual {v0}, Lcom/tencent/map/location/q;->hy()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-void

    :cond_1
    #v0=(Boolean);v1=(One);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    #v0=(Integer);
    if-nez v0, :cond_2

    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0, v0}, Lcom/tencent/map/location/s;->d(Z)V

    goto :goto_0

    :cond_2
    #v0=(Integer);
    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->CC:Lcom/tencent/map/location/c;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->CC:Lcom/tencent/map/location/c;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/map/location/q;->hz()Landroid/location/Location;

    move-result-object v1

    invoke-virtual {v1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v1

    #v1=(DoubleLo);v2=(DoubleHi);
    iget-object v3, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v3=(Reference);
    invoke-virtual {v3}, Lcom/tencent/map/location/q;->hz()Landroid/location/Location;

    move-result-object v3

    invoke-virtual {v3}, Landroid/location/Location;->getLongitude()D

    move-result-wide v3

    #v3=(DoubleLo);v4=(DoubleHi);
    iget-object v5, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    #v5=(Reference);
    move-object v5, p0

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/map/location/c;->a(DDLcom/tencent/map/location/d;)V

    goto :goto_0
.end method

.method static synthetic a(Lcom/tencent/map/location/s;Lcom/tencent/map/location/z;)V
    .locals 0

    if-eqz p1, :cond_0

    iput-object p1, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    invoke-direct {p0}, Lcom/tencent/map/location/s;->hB()V

    :cond_0
    return-void
.end method

.method static synthetic a(Lcom/tencent/map/location/s;Ljava/lang/String;)V
    .locals 7

    const/4 v2, 0x3

    #v2=(PosByte);
    const/4 v6, 0x0

    #v6=(Null);
    invoke-static {p1}, Lcom/tencent/map/location/ac;->ae(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_3

    iget v0, p0, Lcom/tencent/map/location/s;->g:I

    #v0=(Integer);
    if-lez v0, :cond_1

    iget v0, p0, Lcom/tencent/map/location/s;->g:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/tencent/map/location/s;->g:I

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Integer);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-void

    :cond_1
    #v0=(Integer);v1=(Uninit);v2=(PosByte);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    goto :goto_0

    :cond_2
    #v0=(Conflicted);
    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_0

    new-instance v0, Lcom/tencent/map/a/a/d;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/a/a/d;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v2, p0, Lcom/tencent/map/location/s;->Dd:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v2, v0, Lcom/tencent/map/a/a/d;->Cy:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/map/a/a/b;->a(Lcom/tencent/map/a/a/d;)V

    goto :goto_0

    :cond_3
    #v0=(Boolean);v1=(Uninit);
    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    #v0=(Integer);
    if-nez v0, :cond_4

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_4

    :try_start_0
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    goto :goto_0

    :cond_4
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    #v0=(Reference);
    if-nez v0, :cond_5

    move-object v0, v6

    :goto_2
    #v1=(Conflicted);v2=(Integer);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    if-eqz v0, :cond_6

    invoke-direct {p0, v0}, Lcom/tencent/map/location/s;->ab(Ljava/lang/String;)V

    goto :goto_0

    :cond_5
    #v1=(Uninit);v2=(PosByte);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    if-eqz v0, :cond_9

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    if-eqz v0, :cond_9

    iget-object v0, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    iget-object v1, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/map/location/m;->b:I

    #v1=(Integer);
    iget-object v2, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v2=(Reference);
    iget v2, v2, Lcom/tencent/map/location/m;->CR:I

    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v3=(Reference);
    iget v3, v3, Lcom/tencent/map/location/m;->CS:I

    #v3=(Integer);
    iget-object v4, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v4=(Reference);
    iget v4, v4, Lcom/tencent/map/location/m;->Dc:I

    #v4=(Integer);
    iget-object v5, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    #v5=(Reference);
    invoke-virtual {v5}, Lcom/tencent/map/location/z;->hx()Ljava/util/List;

    move-result-object v5

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/map/location/f;->b(IIIILjava/util/List;)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_6
    #v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    if-eqz v0, :cond_7

    iget-object v0, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    if-eqz v0, :cond_7

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    if-eqz v0, :cond_7

    iget-object v0, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    iget-object v1, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/map/location/m;->b:I

    #v1=(Integer);
    iget-object v2, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v2=(Reference);
    iget v2, v2, Lcom/tencent/map/location/m;->CR:I

    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v3=(Reference);
    iget v3, v3, Lcom/tencent/map/location/m;->CS:I

    #v3=(Integer);
    iget-object v4, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v4=(Reference);
    iget v4, v4, Lcom/tencent/map/location/m;->Dc:I

    #v4=(Integer);
    iget-object v5, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    #v5=(Reference);
    invoke-virtual {v5}, Lcom/tencent/map/location/z;->hx()Ljava/util/List;

    move-result-object v5

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/map/location/f;->a(IIIILjava/util/List;)V

    :cond_7
    #v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    iget-boolean v0, p0, Lcom/tencent/map/location/s;->CL:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dt:Lcom/tencent/map/location/w;

    #v0=(Reference);
    if-eqz v0, :cond_8

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dt:Lcom/tencent/map/location/w;

    invoke-virtual {v0}, Lcom/tencent/map/location/w;->interrupt()V

    :cond_8
    iput-object v6, p0, Lcom/tencent/map/location/s;->Dt:Lcom/tencent/map/location/w;

    new-instance v0, Lcom/tencent/map/location/w;

    #v0=(UninitRef);
    invoke-direct {v0, p0, p1}, Lcom/tencent/map/location/w;-><init>(Lcom/tencent/map/location/s;Ljava/lang/String;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dt:Lcom/tencent/map/location/w;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dt:Lcom/tencent/map/location/w;

    invoke-virtual {v0}, Lcom/tencent/map/location/w;->start()V

    goto/16 :goto_0

    :catch_0
    #v1=(Uninit);v2=(PosByte);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    move-exception v0

    goto :goto_1

    :cond_9
    move-object v0, v6

    #v0=(Null);
    goto :goto_2
.end method

.method static synthetic a(Lcom/tencent/map/location/s;Z)Z
    .locals 0

    iput-boolean p1, p0, Lcom/tencent/map/location/s;->CL:Z

    return p1
.end method

.method private ab(Ljava/lang/String;)V
    .locals 12

    const/4 v11, 0x2

    #v11=(PosByte);
    const/4 v10, 0x4

    #v10=(PosByte);
    const-wide/high16 v8, 0x4024

    #v8=(LongLo);v9=(LongHi);
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v2, 0x1

    :try_start_0
    #v2=(One);
    new-instance v0, Lcom/tencent/map/a/a/d;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/a/a/d;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    new-instance v3, Lorg/json/JSONObject;

    #v3=(UninitRef);
    invoke-direct {v3, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    const-string v0, "location"

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    iget-object v4, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v4=(Reference);
    const/4 v5, 0x1

    #v5=(One);
    iput v5, v4, Lcom/tencent/map/a/a/d;->Cc:I

    iget-object v4, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v5, "latitude"

    #v5=(Reference);
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v5

    #v5=(DoubleLo);v6=(DoubleHi);
    const/4 v7, 0x6

    #v7=(PosByte);
    invoke-static {v5, v6, v7}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v5

    iput-wide v5, v4, Lcom/tencent/map/a/a/d;->Ca:D

    iget-object v4, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v5, "longitude"

    #v5=(Reference);
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v5

    #v5=(DoubleLo);
    const/4 v7, 0x6

    invoke-static {v5, v6, v7}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v5

    iput-wide v5, v4, Lcom/tencent/map/a/a/d;->Cb:D

    iget-object v4, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v5, "altitude"

    #v5=(Reference);
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v5

    #v5=(DoubleLo);
    const/4 v7, 0x1

    #v7=(One);
    invoke-static {v5, v6, v7}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v5

    iput-wide v5, v4, Lcom/tencent/map/a/a/d;->Cd:D

    iget-object v4, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v5, "accuracy"

    #v5=(Reference);
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v5

    #v5=(DoubleLo);
    const/4 v0, 0x1

    #v0=(One);
    invoke-static {v5, v6, v0}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v5

    iput-wide v5, v4, Lcom/tencent/map/a/a/d;->Ce:D

    iget-object v4, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    #v0=(Integer);
    if-ne v0, v2, :cond_a

    move v0, v2

    :goto_0
    #v0=(Boolean);
    iput-boolean v0, v4, Lcom/tencent/map/a/a/d;->Cx:Z

    const-string v0, "bearing"

    #v0=(Reference);
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v0, -0x64

    #v0=(Byte);
    if-eqz v4, :cond_0

    const-string v5, ","

    #v5=(Reference);
    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    array-length v5, v5

    #v5=(Integer);
    if-le v5, v2, :cond_0

    const-string v1, ","

    #v1=(Reference);
    invoke-virtual {v4, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    #v4=(One);
    aget-object v1, v1, v4

    #v1=(Null);
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    :cond_0
    #v1=(Integer);v4=(Conflicted);v5=(Conflicted);
    iget-object v4, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v4=(Reference);
    if-eqz v4, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v0=(Reference);
    iget v0, v0, Lcom/tencent/map/location/m;->Dd:I

    :cond_1
    #v0=(Integer);
    iget-object v4, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v5, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v5=(Reference);
    iget-wide v5, v5, Lcom/tencent/map/a/a/d;->Ce:D

    #v5=(DoubleLo);
    const/4 v7, 0x6

    #v7=(PosByte);
    if-lt v1, v7, :cond_b

    const-wide/high16 v0, 0x4044

    :goto_1
    #v0=(LongLo);v1=(LongHi);v5=(LongLo);v6=(LongHi);v7=(Byte);
    iput-wide v0, v4, Lcom/tencent/map/a/a/d;->Ce:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    #v0=(Integer);
    const/4 v1, 0x3

    #v1=(PosByte);
    if-eq v0, v1, :cond_2

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    if-ne v0, v10, :cond_3

    :cond_2
    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    if-ne v0, v2, :cond_3

    const-string v0, "details"

    #v0=(Reference);
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "subnation"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "name"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Lcom/tencent/map/a/a/d;->Z(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "town"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v1, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "village"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v1, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "street"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v1, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "street_no"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v1, 0x3

    #v1=(PosByte);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v1, 0x0

    #v1=(Null);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Ch:I

    :cond_3
    #v0=(Conflicted);v1=(PosByte);
    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    #v0=(Integer);
    if-ne v0, v10, :cond_4

    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    if-ne v0, v2, :cond_4

    const-string v0, "details"

    #v0=(Reference);
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "poilist"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-static {v0}, Lcom/tencent/map/location/s;->a(Lorg/json/JSONArray;)Ljava/util/ArrayList;

    move-result-object v0

    iput-object v0, v1, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v1, 0x4

    #v1=(PosByte);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    :cond_4
    #v0=(Conflicted);
    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    #v0=(Integer);
    const/4 v1, 0x7

    if-ne v0, v1, :cond_6

    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    if-ne v0, v2, :cond_6

    const-string v0, "details"

    #v0=(Reference);
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "stat"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v1

    #v1=(Integer);
    const-string v3, "subnation"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    if-nez v1, :cond_13

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "name"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/tencent/map/a/a/d;->Z(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "town"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "village"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "street"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "street_no"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v3, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    :cond_5
    :goto_2
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v1, v0, Lcom/tencent/map/a/a/d;->Ch:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v1, 0x7

    #v1=(PosByte);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    :cond_6
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cy:I

    new-instance v0, Lcom/tencent/map/a/a/d;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/tencent/map/a/a/d;-><init>(Lcom/tencent/map/a/a/d;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/tencent/map/location/s;->Dd:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    #v0=(Reference);
    if-eqz v0, :cond_7

    iget-object v0, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    invoke-virtual {v0, p1}, Lcom/tencent/map/location/f;->aa(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_7
    :goto_3
    #v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    if-eqz v0, :cond_9

    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    #v0=(Integer);
    if-ne v0, v2, :cond_9

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v0=(Reference);
    if-eqz v0, :cond_8

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    invoke-virtual {v0}, Lcom/tencent/map/location/q;->hy()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_9

    :cond_8
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/map/a/a/b;->a(Lcom/tencent/map/a/a/d;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/s;->Dw:J

    :cond_9
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :cond_a
    #v0=(Integer);v1=(Null);v3=(Reference);v4=(Reference);v5=(DoubleLo);v6=(DoubleHi);v7=(One);
    move v0, v1

    #v0=(Null);
    goto/16 :goto_0

    :cond_b
    #v0=(Integer);v1=(Integer);v7=(PosByte);
    const/4 v7, 0x5

    if-ne v1, v7, :cond_c

    const-wide/high16 v0, 0x404e

    #v0=(LongLo);v1=(LongHi);
    goto/16 :goto_1

    :cond_c
    #v0=(Integer);v1=(Integer);
    if-ne v1, v10, :cond_d

    const-wide v0, 0x4051800000000000L

    #v0=(LongLo);v1=(LongHi);
    goto/16 :goto_1

    :cond_d
    #v0=(Integer);v1=(Integer);
    const/4 v7, 0x3

    if-ne v1, v7, :cond_e

    const-wide v0, 0x4056800000000000L

    #v0=(LongLo);v1=(LongHi);
    goto/16 :goto_1

    :cond_e
    #v0=(Integer);v1=(Integer);
    if-ne v1, v11, :cond_f

    const-wide v0, 0x405b800000000000L

    #v0=(LongLo);v1=(LongHi);
    goto/16 :goto_1

    :cond_f
    #v0=(Integer);v1=(Integer);
    const/16 v7, -0x48

    #v7=(Byte);
    if-lt v0, v7, :cond_10

    if-nez v1, :cond_10

    const-wide v0, 0x3fdccccccccccccdL

    #v0=(LongLo);v1=(LongHi);
    mul-double/2addr v0, v5

    #v0=(DoubleLo);v1=(DoubleHi);
    div-double/2addr v0, v8

    double-to-int v0, v0

    #v0=(Integer);
    mul-int/lit8 v0, v0, 0xa

    :goto_4
    #v5=(LongLo);v6=(LongHi);
    int-to-double v0, v0

    #v0=(DoubleLo);
    goto/16 :goto_1

    :cond_10
    #v0=(Integer);v1=(Integer);v5=(DoubleLo);v6=(DoubleHi);
    const-wide/high16 v0, 0x4059

    #v0=(LongLo);v1=(LongHi);
    cmpg-double v0, v5, v0

    #v0=(Byte);
    if-gtz v0, :cond_11

    const-wide/high16 v0, 0x3ff0

    #v0=(LongLo);
    sub-double v0, v5, v0

    #v0=(DoubleLo);v1=(DoubleHi);
    div-double/2addr v0, v8

    const-wide/high16 v5, 0x3ff0

    #v5=(LongLo);v6=(LongHi);
    add-double/2addr v0, v5

    double-to-int v0, v0

    #v0=(Integer);
    mul-int/lit8 v0, v0, 0xa

    goto :goto_4

    :cond_11
    #v0=(Byte);v1=(LongHi);v5=(DoubleLo);v6=(DoubleHi);
    const-wide/high16 v0, 0x4059

    #v0=(LongLo);
    cmpl-double v0, v5, v0

    #v0=(Byte);
    if-lez v0, :cond_12

    const-wide/high16 v0, 0x4089

    #v0=(LongLo);
    cmpg-double v0, v5, v0

    #v0=(Byte);
    if-gtz v0, :cond_12

    const-wide v0, 0x3feb333333333333L

    #v0=(LongLo);
    mul-double/2addr v0, v5

    #v0=(DoubleLo);v1=(DoubleHi);
    div-double/2addr v0, v8

    double-to-int v0, v0

    #v0=(Integer);
    mul-int/lit8 v0, v0, 0xa

    goto :goto_4

    :cond_12
    #v0=(Byte);v1=(LongHi);
    const-wide v0, 0x3fe999999999999aL

    #v0=(LongLo);
    mul-double/2addr v0, v5

    #v0=(DoubleLo);v1=(DoubleHi);
    div-double/2addr v0, v8

    double-to-int v0, v0

    #v0=(Integer);
    mul-int/lit8 v0, v0, 0xa

    goto :goto_4

    :cond_13
    #v0=(Reference);v1=(Integer);v5=(LongLo);v6=(LongHi);
    if-ne v1, v2, :cond_5

    :try_start_1
    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "nation"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "admin_level_1"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "admin_level_2"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "admin_level_3"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "locality"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "sublocality"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v3, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    iget-object v3, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const-string v4, "route"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v3, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_2

    :catch_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    move-exception v0

    #v0=(Reference);
    new-instance v0, Lcom/tencent/map/a/a/d;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/a/a/d;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v11, v0, Lcom/tencent/map/a/a/d;->Cy:I

    iput v11, p0, Lcom/tencent/map/location/s;->Dd:I

    goto/16 :goto_3
.end method

.method static synthetic b(Lcom/tencent/map/location/s;)Lcom/tencent/map/location/g;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/map/location/s;I)V
    .locals 1

    const/4 v0, 0x3

    #v0=(PosByte);
    if-ne p1, v0, :cond_0

    const/4 v0, 0x4

    :cond_0
    iput v0, p0, Lcom/tencent/map/location/s;->b:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    iget v0, p0, Lcom/tencent/map/location/s;->b:I

    :cond_1
    #v0=(Conflicted);
    return-void
.end method

.method static synthetic b(Lcom/tencent/map/location/s;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/tencent/map/location/s;->ab(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic c(Lcom/tencent/map/location/s;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/s;->CM:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic c(Lcom/tencent/map/location/s;)V
    .locals 0

    invoke-direct {p0}, Lcom/tencent/map/location/s;->hB()V

    return-void
.end method

.method static synthetic d(Lcom/tencent/map/location/s;)Lcom/tencent/map/location/x;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic d(Lcom/tencent/map/location/s;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/s;->b:Ljava/lang/String;

    return-object p1
.end method

.method private d(Z)V
    .locals 7

    const/4 v6, 0x6

    #v6=(PosByte);
    const/4 v5, 0x0

    #v5=(Null);
    const/4 v4, 0x1

    #v4=(One);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    invoke-virtual {v0}, Lcom/tencent/map/location/q;->hy()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/map/location/q;->hz()Landroid/location/Location;

    move-result-object v0

    new-instance v1, Lcom/tencent/map/a/a/d;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/map/a/a/d;-><init>()V

    #v1=(Reference);
    iput-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {v0}, Landroid/location/Location;->getLatitude()D

    move-result-wide v2

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-static {v2, v3, v6}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v2

    iput-wide v2, v1, Lcom/tencent/map/a/a/d;->Ca:D

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {v0}, Landroid/location/Location;->getLongitude()D

    move-result-wide v2

    invoke-static {v2, v3, v6}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v2

    iput-wide v2, v1, Lcom/tencent/map/a/a/d;->Cb:D

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {v0}, Landroid/location/Location;->getAltitude()D

    move-result-wide v2

    invoke-static {v2, v3, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v2

    iput-wide v2, v1, Lcom/tencent/map/a/a/d;->Cd:D

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {v0}, Landroid/location/Location;->getAccuracy()F

    move-result v2

    #v2=(Float);
    float-to-double v2, v2

    #v2=(DoubleLo);
    invoke-static {v2, v3, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v2

    iput-wide v2, v1, Lcom/tencent/map/a/a/d;->Ce:D

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {v0}, Landroid/location/Location;->getSpeed()F

    move-result v2

    #v2=(Float);
    float-to-double v2, v2

    #v2=(DoubleLo);
    invoke-static {v2, v3, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v2

    iput-wide v2, v1, Lcom/tencent/map/a/a/d;->Cf:D

    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-virtual {v0}, Landroid/location/Location;->getBearing()F

    move-result v0

    #v0=(Float);
    float-to-double v2, v0

    invoke-static {v2, v3, v4}, Lcom/tencent/map/location/ac;->a(DI)D

    move-result-wide v2

    iput-wide v2, v1, Lcom/tencent/map/a/a/d;->Cg:D

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v0=(Reference);
    iput v5, v0, Lcom/tencent/map/a/a/d;->Cc:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput-boolean v5, v0, Lcom/tencent/map/a/a/d;->Cx:Z

    if-nez p1, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v5, v0, Lcom/tencent/map/a/a/d;->Cy:I

    :goto_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v5, v0, Lcom/tencent/map/a/a/d;->Cz:I

    new-instance v0, Lcom/tencent/map/a/a/d;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    invoke-direct {v0, v1}, Lcom/tencent/map/a/a/d;-><init>(Lcom/tencent/map/a/a/d;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    iput v5, p0, Lcom/tencent/map/location/s;->Dd:I

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iget-wide v2, p0, Lcom/tencent/map/location/s;->Dw:J

    #v2=(LongLo);v3=(LongHi);
    sub-long/2addr v0, v2

    iget-wide v2, p0, Lcom/tencent/map/location/s;->CO:J

    cmp-long v0, v0, v2

    #v0=(Byte);
    if-ltz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    #v0=(Integer);
    if-ne v0, v4, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/map/a/a/b;->a(Lcom/tencent/map/a/a/d;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/s;->Dw:J

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_1
    #v0=(Reference);v1=(Reference);v2=(DoubleLo);v3=(DoubleHi);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v4, v0, Lcom/tencent/map/a/a/d;->Cy:I

    goto :goto_0
.end method

.method static synthetic e(Lcom/tencent/map/location/s;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/s;->Dd:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic e(Lcom/tencent/map/location/s;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/s;->DA:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic f(Lcom/tencent/map/location/s;)Lcom/tencent/map/location/v;
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Du:Lcom/tencent/map/location/v;

    return-object v0
.end method

.method static synthetic f(Lcom/tencent/map/location/s;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/s;->DB:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic g(Lcom/tencent/map/location/s;)Lcom/tencent/map/location/q;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic h(Lcom/tencent/map/location/s;)V
    .locals 0

    invoke-direct {p0}, Lcom/tencent/map/location/s;->hC()V

    return-void
.end method

.method public static declared-synchronized hA()Lcom/tencent/map/location/s;
    .locals 2

    const-class v1, Lcom/tencent/map/location/s;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    sget-object v0, Lcom/tencent/map/location/s;->Dv:Lcom/tencent/map/location/s;

    #v0=(Reference);
    if-nez v0, :cond_0

    new-instance v0, Lcom/tencent/map/location/s;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/location/s;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/map/location/s;->Dv:Lcom/tencent/map/location/s;

    :cond_0
    sget-object v0, Lcom/tencent/map/location/s;->Dv:Lcom/tencent/map/location/s;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method private hB()V
    .locals 4

    iget-object v0, p0, Lcom/tencent/map/location/s;->Du:Lcom/tencent/map/location/v;

    #v0=(Reference);
    if-eqz v0, :cond_0

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    :cond_0
    #v1=(Uninit);v2=(Uninit);v3=(Uninit);
    new-instance v0, Lcom/tencent/map/location/v;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    #v3=(Reference);
    invoke-direct {v0, p0, v1, v2, v3}, Lcom/tencent/map/location/v;-><init>(Lcom/tencent/map/location/s;Lcom/tencent/map/location/q;Lcom/tencent/map/location/m;Lcom/tencent/map/location/z;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Du:Lcom/tencent/map/location/v;

    iget-object v0, p0, Lcom/tencent/map/location/s;->Du:Lcom/tencent/map/location/v;

    invoke-virtual {v0}, Lcom/tencent/map/location/v;->start()V

    goto :goto_0
.end method

.method private hC()V
    .locals 3

    const/4 v2, 0x1

    #v2=(One);
    new-instance v0, Lcom/tencent/map/a/a/d;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/a/a/d;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v2, p0, Lcom/tencent/map/location/s;->Dd:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v2, v0, Lcom/tencent/map/a/a/d;->Cy:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, v0, Lcom/tencent/map/a/a/d;->Cz:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    iput v2, v0, Lcom/tencent/map/a/a/d;->Cc:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    if-eqz v0, :cond_0

    iget v0, p0, Lcom/tencent/map/location/s;->CR:I

    #v0=(Integer);
    if-ne v0, v2, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/map/a/a/b;->a(Lcom/tencent/map/a/a/d;)V

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void
.end method

.method static synthetic hD()V
    .locals 0

    return-void
.end method

.method static synthetic hE()Z
    .locals 1

    const/4 v0, 0x1

    #v0=(One);
    sput-boolean v0, Lcom/tencent/map/location/s;->Da:Z

    return v0
.end method

.method static synthetic hy()Z
    .locals 1

    sget-boolean v0, Lcom/tencent/map/location/s;->Da:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic i(Lcom/tencent/map/location/s;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/s;->De:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic j(Lcom/tencent/map/location/s;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic k(Lcom/tencent/map/location/s;)Landroid/content/Context;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic l(Lcom/tencent/map/location/s;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->CM:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic m(Lcom/tencent/map/location/s;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->b:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic n(Lcom/tencent/map/location/s;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->DA:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic o(Lcom/tencent/map/location/s;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/s;->b:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic p(Lcom/tencent/map/location/s;)Lcom/tencent/map/location/j;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->Db:Lcom/tencent/map/location/j;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic q(Lcom/tencent/map/location/s;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->d:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic r(Lcom/tencent/map/location/s;)Z
    .locals 1

    iget-boolean v0, p0, Lcom/tencent/map/location/s;->c:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic s(Lcom/tencent/map/location/s;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/s;->CS:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic t(Lcom/tencent/map/location/s;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->DB:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic u(Lcom/tencent/map/location/s;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/s;->DC:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final a(DD)V
    .locals 4

    iget-object v1, p0, Lcom/tencent/map/location/s;->CZ:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v0=(Reference);
    const/4 v2, 0x6

    #v2=(PosByte);
    invoke-virtual {v0, v2}, Lcom/tencent/map/location/x;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    new-instance v2, Landroid/location/Location;

    #v2=(UninitRef);
    const-string v3, "Deflect"

    #v3=(Reference);
    invoke-direct {v2, v3}, Landroid/location/Location;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p1, p2}, Landroid/location/Location;->setLatitude(D)V

    invoke-virtual {v2, p3, p4}, Landroid/location/Location;->setLongitude(D)V

    iput-object v2, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    iget-object v2, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    invoke-virtual {v2, v0}, Lcom/tencent/map/location/x;->sendMessage(Landroid/os/Message;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final a(Lcom/tencent/map/location/m;)V
    .locals 3

    iget-object v1, p0, Lcom/tencent/map/location/s;->CZ:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v0=(Reference);
    const/4 v2, 0x2

    #v2=(PosByte);
    invoke-virtual {v0, v2, p1}, Lcom/tencent/map/location/x;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v2=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/map/location/x;->sendMessage(Landroid/os/Message;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final a(Lcom/tencent/map/location/q;)V
    .locals 3

    iget-object v1, p0, Lcom/tencent/map/location/s;->CZ:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v0=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    invoke-virtual {v0, v2, p1}, Lcom/tencent/map/location/x;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v2=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/map/location/x;->sendMessage(Landroid/os/Message;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final a(Lcom/tencent/map/location/z;)V
    .locals 3

    iget-object v1, p0, Lcom/tencent/map/location/s;->CZ:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v0=(Reference);
    const/4 v2, 0x3

    #v2=(PosByte);
    invoke-virtual {v0, v2, p1}, Lcom/tencent/map/location/x;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v2=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/map/location/x;->sendMessage(Landroid/os/Message;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final a(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    iget-object v1, p0, Lcom/tencent/map/location/s;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    invoke-static {}, Lcom/tencent/map/location/a;->ht()Lcom/tencent/map/location/a;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Lcom/tencent/map/location/a;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iput-object p1, p0, Lcom/tencent/map/location/s;->DC:Ljava/lang/String;

    const/4 v0, 0x1

    #v0=(One);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    const/4 v0, 0x0

    #v0=(Null);
    monitor-exit v1

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final aj(I)V
    .locals 4

    iget-object v1, p0, Lcom/tencent/map/location/s;->CZ:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v0=(Reference);
    const/4 v2, 0x4

    #v2=(PosByte);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {v0, v2, p1, v3}, Lcom/tencent/map/location/x;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v2=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/map/location/x;->sendMessage(Landroid/os/Message;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final ak(I)V
    .locals 4

    iget-object v1, p0, Lcom/tencent/map/location/s;->CZ:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v0=(Reference);
    const/4 v2, 0x5

    #v2=(PosByte);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {v0, v2, p1, v3}, Lcom/tencent/map/location/x;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    #v2=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/map/location/x;->sendMessage(Landroid/os/Message;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public final b(Landroid/content/Context;Lcom/tencent/map/a/a/b;)Z
    .locals 7

    const/4 v2, 0x1

    #v2=(One);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v3, p0, Lcom/tencent/map/location/s;->CY:[B

    #v3=(Reference);
    monitor-enter v3

    if-eqz p1, :cond_0

    if-nez p2, :cond_1

    :cond_0
    monitor-exit v3

    move v0, v1

    :goto_0
    #v0=(Boolean);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return v0

    :cond_1
    :try_start_0
    #v0=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/s;->DC:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/ac;->ac(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_2

    monitor-exit v3

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(Boolean);
    new-instance v0, Lcom/tencent/map/location/x;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/map/location/x;-><init>(Lcom/tencent/map/location/s;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Ds:Lcom/tencent/map/location/x;

    new-instance v0, Landroid/os/Handler;

    #v0=(UninitRef);
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    #v4=(Reference);
    invoke-direct {v0, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/s;->DF:Landroid/os/Handler;

    iput-object p1, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    iput-object p2, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    invoke-static {}, Lcom/tencent/a/a/b;->iz()Lcom/tencent/a/a/b;

    move-result-object v0

    iget-object v4, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v0, v4}, Lcom/tencent/a/a/b;->l(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const-string v0, "connectivity"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v4

    if-eqz v4, :cond_3

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->isRoaming()Z

    move-result v0

    #v0=(Boolean);
    iput-boolean v0, p0, Lcom/tencent/map/location/s;->c:Z

    :cond_3
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    #v0=(Reference);
    iget-object v4, p0, Lcom/tencent/map/location/s;->DH:Landroid/content/BroadcastReceiver;

    new-instance v5, Landroid/content/IntentFilter;

    #v5=(UninitRef);
    const-string v6, "android.net.conn.CONNECTIVITY_CHANGE"

    #v6=(Reference);
    invoke-direct {v5, v6}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    invoke-virtual {v0, v4, v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :goto_1
    :try_start_2
    #v5=(Conflicted);v6=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    invoke-virtual {v0}, Lcom/tencent/map/a/a/b;->hq()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/s;->CR:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/map/a/a/b;->hr()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/s;->CS:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/map/a/a/b;->hs()I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/s;->Dc:I

    const-wide/16 v4, -0x1

    #v4=(LongLo);v5=(LongHi);
    iput-wide v4, p0, Lcom/tencent/map/location/s;->Dw:J

    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/map/location/s;->DD:Z

    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/map/location/s;->De:I

    iget-object v0, p0, Lcom/tencent/map/location/s;->Do:Lcom/tencent/map/location/o;

    #v0=(Reference);
    iget-object v4, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    #v4=(Reference);
    invoke-virtual {v0, p0, v4}, Lcom/tencent/map/location/o;->a(Lcom/tencent/map/location/r;Landroid/content/Context;)Z

    move-result v0

    #v0=(Boolean);
    iget-object v4, p0, Lcom/tencent/map/location/s;->Db:Lcom/tencent/map/location/j;

    iget-object v5, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    #v5=(Reference);
    invoke-virtual {v4, v5, p0}, Lcom/tencent/map/location/j;->a(Landroid/content/Context;Lcom/tencent/map/location/n;)Z

    move-result v4

    #v4=(Boolean);
    iget-object v5, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    iget-object v6, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    #v6=(Reference);
    invoke-virtual {v5, v6, p0}, Lcom/tencent/map/location/g;->a(Landroid/content/Context;Lcom/tencent/map/location/aa;)Z

    move-result v5

    #v5=(Boolean);
    invoke-static {}, Lcom/tencent/map/location/f;->hv()Lcom/tencent/map/location/f;

    move-result-object v6

    iput-object v6, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    invoke-static {}, Lcom/tencent/map/location/c;->hu()Lcom/tencent/map/location/c;

    move-result-object v6

    iput-object v6, p0, Lcom/tencent/map/location/s;->CC:Lcom/tencent/map/location/c;

    const/4 v6, 0x0

    #v6=(Null);
    iput-object v6, p0, Lcom/tencent/map/location/s;->Dn:Lcom/tencent/map/location/q;

    const/4 v6, 0x0

    iput-object v6, p0, Lcom/tencent/map/location/s;->CX:Lcom/tencent/map/location/m;

    const/4 v6, 0x0

    iput-object v6, p0, Lcom/tencent/map/location/s;->Dx:Lcom/tencent/map/location/z;

    const/4 v6, 0x0

    iput-object v6, p0, Lcom/tencent/map/location/s;->Dy:Lcom/tencent/map/a/a/d;

    const/4 v6, 0x0

    iput-object v6, p0, Lcom/tencent/map/location/s;->Dz:Lcom/tencent/map/a/a/d;

    const/4 v6, 0x0

    iput v6, p0, Lcom/tencent/map/location/s;->Dd:I

    iget-object v6, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    #v6=(Reference);
    if-eqz v6, :cond_4

    iget-object v6, p0, Lcom/tencent/map/location/s;->CN:Lcom/tencent/map/location/f;

    invoke-virtual {v6}, Lcom/tencent/map/location/f;->hw()V

    :cond_4
    const/4 v6, 0x1

    #v6=(One);
    iput v6, p0, Lcom/tencent/map/location/s;->g:I

    if-eqz v0, :cond_5

    iget v0, p0, Lcom/tencent/map/location/s;->Dc:I

    #v0=(Integer);
    if-nez v0, :cond_5

    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move v0, v2

    #v0=(One);
    goto/16 :goto_0

    :cond_5
    #v0=(Integer);
    if-nez v4, :cond_6

    if-eqz v5, :cond_7

    :cond_6
    monitor-exit v3

    move v0, v2

    #v0=(One);
    goto/16 :goto_0

    :cond_7
    #v0=(Integer);
    monitor-exit v3

    move v0, v1

    #v0=(Null);
    goto/16 :goto_0

    :catchall_0
    #v0=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v3

    throw v0

    :catch_0
    #v0=(Conflicted);v4=(Reference);
    move-exception v0

    #v0=(Reference);
    goto :goto_1
.end method

.method public final hw()V
    .locals 3

    iget-object v1, p0, Lcom/tencent/map/location/s;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    #v0=(Reference);
    if-eqz v0, :cond_0

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/s;->Dr:Lcom/tencent/map/a/a/b;

    iget-object v0, p0, Lcom/tencent/map/location/s;->DF:Landroid/os/Handler;

    #v0=(Reference);
    iget-object v2, p0, Lcom/tencent/map/location/s;->DG:Ljava/lang/Runnable;

    #v2=(Reference);
    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lcom/tencent/map/location/s;->CT:Landroid/content/Context;

    iget-object v2, p0, Lcom/tencent/map/location/s;->DH:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    iget-object v0, p0, Lcom/tencent/map/location/s;->Do:Lcom/tencent/map/location/o;

    invoke-virtual {v0}, Lcom/tencent/map/location/o;->hw()V

    iget-object v0, p0, Lcom/tencent/map/location/s;->Db:Lcom/tencent/map/location/j;

    invoke-virtual {v0}, Lcom/tencent/map/location/j;->hw()V

    iget-object v0, p0, Lcom/tencent/map/location/s;->Dq:Lcom/tencent/map/location/g;

    invoke-virtual {v0}, Lcom/tencent/map/location/g;->hw()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    :goto_0
    :try_start_1
    #v2=(Conflicted);
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    return-void

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    :catch_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    goto :goto_0
.end method

*/}
