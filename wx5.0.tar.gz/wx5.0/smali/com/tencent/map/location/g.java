package com.tencent.map.location; class g {/*

.class public final Lcom/tencent/map/location/g;
.super Ljava/lang/Object;


# instance fields
.field private CL:Z

.field private CT:Landroid/content/Context;

.field private CY:[B

.field private DF:Landroid/os/Handler;

.field private DG:Ljava/lang/Runnable;

.field private DI:Landroid/net/wifi/WifiManager;

.field private DJ:Lcom/tencent/map/location/g$a;

.field private DK:Lcom/tencent/map/location/aa;

.field private Dx:Lcom/tencent/map/location/z;

.field private a:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    #v2=(Null);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-object v1, p0, Lcom/tencent/map/location/g;->CT:Landroid/content/Context;

    iput-object v1, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    iput-object v1, p0, Lcom/tencent/map/location/g;->DJ:Lcom/tencent/map/location/g$a;

    iput-object v1, p0, Lcom/tencent/map/location/g;->DF:Landroid/os/Handler;

    new-instance v0, Lcom/tencent/map/location/y;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/map/location/y;-><init>(Lcom/tencent/map/location/g;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/g;->DG:Ljava/lang/Runnable;

    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/map/location/g;->a:I

    iput-object v1, p0, Lcom/tencent/map/location/g;->DK:Lcom/tencent/map/location/aa;

    iput-object v1, p0, Lcom/tencent/map/location/g;->Dx:Lcom/tencent/map/location/z;

    iput-boolean v2, p0, Lcom/tencent/map/location/g;->CL:Z

    new-array v0, v2, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/g;->CY:[B

    return-void
.end method

.method static synthetic a(Lcom/tencent/map/location/g;Lcom/tencent/map/location/z;)Lcom/tencent/map/location/z;
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/g;->Dx:Lcom/tencent/map/location/z;

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/map/location/g;)V
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/net/wifi/WifiManager;->startScan()Z

    :cond_0
    #v0=(Conflicted);
    return-void
.end method

.method static synthetic b(Lcom/tencent/map/location/g;)Lcom/tencent/map/location/aa;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/g;->DK:Lcom/tencent/map/location/aa;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/tencent/map/location/g;)Landroid/net/wifi/WifiManager;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic d(Lcom/tencent/map/location/g;)Lcom/tencent/map/location/z;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/g;->Dx:Lcom/tencent/map/location/z;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic e(Lcom/tencent/map/location/g;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/g;->a:I

    #v0=(Integer);
    return v0
.end method


# virtual methods
.method public final a(Landroid/content/Context;Lcom/tencent/map/location/aa;)Z
    .locals 5

    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v2, p0, Lcom/tencent/map/location/g;->CY:[B

    #v2=(Reference);
    monitor-enter v2

    :try_start_0
    iget-boolean v3, p0, Lcom/tencent/map/location/g;->CL:Z

    #v3=(Boolean);
    if-eqz v3, :cond_0

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    #v0=(Boolean);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    :cond_0
    #v0=(One);v1=(Null);v3=(Boolean);v4=(Uninit);
    if-eqz p1, :cond_1

    if-nez p2, :cond_2

    :cond_1
    monitor-exit v2

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_2
    :try_start_1
    #v0=(One);
    new-instance v0, Landroid/os/Handler;

    #v0=(UninitRef);
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    #v3=(Reference);
    invoke-direct {v0, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/g;->DF:Landroid/os/Handler;

    iput-object p1, p0, Lcom/tencent/map/location/g;->CT:Landroid/content/Context;

    iput-object p2, p0, Lcom/tencent/map/location/g;->DK:Lcom/tencent/map/location/aa;

    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/map/location/g;->a:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    iget-object v0, p0, Lcom/tencent/map/location/g;->CT:Landroid/content/Context;

    #v0=(Reference);
    const-string v3, "wifi"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/wifi/WifiManager;

    iput-object v0, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    new-instance v0, Landroid/content/IntentFilter;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    #v0=(Reference);
    new-instance v3, Lcom/tencent/map/location/g$a;

    #v3=(UninitRef);
    invoke-direct {v3, p0}, Lcom/tencent/map/location/g$a;-><init>(Lcom/tencent/map/location/g;)V

    #v3=(Reference);
    iput-object v3, p0, Lcom/tencent/map/location/g;->DJ:Lcom/tencent/map/location/g$a;

    iget-object v3, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    if-eqz v3, :cond_3

    iget-object v3, p0, Lcom/tencent/map/location/g;->DJ:Lcom/tencent/map/location/g$a;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    if-nez v3, :cond_4

    :cond_3
    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :cond_4
    :try_start_4
    #v0=(Reference);
    const-string v3, "android.net.wifi.WIFI_STATE_CHANGED"

    invoke-virtual {v0, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v3, "android.net.wifi.SCAN_RESULTS"

    invoke-virtual {v0, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/tencent/map/location/g;->CT:Landroid/content/Context;

    iget-object v4, p0, Lcom/tencent/map/location/g;->DJ:Lcom/tencent/map/location/g$a;

    #v4=(Reference);
    invoke-virtual {v3, v4, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    const-wide/16 v0, 0x0

    :try_start_5
    #v0=(LongLo);v1=(LongHi);
    invoke-virtual {p0, v0, v1}, Lcom/tencent/map/location/g;->f(J)V

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/map/location/g;->CL:Z

    monitor-exit v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    iget-boolean v0, p0, Lcom/tencent/map/location/g;->CL:Z

    #v0=(Boolean);
    goto :goto_0

    :catch_0
    #v0=(Conflicted);v1=(Null);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    :try_start_6
    #v0=(Reference);
    monitor-exit v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    move v0, v1

    #v0=(Null);
    goto :goto_0

    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0
.end method

.method public final f(J)V
    .locals 2

    iget-object v0, p0, Lcom/tencent/map/location/g;->DF:Landroid/os/Handler;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/tencent/map/location/g;->CL:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/g;->DF:Landroid/os/Handler;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/map/location/g;->DG:Ljava/lang/Runnable;

    #v1=(Reference);
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lcom/tencent/map/location/g;->DF:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tencent/map/location/g;->DG:Ljava/lang/Runnable;

    invoke-virtual {v0, v1, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void
.end method

.method public final hF()Z
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/g;->CT:Landroid/content/Context;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    if-nez v0, :cond_1

    :cond_0
    const/4 v0, 0x0

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_1
    #v0=(Reference);
    iget-object v0, p0, Lcom/tencent/map/location/g;->DI:Landroid/net/wifi/WifiManager;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public final hw()V
    .locals 3

    iget-object v1, p0, Lcom/tencent/map/location/g;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-boolean v0, p0, Lcom/tencent/map/location/g;->CL:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    monitor-exit v1

    :goto_0
    #v0=(Conflicted);v2=(Conflicted);
    return-void

    :cond_0
    #v0=(Boolean);v2=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/g;->CT:Landroid/content/Context;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/g;->DJ:Lcom/tencent/map/location/g$a;

    if-nez v0, :cond_2

    :cond_1
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    :cond_2
    :try_start_1
    #v2=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/g;->CT:Landroid/content/Context;

    iget-object v2, p0, Lcom/tencent/map/location/g;->DJ:Lcom/tencent/map/location/g$a;

    #v2=(Reference);
    invoke-virtual {v0, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :goto_1
    :try_start_2
    #v2=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/g;->DF:Landroid/os/Handler;

    iget-object v2, p0, Lcom/tencent/map/location/g;->DG:Ljava/lang/Runnable;

    #v2=(Reference);
    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/map/location/g;->CL:Z

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catch_0
    #v0=(Reference);v2=(Conflicted);
    move-exception v0

    goto :goto_1
.end method

.method public final hy()Z
    .locals 1

    iget-boolean v0, p0, Lcom/tencent/map/location/g;->CL:Z

    #v0=(Boolean);
    return v0
.end method

*/}
