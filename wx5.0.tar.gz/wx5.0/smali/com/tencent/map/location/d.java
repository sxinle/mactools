package com.tencent.map.location; class d {/*

.class public interface abstract Lcom/tencent/map/location/d;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(DD)V
.end method

*/}
