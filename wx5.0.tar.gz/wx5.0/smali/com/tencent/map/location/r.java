package com.tencent.map.location; class r {/*

.class public interface abstract Lcom/tencent/map/location/r;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/tencent/map/location/q;)V
.end method

.method public abstract aj(I)V
.end method

*/}
