package com.tencent.map.location; class z {/*

.class public final Lcom/tencent/map/location/z;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field private CP:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    if-eqz p1, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    #v1=(Reference);v2=(Conflicted);
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/net/wifi/ScanResult;

    iget-object v2, p0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return-void
.end method


# virtual methods
.method public final clone()Ljava/lang/Object;
    .locals 3

    const/4 v1, 0x0

    :try_start_0
    #v1=(Null);
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/map/location/z;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iget-object v1, p0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    #v1=(Reference);
    if-eqz v1, :cond_0

    new-instance v1, Ljava/util/ArrayList;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    iget-object v1, v0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    iget-object v2, p0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v1, v2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_0
    #v2=(Conflicted);
    return-object v0

    :catch_0
    #v0=(Conflicted);v1=(Null);v2=(Uninit);
    move-exception v0

    #v0=(Reference);
    move-object v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public final hx()Ljava/util/List;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/z;->CP:Ljava/util/List;

    #v0=(Reference);
    return-object v0
.end method

*/}
