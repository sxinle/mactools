package com.tencent.map.location; class ad {/*

.class public final Lcom/tencent/map/location/ad;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    :try_start_0
    const-string v0, "MD5"

    #v0=(Reference);
    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->update([B)V

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v1

    const-string v2, ""

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    #v3=(Reference);
    array-length v4, v1

    #v4=(Integer);
    const/4 v0, 0x0

    :goto_0
    #v0=(Integer);v5=(Conflicted);
    if-ge v0, v4, :cond_0

    aget-byte v5, v1, v0

    #v5=(Byte);
    and-int/lit16 v5, v5, 0xff

    #v5=(Integer);
    invoke-static {v5}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v5

    #v5=(Reference);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    #v5=(Conflicted);
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object p0

    :goto_1
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-object p0

    :catch_0
    move-exception v0

    #v0=(Reference);
    goto :goto_1
.end method

.method public static d([B)[B
    .locals 5

    const/4 v0, 0x0

    #v0=(Null);
    if-nez p0, :cond_0

    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-object v0

    :cond_0
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    #v1=(Reference);
    new-instance v2, Ljava/util/zip/DeflaterOutputStream;

    #v2=(UninitRef);
    invoke-direct {v2, v1}, Ljava/util/zip/DeflaterOutputStream;-><init>(Ljava/io/OutputStream;)V

    #v2=(Reference);
    const/4 v3, 0x0

    :try_start_0
    #v3=(Null);
    array-length v4, p0

    #v4=(Integer);
    invoke-virtual {v2, p0, v3, v4}, Ljava/util/zip/DeflaterOutputStream;->write([BII)V

    invoke-virtual {v2}, Ljava/util/zip/DeflaterOutputStream;->finish()V

    invoke-virtual {v2}, Ljava/util/zip/DeflaterOutputStream;->flush()V

    invoke-virtual {v2}, Ljava/util/zip/DeflaterOutputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    #v0=(Reference);
    goto :goto_0

    :catch_0
    #v0=(Null);v4=(Conflicted);
    move-exception v1

    goto :goto_0
.end method

.method public static e([B)[B
    .locals 11

    const/4 v3, 0x0

    #v3=(Null);
    const/4 v0, 0x0

    #v0=(Null);
    if-nez p0, :cond_0

    move-object v1, v3

    :goto_0
    #v0=(Conflicted);v1=(Reference);v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);
    return-object v1

    :cond_0
    #v0=(Null);v1=(Uninit);v2=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);v10=(Uninit);
    new-instance v4, Ljava/io/ByteArrayInputStream;

    #v4=(UninitRef);
    invoke-direct {v4, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    #v4=(Reference);
    new-instance v5, Ljava/util/zip/InflaterInputStream;

    #v5=(UninitRef);
    invoke-direct {v5, v4}, Ljava/util/zip/InflaterInputStream;-><init>(Ljava/io/InputStream;)V

    #v5=(Reference);
    new-array v2, v0, [B

    #v2=(Reference);
    const/16 v1, 0x400

    #v1=(PosShort);
    new-array v6, v1, [B

    :goto_1
    :try_start_0
    #v0=(Integer);v1=(Conflicted);v6=(Reference);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);
    invoke-virtual {v5, v6}, Ljava/util/zip/InflaterInputStream;->read([B)I

    move-result v7

    #v7=(Integer);
    if-lez v7, :cond_2

    add-int/2addr v0, v7

    new-array v1, v0, [B

    #v1=(Reference);
    const/4 v8, 0x0

    #v8=(Null);
    const/4 v9, 0x0

    #v9=(Null);
    array-length v10, v2

    #v10=(Integer);
    invoke-static {v2, v8, v1, v9, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v8, 0x0

    array-length v2, v2

    #v2=(Integer);
    invoke-static {v6, v8, v1, v2, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :goto_2
    #v2=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);
    if-gtz v7, :cond_1

    :try_start_1
    invoke-virtual {v4}, Ljava/io/ByteArrayInputStream;->close()V

    invoke-virtual {v5}, Ljava/util/zip/InflaterInputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    #v0=(Reference);
    move-object v1, v3

    #v1=(Null);
    goto :goto_0

    :catch_1
    #v0=(Integer);v1=(Conflicted);v7=(Conflicted);
    move-exception v0

    #v0=(Reference);
    move-object v1, v3

    #v1=(Null);
    goto :goto_0

    :cond_1
    #v0=(Integer);v1=(Reference);v7=(Integer);
    move-object v2, v1

    #v2=(Reference);
    goto :goto_1

    :cond_2
    #v1=(Conflicted);
    move-object v1, v2

    #v1=(Reference);
    goto :goto_2
.end method

*/}
