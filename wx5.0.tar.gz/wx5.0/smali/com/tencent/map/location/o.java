package com.tencent.map.location; class o {/*

.class public final Lcom/tencent/map/location/o;
.super Ljava/lang/Object;


# static fields
.field private static Dk:Landroid/location/LocationManager;

.field private static er:F


# instance fields
.field private CL:Z

.field private CO:J

.field private CR:I

.field private CT:Landroid/content/Context;

.field private CY:[B

.field private Da:Z

.field private Dl:Lcom/tencent/map/location/p;

.field private Dm:Lcom/tencent/map/location/r;

.field private Dn:Lcom/tencent/map/location/q;

.field private a:I

.field private b:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    sput-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    const/4 v0, 0x0

    sput v0, Lcom/tencent/map/location/o;->er:F

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/o;->CT:Landroid/content/Context;

    iput-object v0, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;

    iput-object v0, p0, Lcom/tencent/map/location/o;->Dm:Lcom/tencent/map/location/r;

    iput-object v0, p0, Lcom/tencent/map/location/o;->Dn:Lcom/tencent/map/location/q;

    iput-boolean v2, p0, Lcom/tencent/map/location/o;->CL:Z

    new-array v0, v2, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/o;->CY:[B

    const/16 v0, 0x400

    #v0=(PosShort);
    iput v0, p0, Lcom/tencent/map/location/o;->a:I

    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/o;->CO:J

    iput-boolean v2, p0, Lcom/tencent/map/location/o;->Da:Z

    iput v2, p0, Lcom/tencent/map/location/o;->b:I

    iput v2, p0, Lcom/tencent/map/location/o;->CR:I

    return-void
.end method

.method static synthetic a(Lcom/tencent/map/location/o;I)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/o;->a:I

    #v0=(Integer);
    or-int/2addr v0, p1

    iput v0, p0, Lcom/tencent/map/location/o;->a:I

    return v0
.end method

.method static synthetic a(Lcom/tencent/map/location/o;J)J
    .locals 0

    iput-wide p1, p0, Lcom/tencent/map/location/o;->CO:J

    return-wide p1
.end method

.method static synthetic a(Lcom/tencent/map/location/o;Lcom/tencent/map/location/q;)Lcom/tencent/map/location/q;
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/o;->Dn:Lcom/tencent/map/location/q;

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/map/location/o;)V
    .locals 3

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/tencent/map/location/o;->CR:I

    iput v0, p0, Lcom/tencent/map/location/o;->b:I

    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v1}, Landroid/location/LocationManager;->getGpsStatus(Landroid/location/GpsStatus;)Landroid/location/GpsStatus;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/location/GpsStatus;->getMaxSatellites()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v0}, Landroid/location/GpsStatus;->getSatellites()Ljava/lang/Iterable;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    #v2=(Reference);
    if-eqz v2, :cond_1

    :cond_0
    :goto_0
    #v0=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    iget v0, p0, Lcom/tencent/map/location/o;->b:I

    #v0=(Integer);
    if-gt v0, v1, :cond_1

    iget v0, p0, Lcom/tencent/map/location/o;->b:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/tencent/map/location/o;->b:I

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/location/GpsSatellite;

    invoke-virtual {v0}, Landroid/location/GpsSatellite;->usedInFix()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget v0, p0, Lcom/tencent/map/location/o;->CR:I

    #v0=(Integer);
    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/tencent/map/location/o;->CR:I

    goto :goto_0

    :cond_1
    #v0=(Conflicted);v2=(Conflicted);
    return-void
.end method

.method static synthetic b(Lcom/tencent/map/location/o;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/o;->b:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic b(Lcom/tencent/map/location/o;I)I
    .locals 0

    iput p1, p0, Lcom/tencent/map/location/o;->b:I

    return p1
.end method

.method static synthetic c(Lcom/tencent/map/location/o;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/o;->CR:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic c(Lcom/tencent/map/location/o;I)I
    .locals 0

    iput p1, p0, Lcom/tencent/map/location/o;->a:I

    return p1
.end method

.method static synthetic d(Lcom/tencent/map/location/o;)I
    .locals 1

    iget v0, p0, Lcom/tencent/map/location/o;->a:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic e(Lcom/tencent/map/location/o;)J
    .locals 2

    iget-wide v0, p0, Lcom/tencent/map/location/o;->CO:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic f(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/r;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/o;->Dm:Lcom/tencent/map/location/r;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic g(Lcom/tencent/map/location/o;)Lcom/tencent/map/location/q;
    .locals 1

    iget-object v0, p0, Lcom/tencent/map/location/o;->Dn:Lcom/tencent/map/location/q;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic h(Lcom/tencent/map/location/o;)I
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/tencent/map/location/o;->CR:I

    return v0
.end method


# virtual methods
.method public final a(Lcom/tencent/map/location/r;Landroid/content/Context;)Z
    .locals 8

    const/4 v0, 0x1

    #v0=(One);
    const/4 v6, 0x0

    #v6=(Null);
    iget-object v7, p0, Lcom/tencent/map/location/o;->CY:[B

    #v7=(Reference);
    monitor-enter v7

    :try_start_0
    iget-boolean v1, p0, Lcom/tencent/map/location/o;->CL:Z

    #v1=(Boolean);
    if-eqz v1, :cond_0

    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    :cond_0
    #v0=(One);v1=(Boolean);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    if-eqz p2, :cond_1

    if-nez p1, :cond_2

    :cond_1
    monitor-exit v7

    move v0, v6

    #v0=(Null);
    goto :goto_0

    :cond_2
    :try_start_1
    #v0=(One);
    iput-object p2, p0, Lcom/tencent/map/location/o;->CT:Landroid/content/Context;

    iput-object p1, p0, Lcom/tencent/map/location/o;->Dm:Lcom/tencent/map/location/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    iget-object v0, p0, Lcom/tencent/map/location/o;->CT:Landroid/content/Context;

    #v0=(Reference);
    const-string v1, "location"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/location/LocationManager;

    sput-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    new-instance v0, Lcom/tencent/map/location/p;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {v0, p0, v1}, Lcom/tencent/map/location/p;-><init>(Lcom/tencent/map/location/o;B)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;

    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    if-nez v0, :cond_4

    :cond_3
    :try_start_3
    monitor-exit v7
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move v0, v6

    #v0=(Null);
    goto :goto_0

    :catch_0
    #v0=(Conflicted);v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v7

    move v0, v6

    #v0=(Null);
    goto :goto_0

    :cond_4
    :try_start_4
    #v0=(Reference);v1=(Null);
    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    const-string v1, "gps"

    #v1=(Reference);
    const-wide/16 v2, 0x3e8

    #v2=(LongLo);v3=(LongHi);
    const/4 v4, 0x0

    #v4=(Null);
    iget-object v5, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;

    #v5=(Reference);
    invoke-virtual/range {v0 .. v5}, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String;JFLandroid/location/LocationListener;)V

    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    iget-object v1, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;

    invoke-virtual {v0, v1}, Landroid/location/LocationManager;->addGpsStatusListener(Landroid/location/GpsStatus$Listener;)Z

    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    const-string v1, "gps"

    invoke-virtual {v0, v1}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_5

    const/4 v0, 0x4

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/map/location/o;->a:I
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    :goto_1
    const/4 v0, 0x1

    :try_start_5
    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/map/location/o;->CL:Z

    monitor-exit v7
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    iget-boolean v0, p0, Lcom/tencent/map/location/o;->CL:Z

    #v0=(Boolean);
    goto :goto_0

    :cond_5
    const/4 v0, 0x0

    :try_start_6
    #v0=(Null);
    iput v0, p0, Lcom/tencent/map/location/o;->a:I
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    goto :goto_1

    :catch_1
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-exception v0

    :try_start_7
    #v0=(Reference);
    monitor-exit v7
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    move v0, v6

    #v0=(Null);
    goto :goto_0

    :catchall_0
    #v0=(Conflicted);v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v7

    throw v0
.end method

.method public final hw()V
    .locals 3

    iget-object v1, p0, Lcom/tencent/map/location/o;->CY:[B

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    iget-boolean v0, p0, Lcom/tencent/map/location/o;->CL:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    monitor-exit v1

    :goto_0
    #v2=(Conflicted);
    return-void

    :cond_0
    #v2=(Uninit);
    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;

    if-eqz v0, :cond_1

    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    iget-object v2, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;

    #v2=(Reference);
    invoke-virtual {v0, v2}, Landroid/location/LocationManager;->removeGpsStatusListener(Landroid/location/GpsStatus$Listener;)V

    sget-object v0, Lcom/tencent/map/location/o;->Dk:Landroid/location/LocationManager;

    iget-object v2, p0, Lcom/tencent/map/location/o;->Dl:Lcom/tencent/map/location/p;

    invoke-virtual {v0, v2}, Landroid/location/LocationManager;->removeUpdates(Landroid/location/LocationListener;)V

    :cond_1
    #v2=(Conflicted);
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/map/location/o;->CL:Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

*/}
