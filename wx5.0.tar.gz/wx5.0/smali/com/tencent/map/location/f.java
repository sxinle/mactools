package com.tencent.map.location; class f {/*

.class public final Lcom/tencent/map/location/f;
.super Ljava/lang/Object;


# static fields
.field private static CN:Lcom/tencent/map/location/f;


# instance fields
.field private CM:Ljava/lang/String;

.field private CO:J

.field private CP:Ljava/util/List;

.field private CQ:Ljava/util/List;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/f;->CO:J

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/f;->CP:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    return-void
.end method

.method private static a(Ljava/lang/StringBuffer;)Z
    .locals 5

    const/4 v0, 0x0

    :try_start_0
    #v0=(Null);
    new-instance v1, Lorg/json/JSONObject;

    #v1=(UninitRef);
    invoke-virtual {p0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    const-string v2, "location"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "accuracy"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-wide v1

    #v1=(DoubleLo);v2=(DoubleHi);
    const-wide v3, 0x40b3880000000000L

    #v3=(LongLo);v4=(LongHi);
    cmpg-double v1, v1, v3

    #v1=(Byte);
    if-gez v1, :cond_0

    const/4 v0, 0x1

    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    :catch_0
    #v0=(Null);v3=(Uninit);v4=(Uninit);
    move-exception v1

    #v1=(Reference);
    goto :goto_0
.end method

.method private a(Ljava/util/List;)Z
    .locals 9

    const/4 v8, 0x6

    #v8=(PosByte);
    const/4 v7, 0x2

    #v7=(PosByte);
    const/4 v4, 0x1

    #v4=(One);
    const/4 v2, 0x0

    #v2=(Null);
    if-nez p1, :cond_1

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Boolean);v3=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return v2

    :cond_1
    #v0=(Uninit);v1=(Uninit);v2=(Null);v3=(Uninit);v5=(Uninit);v6=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_4

    move v1, v2

    #v1=(Null);
    move v3, v2

    :goto_1
    #v0=(Conflicted);v1=(Integer);v3=(Integer);v5=(Conflicted);v6=(Conflicted);
    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-ge v1, v0, :cond_5

    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/map/location/i;

    iget-object v6, v0, Lcom/tencent/map/location/i;->CM:Ljava/lang/String;

    #v6=(Reference);
    move v5, v2

    :goto_2
    #v0=(Conflicted);v5=(Integer);
    if-eqz v6, :cond_2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-ge v5, v0, :cond_2

    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/net/wifi/ScanResult;

    iget-object v0, v0, Landroid/net/wifi/ScanResult;->BSSID:Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    add-int/lit8 v3, v3, 0x1

    :cond_2
    #v0=(Conflicted);
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_1

    :cond_3
    #v0=(Boolean);
    add-int/lit8 v0, v5, 0x1

    #v0=(Integer);
    move v5, v0

    goto :goto_2

    :cond_4
    #v0=(Reference);v1=(Uninit);v3=(Uninit);v5=(Uninit);v6=(Uninit);
    move v3, v2

    :cond_5
    #v0=(Conflicted);v1=(Conflicted);v3=(Integer);v5=(Conflicted);v6=(Conflicted);
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-lt v0, v8, :cond_6

    div-int/lit8 v1, v0, 0x2

    #v1=(Integer);
    add-int/lit8 v1, v1, 0x1

    if-lt v3, v1, :cond_6

    move v2, v4

    #v2=(One);
    goto :goto_0

    :cond_6
    #v1=(Conflicted);v2=(Null);
    if-ge v0, v8, :cond_7

    if-lt v3, v7, :cond_7

    move v2, v4

    #v2=(One);
    goto :goto_0

    :cond_7
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-gt v0, v7, :cond_0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-gt v0, v7, :cond_0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iget-wide v5, p0, Lcom/tencent/map/location/f;->CO:J

    #v5=(LongLo);v6=(LongHi);
    sub-long/2addr v0, v5

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    const-wide/16 v5, 0x7530

    cmp-long v0, v0, v5

    #v0=(Byte);
    if-gtz v0, :cond_0

    move v2, v4

    #v2=(One);
    goto :goto_0
.end method

.method public static hv()Lcom/tencent/map/location/f;
    .locals 1

    sget-object v0, Lcom/tencent/map/location/f;->CN:Lcom/tencent/map/location/f;

    #v0=(Reference);
    if-nez v0, :cond_0

    new-instance v0, Lcom/tencent/map/location/f;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/location/f;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/map/location/f;->CN:Lcom/tencent/map/location/f;

    :cond_0
    sget-object v0, Lcom/tencent/map/location/f;->CN:Lcom/tencent/map/location/f;

    return-object v0
.end method


# virtual methods
.method public final a(IIIILjava/util/List;)V
    .locals 4

    const/4 v2, 0x0

    #v2=(Null);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/location/f;->CO:J

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/f;->CP:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/List;->clear()V

    new-instance v0, Lcom/tencent/map/location/h;

    #v0=(UninitRef);
    invoke-direct {v0, v2}, Lcom/tencent/map/location/h;-><init>(B)V

    #v0=(Reference);
    iput p1, v0, Lcom/tencent/map/location/h;->a:I

    iput p2, v0, Lcom/tencent/map/location/h;->b:I

    iput p3, v0, Lcom/tencent/map/location/h;->CR:I

    iput p4, v0, Lcom/tencent/map/location/h;->CS:I

    iget-object v1, p0, Lcom/tencent/map/location/f;->CP:Ljava/util/List;

    #v1=(Reference);
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    if-eqz p5, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    move v1, v2

    :goto_0
    #v0=(Conflicted);v1=(Integer);v3=(Conflicted);
    invoke-interface {p5}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-ge v1, v0, :cond_0

    new-instance v3, Lcom/tencent/map/location/i;

    #v3=(UninitRef);
    invoke-direct {v3, v2}, Lcom/tencent/map/location/i;-><init>(B)V

    #v3=(Reference);
    invoke-interface {p5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/net/wifi/ScanResult;

    iget-object v0, v0, Landroid/net/wifi/ScanResult;->BSSID:Ljava/lang/String;

    iput-object v0, v3, Lcom/tencent/map/location/i;->CM:Ljava/lang/String;

    invoke-interface {p5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/wifi/ScanResult;

    iget v0, v0, Landroid/net/wifi/ScanResult;->level:I

    #v0=(Integer);
    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);
    return-void
.end method

.method public final aa(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    return-void
.end method

.method public final b(IIIILjava/util/List;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x2

    #v6=(PosByte);
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    const/16 v2, 0xa

    #v2=(PosByte);
    if-ge v0, v2, :cond_1

    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Reference);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v1

    :cond_1
    #v0=(Integer);v1=(Null);v2=(PosByte);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    #v0=(Reference);
    if-eqz v0, :cond_2

    if-nez p5, :cond_6

    :cond_2
    move-object v0, v1

    :cond_3
    :goto_1
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    iput-object v0, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    iget-object v0, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/f;->CP:Ljava/util/List;

    if-eqz v0, :cond_b

    iget-object v0, p0, Lcom/tencent/map/location/f;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_b

    iget-object v0, p0, Lcom/tencent/map/location/f;->CP:Ljava/util/List;

    #v0=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/map/location/h;

    iget v2, v0, Lcom/tencent/map/location/h;->a:I

    #v2=(Integer);
    if-ne v2, p1, :cond_0

    iget v2, v0, Lcom/tencent/map/location/h;->b:I

    if-ne v2, p2, :cond_0

    iget v2, v0, Lcom/tencent/map/location/h;->CR:I

    if-ne v2, p3, :cond_0

    iget v0, v0, Lcom/tencent/map/location/h;->CS:I

    #v0=(Integer);
    if-ne v0, p4, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    #v0=(Reference);
    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/tencent/map/location/f;->CQ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_a

    :cond_4
    #v0=(Conflicted);
    if-eqz p5, :cond_5

    invoke-interface {p5}, Ljava/util/List;->size()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_a

    :cond_5
    #v0=(Conflicted);
    iget-object v1, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    #v1=(Reference);
    goto :goto_0

    :cond_6
    #v0=(Reference);v1=(Null);v2=(PosByte);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    iget-wide v4, p0, Lcom/tencent/map/location/f;->CO:J

    #v4=(LongLo);v5=(LongHi);
    sub-long/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(J)J

    move-result-wide v2

    const-wide/16 v4, 0x7530

    cmp-long v4, v2, v4

    #v4=(Byte);
    if-lez v4, :cond_7

    invoke-interface {p5}, Ljava/util/List;->size()I

    move-result v4

    #v4=(Integer);
    if-gt v4, v6, :cond_9

    :cond_7
    const-wide/32 v4, 0xafc8

    #v4=(LongLo);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-lez v2, :cond_8

    invoke-interface {p5}, Ljava/util/List;->size()I

    move-result v2

    #v2=(Integer);
    if-le v2, v6, :cond_9

    :cond_8
    new-instance v2, Ljava/lang/StringBuffer;

    #v2=(UninitRef);
    invoke-direct {v2, v0}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/map/location/f;->a(Ljava/lang/StringBuffer;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_3

    :cond_9
    #v2=(Conflicted);v4=(Conflicted);
    move-object v0, v1

    #v0=(Null);
    goto :goto_1

    :cond_a
    #v0=(Integer);v2=(Integer);v3=(Conflicted);v5=(Conflicted);
    invoke-direct {p0, p5}, Lcom/tencent/map/location/f;->a(Ljava/util/List;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_b

    iget-object v1, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    #v1=(Reference);
    goto/16 :goto_0

    :cond_b
    #v0=(Conflicted);v1=(Null);v2=(Conflicted);
    invoke-direct {p0, p5}, Lcom/tencent/map/location/f;->a(Ljava/util/List;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    iget-object v1, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    #v1=(Reference);
    goto/16 :goto_0
.end method

.method public final hw()V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/f;->CM:Ljava/lang/String;

    return-void
.end method

*/}
