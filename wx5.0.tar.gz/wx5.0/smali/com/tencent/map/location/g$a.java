package com.tencent.map.location; class g$a {/*

.class public final Lcom/tencent/map/location/g$a;
.super Landroid/content/BroadcastReceiver;


# instance fields
.field private CL:Z

.field private CP:Ljava/util/List;

.field private synthetic Dq:Lcom/tencent/map/location/g;

.field private a:I


# direct methods
.method public constructor <init>(Lcom/tencent/map/location/g;)V
    .locals 1

    iput-object p1, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x4

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/map/location/g$a;->a:I

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tencent/map/location/g$a;->CL:Z

    return-void
.end method

.method private b(Ljava/util/List;)V
    .locals 6

    if-nez p1, :cond_1

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-void

    :cond_1
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget-boolean v0, p0, Lcom/tencent/map/location/g$a;->CL:Z

    #v0=(Boolean);
    if-eqz v0, :cond_5

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_2

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    :cond_2
    iget-object v0, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    #v3=(Integer);
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v4=(Reference);v5=(Conflicted);
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/net/wifi/ScanResult;

    const/4 v1, 0x0

    #v1=(Null);
    move v2, v1

    :goto_1
    #v1=(Integer);v2=(Integer);
    if-ge v2, v3, :cond_3

    iget-object v1, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    #v1=(Reference);
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/wifi/ScanResult;

    iget-object v1, v1, Landroid/net/wifi/ScanResult;->BSSID:Ljava/lang/String;

    iget-object v5, v0, Landroid/net/wifi/ScanResult;->BSSID:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_4

    iget-object v1, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    #v1=(Reference);
    invoke-interface {v1, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_3
    #v1=(Conflicted);v5=(Conflicted);
    iget-object v1, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    #v1=(Reference);
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_4
    #v1=(Boolean);v5=(Reference);
    add-int/lit8 v1, v2, 0x1

    #v1=(Integer);
    move v2, v1

    goto :goto_1

    :cond_5
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    #v0=(Reference);
    if-nez v0, :cond_6

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    :goto_2
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_3
    #v1=(Reference);v2=(Conflicted);
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Landroid/net/wifi/ScanResult;

    iget-object v2, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    #v2=(Reference);
    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_6
    #v1=(Uninit);v2=(Uninit);
    iget-object v0, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    goto :goto_2
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const/4 v3, 0x4

    #v3=(PosByte);
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "android.net.wifi.WIFI_STATE_CHANGED"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const-string v0, "wifi_state"

    #v0=(Reference);
    invoke-virtual {p2, v0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/location/g$a;->a:I

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/g;->b(Lcom/tencent/map/location/g;)Lcom/tencent/map/location/aa;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    invoke-static {v0}, Lcom/tencent/map/location/g;->b(Lcom/tencent/map/location/g;)Lcom/tencent/map/location/aa;

    move-result-object v0

    iget v1, p0, Lcom/tencent/map/location/g$a;->a:I

    #v1=(Integer);
    invoke-interface {v0, v1}, Lcom/tencent/map/location/aa;->ak(I)V

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "android.net.wifi.SCAN_RESULTS"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    const-string v1, "android.net.wifi.WIFI_STATE_CHANGED"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    :cond_1
    const/4 v0, 0x0

    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    invoke-static {v1}, Lcom/tencent/map/location/g;->c(Lcom/tencent/map/location/g;)Landroid/net/wifi/WifiManager;

    move-result-object v1

    if-eqz v1, :cond_2

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/map/location/g;->c(Lcom/tencent/map/location/g;)Landroid/net/wifi/WifiManager;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager;->getScanResults()Ljava/util/List;

    move-result-object v0

    :cond_2
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.net.wifi.WIFI_STATE_CHANGED"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_4

    if-eqz v0, :cond_3

    if-eqz v0, :cond_4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_4

    :cond_3
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    :cond_4
    #v0=(Reference);v1=(Integer);v2=(Reference);v3=(PosByte);v4=(Uninit);
    iget-boolean v1, p0, Lcom/tencent/map/location/g$a;->CL:Z

    #v1=(Boolean);
    if-nez v1, :cond_5

    iget-object v1, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    #v1=(Reference);
    if-eqz v1, :cond_5

    iget-object v1, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    #v1=(Integer);
    if-lt v1, v3, :cond_5

    if-eqz v0, :cond_5

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x2

    #v2=(PosByte);
    if-gt v1, v2, :cond_5

    invoke-direct {p0, v0}, Lcom/tencent/map/location/g$a;->b(Ljava/util/List;)V

    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/map/location/g$a;->CL:Z

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    const-wide/16 v1, 0x0

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/map/location/g;->f(J)V

    goto :goto_0

    :cond_5
    #v1=(Conflicted);v2=(Conflicted);
    invoke-direct {p0, v0}, Lcom/tencent/map/location/g$a;->b(Ljava/util/List;)V

    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/map/location/g$a;->CL:Z

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    #v0=(Reference);
    new-instance v1, Lcom/tencent/map/location/z;

    #v1=(UninitRef);
    iget-object v2, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    #v2=(Reference);
    iget-object v2, p0, Lcom/tencent/map/location/g$a;->CP:Ljava/util/List;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    iget v3, p0, Lcom/tencent/map/location/g$a;->a:I

    #v3=(Integer);
    invoke-direct {v1, v2}, Lcom/tencent/map/location/z;-><init>(Ljava/util/List;)V

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/map/location/g;->a(Lcom/tencent/map/location/g;Lcom/tencent/map/location/z;)Lcom/tencent/map/location/z;

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    invoke-static {v0}, Lcom/tencent/map/location/g;->b(Lcom/tencent/map/location/g;)Lcom/tencent/map/location/aa;

    move-result-object v0

    if-eqz v0, :cond_6

    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    invoke-static {v0}, Lcom/tencent/map/location/g;->b(Lcom/tencent/map/location/g;)Lcom/tencent/map/location/aa;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    invoke-static {v1}, Lcom/tencent/map/location/g;->d(Lcom/tencent/map/location/g;)Lcom/tencent/map/location/z;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/tencent/map/location/aa;->a(Lcom/tencent/map/location/z;)V

    :cond_6
    iget-object v0, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    iget-object v1, p0, Lcom/tencent/map/location/g$a;->Dq:Lcom/tencent/map/location/g;

    invoke-static {v1}, Lcom/tencent/map/location/g;->e(Lcom/tencent/map/location/g;)I

    move-result v1

    #v1=(Integer);
    int-to-long v1, v1

    #v1=(LongLo);v2=(LongHi);
    const-wide/16 v3, 0x4e20

    #v3=(LongLo);v4=(LongHi);
    mul-long/2addr v1, v3

    invoke-virtual {v0, v1, v2}, Lcom/tencent/map/location/g;->f(J)V

    goto :goto_0
.end method

*/}
