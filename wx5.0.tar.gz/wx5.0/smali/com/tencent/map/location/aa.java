package com.tencent.map.location; class aa {/*

.class public interface abstract Lcom/tencent/map/location/aa;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/tencent/map/location/z;)V
.end method

.method public abstract ak(I)V
.end method

*/}
