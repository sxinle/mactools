package com.tencent.map.location; class a {/*

.class public final Lcom/tencent/map/location/a;
.super Ljava/lang/Object;


# static fields
.field private static CB:Lcom/tencent/map/location/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    #v0=(Null);
    sput-object v0, Lcom/tencent/map/location/a;->CB:Lcom/tencent/map/location/a;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method public static declared-synchronized ht()Lcom/tencent/map/location/a;
    .locals 2

    const-class v1, Lcom/tencent/map/location/a;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    sget-object v0, Lcom/tencent/map/location/a;->CB:Lcom/tencent/map/location/a;

    #v0=(Reference);
    if-nez v0, :cond_0

    new-instance v0, Lcom/tencent/map/location/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/location/a;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/map/location/a;->CB:Lcom/tencent/map/location/a;

    :cond_0
    sget-object v0, Lcom/tencent/map/location/a;->CB:Lcom/tencent/map/location/a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 8

    const/16 v7, 0x1b

    #v7=(PosByte);
    const/4 v3, 0x1

    #v3=(One);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {p1}, Lcom/tencent/map/location/ac;->ac(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    :cond_0
    :goto_0
    #v1=(Boolean);v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return v1

    :cond_1
    #v1=(Null);v2=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    invoke-static {p2}, Lcom/tencent/map/location/ac;->ad(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Lcom/tencent/map/location/b;

    #v0=(UninitRef);
    invoke-direct {v0, p0, v1}, Lcom/tencent/map/location/b;-><init>(Lcom/tencent/map/location/a;B)V

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/map/location/b;->CB:Lcom/tencent/map/location/a;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    #v4=(Integer);
    move v0, v1

    #v0=(Null);
    move v2, v1

    :goto_1
    #v0=(Integer);v2=(Integer);v5=(Conflicted);
    if-ge v0, v4, :cond_2

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v5

    #v5=(Char);
    invoke-static {v5}, Lcom/tencent/map/location/ac;->g(C)I

    move-result v5

    #v5=(Integer);
    add-int/2addr v2, v5

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    #v5=(Conflicted);
    shl-int/lit8 v0, v4, 0x7

    add-int/2addr v0, v4

    xor-int/2addr v0, v2

    mul-int/lit8 v2, v0, 0x9

    add-int/lit8 v2, v2, 0xa

    div-int/lit8 v2, v2, 0x3

    add-int/lit8 v2, v2, 0x24

    and-int/lit8 v2, v2, 0x1f

    const/4 v4, 0x4

    #v4=(PosByte);
    invoke-virtual {p2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    if-eq v4, v2, :cond_3

    move v0, v1

    :goto_2
    #v0=(Boolean);v2=(Integer);v4=(Conflicted);v6=(Conflicted);
    if-eqz v0, :cond_0

    move v0, v1

    #v0=(Null);
    move v2, v1

    :goto_3
    #v0=(Integer);
    if-ge v0, v7, :cond_d

    shr-int/lit8 v4, v2, 0x8

    #v4=(Integer);
    and-int/lit16 v4, v4, 0xff

    sget-object v5, Lcom/tencent/map/location/ac;->DL:[I

    invoke-virtual {p2, v0}, Ljava/lang/String;->charAt(I)C

    move-result v6

    #v6=(Char);
    invoke-static {v6}, Lcom/tencent/map/location/ac;->g(C)I

    move-result v6

    #v6=(Integer);
    xor-int/2addr v2, v6

    and-int/lit16 v2, v2, 0xff

    aget v2, v5, v2

    xor-int/2addr v2, v4

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_3
    #v2=(Char);v4=(Char);v6=(Uninit);
    mul-int/lit8 v2, v0, 0x5

    #v2=(Integer);
    add-int/lit8 v2, v2, 0xb

    div-int/lit8 v2, v2, 0x5

    and-int/lit8 v2, v2, 0x1f

    const/4 v4, 0x7

    #v4=(PosByte);
    invoke-virtual {p2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    if-eq v4, v2, :cond_4

    move v0, v1

    #v0=(Null);
    goto :goto_2

    :cond_4
    #v0=(Integer);
    add-int/lit8 v2, v0, 0xa

    #v2=(Integer);
    div-int/lit8 v2, v2, 0x3

    shl-int/lit8 v2, v2, 0x3

    and-int/lit8 v2, v2, 0x1f

    const/16 v4, 0xc

    #v4=(PosByte);
    invoke-virtual {p2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    if-eq v4, v2, :cond_5

    move v0, v1

    #v0=(Null);
    goto :goto_2

    :cond_5
    #v0=(Integer);
    mul-int/lit8 v2, v0, 0x3

    #v2=(Integer);
    add-int/lit8 v2, v2, 0x13

    div-int/lit8 v2, v2, 0x9

    and-int/lit8 v2, v2, 0x1f

    const/16 v4, 0xe

    #v4=(PosByte);
    invoke-virtual {p2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    if-eq v4, v2, :cond_6

    move v0, v1

    #v0=(Null);
    goto :goto_2

    :cond_6
    #v0=(Integer);
    mul-int/lit8 v2, v0, 0x3

    #v2=(Integer);
    add-int/lit8 v2, v2, 0x27

    div-int/lit8 v2, v2, 0x8

    and-int/lit8 v2, v2, 0x1f

    const/16 v4, 0x13

    #v4=(PosByte);
    invoke-virtual {p2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    if-eq v4, v2, :cond_7

    move v0, v1

    #v0=(Null);
    goto :goto_2

    :cond_7
    #v0=(Integer);
    div-int/lit8 v2, v0, 0x17

    #v2=(Integer);
    add-int/lit8 v2, v2, 0x43

    div-int/lit8 v2, v2, 0x7

    and-int/lit8 v2, v2, 0x1f

    const/16 v4, 0x15

    #v4=(PosByte);
    invoke-virtual {p2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    if-eq v4, v2, :cond_8

    move v0, v1

    #v0=(Null);
    goto/16 :goto_2

    :cond_8
    #v0=(Integer);
    add-int/lit8 v0, v0, 0x17

    div-int/lit8 v0, v0, 0x6

    add-int/lit8 v0, v0, 0x3

    mul-int/lit8 v0, v0, 0x7

    and-int/lit8 v0, v0, 0x1f

    const/16 v2, 0x1a

    #v2=(PosByte);
    invoke-virtual {p2, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    sget-object v4, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    #v0=(Char);
    if-eq v2, v0, :cond_9

    move v0, v1

    #v0=(Null);
    goto/16 :goto_2

    :cond_9
    #v0=(Char);
    move v0, v1

    #v0=(Null);
    move v2, v1

    :goto_4
    #v0=(Integer);v2=(Integer);v4=(Conflicted);v6=(Conflicted);
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    #v4=(Integer);
    if-ge v0, v4, :cond_a

    shr-int/lit8 v4, v2, 0x8

    and-int/lit16 v4, v4, 0xff

    sget-object v5, Lcom/tencent/map/location/ac;->DL:[I

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v6

    #v6=(Char);
    invoke-static {v6}, Lcom/tencent/map/location/ac;->g(C)I

    move-result v6

    #v6=(Integer);
    xor-int/2addr v2, v6

    and-int/lit16 v2, v2, 0xff

    aget v2, v5, v2

    xor-int/2addr v2, v4

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_a
    #v6=(Conflicted);
    and-int/lit8 v0, v2, 0x1f

    invoke-virtual {p2, v1}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    invoke-virtual {v5, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    #v0=(Char);
    if-eq v4, v0, :cond_b

    move v0, v1

    #v0=(Null);
    goto/16 :goto_2

    :cond_b
    #v0=(Char);
    shr-int/lit8 v0, v2, 0x5

    #v0=(Integer);
    and-int/lit8 v0, v0, 0x1f

    invoke-virtual {p2, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    sget-object v4, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    #v0=(Char);
    if-eq v2, v0, :cond_c

    move v0, v1

    #v0=(Null);
    goto/16 :goto_2

    :cond_c
    #v0=(Char);
    move v0, v3

    #v0=(One);
    goto/16 :goto_2

    :cond_d
    #v0=(Integer);v2=(Integer);v4=(Conflicted);
    and-int/lit8 v0, v2, 0x1f

    invoke-virtual {p2, v7}, Ljava/lang/String;->charAt(I)C

    move-result v4

    #v4=(Char);
    sget-object v5, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    invoke-virtual {v5, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    #v0=(Char);
    if-eq v4, v0, :cond_e

    move v0, v1

    :goto_5
    #v0=(Boolean);v4=(Conflicted);
    if-eqz v0, :cond_0

    move v1, v3

    #v1=(One);
    goto/16 :goto_0

    :cond_e
    #v0=(Char);v1=(Null);v4=(Char);
    shr-int/lit8 v0, v2, 0x5

    #v0=(Integer);
    and-int/lit8 v0, v0, 0x1f

    const/16 v2, 0x1c

    #v2=(PosByte);
    invoke-virtual {p2, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    #v2=(Char);
    sget-object v4, Lcom/tencent/map/location/ac;->CM:Ljava/lang/String;

    #v4=(Reference);
    invoke-virtual {v4, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    #v0=(Char);
    if-eq v2, v0, :cond_f

    move v0, v1

    #v0=(Null);
    goto :goto_5

    :cond_f
    #v0=(Char);
    move v0, v3

    #v0=(One);
    goto :goto_5
.end method

*/}
