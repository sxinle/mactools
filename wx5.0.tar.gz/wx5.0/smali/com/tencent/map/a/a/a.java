package com.tencent.map.a.a; class a {/*

.class public final Lcom/tencent/map/a/a/a;
.super Ljava/lang/Object;


# static fields
.field private static BQ:Lcom/tencent/map/location/s;

.field private static BR:Lcom/tencent/map/a/a/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    invoke-static {}, Lcom/tencent/map/location/s;->hA()Lcom/tencent/map/location/s;

    move-result-object v0

    #v0=(Reference);
    sput-object v0, Lcom/tencent/map/a/a/a;->BQ:Lcom/tencent/map/location/s;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method public static a(Landroid/content/Context;Lcom/tencent/map/a/a/b;)Z
    .locals 1

    sget-object v0, Lcom/tencent/map/a/a/a;->BQ:Lcom/tencent/map/location/s;

    #v0=(Reference);
    invoke-virtual {v0, p0, p1}, Lcom/tencent/map/location/s;->b(Landroid/content/Context;Lcom/tencent/map/a/a/b;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public static g(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 1

    sget-object v0, Lcom/tencent/map/a/a/a;->BQ:Lcom/tencent/map/location/s;

    #v0=(Reference);
    invoke-virtual {v0, p0, p1}, Lcom/tencent/map/location/s;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public static declared-synchronized ho()Lcom/tencent/map/a/a/a;
    .locals 2

    const-class v1, Lcom/tencent/map/a/a/a;

    #v1=(Reference);
    monitor-enter v1

    :try_start_0
    sget-object v0, Lcom/tencent/map/a/a/a;->BR:Lcom/tencent/map/a/a/a;

    #v0=(Reference);
    if-nez v0, :cond_0

    new-instance v0, Lcom/tencent/map/a/a/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/map/a/a/a;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/map/a/a/a;->BR:Lcom/tencent/map/a/a/a;

    :cond_0
    sget-object v0, Lcom/tencent/map/a/a/a;->BR:Lcom/tencent/map/a/a/a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object v0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0
.end method

.method public static hp()V
    .locals 1

    sget-object v0, Lcom/tencent/map/a/a/a;->BQ:Lcom/tencent/map/location/s;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/map/location/s;->hw()V

    return-void
.end method

*/}
