package com.tencent.map.a.a; class c {/*

.class public final Lcom/tencent/map/a/a/c;
.super Ljava/lang/Object;


# instance fields
.field public BW:Ljava/lang/String;

.field public BX:Ljava/lang/String;

.field public BY:Ljava/lang/String;

.field public BZ:D

.field public Ca:D

.field public Cb:D


# direct methods
.method public constructor <init>(Lcom/tencent/map/a/a/c;)V
    .locals 3

    const/4 v2, 0x0

    #v2=(Null);
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-object v2, p0, Lcom/tencent/map/a/a/c;->BW:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/c;->BX:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/c;->BY:Ljava/lang/String;

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->BZ:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->Ca:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->Cb:D

    iget-object v0, p1, Lcom/tencent/map/a/a/c;->BW:Ljava/lang/String;

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/a/a/c;->BW:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/c;->BX:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/c;->BX:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/c;->BY:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/c;->BY:Ljava/lang/String;

    iget-wide v0, p1, Lcom/tencent/map/a/a/c;->BZ:D

    #v0=(DoubleLo);v1=(DoubleHi);
    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->BZ:D

    iget-wide v0, p1, Lcom/tencent/map/a/a/c;->Ca:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->Ca:D

    iget-wide v0, p1, Lcom/tencent/map/a/a/c;->Cb:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->Cb:D

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDD)V
    .locals 3

    const/4 v2, 0x0

    #v2=(Null);
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput-object v2, p0, Lcom/tencent/map/a/a/c;->BW:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/c;->BX:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/c;->BY:Ljava/lang/String;

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->BZ:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->Ca:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/c;->Cb:D

    iput-object p1, p0, Lcom/tencent/map/a/a/c;->BW:Ljava/lang/String;

    iput-object p2, p0, Lcom/tencent/map/a/a/c;->BX:Ljava/lang/String;

    iput-object p3, p0, Lcom/tencent/map/a/a/c;->BY:Ljava/lang/String;

    iput-wide p4, p0, Lcom/tencent/map/a/a/c;->BZ:D

    iput-wide p6, p0, Lcom/tencent/map/a/a/c;->Ca:D

    iput-wide p8, p0, Lcom/tencent/map/a/a/c;->Cb:D

    return-void
.end method

*/}
