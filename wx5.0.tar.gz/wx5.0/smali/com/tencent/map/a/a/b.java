package com.tencent.map.a.a; class b {/*

.class public Lcom/tencent/map/a/a/b;
.super Ljava/lang/Object;


# instance fields
.field private BS:I

.field private BT:I

.field private BU:I

.field private BV:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    #v3=(Null);
    const/4 v2, 0x1

    #v2=(One);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    iput v2, p0, Lcom/tencent/map/a/a/b;->BS:I

    iput v3, p0, Lcom/tencent/map/a/a/b;->BT:I

    const/16 v0, 0xc

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/map/a/a/b;->BU:I

    iput v2, p0, Lcom/tencent/map/a/a/b;->BV:I

    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "argument: "

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    iget v1, p0, Lcom/tencent/map/a/a/b;->BS:I

    #v1=(Integer);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " "

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/tencent/map/a/a/b;->BV:I

    #v1=(Integer);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " "

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/tencent/map/a/a/b;->BT:I

    #v1=(Integer);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    invoke-static {}, Lcom/tencent/map/location/ab;->hG()V

    iput v2, p0, Lcom/tencent/map/a/a/b;->BS:I

    iput v2, p0, Lcom/tencent/map/a/a/b;->BV:I

    iput v3, p0, Lcom/tencent/map/a/a/b;->BT:I

    iget v0, p0, Lcom/tencent/map/a/a/b;->BV:I

    #v0=(Integer);
    if-nez v0, :cond_0

    iput v3, p0, Lcom/tencent/map/a/a/b;->BT:I

    :cond_0
    iput v2, p0, Lcom/tencent/map/a/a/b;->BU:I

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/map/a/a/d;)V
    .locals 0

    return-void
.end method

.method public final hq()I
    .locals 1

    iget v0, p0, Lcom/tencent/map/a/a/b;->BS:I

    #v0=(Integer);
    return v0
.end method

.method public final hr()I
    .locals 1

    iget v0, p0, Lcom/tencent/map/a/a/b;->BT:I

    #v0=(Integer);
    return v0
.end method

.method public final hs()I
    .locals 1

    iget v0, p0, Lcom/tencent/map/a/a/b;->BV:I

    #v0=(Integer);
    return v0
.end method

*/}
