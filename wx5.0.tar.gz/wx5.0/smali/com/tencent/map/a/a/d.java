package com.tencent.map.a.a; class d {/*

.class public final Lcom/tencent/map/a/a/d;
.super Ljava/lang/Object;


# instance fields
.field private CA:J

.field public Ca:D

.field public Cb:D

.field public Cc:I

.field public Cd:D

.field public Ce:D

.field public Cf:D

.field public Cg:D

.field public Ch:I

.field public Ci:Ljava/lang/String;

.field public Cj:Ljava/lang/String;

.field public Ck:Ljava/lang/String;

.field public Cl:Ljava/lang/String;

.field public Cm:Ljava/lang/String;

.field public Cn:Ljava/lang/String;

.field public Co:Ljava/lang/String;

.field public Cp:Ljava/lang/String;

.field public Cq:Ljava/lang/String;

.field public Cr:Ljava/lang/String;

.field public Cs:Ljava/lang/String;

.field public Ct:Ljava/lang/String;

.field public Cu:Ljava/lang/String;

.field public Cv:Ljava/lang/String;

.field public Cw:Ljava/util/ArrayList;

.field public Cx:Z

.field public Cy:I

.field public Cz:I


# direct methods
.method public constructor <init>()V
    .locals 7

    const/4 v6, -0x1

    #v6=(Byte);
    const/4 v5, 0x0

    #v5=(Null);
    const-wide/16 v3, 0x0

    #v3=(LongLo);v4=(LongHi);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/map/a/a/d;->Cc:I

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Ca:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cb:D

    const-wide/high16 v0, -0x4010

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->Cd:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Ce:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cf:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cg:D

    iput v5, p0, Lcom/tencent/map/a/a/d;->Ch:I

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    iput-boolean v5, p0, Lcom/tencent/map/a/a/d;->Cx:Z

    iput v5, p0, Lcom/tencent/map/a/a/d;->Cy:I

    iput v6, p0, Lcom/tencent/map/a/a/d;->Cz:I

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->CA:J

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Ce:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cd:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cb:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Ca:D

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iput-boolean v5, p0, Lcom/tencent/map/a/a/d;->Cx:Z

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->CA:J

    iput v5, p0, Lcom/tencent/map/a/a/d;->Cy:I

    iput v6, p0, Lcom/tencent/map/a/a/d;->Cz:I

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>(Lcom/tencent/map/a/a/d;)V
    .locals 6

    const/4 v5, 0x0

    #v5=(Null);
    const-wide/16 v3, 0x0

    #v3=(LongLo);v4=(LongHi);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/map/a/a/d;->Cc:I

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Ca:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cb:D

    const-wide/high16 v0, -0x4010

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->Cd:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Ce:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cf:D

    iput-wide v3, p0, Lcom/tencent/map/a/a/d;->Cg:D

    iput v5, p0, Lcom/tencent/map/a/a/d;->Ch:I

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    iput-boolean v5, p0, Lcom/tencent/map/a/a/d;->Cx:Z

    iput v5, p0, Lcom/tencent/map/a/a/d;->Cy:I

    const/4 v0, -0x1

    #v0=(Byte);
    iput v0, p0, Lcom/tencent/map/a/a/d;->Cz:I

    const-wide/16 v0, -0x1

    #v0=(LongLo);
    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->CA:J

    iget v0, p1, Lcom/tencent/map/a/a/d;->Cc:I

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/a/a/d;->Cc:I

    iget-wide v0, p1, Lcom/tencent/map/a/a/d;->Ca:D

    #v0=(DoubleLo);v1=(DoubleHi);
    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->Ca:D

    iget-wide v0, p1, Lcom/tencent/map/a/a/d;->Cb:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->Cb:D

    iget-wide v0, p1, Lcom/tencent/map/a/a/d;->Cd:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->Cd:D

    iget-wide v0, p1, Lcom/tencent/map/a/a/d;->Ce:D

    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->Ce:D

    iget-boolean v0, p1, Lcom/tencent/map/a/a/d;->Cx:Z

    #v0=(Boolean);
    iput-boolean v0, p0, Lcom/tencent/map/a/a/d;->Cx:Z

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    iput v5, p0, Lcom/tencent/map/a/a/d;->Ch:I

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;

    iget-wide v0, p1, Lcom/tencent/map/a/a/d;->CA:J

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/map/a/a/d;->CA:J

    iget v0, p1, Lcom/tencent/map/a/a/d;->Cy:I

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/map/a/a/d;->Cy:I

    iget v0, p1, Lcom/tencent/map/a/a/d;->Cz:I

    iput v0, p0, Lcom/tencent/map/a/a/d;->Cz:I

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    #v0=(Reference);
    if-eqz v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    iget-object v0, p1, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    #v1=(Reference);v2=(Reference);
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/map/a/a/c;

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void
.end method


# virtual methods
.method public final Z(Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x2

    #v5=(PosByte);
    const/4 v4, 0x1

    #v4=(One);
    const/4 v3, 0x3

    #v3=(PosByte);
    const-string v0, "Unknown"

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    if-nez p1, :cond_1

    :cond_0
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    :cond_1
    #v1=(Uninit);v2=(Uninit);
    const-string v0, ","

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    array-length v1, v0

    #v1=(Integer);
    if-lez v1, :cond_2

    const/4 v2, 0x0

    #v2=(Null);
    aget-object v2, v0, v2

    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    :cond_2
    #v2=(Conflicted);
    if-le v1, v4, :cond_3

    aget-object v2, v0, v4

    #v2=(Null);
    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    :cond_3
    #v2=(Conflicted);
    if-ne v1, v3, :cond_5

    aget-object v2, v0, v4

    #v2=(Null);
    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    :cond_4
    :goto_1
    #v2=(Conflicted);
    if-ne v1, v3, :cond_6

    aget-object v0, v0, v5

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    goto :goto_0

    :cond_5
    #v0=(Reference);
    if-le v1, v3, :cond_4

    aget-object v2, v0, v5

    #v2=(Null);
    iput-object v2, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    goto :goto_1

    :cond_6
    #v2=(Conflicted);
    if-le v1, v3, :cond_0

    aget-object v0, v0, v3

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    goto :goto_0
.end method

.method public final toString()Ljava/lang/String;
    .locals 6

    const/4 v4, 0x4

    #v4=(PosByte);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    #v1=(Reference);
    iget v0, p0, Lcom/tencent/map/a/a/d;->Cz:I

    #v0=(Integer);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v2, p0, Lcom/tencent/map/a/a/d;->Cy:I

    #v2=(Integer);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-boolean v0, p0, Lcom/tencent/map/a/a/d;->Cx:Z

    #v0=(Boolean);
    if-eqz v0, :cond_2

    const-string v0, "Mars"

    :goto_0
    #v0=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v0, p0, Lcom/tencent/map/a/a/d;->Cc:I

    #v0=(Integer);
    if-nez v0, :cond_3

    const-string v0, "GPS"

    :goto_1
    #v0=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lcom/tencent/map/a/a/d;->Ca:D

    #v2=(DoubleLo);v3=(DoubleHi);
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v2, p0, Lcom/tencent/map/a/a/d;->Cb:D

    #v2=(DoubleLo);
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\n"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lcom/tencent/map/a/a/d;->Cd:D

    #v2=(DoubleLo);
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v2, p0, Lcom/tencent/map/a/a/d;->Ce:D

    #v2=(DoubleLo);
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\n"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lcom/tencent/map/a/a/d;->Cf:D

    #v2=(DoubleLo);
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v2, p0, Lcom/tencent/map/a/a/d;->Cg:D

    #v2=(DoubleLo);
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\n"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Lcom/tencent/map/a/a/d;->Cz:I

    #v0=(Integer);
    const/4 v2, 0x3

    #v2=(PosByte);
    if-eq v0, v2, :cond_0

    iget v0, p0, Lcom/tencent/map/a/a/d;->Cz:I

    if-ne v0, v4, :cond_1

    :cond_0
    iget-object v0, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    #v0=(Conflicted);v2=(Conflicted);
    iget v0, p0, Lcom/tencent/map/a/a/d;->Cz:I

    #v0=(Integer);
    if-ne v0, v4, :cond_4

    iget-object v0, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    #v0=(Reference);
    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    const-string v2, "\n"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/tencent/map/a/a/d;->Cw:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    #v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/map/a/a/c;

    iget-object v3, v0, Lcom/tencent/map/a/a/c;->BW:Ljava/lang/String;

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ","

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v0, Lcom/tencent/map/a/a/c;->BX:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ","

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v0, Lcom/tencent/map/a/a/c;->BY:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ","

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v4, v0, Lcom/tencent/map/a/a/c;->BZ:D

    #v4=(DoubleLo);v5=(DoubleHi);
    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ","

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v4, v0, Lcom/tencent/map/a/a/c;->Ca:D

    #v4=(DoubleLo);
    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ","

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v4, v0, Lcom/tencent/map/a/a/c;->Cb:D

    #v4=(DoubleLo);
    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2

    :cond_2
    #v0=(Boolean);v3=(Uninit);v4=(PosByte);v5=(Uninit);
    const-string v0, "WGS84"

    #v0=(Reference);
    goto/16 :goto_0

    :cond_3
    #v0=(Integer);
    const-string v0, "Network"

    #v0=(Reference);
    goto/16 :goto_1

    :cond_4
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    iget v0, p0, Lcom/tencent/map/a/a/d;->Cz:I

    #v0=(Integer);
    const/4 v2, 0x7

    #v2=(PosByte);
    if-ne v0, v2, :cond_5

    iget v0, p0, Lcom/tencent/map/a/a/d;->Ch:I

    if-nez v0, :cond_6

    iget-object v0, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cj:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Ck:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cl:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cm:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cn:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Co:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cp:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    :goto_3
    #v0=(Conflicted);v2=(Conflicted);
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    invoke-static {}, Lcom/tencent/map/location/ab;->hG()V

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0

    :cond_6
    #v0=(Integer);v2=(PosByte);
    iget v0, p0, Lcom/tencent/map/a/a/d;->Ch:I

    const/4 v2, 0x1

    #v2=(One);
    if-ne v0, v2, :cond_5

    iget-object v0, p0, Lcom/tencent/map/a/a/d;->Ci:Ljava/lang/String;

    #v0=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cq:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cr:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cs:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Ct:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cu:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/map/a/a/d;->Cv:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_3
.end method

*/}
