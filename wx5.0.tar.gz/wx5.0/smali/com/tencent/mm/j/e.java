package com.tencent.mm.j; class e {/*

.class final Lcom/tencent/mm/j/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final synthetic bDp:Lcom/tencent/mm/j/a;

.field bDq:I

.field bDr:I


# direct methods
.method public constructor <init>(Lcom/tencent/mm/j/a;II)V
    .locals 0
    .parameter
    .parameter
    .parameter

    .prologue
    .line 53
    iput-object p1, p0, Lcom/tencent/mm/j/e;->bDp:Lcom/tencent/mm/j/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 54
    #p0=(Reference);
    iput p2, p0, Lcom/tencent/mm/j/e;->bDr:I

    .line 55
    iput p3, p0, Lcom/tencent/mm/j/e;->bDq:I

    .line 56
    return-void
.end method

*/}
