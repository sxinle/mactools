package com.tencent.mm.j; class b {/*

.class final Lcom/tencent/mm/j/b;
.super Landroid/os/Handler;
.source "SourceFile"


# instance fields
.field final synthetic bDp:Lcom/tencent/mm/j/a;


# direct methods
.method constructor <init>(Lcom/tencent/mm/j/a;Landroid/os/Looper;)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 59
    iput-object p1, p0, Lcom/tencent/mm/j/b;->bDp:Lcom/tencent/mm/j/a;

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 4
    .parameter

    .prologue
    .line 62
    iget v0, p1, Landroid/os/Message;->what:I

    #v0=(Integer);
    if-nez v0, :cond_0

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    #v0=(Reference);
    instance-of v0, v0, Lcom/tencent/mm/j/d;

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 63
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mm/j/d;

    .line 64
    iget-object v1, p0, Lcom/tencent/mm/j/b;->bDp:Lcom/tencent/mm/j/a;

    #v1=(Reference);
    iget v2, v0, Lcom/tencent/mm/j/d;->bDq:I

    #v2=(Integer);
    iget v3, v0, Lcom/tencent/mm/j/d;->type:I

    #v3=(Integer);
    iget-object v0, v0, Lcom/tencent/mm/j/d;->value:Ljava/lang/String;

    invoke-static {v1, v2}, Lcom/tencent/mm/j/a;->a(Lcom/tencent/mm/j/a;I)V

    .line 67
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    iget v0, p1, Landroid/os/Message;->what:I

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    if-ne v0, v1, :cond_1

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    #v0=(Reference);
    instance-of v0, v0, Lcom/tencent/mm/j/e;

    #v0=(Boolean);
    if-eqz v0, :cond_1

    .line 68
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mm/j/e;

    .line 69
    iget-object v1, p0, Lcom/tencent/mm/j/b;->bDp:Lcom/tencent/mm/j/a;

    #v1=(Reference);
    iget v2, v0, Lcom/tencent/mm/j/e;->bDr:I

    #v2=(Integer);
    iget v0, v0, Lcom/tencent/mm/j/e;->bDq:I

    #v0=(Integer);
    invoke-static {v1, v2}, Lcom/tencent/mm/j/a;->b(Lcom/tencent/mm/j/a;I)V

    .line 71
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    return-void
.end method

*/}
