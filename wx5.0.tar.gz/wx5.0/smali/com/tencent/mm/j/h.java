package com.tencent.mm.j; class h {/*

.class public final Lcom/tencent/mm/j/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final synthetic bDx:Lcom/tencent/mm/j/f;

.field bDy:I

.field bDz:Landroid/util/SparseArray;


# direct methods
.method public constructor <init>(Lcom/tencent/mm/j/f;)V
    .locals 1
    .parameter

    .prologue
    .line 22
    iput-object p1, p0, Lcom/tencent/mm/j/h;->bDx:Lcom/tencent/mm/j/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    #p0=(Reference);
    new-instance v0, Landroid/util/SparseArray;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    return-void
.end method

*/}
