package com.tencent.mm.j; class d {/*

.class final Lcom/tencent/mm/j/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final synthetic bDp:Lcom/tencent/mm/j/a;

.field bDq:I

.field type:I

.field value:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/tencent/mm/j/a;IILjava/lang/String;)V
    .locals 0
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 42
    iput-object p1, p0, Lcom/tencent/mm/j/d;->bDp:Lcom/tencent/mm/j/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    #p0=(Reference);
    iput p2, p0, Lcom/tencent/mm/j/d;->bDq:I

    .line 44
    iput p3, p0, Lcom/tencent/mm/j/d;->type:I

    .line 45
    iput-object p4, p0, Lcom/tencent/mm/j/d;->value:Ljava/lang/String;

    .line 46
    return-void
.end method

*/}
