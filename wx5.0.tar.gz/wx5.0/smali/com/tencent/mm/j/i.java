package com.tencent.mm.j; class i {/*

.class public Lcom/tencent/mm/j/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/model/ay;


# instance fields
.field private bDA:Lcom/tencent/mm/j/a;


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 49
    #p0=(Reference);
    invoke-static {}, Lcom/tencent/mm/j/a;->no()Lcom/tencent/mm/j/a;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/i;->bDA:Lcom/tencent/mm/j/a;

    return-void
.end method

.method public static nr()Lcom/tencent/mm/j/a;
    .locals 2

    .prologue
    .line 52
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_0

    .line 53
    new-instance v0, Lcom/tencent/mm/model/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/model/a;-><init>()V

    #v0=(Reference);
    throw v0

    .line 55
    :cond_0
    #v0=(Integer);
    const-class v0, Lcom/tencent/mm/j/i;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/model/ba;->dg(Ljava/lang/String;)Lcom/tencent/mm/model/ay;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/j/i;

    if-nez v0, :cond_1

    new-instance v0, Lcom/tencent/mm/j/i;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/j/i;-><init>()V

    #v0=(Reference);
    const-class v1, Lcom/tencent/mm/j/i;

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/tencent/mm/model/ba;->a(Ljava/lang/String;Lcom/tencent/mm/model/ay;)V

    iget-object v1, v0, Lcom/tencent/mm/j/i;->bDA:Lcom/tencent/mm/j/a;

    invoke-virtual {v1}, Lcom/tencent/mm/j/a;->init()V

    :cond_1
    #v1=(Conflicted);
    iget-object v0, v0, Lcom/tencent/mm/j/i;->bDA:Lcom/tencent/mm/j/a;

    return-object v0
.end method


# virtual methods
.method public final aQ(I)V
    .locals 0
    .parameter

    .prologue
    .line 32
    return-void
.end method

.method public final l(Z)V
    .locals 0
    .parameter

    .prologue
    .line 36
    return-void
.end method

.method public final lP()V
    .locals 1

    .prologue
    .line 27
    iget-object v0, p0, Lcom/tencent/mm/j/i;->bDA:Lcom/tencent/mm/j/a;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/j/a;->clear()V

    .line 28
    return-void
.end method

.method public final lQ()Ljava/util/HashMap;
    .locals 1

    .prologue
    .line 46
    const/4 v0, 0x0

    #v0=(Null);
    return-object v0
.end method

.method public final p(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 40
    iget-object v0, p0, Lcom/tencent/mm/j/i;->bDA:Lcom/tencent/mm/j/a;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/j/a;->init()V

    .line 41
    return-void
.end method

*/}
