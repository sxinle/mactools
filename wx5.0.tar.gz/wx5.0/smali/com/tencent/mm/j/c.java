package com.tencent.mm.j; class c {/*

.class public interface abstract Lcom/tencent/mm/j/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract bk(I)V
.end method

.method public abstract bl(I)V
.end method

*/}
