package com.tencent.mm.j; class g {/*

.class public final Lcom/tencent/mm/j/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field bDq:I

.field bDw:Ljava/lang/String;

.field final synthetic bDx:Lcom/tencent/mm/j/f;

.field type:I

.field value:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/tencent/mm/j/f;)V
    .locals 0
    .parameter

    .prologue
    .line 15
    iput-object p1, p0, Lcom/tencent/mm/j/g;->bDx:Lcom/tencent/mm/j/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

*/}
