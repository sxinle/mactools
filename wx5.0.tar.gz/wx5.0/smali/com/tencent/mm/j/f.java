package com.tencent.mm.j; class f {/*

.class public final Lcom/tencent/mm/j/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private bDs:Landroid/util/SparseArray;

.field private bDt:Landroid/util/SparseArray;

.field private bDu:Ljava/util/Random;

.field private bDv:Lcom/tencent/mm/storage/e;


# direct methods
.method public constructor <init>()V
    .locals 1

    .prologue
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    #p0=(Reference);
    new-instance v0, Landroid/util/SparseArray;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/f;->bDs:Landroid/util/SparseArray;

    .line 28
    new-instance v0, Landroid/util/SparseArray;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/f;->bDt:Landroid/util/SparseArray;

    .line 29
    new-instance v0, Ljava/util/Random;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/f;->bDu:Ljava/util/Random;

    .line 30
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/j/f;->bDv:Lcom/tencent/mm/storage/e;

    return-void
.end method

.method private a(IILjava/lang/String;Ljava/lang/String;)Lcom/tencent/mm/j/g;
    .locals 1
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 127
    new-instance v0, Lcom/tencent/mm/j/g;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/j/g;-><init>(Lcom/tencent/mm/j/f;)V

    .line 128
    #v0=(Reference);
    iput p1, v0, Lcom/tencent/mm/j/g;->bDq:I

    .line 129
    iput p2, v0, Lcom/tencent/mm/j/g;->type:I

    .line 130
    iput-object p3, v0, Lcom/tencent/mm/j/g;->value:Ljava/lang/String;

    .line 131
    iput-object p4, v0, Lcom/tencent/mm/j/g;->bDw:Ljava/lang/String;

    .line 132
    return-object v0
.end method

.method private a(Lcom/tencent/mm/j/g;)V
    .locals 3
    .parameter

    .prologue
    .line 44
    new-instance v0, Ljava/lang/StringBuffer;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    .line 45
    #v0=(Reference);
    iget v1, p1, Lcom/tencent/mm/j/g;->type:I

    #v1=(Integer);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    .line 46
    const-string v1, "|"

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 47
    iget-object v1, p1, Lcom/tencent/mm/j/g;->value:Ljava/lang/String;

    invoke-static {v1}, Lcom/tencent/mm/j/f;->bI(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 48
    const-string v1, "|"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 49
    iget-object v1, p1, Lcom/tencent/mm/j/g;->bDw:Ljava/lang/String;

    invoke-static {v1}, Lcom/tencent/mm/j/f;->bI(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 50
    iget-object v1, p0, Lcom/tencent/mm/j/f;->bDv:Lcom/tencent/mm/storage/e;

    iget v2, p1, Lcom/tencent/mm/j/g;->bDq:I

    #v2=(Integer);
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Lcom/tencent/mm/storage/e;->set(ILjava/lang/Object;)V

    .line 51
    return-void
.end method

.method private a(Lcom/tencent/mm/j/h;)V
    .locals 5
    .parameter

    .prologue
    .line 54
    new-instance v2, Ljava/lang/StringBuffer;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    .line 55
    #v2=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    move v1, v0

    :goto_0
    #v0=(Integer);v1=(Integer);v3=(Conflicted);v4=(Conflicted);
    iget-object v0, p1, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    #v0=(Integer);
    if-ge v1, v0, :cond_1

    .line 56
    iget-object v0, p1, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    #v0=(Reference);
    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v3

    .line 57
    #v3=(Integer);
    iget-object v0, p1, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    invoke-virtual {v0, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 58
    if-eqz v1, :cond_0

    .line 59
    const-string v4, "|"

    #v4=(Reference);
    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 61
    :cond_0
    #v4=(Conflicted);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    .line 62
    const-string v3, "|"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 63
    invoke-static {v0}, Lcom/tencent/mm/j/f;->bI(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 55
    add-int/lit8 v0, v1, 0x1

    #v0=(Integer);
    move v1, v0

    goto :goto_0

    .line 65
    :cond_1
    #v3=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/j/f;->bDv:Lcom/tencent/mm/storage/e;

    #v0=(Reference);
    iget v1, p1, Lcom/tencent/mm/j/h;->bDy:I

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/e;->set(ILjava/lang/Object;)V

    .line 66
    return-void
.end method

.method private static bI(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .parameter

    .prologue
    .line 36
    const-string v0, "\\|"

    #v0=(Reference);
    const-string v1, "%7C"

    #v1=(Reference);
    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private bm(I)Lcom/tencent/mm/j/g;
    .locals 8
    .parameter

    .prologue
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v7, 0x1

    #v7=(One);
    const/4 v6, 0x0

    .line 69
    #v6=(Null);
    iget-object v0, p0, Lcom/tencent/mm/j/f;->bDv:Lcom/tencent/mm/storage/e;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/tencent/mm/storage/e;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 70
    if-nez v0, :cond_0

    move-object v0, v1

    .line 85
    :goto_0
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    .line 73
    :cond_0
    #v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    const-string v2, "\\|"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 74
    array-length v3, v2

    #v3=(Integer);
    const/4 v4, 0x3

    #v4=(PosByte);
    if-eq v3, v4, :cond_1

    .line 75
    const-string v2, "MicroMsg.NewBandageDecoder"

    const-string v3, "loadDataSource array.length != 3 content %s"

    #v3=(Reference);
    new-array v4, v7, [Ljava/lang/Object;

    #v4=(Reference);
    aput-object v0, v4, v6

    invoke-static {v2, v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->b(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    move-object v0, v1

    .line 76
    #v0=(Null);
    goto :goto_0

    .line 80
    :cond_1
    #v0=(Reference);v3=(Integer);v4=(PosByte);
    const/4 v3, 0x0

    :try_start_0
    #v3=(Null);
    aget-object v3, v2, v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    #v3=(Integer);
    const/4 v4, 0x1

    #v4=(One);
    aget-object v4, v2, v4

    #v4=(Null);
    invoke-static {v4}, Lcom/tencent/mm/j/f;->unescape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    #v4=(Reference);
    const/4 v5, 0x2

    #v5=(PosByte);
    aget-object v2, v2, v5

    #v2=(Null);
    invoke-static {v2}, Lcom/tencent/mm/j/f;->unescape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-direct {p0, p1, v3, v4, v2}, Lcom/tencent/mm/j/f;->a(IILjava/lang/String;Ljava/lang/String;)Lcom/tencent/mm/j/g;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v0

    goto :goto_0

    .line 82
    :catch_0
    #v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    move-exception v2

    const-string v2, "MicroMsg.NewBandageDecoder"

    const-string v3, "loadDataSource exception content %s"

    #v3=(Reference);
    new-array v4, v7, [Ljava/lang/Object;

    #v4=(Reference);
    aput-object v0, v4, v6

    invoke-static {v2, v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->b(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    move-object v0, v1

    .line 85
    #v0=(Null);
    goto :goto_0
.end method

.method private bn(I)Lcom/tencent/mm/j/h;
    .locals 10
    .parameter

    .prologue
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v9, 0x1

    #v9=(One);
    const/4 v4, 0x0

    .line 90
    #v4=(Null);
    iget-object v0, p0, Lcom/tencent/mm/j/f;->bDv:Lcom/tencent/mm/storage/e;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Lcom/tencent/mm/storage/e;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 91
    if-nez v0, :cond_0

    .line 92
    invoke-direct {p0, p1}, Lcom/tencent/mm/j/f;->bo(I)Lcom/tencent/mm/j/h;

    move-result-object v0

    .line 110
    :goto_0
    #v2=(Conflicted);v3=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-object v0

    .line 94
    :cond_0
    #v2=(Uninit);v3=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    const-string v2, "\\|"

    #v2=(Reference);
    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    .line 95
    #v5=(Reference);
    array-length v2, v5

    #v2=(Integer);
    rem-int/lit8 v2, v2, 0x2

    if-eqz v2, :cond_1

    .line 96
    const-string v2, "MicroMsg.NewBandageDecoder"

    #v2=(Reference);
    const-string v3, "loadWatcher array.length %% 2 != 0 content %s"

    #v3=(Reference);
    new-array v5, v9, [Ljava/lang/Object;

    aput-object v0, v5, v4

    invoke-static {v2, v3, v5}, Lcom/tencent/mm/sdk/platformtools/y;->b(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    move-object v0, v1

    .line 97
    #v0=(Null);
    goto :goto_0

    .line 101
    :cond_1
    :try_start_0
    #v0=(Reference);v2=(Integer);v3=(Uninit);
    invoke-direct {p0, p1}, Lcom/tencent/mm/j/f;->bo(I)Lcom/tencent/mm/j/h;

    move-result-object v2

    #v2=(Reference);
    move v3, v4

    .line 102
    :goto_1
    #v3=(Integer);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    array-length v6, v5

    #v6=(Integer);
    if-ge v3, v6, :cond_2

    .line 103
    iget-object v6, v2, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    #v6=(Reference);
    aget-object v7, v5, v3

    #v7=(Null);
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    #v7=(Integer);
    add-int/lit8 v8, v3, 0x1

    #v8=(Integer);
    aget-object v8, v5, v8

    #v8=(Null);
    invoke-static {v8}, Lcom/tencent/mm/j/f;->unescape(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    #v8=(Reference);
    invoke-virtual {v6, v7, v8}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 102
    add-int/lit8 v3, v3, 0x2

    goto :goto_1

    :cond_2
    #v6=(Integer);v7=(Conflicted);v8=(Conflicted);
    move-object v0, v2

    .line 105
    goto :goto_0

    .line 107
    :catch_0
    #v2=(Conflicted);v3=(Conflicted);v6=(Conflicted);
    move-exception v2

    #v2=(Reference);
    const-string v2, "MicroMsg.NewBandageDecoder"

    const-string v3, "loadWatcher exception content %s"

    #v3=(Reference);
    new-array v5, v9, [Ljava/lang/Object;

    aput-object v0, v5, v4

    invoke-static {v2, v3, v5}, Lcom/tencent/mm/sdk/platformtools/y;->b(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    move-object v0, v1

    .line 110
    #v0=(Null);
    goto :goto_0
.end method

.method private bo(I)Lcom/tencent/mm/j/h;
    .locals 1
    .parameter

    .prologue
    .line 121
    new-instance v0, Lcom/tencent/mm/j/h;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/j/h;-><init>(Lcom/tencent/mm/j/f;)V

    .line 122
    #v0=(Reference);
    iput p1, v0, Lcom/tencent/mm/j/h;->bDy:I

    .line 123
    return-object v0
.end method

.method private bq(I)Lcom/tencent/mm/j/h;
    .locals 2
    .parameter

    .prologue
    .line 157
    iget-object v0, p0, Lcom/tencent/mm/j/f;->bDt:Landroid/util/SparseArray;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/j/h;

    .line 158
    if-nez v0, :cond_0

    .line 159
    invoke-direct {p0, p1}, Lcom/tencent/mm/j/f;->bn(I)Lcom/tencent/mm/j/h;

    move-result-object v0

    .line 160
    if-nez v0, :cond_1

    .line 161
    const-string v0, "MicroMsg.NewBandageDecoder"

    const-string v1, "[carl] loadWatcher watcher == null"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    const/4 v0, 0x0

    .line 166
    :cond_0
    :goto_0
    #v1=(Conflicted);
    return-object v0

    .line 164
    :cond_1
    #v1=(Uninit);
    iget-object v1, p0, Lcom/tencent/mm/j/f;->bDt:Landroid/util/SparseArray;

    #v1=(Reference);
    invoke-virtual {v1, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    goto :goto_0
.end method

.method private nq()Ljava/lang/String;
    .locals 6

    .prologue
    .line 115
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 116
    #v0=(LongLo);v1=(LongHi);
    iget-object v2, p0, Lcom/tencent/mm/j/f;->bDu:Ljava/util/Random;

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/j/f;->bDu:Ljava/util/Random;

    #v3=(Reference);
    const v4, 0x7fffffff

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    #v3=(Integer);
    invoke-static {v3}, Ljava/lang/Math;->abs(I)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    #v2=(Integer);
    rem-int/lit16 v2, v2, 0x2710

    .line 117
    const-string v3, "%d%04d"

    #v3=(Reference);
    const/4 v4, 0x2

    #v4=(PosByte);
    new-array v4, v4, [Ljava/lang/Object;

    #v4=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    #v0=(Reference);
    aput-object v0, v4, v5

    const/4 v0, 0x1

    #v0=(One);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    aput-object v1, v4, v0

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method private static unescape(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .parameter

    .prologue
    .line 40
    const-string v0, "%7C"

    #v0=(Reference);
    const-string v1, "|"

    #v1=(Reference);
    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final b(IILjava/lang/String;)V
    .locals 5
    .parameter
    .parameter
    .parameter

    .prologue
    .line 185
    const-string v0, "MicroMsg.NewBandageDecoder"

    #v0=(Reference);
    const-string v1, "[carl] updateDataSourceValue, dataSourceId %d, type %d, value %s"

    #v1=(Reference);
    const/4 v2, 0x3

    #v2=(PosByte);
    new-array v2, v2, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    #v4=(Reference);
    aput-object v4, v2, v3

    const/4 v3, 0x1

    #v3=(One);
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    const/4 v3, 0x2

    #v3=(PosByte);
    aput-object p3, v2, v3

    invoke-static {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 186
    invoke-virtual {p0, p1}, Lcom/tencent/mm/j/f;->bp(I)Lcom/tencent/mm/j/g;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, ""

    const-string v1, ""

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/tencent/mm/j/f;->a(IILjava/lang/String;Ljava/lang/String;)Lcom/tencent/mm/j/g;

    move-result-object v0

    iget-object v1, p0, Lcom/tencent/mm/j/f;->bDs:Landroid/util/SparseArray;

    invoke-virtual {v1, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    invoke-direct {p0, v0}, Lcom/tencent/mm/j/f;->a(Lcom/tencent/mm/j/g;)V

    .line 187
    :cond_0
    iput-object p3, v0, Lcom/tencent/mm/j/g;->value:Ljava/lang/String;

    .line 188
    iput p2, v0, Lcom/tencent/mm/j/g;->type:I

    .line 189
    invoke-direct {p0}, Lcom/tencent/mm/j/f;->nq()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/tencent/mm/j/g;->bDw:Ljava/lang/String;

    .line 190
    invoke-direct {p0, v0}, Lcom/tencent/mm/j/f;->a(Lcom/tencent/mm/j/g;)V

    .line 191
    return-void
.end method

.method public final bp(I)Lcom/tencent/mm/j/g;
    .locals 2
    .parameter

    .prologue
    .line 146
    iget-object v0, p0, Lcom/tencent/mm/j/f;->bDs:Landroid/util/SparseArray;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/j/g;

    .line 147
    if-nez v0, :cond_0

    .line 148
    invoke-direct {p0, p1}, Lcom/tencent/mm/j/f;->bm(I)Lcom/tencent/mm/j/g;

    move-result-object v0

    .line 149
    if-eqz v0, :cond_0

    .line 150
    iget-object v1, p0, Lcom/tencent/mm/j/f;->bDs:Landroid/util/SparseArray;

    #v1=(Reference);
    invoke-virtual {v1, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 153
    :cond_0
    #v1=(Conflicted);
    return-object v0
.end method

.method public final clear()V
    .locals 2

    .prologue
    .line 174
    const-string v0, "MicroMsg.NewBandageDecoder"

    #v0=(Reference);
    const-string v1, "[carl] decoder.clear()"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 175
    iget-object v0, p0, Lcom/tencent/mm/j/f;->bDs:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->clear()V

    .line 176
    iget-object v0, p0, Lcom/tencent/mm/j/f;->bDt:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->clear()V

    .line 177
    return-void
.end method

.method public final g(III)Lcom/tencent/mm/j/g;
    .locals 6
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 199
    #v1=(Null);
    const-string v0, "MicroMsg.NewBandageDecoder"

    #v0=(Reference);
    const-string v2, "[carl] peek, dataSourceId %d, watcherId %d, type %d"

    #v2=(Reference);
    const/4 v3, 0x3

    #v3=(PosByte);
    new-array v3, v3, [Ljava/lang/Object;

    #v3=(Reference);
    const/4 v4, 0x0

    #v4=(Null);
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    #v5=(Reference);
    aput-object v5, v3, v4

    const/4 v4, 0x1

    #v4=(One);
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x2

    #v4=(PosByte);
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v3, v4

    invoke-static {v0, v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 200
    invoke-virtual {p0, p1}, Lcom/tencent/mm/j/f;->bp(I)Lcom/tencent/mm/j/g;

    move-result-object v2

    .line 201
    if-nez v2, :cond_0

    .line 202
    const-string v0, "MicroMsg.NewBandageDecoder"

    const-string v2, "[carl] peek, dataSource == null"

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v1

    .line 224
    :goto_0
    #v1=(Reference);
    return-object v0

    .line 204
    :cond_0
    #v1=(Null);
    iget v0, v2, Lcom/tencent/mm/j/g;->type:I

    #v0=(Integer);
    and-int/2addr v0, p3

    if-nez v0, :cond_1

    .line 205
    const-string v0, "MicroMsg.NewBandageDecoder"

    #v0=(Reference);
    const-string v2, "[alex] peek, dataSource.type is wrong"

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v1

    .line 206
    #v0=(Null);
    goto :goto_0

    .line 209
    :cond_1
    #v0=(Integer);
    invoke-direct {p0, p2}, Lcom/tencent/mm/j/f;->bq(I)Lcom/tencent/mm/j/h;

    move-result-object v3

    .line 210
    if-eqz v3, :cond_4

    .line 211
    iget-object v0, v3, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    #v0=(Reference);
    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 212
    if-eqz v0, :cond_2

    iget-object v4, v2, Lcom/tencent/mm/j/g;->bDw:Ljava/lang/String;

    #v4=(Reference);
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_2

    move-object v0, v1

    .line 213
    #v0=(Null);
    goto :goto_0

    .line 215
    :cond_2
    #v0=(Reference);v4=(PosByte);
    if-nez v0, :cond_3

    .line 216
    invoke-direct {p0}, Lcom/tencent/mm/j/f;->nq()Ljava/lang/String;

    move-result-object v0

    .line 217
    iget-object v1, v3, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    #v1=(Reference);
    invoke-virtual {v1, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 218
    invoke-direct {p0, v3}, Lcom/tencent/mm/j/f;->a(Lcom/tencent/mm/j/h;)V

    :cond_3
    move-object v0, v2

    .line 220
    goto :goto_0

    .line 223
    :cond_4
    #v0=(Integer);v1=(Null);
    const-string v0, "MicroMsg.NewBandageDecoder"

    #v0=(Reference);
    const-string v2, "[carl] peek, watcher == null"

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v1

    .line 224
    #v0=(Null);
    goto :goto_0
.end method

.method public final init()V
    .locals 1

    .prologue
    .line 170
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nJ()Lcom/tencent/mm/storage/e;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mm/j/f;->bDv:Lcom/tencent/mm/storage/e;

    .line 171
    return-void
.end method

.method public final o(II)V
    .locals 5
    .parameter
    .parameter

    .prologue
    .line 235
    const-string v0, "MicroMsg.NewBandageDecoder"

    #v0=(Reference);
    const-string v1, "[carl] doWatch, doWatch %d, watcherId %d"

    #v1=(Reference);
    const/4 v2, 0x2

    #v2=(PosByte);
    new-array v2, v2, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    #v4=(Reference);
    aput-object v4, v2, v3

    const/4 v3, 0x1

    #v3=(One);
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 236
    invoke-virtual {p0, p1}, Lcom/tencent/mm/j/f;->bp(I)Lcom/tencent/mm/j/g;

    move-result-object v1

    .line 237
    if-nez v1, :cond_0

    .line 238
    const-string v0, "MicroMsg.NewBandageDecoder"

    const-string v1, "[carl] doWatch, dataSource == null"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 249
    :goto_0
    return-void

    .line 241
    :cond_0
    invoke-direct {p0, p2}, Lcom/tencent/mm/j/f;->bq(I)Lcom/tencent/mm/j/h;

    move-result-object v0

    .line 242
    if-nez v0, :cond_1

    .line 243
    const-string v0, "MicroMsg.NewBandageDecoder"

    const-string v2, "[carl] doWatch, watcher == null, do some fix"

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 244
    invoke-direct {p0, p2}, Lcom/tencent/mm/j/f;->bo(I)Lcom/tencent/mm/j/h;

    move-result-object v0

    .line 245
    iget-object v2, p0, Lcom/tencent/mm/j/f;->bDt:Landroid/util/SparseArray;

    invoke-virtual {v2, p2, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 247
    :cond_1
    iget-object v2, v0, Lcom/tencent/mm/j/h;->bDz:Landroid/util/SparseArray;

    iget-object v1, v1, Lcom/tencent/mm/j/g;->bDw:Ljava/lang/String;

    invoke-virtual {v2, p1, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 248
    invoke-direct {p0, v0}, Lcom/tencent/mm/j/f;->a(Lcom/tencent/mm/j/h;)V

    goto :goto_0
.end method

*/}
