package com.tencent.mm.j; class a {/*

.class public final Lcom/tencent/mm/j/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static bDj:Lcom/tencent/mm/j/a;


# instance fields
.field private bDk:Lcom/tencent/mm/j/f;

.field private bDl:Ljava/util/ArrayList;

.field private bDm:Z

.field private final bDn:I

.field private final bDo:I

.field private handler:Landroid/os/Handler;


# direct methods
.method public constructor <init>()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 14
    #v1=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    #p0=(Reference);
    new-instance v0, Lcom/tencent/mm/j/f;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/j/f;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    .line 30
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    .line 32
    iput-boolean v1, p0, Lcom/tencent/mm/j/a;->bDm:Z

    .line 34
    iput v1, p0, Lcom/tencent/mm/j/a;->bDn:I

    .line 35
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/mm/j/a;->bDo:I

    .line 59
    new-instance v0, Lcom/tencent/mm/j/b;

    #v0=(UninitRef);
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, p0, v1}, Lcom/tencent/mm/j/b;-><init>(Lcom/tencent/mm/j/a;Landroid/os/Looper;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/j/a;->handler:Landroid/os/Handler;

    return-void
.end method

.method private a(IILjava/lang/String;)V
    .locals 4
    .parameter
    .parameter
    .parameter

    .prologue
    .line 149
    iget-boolean v0, p0, Lcom/tencent/mm/j/a;->bDm:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 150
    const-string v0, "MicroMsg.NewBandage"

    #v0=(Reference);
    const-string v1, "updateDataSource NewBandage has not initialized"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 156
    :goto_0
    #v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 153
    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    #v0=(Reference);
    invoke-virtual {v0, p1, p2, p3}, Lcom/tencent/mm/j/f;->b(IILjava/lang/String;)V

    .line 155
    iget-object v0, p0, Lcom/tencent/mm/j/a;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tencent/mm/j/a;->handler:Landroid/os/Handler;

    #v1=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    new-instance v3, Lcom/tencent/mm/j/d;

    #v3=(UninitRef);
    invoke-direct {v3, p0, p1, p2, p3}, Lcom/tencent/mm/j/d;-><init>(Lcom/tencent/mm/j/a;IILjava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v1, v2, v3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0
.end method

.method static synthetic a(Lcom/tencent/mm/j/a;I)V
    .locals 4
    .parameter
    .parameter

    .prologue
    .line 14
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    #v1=(Reference);v2=(Reference);v3=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    #v3=(Reference);
    if-eqz v3, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/j/c;

    invoke-interface {v0, p1}, Lcom/tencent/mm/j/c;->bk(I)V

    goto :goto_0

    :cond_0
    #v3=(Conflicted);
    if-nez v1, :cond_1

    new-instance v1, Ljava/util/ArrayList;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :cond_1
    #v1=(Reference);
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    #v0=(Boolean);
    if-eqz v1, :cond_4

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    #v0=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/ref/WeakReference;

    iget-object v3, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v3=(Reference);
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_3
    #v0=(Boolean);v3=(Conflicted);
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    :cond_4
    return-void
.end method

.method static synthetic b(Lcom/tencent/mm/j/a;I)V
    .locals 4
    .parameter
    .parameter

    .prologue
    .line 14
    const/4 v1, 0x0

    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    #v1=(Reference);v2=(Reference);v3=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    #v3=(Reference);
    if-eqz v3, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/j/c;

    invoke-interface {v0, p1}, Lcom/tencent/mm/j/c;->bl(I)V

    goto :goto_0

    :cond_0
    #v3=(Conflicted);
    if-nez v1, :cond_1

    new-instance v1, Ljava/util/ArrayList;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :cond_1
    #v1=(Reference);
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    #v0=(Boolean);
    if-eqz v1, :cond_4

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    #v0=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/ref/WeakReference;

    iget-object v3, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v3=(Reference);
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_3
    #v0=(Boolean);v3=(Conflicted);
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    :cond_4
    return-void
.end method

.method public static no()Lcom/tencent/mm/j/a;
    .locals 1

    .prologue
    .line 75
    sget-object v0, Lcom/tencent/mm/j/a;->bDj:Lcom/tencent/mm/j/a;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 76
    new-instance v0, Lcom/tencent/mm/j/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/j/a;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/j/a;->bDj:Lcom/tencent/mm/j/a;

    .line 78
    :cond_0
    sget-object v0, Lcom/tencent/mm/j/a;->bDj:Lcom/tencent/mm/j/a;

    return-object v0
.end method

.method private static parseInt(Ljava/lang/String;)I
    .locals 1
    .parameter

    .prologue
    .line 254
    invoke-static {p0}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 255
    const/4 v0, 0x0

    .line 258
    :goto_0
    #v0=(Integer);
    return v0

    :cond_0
    #v0=(Boolean);
    invoke-static {p0}, Lcom/tencent/mm/sdk/platformtools/ce;->ru(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    goto :goto_0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/j/c;)V
    .locals 2
    .parameter

    .prologue
    .line 274
    iget-boolean v0, p0, Lcom/tencent/mm/j/a;->bDm:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 275
    const-string v0, "MicroMsg.NewBandage"

    #v0=(Reference);
    const-string v1, "addWatch NewBandage has not initialized"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 285
    :goto_0
    return-void

    .line 284
    :cond_0
    #v0=(Boolean);v1=(Uninit);
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v0=(Reference);
    new-instance v1, Ljava/lang/ref/WeakReference;

    #v1=(UninitRef);
    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0
.end method

.method public final b(Lcom/tencent/mm/j/c;)V
    .locals 4
    .parameter

    .prologue
    .line 288
    iget-boolean v0, p0, Lcom/tencent/mm/j/a;->bDm:Z

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 289
    const-string v0, "MicroMsg.NewBandage"

    #v0=(Reference);
    const-string v1, "removeWatch NewBandage has not initialized"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 311
    :cond_0
    :goto_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 293
    :cond_1
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    const/4 v1, 0x0

    .line 294
    #v1=(Null);
    const/4 v0, 0x0

    #v0=(Null);
    move v2, v0

    :goto_1
    #v0=(Integer);v1=(Reference);v2=(Integer);v3=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    #v0=(Integer);
    if-ge v2, v0, :cond_5

    .line 295
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 296
    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    #v3=(Reference);
    if-eqz v3, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    if-ne v3, p1, :cond_4

    .line 297
    :cond_2
    #v3=(Conflicted);
    if-nez v1, :cond_3

    .line 298
    new-instance v1, Ljava/util/ArrayList;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 300
    :cond_3
    #v1=(Reference);
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 294
    :cond_4
    add-int/lit8 v0, v2, 0x1

    #v0=(Integer);
    move v2, v0

    goto :goto_1

    .line 305
    :cond_5
    if-eqz v1, :cond_0

    .line 306
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    #v0=(Conflicted);v2=(Reference);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 307
    iget-object v3, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v3=(Reference);
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_2

    .line 309
    :cond_6
    #v0=(Boolean);v3=(Conflicted);
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    goto :goto_0
.end method

.method public final bi(I)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 177
    #v0=(Null);
    iget-boolean v1, p0, Lcom/tencent/mm/j/a;->bDm:Z

    #v1=(Boolean);
    if-nez v1, :cond_1

    .line 178
    const-string v1, "MicroMsg.NewBandage"

    #v1=(Reference);
    const-string v2, "hasDot NewBandage has not initialized"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 189
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 181
    :cond_1
    #v0=(Null);v1=(Boolean);v2=(Uninit);v3=(Uninit);
    iget-object v1, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    #v1=(Reference);
    const v2, 0x40004

    #v2=(Integer);
    const/4 v3, 0x2

    #v3=(PosByte);
    invoke-virtual {v1, v2, p1, v3}, Lcom/tencent/mm/j/f;->g(III)Lcom/tencent/mm/j/g;

    move-result-object v1

    .line 182
    if-eqz v1, :cond_0

    .line 185
    iget-object v1, v1, Lcom/tencent/mm/j/g;->value:Ljava/lang/String;

    invoke-static {v1}, Lcom/tencent/mm/j/a;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 186
    #v1=(Integer);
    if-eqz v1, :cond_0

    .line 189
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final bj(I)Z
    .locals 2
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 219
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    #v1=(Reference);
    invoke-virtual {v1, p1}, Lcom/tencent/mm/j/f;->bp(I)Lcom/tencent/mm/j/g;

    move-result-object v1

    .line 220
    if-nez v1, :cond_1

    .line 227
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);
    return v0

    .line 224
    :cond_1
    #v0=(Null);v1=(Reference);
    iget-object v1, v1, Lcom/tencent/mm/j/g;->value:Ljava/lang/String;

    invoke-static {v1}, Lcom/tencent/mm/j/a;->parseInt(Ljava/lang/String;)I

    move-result v1

    #v1=(Integer);
    if-eqz v1, :cond_0

    .line 227
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final c(IZ)V
    .locals 2
    .parameter
    .parameter

    .prologue
    .line 93
    const/4 v1, 0x1

    #v1=(One);
    if-nez p2, :cond_0

    const-string v0, "0"

    :goto_0
    #v0=(Reference);
    invoke-direct {p0, p1, v1, v0}, Lcom/tencent/mm/j/a;->a(IILjava/lang/String;)V

    .line 94
    return-void

    .line 93
    :cond_0
    #v0=(Uninit);
    const-string v0, "1"

    #v0=(Reference);
    goto :goto_0
.end method

.method public final clear()V
    .locals 1

    .prologue
    .line 87
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDl:Ljava/util/ArrayList;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 88
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    invoke-virtual {v0}, Lcom/tencent/mm/j/f;->clear()V

    .line 89
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/mm/j/a;->bDm:Z

    .line 90
    return-void
.end method

.method public final init()V
    .locals 1

    .prologue
    .line 82
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mm/j/a;->bDm:Z

    .line 83
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/j/f;->init()V

    .line 84
    return-void
.end method

.method public final m(II)Z
    .locals 3
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 159
    #v0=(Null);
    iget-boolean v2, p0, Lcom/tencent/mm/j/a;->bDm:Z

    #v2=(Boolean);
    if-nez v2, :cond_1

    .line 160
    const-string v1, "MicroMsg.NewBandage"

    #v1=(Reference);
    const-string v2, "hasNew NewBandage has not initialized"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 171
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return v0

    .line 163
    :cond_1
    #v0=(Null);v1=(One);v2=(Boolean);
    iget-object v2, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    #v2=(Reference);
    invoke-virtual {v2, p1, p2, v1}, Lcom/tencent/mm/j/f;->g(III)Lcom/tencent/mm/j/g;

    move-result-object v2

    .line 164
    if-eqz v2, :cond_0

    .line 167
    iget-object v2, v2, Lcom/tencent/mm/j/g;->value:Ljava/lang/String;

    invoke-static {v2}, Lcom/tencent/mm/j/a;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 168
    #v2=(Integer);
    if-eqz v2, :cond_0

    move v0, v1

    .line 171
    #v0=(One);
    goto :goto_0
.end method

.method public final n(II)V
    .locals 4
    .parameter
    .parameter

    .prologue
    .line 208
    iget-boolean v0, p0, Lcom/tencent/mm/j/a;->bDm:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 209
    const-string v0, "MicroMsg.NewBandage"

    #v0=(Reference);
    const-string v1, "markRead NewBandage has not initialized"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 216
    :goto_0
    #v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 212
    :cond_0
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/mm/j/a;->bDk:Lcom/tencent/mm/j/f;

    #v0=(Reference);
    invoke-virtual {v0, p1, p2}, Lcom/tencent/mm/j/f;->o(II)V

    .line 215
    iget-object v0, p0, Lcom/tencent/mm/j/a;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/tencent/mm/j/a;->handler:Landroid/os/Handler;

    #v1=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    new-instance v3, Lcom/tencent/mm/j/e;

    #v3=(UninitRef);
    invoke-direct {v3, p0, p2, p1}, Lcom/tencent/mm/j/e;-><init>(Lcom/tencent/mm/j/a;II)V

    #v3=(Reference);
    invoke-virtual {v1, v2, v3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_0
.end method

.method public final np()V
    .locals 3

    .prologue
    .line 97
    const v0, 0x40004

    #v0=(Integer);
    const/4 v1, 0x2

    #v1=(PosByte);
    const-string v2, "1"

    #v2=(Reference);
    invoke-direct {p0, v0, v1, v2}, Lcom/tencent/mm/j/a;->a(IILjava/lang/String;)V

    .line 98
    return-void
.end method

*/}
