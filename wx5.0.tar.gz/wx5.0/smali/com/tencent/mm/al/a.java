package com.tencent.mm.al; class a {/*

.class public Lcom/tencent/mm/al/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field protected static eBr:La/a/a/a/a/b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 26
    invoke-static {}, La/a/a/a/a/a;->aEl()La/a/a/a/a/a;

    move-result-object v0

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/al/a;->eBr:La/a/a/a/a/b;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method public static a(La/a/a/a/a;)I
    .locals 1
    .parameter

    .prologue
    .line 29
    invoke-virtual {p0}, La/a/a/a/a;->aEj()I

    move-result v0

    #v0=(Integer);
    return v0
.end method


# virtual methods
.method public a(La/a/a/c/a;)V
    .locals 2
    .parameter

    .prologue
    .line 33
    new-instance v0, Ljava/io/IOException;

    #v0=(UninitRef);
    const-string v1, "Cannot use this method."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method public iR()I
    .locals 2

    .prologue
    .line 37
    new-instance v0, Ljava/lang/Error;

    #v0=(UninitRef);
    const-string v1, "Cannot use this method"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method protected iS()Lcom/tencent/mm/al/a;
    .locals 0

    .prologue
    .line 40
    return-object p0
.end method

.method public n([B)Lcom/tencent/mm/al/a;
    .locals 2
    .parameter

    .prologue
    .line 23
    new-instance v0, Ljava/io/IOException;

    #v0=(UninitRef);
    const-string v1, "Cannot use this method."

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method public toByteArray()[B
    .locals 2

    .prologue
    .line 12
    invoke-virtual {p0}, Lcom/tencent/mm/al/a;->iS()Lcom/tencent/mm/al/a;

    .line 14
    invoke-virtual {p0}, Lcom/tencent/mm/al/a;->iR()I

    move-result v0

    #v0=(Integer);
    new-array v0, v0, [B

    .line 15
    #v0=(Reference);
    new-instance v1, La/a/a/c/a;

    #v1=(UninitRef);
    invoke-direct {v1, v0}, La/a/a/c/a;-><init>([B)V

    .line 16
    #v1=(Reference);
    invoke-virtual {p0, v1}, Lcom/tencent/mm/al/a;->a(La/a/a/c/a;)V

    .line 17
    invoke-virtual {v1}, La/a/a/c/a;->aEz()V

    .line 19
    return-object v0
.end method

*/}
