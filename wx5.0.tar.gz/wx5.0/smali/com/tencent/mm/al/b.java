package com.tencent.mm.al; class b {/*

.class public final Lcom/tencent/mm/al/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private eBs:[B


# direct methods
.method private constructor <init>()V
    .locals 0

    .prologue
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    #p0=(Reference);
    return-void
.end method

.method public constructor <init>([B)V
    .locals 2
    .parameter

    .prologue
    .line 12
    const/4 v0, 0x0

    #v0=(Null);
    array-length v1, p1

    #v1=(Integer);
    invoke-direct {p0, p1, v0, v1}, Lcom/tencent/mm/al/b;-><init>([BII)V

    .line 13
    #p0=(Reference);
    return-void
.end method

.method private constructor <init>([BII)V
    .locals 2
    .parameter
    .parameter
    .parameter

    .prologue
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    #p0=(Reference);
    new-array v0, p3, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/al/b;->eBs:[B

    .line 17
    iget-object v0, p0, Lcom/tencent/mm/al/b;->eBs:[B

    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {p1, p2, v0, v1, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 18
    return-void
.end method

.method public static at([B)Lcom/tencent/mm/al/b;
    .locals 1
    .parameter

    .prologue
    .line 29
    new-instance v0, Lcom/tencent/mm/al/b;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/al/b;-><init>([B)V

    #v0=(Reference);
    return-object v0
.end method

.method public static c([BII)Lcom/tencent/mm/al/b;
    .locals 1
    .parameter
    .parameter
    .parameter

    .prologue
    .line 25
    new-instance v0, Lcom/tencent/mm/al/b;

    #v0=(UninitRef);
    invoke-direct {v0, p0, p1, p2}, Lcom/tencent/mm/al/b;-><init>([BII)V

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final alx()Ljava/lang/String;
    .locals 5

    .prologue
    const/4 v0, 0x0

    .line 135
    .line 138
    :goto_0
    :try_start_0
    #v0=(Integer);v1=(Conflicted);
    iget-object v1, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v1=(Reference);
    array-length v1, v1

    #v1=(Integer);
    if-lt v0, v1, :cond_1

    .line 141
    :cond_0
    new-instance v1, Ljava/lang/String;

    #v1=(UninitRef);
    iget-object v2, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    const-string v4, "UTF-8"

    #v4=(Reference);
    invoke-direct {v1, v2, v3, v0, v4}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    #v1=(Reference);
    return-object v1

    .line 137
    :cond_1
    #v1=(Integer);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v1, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v1=(Reference);
    aget-byte v1, v1, v0
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    #v1=(Byte);
    if-eqz v1, :cond_0

    .line 138
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 143
    :catch_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    #v0=(Reference);
    new-instance v0, Ljava/lang/RuntimeException;

    #v0=(UninitRef);
    const-string v1, "UTF-8 not supported?"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
.end method

.method public final getBytes()[B
    .locals 1

    .prologue
    .line 116
    iget-object v0, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v0=(Reference);
    return-object v0
.end method

.method public final jd(I)Lcom/tencent/mm/al/b;
    .locals 4
    .parameter

    .prologue
    const/4 v3, 0x0

    .line 59
    #v3=(Null);
    new-array v0, p1, [B

    .line 60
    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v1=(Reference);
    array-length v1, v1

    #v1=(Integer);
    if-lt v1, p1, :cond_0

    .line 61
    iget-object v1, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v1=(Reference);
    add-int/lit8 v2, p1, -0x1

    #v2=(Integer);
    invoke-static {v1, v3, v0, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 62
    iput-object v0, p0, Lcom/tencent/mm/al/b;->eBs:[B

    .line 67
    :goto_0
    return-object p0

    .line 64
    :cond_0
    #v1=(Integer);v2=(Uninit);
    iget-object v1, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v2=(Reference);
    array-length v2, v2

    #v2=(Integer);
    invoke-static {v1, v3, v0, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 65
    iput-object v0, p0, Lcom/tencent/mm/al/b;->eBs:[B

    goto :goto_0
.end method

.method public final size()I
    .locals 1

    .prologue
    .line 21
    iget-object v0, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v0=(Reference);
    array-length v0, v0

    #v0=(Integer);
    return v0
.end method

.method public final toByteArray()[B
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 105
    #v3=(Null);
    iget-object v0, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v0=(Reference);
    array-length v0, v0

    .line 106
    #v0=(Integer);
    new-array v1, v0, [B

    .line 107
    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/al/b;->eBs:[B

    #v2=(Reference);
    invoke-static {v2, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 108
    return-object v1
.end method

*/}
