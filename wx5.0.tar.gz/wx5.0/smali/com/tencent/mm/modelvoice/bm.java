package com.tencent.mm.modelvoice; class bm {/*

.class final Lcom/tencent/mm/modelvoice/bm;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# instance fields
.field final synthetic bZB:Lcom/tencent/mm/modelvoice/bk;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/bk;)V
    .locals 0
    .parameter

    .prologue
    .line 70
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bm;->bZB:Lcom/tencent/mm/modelvoice/bk;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final onError(Landroid/media/MediaPlayer;II)Z
    .locals 4
    .parameter
    .parameter
    .parameter

    .prologue
    .line 73
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bm;->bZB:Lcom/tencent/mm/modelvoice/bk;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bk;->d(Lcom/tencent/mm/modelvoice/bk;)Lcom/tencent/mm/modelvoice/f;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 74
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bm;->bZB:Lcom/tencent/mm/modelvoice/bk;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bk;->d(Lcom/tencent/mm/modelvoice/bk;)Lcom/tencent/mm/modelvoice/f;

    move-result-object v0

    invoke-interface {v0}, Lcom/tencent/mm/modelvoice/f;->kX()V

    .line 77
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bm;->bZB:Lcom/tencent/mm/modelvoice/bk;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bk;->b(Lcom/tencent/mm/modelvoice/bk;)Landroid/media/MediaPlayer;

    move-result-object v0

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    .line 78
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bm;->bZB:Lcom/tencent/mm/modelvoice/bk;

    const/4 v1, -0x1

    #v1=(Byte);
    invoke-static {v0, v1}, Lcom/tencent/mm/modelvoice/bk;->a(Lcom/tencent/mm/modelvoice/bk;I)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 82
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    const/4 v0, 0x0

    #v0=(Null);
    return v0

    .line 79
    :catch_0
    #v0=(Reference);v2=(Uninit);v3=(Uninit);
    move-exception v0

    .line 80
    const-string v1, "VoicePlayer"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "setErrorListener File["

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bm;->bZB:Lcom/tencent/mm/modelvoice/bk;

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/bk;->c(Lcom/tencent/mm/modelvoice/bk;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "] ErrMsg["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "]"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

*/}
