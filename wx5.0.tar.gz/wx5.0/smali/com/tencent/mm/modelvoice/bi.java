package com.tencent.mm.modelvoice; class bi {/*

.class public final Lcom/tencent/mm/modelvoice/bi;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/o/j;


# static fields
.field private static bZy:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 23
    new-instance v0, Ljava/util/HashSet;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/modelvoice/bi;->bZy:Ljava/util/Set;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method public static b(Lcom/tencent/mm/modelvoice/c;)V
    .locals 1
    .parameter

    .prologue
    .line 32
    sget-object v0, Lcom/tencent/mm/modelvoice/bi;->bZy:Ljava/util/Set;

    #v0=(Reference);
    invoke-interface {v0, p0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 33
    return-void
.end method

.method public static c(Lcom/tencent/mm/modelvoice/c;)V
    .locals 1
    .parameter

    .prologue
    .line 26
    sget-object v0, Lcom/tencent/mm/modelvoice/bi;->bZy:Ljava/util/Set;

    #v0=(Reference);
    invoke-interface {v0, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 27
    sget-object v0, Lcom/tencent/mm/modelvoice/bi;->bZy:Ljava/util/Set;

    #v0=(Reference);
    invoke-interface {v0, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 29
    :cond_0
    #v0=(Conflicted);
    return-void
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/protocal/a/j;)Lcom/tencent/mm/o/k;
    .locals 11
    .parameter

    .prologue
    const-wide/16 v9, 0x0

    #v9=(LongLo);v10=(LongHi);
    const/4 v4, 0x0

    #v4=(Null);
    const/4 v3, 0x1

    #v3=(One);
    const/4 v2, 0x0

    .line 37
    #v2=(Null);
    if-nez p1, :cond_1

    .line 38
    const-string v0, "MicroMsg.VoiceMessageExtension"

    #v0=(Reference);
    const-string v1, "onPreAddMessage cmdAM is null , give up."

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    :cond_0
    :goto_0
    #v1=(Conflicted);v2=(Reference);v3=(Integer);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-object v2

    .line 42
    :cond_1
    #v0=(Uninit);v1=(Uninit);v2=(Null);v3=(One);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    const-string v0, "MicroMsg.VoiceMessageExtension"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v5, "parseVoiceMsg srvId:"

    #v5=(Reference);
    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget v5, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v5=(Integer);
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 44
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDy:Lcom/tencent/mm/protocal/a/pt;

    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v1

    .line 47
    invoke-static {}, Lcom/tencent/mm/model/s;->ow()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_a

    .line 48
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDz:Lcom/tencent/mm/protocal/a/pt;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    .line 52
    :goto_1
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v5

    #v5=(Reference);
    invoke-virtual {v5}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v5

    iget v6, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v6=(Integer);
    invoke-virtual {v5, v0, v6}, Lcom/tencent/mm/storage/ar;->ad(Ljava/lang/String;I)Lcom/tencent/mm/storage/am;

    move-result-object v5

    .line 53
    if-eqz v5, :cond_2

    invoke-virtual {v5}, Lcom/tencent/mm/storage/am;->wm()J

    move-result-wide v6

    #v6=(LongLo);v7=(LongHi);
    cmp-long v6, v6, v9

    #v6=(Byte);
    if-eqz v6, :cond_2

    invoke-virtual {v5}, Lcom/tencent/mm/storage/am;->yI()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    const-wide/32 v7, 0x240c8400

    #v7=(LongLo);v8=(LongHi);
    add-long/2addr v5, v7

    iget v7, p1, Lcom/tencent/mm/protocal/a/j;->eDF:I

    #v7=(Integer);
    int-to-long v7, v7

    #v7=(LongLo);
    invoke-static {v0, v7, v8}, Lcom/tencent/mm/model/bm;->b(Ljava/lang/String;J)J

    move-result-wide v7

    cmp-long v5, v5, v7

    #v5=(Byte);
    if-gez v5, :cond_2

    .line 58
    const-string v5, "MicroMsg.VoiceMessageExtension"

    #v5=(Reference);
    const-string v6, "dkmsgid prepareMsgInfo msg Too Old Remove it. svrid:%d"

    #v6=(Reference);
    new-array v7, v3, [Ljava/lang/Object;

    #v7=(Reference);
    iget v8, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v8=(Integer);
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    #v8=(Reference);
    aput-object v8, v7, v4

    invoke-static {v5, v6, v7}, Lcom/tencent/mm/sdk/platformtools/y;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 59
    iget v5, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v5=(Integer);
    int-to-long v5, v5

    #v5=(LongLo);v6=(LongHi);
    invoke-static {v5, v6}, Lcom/tencent/mm/model/bm;->q(J)I

    .line 60
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v5

    #v5=(Reference);
    iget v6, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Lcom/tencent/mm/modelvoice/bq;->dG(I)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v5

    .line 61
    if-eqz v5, :cond_2

    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    invoke-static {v6}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v6

    #v6=(Boolean);
    if-nez v6, :cond_2

    .line 62
    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/tencent/mm/modelvoice/bh;->he(Ljava/lang/String;)Z

    .line 69
    :cond_2
    #v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    new-instance v5, Lcom/tencent/mm/modelvoice/bg;

    #v5=(UninitRef);
    invoke-direct {v5}, Lcom/tencent/mm/modelvoice/bg;-><init>()V

    .line 70
    #v5=(Reference);
    invoke-virtual {v5, v0}, Lcom/tencent/mm/modelvoice/bg;->setUser(Ljava/lang/String;)V

    .line 71
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDF:I

    #v0=(Integer);
    int-to-long v6, v0

    #v6=(LongLo);v7=(LongHi);
    invoke-virtual {v5, v6, v7}, Lcom/tencent/mm/modelvoice/bg;->F(J)V

    .line 72
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    invoke-virtual {v5, v0}, Lcom/tencent/mm/modelvoice/bg;->cC(I)V

    .line 74
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDB:Lcom/tencent/mm/protocal/a/pt;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    .line 75
    invoke-static {v1}, Lcom/tencent/mm/model/t;->ce(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_3

    .line 76
    invoke-static {v0}, Lcom/tencent/mm/model/bm;->dn(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 77
    const-string v1, "MicroMsg.VoiceMessageExtension"

    #v1=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "chatroom voicemsg, new content="

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 80
    :cond_3
    #v1=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    const-string v1, "msg"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/s;->aF(Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v1

    .line 81
    if-eqz v1, :cond_0

    .line 85
    :try_start_0
    const-string v0, ".msg.voicemsg.$length"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v5, v0}, Lcom/tencent/mm/modelvoice/bg;->dx(I)V

    .line 89
    const-string v0, ".msg.voicemsg.$clientmsgid"

    #v0=(Reference);
    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v5, v0}, Lcom/tencent/mm/modelvoice/bg;->gV(Ljava/lang/String;)V

    .line 90
    const-string v0, ".msg.voicemsg.$endflag"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v6

    .line 91
    #v6=(Integer);
    const-string v0, ".msg.voicemsg.$cancelflag"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v7

    .line 92
    #v7=(Integer);
    const-string v0, ".msg.voicemsg.$voicelength"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v5, v0}, Lcom/tencent/mm/modelvoice/bg;->dF(I)V

    .line 93
    const-string v0, ".msg.voicemsg.$fromusername"

    #v0=(Reference);
    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v5, v0}, Lcom/tencent/mm/modelvoice/bg;->gA(Ljava/lang/String;)V

    .line 95
    const-string v0, ".msg.commenturl"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 96
    const-string v8, ".msg.voicemsg.$forwardflag"

    #v8=(Reference);
    invoke-interface {v1, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v8, "0"

    invoke-static {v1, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->N(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v5, v1}, Lcom/tencent/mm/modelvoice/bg;->dE(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 104
    if-ne v7, v3, :cond_4

    .line 105
    const-string v0, "MicroMsg.VoiceMessageExtension"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v3, "cancelFlag = 1 srvId:"

    #v3=(Reference);
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget v3, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 106
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/modelvoice/bq;->dG(I)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v0

    .line 107
    if-eqz v0, :cond_0

    .line 108
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->hc(Ljava/lang/String;)Z

    goto/16 :goto_0

    .line 99
    :catch_0
    #v0=(Conflicted);v1=(Conflicted);v3=(One);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    move-exception v0

    #v0=(Reference);
    const-string v0, "MicroMsg.VoiceMessageExtension"

    const-string v1, "parsing voice msg xml failed"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 113
    :cond_4
    #v1=(Integer);v6=(Integer);v7=(Integer);v8=(Reference);
    if-ne v6, v3, :cond_5

    .line 114
    const-string v1, "MicroMsg.VoiceMessageExtension"

    #v1=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "endFlag = 1 srvId:"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    iget v7, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 115
    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v5, v1}, Lcom/tencent/mm/modelvoice/bg;->bM(I)V

    .line 117
    :cond_5
    #v6=(Conflicted);
    const/16 v1, 0x16ae

    #v1=(PosShort);
    invoke-virtual {v5, v1}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 121
    iget-object v1, p1, Lcom/tencent/mm/protocal/a/j;->eDE:Lcom/tencent/mm/protocal/a/ps;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/ps;)[B

    move-result-object v1

    .line 123
    if-eqz v1, :cond_6

    .line 124
    const-string v6, "MicroMsg.VoiceMessageExtension"

    #v6=(Reference);
    new-instance v7, Ljava/lang/StringBuilder;

    #v7=(UninitRef);
    const-string v8, "Voice Buf Len:"

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v7=(Reference);
    array-length v8, v1

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " srvId:"

    #v8=(Reference);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget v8, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 127
    :cond_6
    #v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    iget v6, p1, Lcom/tencent/mm/protocal/a/j;->eDC:I

    #v6=(Integer);
    invoke-static {v5, v1, v6, v0}, Lcom/tencent/mm/modelvoice/bh;->a(Lcom/tencent/mm/modelvoice/bg;[BILjava/lang/String;)I

    move-result v0

    .line 129
    #v0=(Integer);
    if-lez v0, :cond_9

    .line 130
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v0

    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/ar;->ad(Ljava/lang/String;I)Lcom/tencent/mm/storage/am;

    move-result-object v1

    .line 131
    invoke-virtual {v1, v4}, Lcom/tencent/mm/storage/am;->kg(I)V

    .line 132
    sget-object v0, Lcom/tencent/mm/modelvoice/bi;->bZy:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    #v2=(Reference);v6=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mm/modelvoice/c;

    .line 133
    new-instance v6, Lcom/tencent/mm/modelvoice/bj;

    #v6=(UninitRef);
    invoke-direct {v6, p0, v0, v5}, Lcom/tencent/mm/modelvoice/bj;-><init>(Lcom/tencent/mm/modelvoice/bi;Lcom/tencent/mm/modelvoice/c;Lcom/tencent/mm/modelvoice/bg;)V

    #v6=(Reference);
    invoke-static {v6}, Lcom/tencent/mm/sdk/platformtools/al;->h(Ljava/lang/Runnable;)V

    goto :goto_2

    :cond_7
    #v0=(Boolean);v6=(Conflicted);
    move-object v0, v1

    .line 143
    :goto_3
    #v0=(Reference);
    new-instance v2, Lcom/tencent/mm/o/k;

    #v2=(UninitRef);
    if-eqz v0, :cond_8

    invoke-virtual {v0}, Lcom/tencent/mm/storage/am;->wm()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    cmp-long v1, v5, v9

    #v1=(Byte);
    if-lez v1, :cond_8

    move v1, v3

    :goto_4
    #v1=(Boolean);v5=(Conflicted);v6=(Conflicted);
    invoke-direct {v2, v0, v1}, Lcom/tencent/mm/o/k;-><init>(Lcom/tencent/mm/storage/am;Z)V

    #v2=(Reference);
    goto/16 :goto_0

    :cond_8
    #v1=(Conflicted);v2=(UninitRef);
    move v1, v4

    #v1=(Null);
    goto :goto_4

    :cond_9
    #v0=(Integer);v1=(Reference);v2=(Null);v5=(Reference);v6=(Integer);
    move-object v0, v2

    #v0=(Null);
    goto :goto_3

    :cond_a
    #v0=(Boolean);v5=(Integer);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    move-object v0, v1

    #v0=(Reference);
    goto/16 :goto_1
.end method

.method public final c(Lcom/tencent/mm/storage/am;)V
    .locals 3
    .parameter

    .prologue
    .line 148
    const-string v0, "MicroMsg.VoiceMessageExtension"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "onPreDelMessage "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {p1}, Lcom/tencent/mm/storage/am;->jT()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/tencent/mm/storage/am;->arU()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 149
    invoke-virtual {p1}, Lcom/tencent/mm/storage/am;->arU()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/model/t;->cE(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 153
    invoke-virtual {p1}, Lcom/tencent/mm/storage/am;->jT()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->he(Ljava/lang/String;)Z

    .line 155
    :cond_0
    #v0=(Conflicted);
    return-void
.end method

*/}
