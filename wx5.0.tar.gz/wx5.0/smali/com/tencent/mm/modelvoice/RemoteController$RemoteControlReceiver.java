package com.tencent.mm.modelvoice; class RemoteController$RemoteControlReceiver {/*

.class public Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# static fields
.field private static bYp:Lcom/tencent/mm/sdk/platformtools/ax;

.field private static bYq:Lcom/tencent/mm/modelvoice/v;


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 34
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method public static zg()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 74
    #v1=(Null);
    sput-object v1, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYq:Lcom/tencent/mm/modelvoice/v;

    .line 75
    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 76
    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    invoke-virtual {v0}, Lcom/tencent/mm/sdk/platformtools/ax;->apg()V

    .line 77
    sput-object v1, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    .line 79
    :cond_0
    return-void
.end method

.method static synthetic zh()Lcom/tencent/mm/modelvoice/v;
    .locals 1

    .prologue
    .line 34
    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYq:Lcom/tencent/mm/modelvoice/v;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic zi()Lcom/tencent/mm/sdk/platformtools/ax;
    .locals 1

    .prologue
    .line 34
    const/4 v0, 0x0

    #v0=(Null);
    sput-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    return-object v0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3
    .parameter
    .parameter

    .prologue
    .line 44
    const-string v0, "android.intent.action.MEDIA_BUTTON"

    #v0=(Reference);
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 45
    const-string v0, "MicroMsg.RemoteControlReceiver"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "unknown action, ignore"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 71
    :cond_0
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    .line 49
    :cond_1
    #v0=(Boolean);v1=(Reference);v2=(Uninit);
    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    #v0=(Reference);
    if-nez v0, :cond_2

    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYq:Lcom/tencent/mm/modelvoice/v;

    if-eqz v0, :cond_2

    .line 50
    const-string v0, "MicroMsg.RemoteControlReceiver"

    const-string v1, "got remote key event down"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYq:Lcom/tencent/mm/modelvoice/v;

    .line 53
    new-instance v0, Lcom/tencent/mm/sdk/platformtools/ax;

    #v0=(UninitRef);
    new-instance v1, Lcom/tencent/mm/modelvoice/w;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mm/modelvoice/w;-><init>(Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;)V

    #v1=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    invoke-direct {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/ax;-><init>(Lcom/tencent/mm/sdk/platformtools/ay;Z)V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    .line 68
    :cond_2
    #v2=(Conflicted);
    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    if-eqz v0, :cond_0

    .line 69
    sget-object v0, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->bYp:Lcom/tencent/mm/sdk/platformtools/ax;

    const-wide/16 v1, 0x3e8

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/ax;->bL(J)V

    goto :goto_0
.end method

*/}
