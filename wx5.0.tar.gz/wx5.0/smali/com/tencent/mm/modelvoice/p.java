package com.tencent.mm.modelvoice; class p {/*

.class public final Lcom/tencent/mm/modelvoice/p;
.super Lcom/tencent/mm/o/x;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/network/aa;


# static fields
.field private static bYb:Lcom/tencent/mm/model/au;

.field private static bYc:Ljava/util/List;


# instance fields
.field private ah:Ljava/lang/String;

.field private bFU:Lcom/tencent/mm/o/m;

.field private bGI:Lcom/tencent/mm/o/a;

.field private bGV:Lcom/tencent/mm/sdk/platformtools/ax;

.field private bWS:I

.field private bYd:Z

.field private bYe:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 32
    const/4 v0, 0x0

    #v0=(Null);
    sput-object v0, Lcom/tencent/mm/modelvoice/p;->bYb:Lcom/tencent/mm/model/au;

    .line 33
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/modelvoice/p;->bYc:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 87
    #v0=(Null);
    invoke-direct {p0}, Lcom/tencent/mm/o/x;-><init>()V

    .line 37
    #p0=(Reference);
    iput v0, p0, Lcom/tencent/mm/modelvoice/p;->bWS:I

    .line 93
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/p;->bYd:Z

    .line 94
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/p;->bYe:Z

    .line 256
    new-instance v1, Lcom/tencent/mm/sdk/platformtools/ax;

    #v1=(UninitRef);
    new-instance v2, Lcom/tencent/mm/modelvoice/r;

    #v2=(UninitRef);
    invoke-direct {v2, p0}, Lcom/tencent/mm/modelvoice/r;-><init>(Lcom/tencent/mm/modelvoice/p;)V

    #v2=(Reference);
    invoke-direct {v1, v2, v0}, Lcom/tencent/mm/sdk/platformtools/ax;-><init>(Lcom/tencent/mm/sdk/platformtools/ay;Z)V

    #v1=(Reference);
    iput-object v1, p0, Lcom/tencent/mm/modelvoice/p;->bGV:Lcom/tencent/mm/sdk/platformtools/ax;

    .line 88
    if-eqz p1, :cond_0

    const/4 v0, 0x1

    :cond_0
    #v0=(Boolean);
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 89
    const-string v0, "MicroMsg.NetSceneDownloadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "NetSceneDownloadVoice:  file:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    .line 91
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/p;)Lcom/tencent/mm/network/q;
    .locals 1
    .parameter

    .prologue
    .line 25
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/p;->rQ()Lcom/tencent/mm/network/q;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method

.method public static a(Lcom/tencent/mm/model/au;)V
    .locals 1
    .parameter

    .prologue
    .line 48
    sget-object v0, Lcom/tencent/mm/modelvoice/p;->bYb:Lcom/tencent/mm/model/au;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 49
    sput-object p0, Lcom/tencent/mm/modelvoice/p;->bYb:Lcom/tencent/mm/model/au;

    .line 51
    :cond_0
    return-void
.end method

.method public static a(Lcom/tencent/mm/modelvoice/c;)V
    .locals 1
    .parameter

    .prologue
    .line 58
    sget-object v0, Lcom/tencent/mm/modelvoice/p;->bYc:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 59
    sget-object v0, Lcom/tencent/mm/modelvoice/p;->bYc:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 61
    :cond_0
    #v0=(Conflicted);
    return-void
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/p;)Lcom/tencent/mm/o/m;
    .locals 1
    .parameter

    .prologue
    .line 25
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    #v0=(Reference);
    return-object v0
.end method

.method public static b(Lcom/tencent/mm/modelvoice/c;)V
    .locals 1
    .parameter

    .prologue
    .line 64
    sget-object v0, Lcom/tencent/mm/modelvoice/p;->bYc:Ljava/util/List;

    #v0=(Reference);
    invoke-interface {v0, p0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 65
    return-void
.end method

.method private zf()V
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 68
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    #v1=(Reference);
    if-nez v1, :cond_1

    move-object v1, v0

    .line 69
    :goto_0
    #v0=(Reference);v2=(Conflicted);
    if-eqz v1, :cond_3

    .line 70
    sget-object v0, Lcom/tencent/mm/modelvoice/p;->bYb:Lcom/tencent/mm/model/au;

    if-eqz v0, :cond_0

    .line 71
    sget-object v0, Lcom/tencent/mm/modelvoice/p;->bYb:Lcom/tencent/mm/model/au;

    invoke-interface {v0, v1}, Lcom/tencent/mm/model/au;->b(Lcom/tencent/mm/storage/am;)V

    .line 74
    :cond_0
    sget-object v0, Lcom/tencent/mm/modelvoice/p;->bYc:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    #v2=(Reference);v3=(Conflicted);
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mm/modelvoice/c;

    .line 75
    new-instance v3, Lcom/tencent/mm/modelvoice/q;

    #v3=(UninitRef);
    invoke-direct {v3, p0, v0, v1}, Lcom/tencent/mm/modelvoice/q;-><init>(Lcom/tencent/mm/modelvoice/p;Lcom/tencent/mm/modelvoice/c;Lcom/tencent/mm/storage/am;)V

    #v3=(Reference);
    invoke-static {v3}, Lcom/tencent/mm/sdk/platformtools/al;->h(Ljava/lang/Runnable;)V

    goto :goto_1

    .line 68
    :cond_1
    #v0=(Null);v2=(Uninit);v3=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2, v1}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    if-nez v1, :cond_2

    move-object v1, v0

    #v1=(Null);
    goto :goto_0

    :cond_2
    #v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v0

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v1

    #v1=(Integer);
    int-to-long v1, v1

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/ar;->bR(J)Lcom/tencent/mm/storage/am;

    move-result-object v0

    move-object v1, v0

    #v1=(Reference);
    goto :goto_0

    .line 85
    :cond_3
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/network/q;Lcom/tencent/mm/o/m;)I
    .locals 6
    .parameter
    .parameter

    .prologue
    const/4 v5, 0x1

    #v5=(One);
    const/4 v0, -0x1

    .line 104
    #v0=(Byte);
    iput-object p2, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    .line 106
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    #v1=(Reference);
    if-nez v1, :cond_0

    .line 107
    const-string v1, "MicroMsg.NetSceneDownloadVoice"

    const-string v2, "doScene:  filename null!"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 108
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v1

    #v1=(Integer);
    add-int/lit16 v1, v1, 0x2710

    iput v1, p0, Lcom/tencent/mm/modelvoice/p;->bWS:I

    .line 158
    :goto_0
    #v0=(Integer);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 111
    :cond_0
    #v0=(Byte);v1=(Reference);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2, v1}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    .line 112
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->zt()Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_2

    .line 113
    :cond_1
    #v2=(Conflicted);
    const-string v1, "MicroMsg.NetSceneDownloadVoice"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Get info Failed file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v1

    #v1=(Integer);
    add-int/lit16 v1, v1, 0x2710

    iput v1, p0, Lcom/tencent/mm/modelvoice/p;->bWS:I

    goto :goto_0

    .line 117
    :cond_2
    #v1=(Reference);v2=(Boolean);v3=(Uninit);
    const-string v2, "MicroMsg.NetSceneDownloadVoice"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "doScene file:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " netTimes:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yM()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 118
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/bh;->gW(Ljava/lang/String;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_3

    .line 119
    const-string v1, "MicroMsg.NetSceneDownloadVoice"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "checkVoiceNetTimes Failed file:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 120
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 121
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v1

    #v1=(Integer);
    add-int/lit16 v1, v1, 0x2710

    iput v1, p0, Lcom/tencent/mm/modelvoice/p;->bWS:I

    goto/16 :goto_0

    .line 125
    :cond_3
    #v1=(Reference);v2=(Boolean);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v3

    #v3=(Integer);
    sub-int/2addr v2, v3

    .line 126
    if-gtz v2, :cond_5

    .line 127
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    const/4 v3, 0x5

    #v3=(PosByte);
    if-ne v2, v3, :cond_4

    .line 128
    iput-boolean v5, p0, Lcom/tencent/mm/modelvoice/p;->bYe:Z

    .line 129
    const-string v2, "MicroMsg.NetSceneDownloadVoice"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "doScene file:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " Net:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " Local:"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 130
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v1

    #v1=(Integer);
    add-int/lit16 v1, v1, 0x2710

    iput v1, p0, Lcom/tencent/mm/modelvoice/p;->bWS:I

    goto/16 :goto_0

    .line 133
    :cond_4
    #v1=(Reference);v2=(Integer);v3=(PosByte);v4=(Integer);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v1

    #v1=(Integer);
    invoke-static {v2, v1}, Lcom/tencent/mm/modelvoice/bh;->x(Ljava/lang/String;I)I

    .line 134
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v1

    add-int/lit16 v1, v1, 0x2710

    iput v1, p0, Lcom/tencent/mm/modelvoice/p;->bWS:I

    goto/16 :goto_0

    .line 139
    :cond_5
    #v1=(Reference);v2=(Integer);v3=(Integer);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v3

    if-ne v0, v3, :cond_6

    .line 140
    iput-boolean v5, p0, Lcom/tencent/mm/modelvoice/p;->bYd:Z

    .line 143
    :cond_6
    new-instance v0, Lcom/tencent/mm/o/b;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/o/b;-><init>()V

    .line 144
    #v0=(Reference);
    new-instance v3, Lcom/tencent/mm/protocal/a/dt;

    #v3=(UninitRef);
    invoke-direct {v3}, Lcom/tencent/mm/protocal/a/dt;-><init>()V

    #v3=(Reference);
    invoke-virtual {v0, v3}, Lcom/tencent/mm/o/b;->a(Lcom/tencent/mm/al/a;)V

    .line 145
    new-instance v3, Lcom/tencent/mm/protocal/a/du;

    #v3=(UninitRef);
    invoke-direct {v3}, Lcom/tencent/mm/protocal/a/du;-><init>()V

    #v3=(Reference);
    invoke-virtual {v0, v3}, Lcom/tencent/mm/o/b;->b(Lcom/tencent/mm/al/a;)V

    .line 146
    const-string v3, "/cgi-bin/micromsg-bin/downloadvoice"

    invoke-virtual {v0, v3}, Lcom/tencent/mm/o/b;->ee(Ljava/lang/String;)V

    .line 147
    const/16 v3, 0x80

    #v3=(PosShort);
    invoke-virtual {v0, v3}, Lcom/tencent/mm/o/b;->bQ(I)V

    .line 148
    const/16 v3, 0x14

    #v3=(PosByte);
    invoke-virtual {v0, v3}, Lcom/tencent/mm/o/b;->bR(I)V

    .line 149
    const v3, 0x3b9aca14

    #v3=(Integer);
    invoke-virtual {v0, v3}, Lcom/tencent/mm/o/b;->bS(I)V

    .line 150
    invoke-virtual {v0}, Lcom/tencent/mm/o/b;->rA()Lcom/tencent/mm/o/a;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bGI:Lcom/tencent/mm/o/a;

    .line 152
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bGI:Lcom/tencent/mm/o/a;

    invoke-virtual {v0}, Lcom/tencent/mm/o/a;->ru()Lcom/tencent/mm/al/a;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/protocal/a/dt;

    .line 153
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->zx()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    iput-object v3, v0, Lcom/tencent/mm/protocal/a/dt;->eDZ:Ljava/lang/String;

    .line 154
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v3

    #v3=(Integer);
    iput v3, v0, Lcom/tencent/mm/protocal/a/dt;->eDx:I

    .line 155
    iput v2, v0, Lcom/tencent/mm/protocal/a/dt;->eEP:I

    .line 156
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v1

    #v1=(Integer);
    iput v1, v0, Lcom/tencent/mm/protocal/a/dt;->eEL:I

    .line 158
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bGI:Lcom/tencent/mm/o/a;

    invoke-virtual {p0, p1, v0, p0}, Lcom/tencent/mm/modelvoice/p;->a(Lcom/tencent/mm/network/q;Lcom/tencent/mm/network/ai;Lcom/tencent/mm/network/aa;)I

    move-result v0

    #v0=(Integer);
    goto/16 :goto_0
.end method

.method protected final a(Lcom/tencent/mm/network/ai;)Lcom/tencent/mm/o/aa;
    .locals 2
    .parameter

    .prologue
    .line 163
    check-cast p1, Lcom/tencent/mm/o/a;

    invoke-virtual {p1}, Lcom/tencent/mm/o/a;->ru()Lcom/tencent/mm/al/a;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mm/protocal/a/dt;

    .line 165
    iget v1, v0, Lcom/tencent/mm/protocal/a/dt;->eDx:I

    #v1=(Integer);
    if-eqz v1, :cond_0

    iget-object v1, v0, Lcom/tencent/mm/protocal/a/dt;->eDZ:Ljava/lang/String;

    #v1=(Reference);
    if-eqz v1, :cond_0

    iget-object v1, v0, Lcom/tencent/mm/protocal/a/dt;->eDZ:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-eqz v1, :cond_0

    iget v1, v0, Lcom/tencent/mm/protocal/a/dt;->eEP:I

    if-lez v1, :cond_0

    iget v0, v0, Lcom/tencent/mm/protocal/a/dt;->eEL:I

    #v0=(Integer);
    if-gez v0, :cond_1

    .line 166
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 167
    sget-object v0, Lcom/tencent/mm/o/aa;->bIJ:Lcom/tencent/mm/o/aa;

    .line 169
    :goto_0
    return-object v0

    :cond_1
    #v0=(Integer);v1=(Integer);
    sget-object v0, Lcom/tencent/mm/o/aa;->bII:Lcom/tencent/mm/o/aa;

    #v0=(Reference);
    goto :goto_0
.end method

.method public final a(IIILjava/lang/String;Lcom/tencent/mm/network/ai;[B)V
    .locals 5
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v4, 0x1

    .line 184
    #v4=(One);
    const-string v0, "MicroMsg.NetSceneDownloadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "onGYNetEnd file:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " + id:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " errtype:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " errCode:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, p5

    .line 186
    check-cast v0, Lcom/tencent/mm/o/a;

    invoke-virtual {v0}, Lcom/tencent/mm/o/a;->rv()Lcom/tencent/mm/al/a;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/protocal/a/du;

    .line 188
    iget v1, v0, Lcom/tencent/mm/protocal/a/du;->eEN:I

    #v1=(Integer);
    if-ne v1, v4, :cond_0

    .line 190
    const-string v0, "MicroMsg.NetSceneDownloadVoice"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " cancelFlag = 1"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 191
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->hc(Ljava/lang/String;)Z

    .line 254
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 194
    :cond_0
    #v0=(Reference);v1=(Integer);v2=(Reference);v3=(Uninit);
    const/16 v1, -0x16

    #v1=(Byte);
    if-ne p3, v1, :cond_1

    .line 195
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 196
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto :goto_0

    .line 199
    :cond_1
    const/4 v1, 0x4

    #v1=(PosByte);
    if-ne p2, v1, :cond_2

    if-eqz p3, :cond_2

    const/16 v1, -0xd

    #v1=(Byte);
    if-eq p3, v1, :cond_2

    const/4 v1, -0x6

    if-eq p3, v1, :cond_2

    .line 200
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 201
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto :goto_0

    .line 204
    :cond_2
    if-nez p2, :cond_3

    if-eqz p3, :cond_4

    .line 205
    :cond_3
    const-string v0, "MicroMsg.NetSceneDownloadVoice"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "onGYNetEnd  errType:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " errCode:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " resp:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-interface {p5}, Lcom/tencent/mm/network/ai;->ry()Lcom/tencent/mm/protocal/q;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/mm/protocal/q;->sp()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 206
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto :goto_0

    .line 210
    :cond_4
    #v1=(Byte);v2=(Reference);
    const-string v1, "MicroMsg.NetSceneDownloadVoice"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "onGYNetEnd file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " Recv:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v0, Lcom/tencent/mm/protocal/a/du;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    invoke-virtual {v3}, Lcom/tencent/mm/protocal/a/ps;->anY()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " fileOff:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcom/tencent/mm/protocal/a/du;->eEL:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 211
    iget-object v1, v0, Lcom/tencent/mm/protocal/a/du;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    invoke-virtual {v1}, Lcom/tencent/mm/protocal/a/ps;->anZ()Lcom/tencent/mm/al/b;

    move-result-object v1

    if-nez v1, :cond_5

    .line 214
    const-string v0, "MicroMsg.NetSceneDownloadVoice"

    const-string v1, "onGYNetEnd get recv Buffer null"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 215
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 216
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 220
    :cond_5
    iget-object v1, v0, Lcom/tencent/mm/protocal/a/du;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    invoke-virtual {v1}, Lcom/tencent/mm/protocal/a/ps;->anZ()Lcom/tencent/mm/al/b;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tencent/mm/al/b;->toByteArray()[B

    move-result-object v1

    .line 222
    if-eqz v1, :cond_6

    array-length v2, v1

    #v2=(Integer);
    if-nez v2, :cond_7

    .line 223
    :cond_6
    #v2=(Conflicted);
    const-string v0, "MicroMsg.NetSceneDownloadVoice"

    const-string v1, "onGYNetEnd Recv Buf ZERO length "

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 224
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 225
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 229
    :cond_7
    #v2=(Integer);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/modelvoice/bh;->gX(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/b;

    move-result-object v2

    array-length v3, v1

    iget v0, v0, Lcom/tencent/mm/protocal/a/du;->eEL:I

    #v0=(Integer);
    invoke-interface {v2, v1, v3, v0}, Lcom/tencent/mm/modelvoice/b;->write([BII)I

    move-result v0

    .line 230
    if-gez v0, :cond_8

    .line 231
    const-string v1, "MicroMsg.NetSceneDownloadVoice"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "onGYNetEnd Write Failed File:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " ret:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 232
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 233
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 236
    :cond_8
    #v0=(Integer);v3=(Integer);
    const-string v1, "MicroMsg.NetSceneDownloadVoice"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "OnRecvEnd : file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " filesize:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 237
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-static {v1, v0}, Lcom/tencent/mm/modelvoice/bh;->x(Ljava/lang/String;I)I

    move-result v0

    .line 239
    if-gez v0, :cond_9

    .line 240
    const-string v1, "MicroMsg.NetSceneDownloadVoice"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "onGYNetEnd file:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "updateAfterRecv Ret:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 241
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 244
    :cond_9
    #v0=(Integer);
    if-ne v0, v4, :cond_a

    .line 245
    invoke-direct {p0}, Lcom/tencent/mm/modelvoice/p;->zf()V

    .line 246
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->bFU:Lcom/tencent/mm/o/m;

    #v0=(Reference);
    invoke-interface {v0, p2, p3, p4, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 249
    :cond_a
    #v0=(Integer);
    const-wide/16 v0, 0x3e8

    .line 250
    #v0=(LongLo);v1=(LongHi);
    iget-boolean v2, p0, Lcom/tencent/mm/modelvoice/p;->bYd:Z

    #v2=(Boolean);
    if-eqz v2, :cond_b

    .line 251
    const-wide/16 v0, 0x0

    .line 253
    :cond_b
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/p;->bGV:Lcom/tencent/mm/sdk/platformtools/ax;

    #v2=(Reference);
    invoke-virtual {v2, v0, v1}, Lcom/tencent/mm/sdk/platformtools/ax;->bL(J)V

    goto/16 :goto_0
.end method

.method protected final a(Lcom/tencent/mm/o/z;)V
    .locals 1
    .parameter

    .prologue
    .line 179
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 180
    return-void
.end method

.method public final getFileName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 44
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/p;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getType()I
    .locals 1

    .prologue
    .line 268
    const/16 v0, 0x80

    #v0=(PosShort);
    return v0
.end method

.method protected final rh()I
    .locals 1

    .prologue
    .line 174
    const/16 v0, 0x64

    #v0=(PosByte);
    return v0
.end method

.method public final yz()I
    .locals 1

    .prologue
    .line 40
    iget v0, p0, Lcom/tencent/mm/modelvoice/p;->bWS:I

    #v0=(Integer);
    return v0
.end method

*/}
