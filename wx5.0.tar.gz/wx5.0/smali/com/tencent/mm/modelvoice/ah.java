package com.tencent.mm.modelvoice; class ah {/*

.class final Lcom/tencent/mm/modelvoice/ah;
.super Landroid/os/Handler;
.source "SourceFile"


# instance fields
.field final synthetic bYP:Lcom/tencent/mm/modelvoice/af;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/af;)V
    .locals 0
    .parameter

    .prologue
    .line 229
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ah;->bYP:Lcom/tencent/mm/modelvoice/af;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 2
    .parameter

    .prologue
    .line 232
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    const-string v1, "dkbt Recorder handleMessage"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 233
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ah;->bYP:Lcom/tencent/mm/modelvoice/af;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/af;->i(Lcom/tencent/mm/modelvoice/af;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 239
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 236
    :cond_0
    #v0=(Boolean);v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ah;->bYP:Lcom/tencent/mm/modelvoice/af;

    invoke-virtual {v0, v1}, Lcom/tencent/mm/compatible/audio/d;->b(Lcom/tencent/mm/compatible/audio/i;)V

    .line 237
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->kC()V

    .line 238
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ah;->bYP:Lcom/tencent/mm/modelvoice/af;

    const/16 v1, 0xc8

    #v1=(PosShort);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/modelvoice/af;->aH(I)V

    goto :goto_0
.end method

*/}
