package com.tencent.mm.modelvoice; class bp {/*

.class public interface abstract Lcom/tencent/mm/modelvoice/bp;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract kX()V
.end method

*/}
