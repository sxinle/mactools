package com.tencent.mm.modelvoice; class ba {/*

.class final Lcom/tencent/mm/modelvoice/ba;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic bZt:Lcom/tencent/mm/modelvoice/az;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/az;)V
    .locals 0
    .parameter

    .prologue
    .line 58
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    .prologue
    const/4 v6, 0x0

    #v6=(Null);
    const/4 v9, 0x1

    .line 63
    #v9=(One);
    const/16 v0, -0x13

    #v0=(Byte);
    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    .line 72
    const/16 v0, 0x3e80

    #v0=(PosShort);
    const/4 v1, 0x1

    #v1=(One);
    const/4 v2, 0x2

    :try_start_0
    #v2=(PosByte);
    invoke-static {v0, v1, v2}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result v7

    .line 74
    #v7=(Integer);
    if-ltz v7, :cond_0

    .line 77
    sget-object v0, Lcom/tencent/mm/compatible/c/s;->bBG:Lcom/tencent/mm/compatible/c/m;

    #v0=(Reference);
    iget v0, v0, Lcom/tencent/mm/compatible/c/m;->bAV:I

    #v0=(Integer);
    if-lez v0, :cond_1

    .line 79
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/c/s;->bBG:Lcom/tencent/mm/compatible/c/m;

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/mm/compatible/c/m;->bAV:I

    #v1=(Integer);
    invoke-static {v0, v1}, Lcom/tencent/mm/modelvoice/az;->a(Lcom/tencent/mm/modelvoice/az;I)I

    .line 83
    :goto_0
    const-string v0, "MicroMsg.SpeexRecorder"

    const-string v1, "new AudioRecord [%d]"

    #v1=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    new-array v2, v2, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    sget v4, Lcom/tencent/mm/compatible/audio/n;->count:I

    #v4=(Integer);
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    #v4=(Reference);
    aput-object v4, v2, v3

    invoke-static {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 84
    iget-object v8, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v8=(Reference);
    new-instance v0, Landroid/media/AudioRecord;

    #v0=(UninitRef);
    const/4 v1, 0x1

    #v1=(One);
    const/16 v2, 0x3e80

    #v2=(PosShort);
    const/4 v3, 0x1

    #v3=(One);
    const/4 v4, 0x2

    #v4=(PosByte);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v5=(Reference);
    invoke-static {v5}, Lcom/tencent/mm/modelvoice/az;->a(Lcom/tencent/mm/modelvoice/az;)I

    move-result v5

    #v5=(Integer);
    mul-int/2addr v5, v7

    invoke-direct/range {v0 .. v5}, Landroid/media/AudioRecord;-><init>(IIIII)V

    #v0=(Reference);
    invoke-static {v8, v0}, Lcom/tencent/mm/modelvoice/az;->a(Lcom/tencent/mm/modelvoice/az;Landroid/media/AudioRecord;)Landroid/media/AudioRecord;

    .line 89
    :cond_0
    #v0=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v8=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->b(Lcom/tencent/mm/modelvoice/az;)Landroid/media/AudioRecord;

    move-result-object v0

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getState()I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 98
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    new-instance v1, Lcom/tencent/qqpinyin/voicerecoapi/a;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/qqpinyin/voicerecoapi/a;-><init>()V

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/modelvoice/az;->a(Lcom/tencent/mm/modelvoice/az;Lcom/tencent/qqpinyin/voicerecoapi/a;)Lcom/tencent/qqpinyin/voicerecoapi/a;

    .line 99
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->d(Lcom/tencent/mm/modelvoice/az;)Lcom/tencent/qqpinyin/voicerecoapi/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/qqpinyin/voicerecoapi/a;->aDV()I

    move-result v0

    .line 100
    #v0=(Integer);
    if-eqz v0, :cond_2

    .line 101
    const-string v1, "MicroMsg.SpeexRecorder"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "speexInit failed :"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 102
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->c(Lcom/tencent/mm/modelvoice/az;)V

    .line 162
    :goto_1
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v7=(Conflicted);
    return-void

    .line 81
    :cond_1
    :try_start_1
    #v0=(Integer);v1=(One);v2=(PosByte);v3=(Uninit);v4=(Uninit);v5=(Uninit);v7=(Integer);v8=(Uninit);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    const/4 v1, 0x5

    #v1=(PosByte);
    invoke-static {v0, v1}, Lcom/tencent/mm/modelvoice/az;->a(Lcom/tencent/mm/modelvoice/az;I)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    .line 92
    :catch_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    move-exception v0

    #v0=(Reference);
    const-string v0, "MicroMsg.SpeexRecorder"

    const-string v1, "init record failed"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->c(Lcom/tencent/mm/modelvoice/az;)V

    goto :goto_1

    .line 106
    :cond_2
    :try_start_2
    #v0=(Integer);v2=(PosShort);v7=(Integer);
    new-instance v0, Ljava/io/File;

    #v0=(UninitRef);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/az;->e(Lcom/tencent/mm/modelvoice/az;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 107
    #v0=(Reference);
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 108
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    new-instance v2, Ljava/io/FileOutputStream;

    #v2=(UninitRef);
    invoke-direct {v2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/modelvoice/az;->a(Lcom/tencent/mm/modelvoice/az;Ljava/io/FileOutputStream;)Ljava/io/FileOutputStream;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 117
    :try_start_3
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->b(Lcom/tencent/mm/modelvoice/az;)Landroid/media/AudioRecord;

    move-result-object v0

    invoke-virtual {v0}, Landroid/media/AudioRecord;->startRecording()V

    .line 118
    new-array v2, v7, [S

    .line 120
    :cond_3
    :goto_2
    #v0=(Conflicted);v1=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->f(Lcom/tencent/mm/modelvoice/az;)I

    move-result v0

    #v0=(Integer);
    if-ne v0, v9, :cond_8

    .line 121
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->b(Lcom/tencent/mm/modelvoice/az;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, v2, v1, v7}, Landroid/media/AudioRecord;->read([SII)I

    move-result v3

    .line 123
    #v3=(Integer);
    const/4 v0, -0x3

    #v0=(Byte);
    if-ne v3, v0, :cond_4

    .line 124
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "read() returned AudioRecord.ERROR_INVALID_OPERATION"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 161
    :catch_1
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    move-exception v0

    #v0=(Reference);
    goto :goto_1

    .line 110
    :catch_2
    #v0=(Conflicted);v1=(Reference);
    move-exception v0

    #v0=(Reference);
    const-string v0, "MicroMsg.SpeexRecorder"

    const-string v1, "filename open failed"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 112
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->c(Lcom/tencent/mm/modelvoice/az;)V

    goto :goto_1

    .line 126
    :cond_4
    #v0=(Byte);v1=(Null);v2=(Reference);v3=(Integer);
    const/4 v0, -0x2

    if-ne v3, v0, :cond_5

    .line 127
    :try_start_4
    new-instance v0, Ljava/lang/IllegalStateException;

    #v0=(UninitRef);
    const-string v1, "read() returned AudioRecord.ERROR_BAD_VALUE"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    throw v0

    .line 131
    :cond_5
    #v0=(Byte);v1=(Null);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    invoke-static {v0, v2, v3}, Lcom/tencent/mm/modelvoice/az;->a(Lcom/tencent/mm/modelvoice/az;[SI)V

    .line 132
    mul-int/lit8 v0, v3, 0x2

    #v0=(Integer);
    new-array v4, v0, [B

    #v4=(Reference);
    move v0, v6

    #v0=(Null);
    move v1, v6

    .line 133
    :goto_3
    #v0=(Integer);v1=(Integer);
    if-ge v1, v3, :cond_6

    .line 134
    aget-short v5, v2, v1

    #v5=(Short);
    and-int/lit16 v5, v5, 0xff

    #v5=(Integer);
    int-to-byte v5, v5

    #v5=(Byte);
    aput-byte v5, v4, v0

    .line 135
    add-int/lit8 v5, v0, 0x1

    #v5=(Integer);
    aget-short v8, v2, v1

    #v8=(Short);
    shr-int/lit8 v8, v8, 0x8

    #v8=(Byte);
    and-int/lit16 v8, v8, 0xff

    #v8=(Integer);
    int-to-byte v8, v8

    #v8=(Byte);
    aput-byte v8, v4, v5

    .line 133
    add-int/lit8 v1, v1, 0x1

    add-int/lit8 v0, v0, 0x2

    goto :goto_3

    .line 137
    :cond_6
    #v5=(Conflicted);v8=(Conflicted);
    array-length v0, v4

    if-lez v0, :cond_3

    .line 138
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->d(Lcom/tencent/mm/modelvoice/az;)Lcom/tencent/qqpinyin/voicerecoapi/a;

    move-result-object v0

    array-length v1, v4

    invoke-virtual {v0, v4, v1}, Lcom/tencent/qqpinyin/voicerecoapi/a;->j([BI)[B

    move-result-object v1

    .line 139
    #v1=(Reference);
    const-string v5, "MicroMsg.SpeexRecorder"

    #v5=(Reference);
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v8, " pcmlen(short):"

    #v8=(Reference);
    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, " inSpeexBuffer:"

    #v3=(Reference);
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    array-length v3, v4

    #v3=(Integer);
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, " outSpeexBuf:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-nez v1, :cond_7

    const-string v0, "null"

    :goto_4
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    if-eqz v1, :cond_3

    array-length v0, v1

    #v0=(Integer);
    if-lez v0, :cond_3

    .line 144
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->g(Lcom/tencent/mm/modelvoice/az;)Ljava/io/FileOutputStream;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/io/FileOutputStream;->write([B)V

    .line 145
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->g(Lcom/tencent/mm/modelvoice/az;)Ljava/io/FileOutputStream;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->flush()V

    .line 146
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    iget v3, v0, Lcom/tencent/mm/modelvoice/az;->bZs:I

    #v3=(Integer);
    array-length v1, v1

    #v1=(Integer);
    add-int/2addr v1, v3

    iput v1, v0, Lcom/tencent/mm/modelvoice/az;->bZs:I

    goto/16 :goto_2

    .line 139
    :cond_7
    #v1=(Reference);v3=(Reference);
    array-length v0, v1

    #v0=(Integer);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    move-result-object v0

    #v0=(Reference);
    goto :goto_4

    .line 153
    :cond_8
    :try_start_5
    #v0=(Integer);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v8=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->c(Lcom/tencent/mm/modelvoice/az;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto/16 :goto_1

    .line 155
    :catch_3
    #v0=(Conflicted);
    move-exception v0

    .line 156
    :try_start_6
    #v0=(Reference);
    const-string v1, "MicroMsg.SpeexRecorder"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "StopRecord ErrMsg["

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "]"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 157
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ba;->bZt:Lcom/tencent/mm/modelvoice/az;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/az;->h(Lcom/tencent/mm/modelvoice/az;)I
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    goto/16 :goto_1
.end method

*/}
