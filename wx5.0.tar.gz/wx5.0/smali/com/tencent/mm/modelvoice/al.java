package com.tencent.mm.modelvoice; class al {/*

.class public final Lcom/tencent/mm/modelvoice/al;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/o/m;


# static fields
.field private static bXJ:I


# instance fields
.field private bM:Z

.field bQg:Ljava/util/Queue;

.field private bQh:I

.field private bQi:J

.field private bQj:Z

.field bQk:Lcom/tencent/mm/compatible/f/k;

.field private bQl:Lcom/tencent/mm/sdk/platformtools/ax;

.field bXE:Ljava/util/Queue;

.field bXF:Ljava/util/Map;

.field private bXG:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 1069
    const/4 v0, 0x0

    #v0=(Null);
    sput v0, Lcom/tencent/mm/modelvoice/al;->bXJ:I

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .prologue
    const/4 v3, 0x0

    .line 938
    #v3=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 943
    #p0=(Reference);
    new-instance v0, Ljava/util/LinkedList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    .line 944
    new-instance v0, Ljava/util/LinkedList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    .line 945
    new-instance v0, Ljava/util/HashMap;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    .line 1019
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    .line 1020
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    .line 1021
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/al;->bM:Z

    .line 1023
    iput v3, p0, Lcom/tencent/mm/modelvoice/al;->bQh:I

    .line 1024
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/al;->bQi:J

    .line 1118
    new-instance v0, Lcom/tencent/mm/compatible/f/k;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQk:Lcom/tencent/mm/compatible/f/k;

    .line 1158
    new-instance v0, Lcom/tencent/mm/sdk/platformtools/ax;

    #v0=(UninitRef);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pH()Lcom/tencent/mm/sdk/platformtools/al;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/sdk/platformtools/al;->getLooper()Landroid/os/Looper;

    move-result-object v1

    new-instance v2, Lcom/tencent/mm/modelvoice/ao;

    #v2=(UninitRef);
    invoke-direct {v2, p0}, Lcom/tencent/mm/modelvoice/ao;-><init>(Lcom/tencent/mm/modelvoice/al;)V

    #v2=(Reference);
    invoke-direct {v0, v1, v2, v3}, Lcom/tencent/mm/sdk/platformtools/ax;-><init>(Landroid/os/Looper;Lcom/tencent/mm/sdk/platformtools/ay;Z)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQl:Lcom/tencent/mm/sdk/platformtools/ax;

    .line 939
    invoke-static {}, Lcom/tencent/mm/model/ba;->pO()Lcom/tencent/mm/o/ac;

    move-result-object v0

    const/16 v1, 0x7f

    #v1=(PosByte);
    invoke-virtual {v0, v1, p0}, Lcom/tencent/mm/o/ac;->a(ILcom/tencent/mm/o/m;)V

    .line 940
    invoke-static {}, Lcom/tencent/mm/model/ba;->pO()Lcom/tencent/mm/o/ac;

    move-result-object v0

    const/16 v1, 0x80

    #v1=(PosShort);
    invoke-virtual {v0, v1, p0}, Lcom/tencent/mm/o/ac;->a(ILcom/tencent/mm/o/m;)V

    .line 941
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/al;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 936
    iput p1, p0, Lcom/tencent/mm/modelvoice/al;->bQh:I

    return p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/al;)Z
    .locals 1
    .parameter

    .prologue
    .line 936
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    return v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/al;)Z
    .locals 1
    .parameter

    .prologue
    .line 936
    const/4 v0, 0x0

    #v0=(Null);
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    return v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/al;)I
    .locals 2
    .parameter

    .prologue
    .line 936
    iget v0, p0, Lcom/tencent/mm/modelvoice/al;->bQh:I

    #v0=(Integer);
    add-int/lit8 v1, v0, -0x1

    #v1=(Integer);
    iput v1, p0, Lcom/tencent/mm/modelvoice/al;->bQh:I

    return v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/al;)I
    .locals 1
    .parameter

    .prologue
    .line 936
    iget v0, p0, Lcom/tencent/mm/modelvoice/al;->bQh:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic e(Lcom/tencent/mm/modelvoice/al;)Z
    .locals 1
    .parameter

    .prologue
    .line 936
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bM:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic f(Lcom/tencent/mm/modelvoice/al;)Z
    .locals 1
    .parameter

    .prologue
    .line 936
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic g(Lcom/tencent/mm/modelvoice/al;)Z
    .locals 1
    .parameter

    .prologue
    .line 936
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic h(Lcom/tencent/mm/modelvoice/al;)V
    .locals 11
    .parameter

    .prologue
    const/4 v10, 0x0

    #v10=(Null);
    const/4 v9, 0x1

    .line 936
    #v9=(One);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/al;->bQi:J

    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    #v0=(Boolean);
    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->size()I

    move-result v0

    #v0=(Integer);
    if-eqz v0, :cond_1

    :cond_0
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    #v0=(Boolean);
    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->size()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_2

    :cond_1
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bq;->yR()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_4

    :cond_2
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    #v0=(Boolean);
    if-nez v0, :cond_10

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->size()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_10

    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    #v0=(Boolean);
    if-nez v0, :cond_10

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->size()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_10

    invoke-direct {p0}, Lcom/tencent/mm/modelvoice/al;->vO()V

    const-string v0, "MicroMsg.SceneVoice"

    #v0=(Reference);
    const-string v1, "No Data Any More , Stop Service"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    :cond_4
    #v0=(Reference);v1=(Integer);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    const-wide/16 v3, 0x3e8

    #v3=(LongLo);v4=(LongHi);
    div-long/2addr v1, v3

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_5
    :goto_2
    #v4=(Reference);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_f

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mm/modelvoice/bg;

    iget-object v5, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    #v5=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    invoke-interface {v5, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    #v5=(Boolean);
    if-eqz v5, :cond_6

    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "File is Already running:"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2

    :cond_6
    #v5=(Boolean);v7=(Conflicted);
    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "Get file:"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " status:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " user"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " human:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " create:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yI()J

    move-result-wide v7

    #v7=(LongLo);v8=(LongHi);
    invoke-static {v7, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " last:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);
    invoke-static {v7, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " now:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);
    sub-long v7, v1, v7

    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->zt()Z

    move-result v5

    #v5=(Boolean);
    if-eqz v5, :cond_a

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    sub-long v5, v1, v5

    const-wide/16 v7, 0x50

    cmp-long v5, v5, v7

    #v5=(Byte);
    if-lez v5, :cond_7

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v5

    #v5=(Integer);
    const/4 v6, 0x5

    #v6=(PosByte);
    if-ne v5, v6, :cond_7

    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "time out file: "

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " last:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);
    invoke-static {v7, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " now:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    goto/16 :goto_2

    :cond_7
    #v5=(Integer);v6=(Conflicted);v7=(LongLo);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    sub-long v5, v1, v5

    const-wide/16 v7, 0x12c

    cmp-long v5, v5, v7

    #v5=(Byte);
    if-lez v5, :cond_8

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v5

    #v5=(Integer);
    const/4 v6, 0x6

    #v6=(PosByte);
    if-ne v5, v6, :cond_8

    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "time out file: "

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " last:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);
    invoke-static {v7, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " now:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    goto/16 :goto_2

    :cond_8
    #v5=(Integer);v6=(Conflicted);v7=(LongLo);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v5

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v6

    #v6=(Integer);
    if-lt v5, v6, :cond_9

    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "file: "

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " stat:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " now:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " net:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    :cond_9
    #v5=(Integer);v6=(Integer);v7=(LongLo);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    #v5=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    invoke-interface {v5, v6}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    iget-object v5, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v6, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_a
    #v5=(Conflicted);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->zu()Z

    move-result v5

    #v5=(Boolean);
    if-eqz v5, :cond_5

    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "now "

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v6, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "info.getLastModifyTime()  "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);
    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "  info.getStatus() "

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "  info.getCreateTime() "

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yI()J

    move-result-wide v7

    #v7=(LongLo);
    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    sub-long v5, v1, v5

    const-wide/16 v7, 0xa

    cmp-long v5, v5, v7

    #v5=(Byte);
    if-lez v5, :cond_c

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v5

    #v5=(Integer);
    const/4 v6, 0x2

    #v6=(PosByte);
    if-eq v5, v6, :cond_b

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v5

    if-ne v5, v9, :cond_c

    :cond_b
    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "time out file: "

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " last:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);
    invoke-static {v7, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " now:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    goto/16 :goto_2

    :cond_c
    #v5=(Integer);v6=(Conflicted);v7=(LongLo);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yI()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    sub-long v5, v1, v5

    const-wide/16 v7, 0x258

    cmp-long v5, v5, v7

    #v5=(Byte);
    if-lez v5, :cond_d

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v5

    #v5=(Integer);
    const/4 v6, 0x3

    #v6=(PosByte);
    if-ne v5, v6, :cond_d

    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "time out file: "

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " last:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);
    invoke-static {v7, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->bM(J)Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " now:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    goto/16 :goto_2

    :cond_d
    #v5=(Integer);v6=(Conflicted);v7=(LongLo);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v5

    #v5=(Reference);
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    #v5=(Integer);
    if-gtz v5, :cond_e

    const-string v5, "MicroMsg.SceneVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "Create a new ChatRoom? , set username first :"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    :cond_e
    #v5=(Integer);v6=(Conflicted);v7=(LongLo);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    #v5=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    invoke-interface {v5, v6}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    iget-object v5, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v5, v0, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_2

    :cond_f
    #v0=(Boolean);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    const-string v0, "MicroMsg.SceneVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "GetNeedRun procing:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->size()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " [recv:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    invoke-interface {v2}, Ljava/util/Queue;->size()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ",send:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    invoke-interface {v2}, Ljava/util/Queue;->size()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "]"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    invoke-interface {v0}, Ljava/util/Queue;->size()I

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    invoke-interface {v0}, Ljava/util/Queue;->size()I

    goto/16 :goto_0

    :cond_10
    #v0=(Integer);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    #v0=(Boolean);
    if-nez v0, :cond_11

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->size()I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_11

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "MicroMsg.SceneVoice"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Start Recv :"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v0, :cond_11

    iget-object v1, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    new-instance v2, Lcom/tencent/mm/compatible/f/k;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    #v2=(Reference);
    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-boolean v9, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    new-instance v1, Lcom/tencent/mm/modelvoice/p;

    #v1=(UninitRef);
    invoke-direct {v1, v0}, Lcom/tencent/mm/modelvoice/p;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pO()Lcom/tencent/mm/o/ac;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/tencent/mm/o/ac;->d(Lcom/tencent/mm/o/x;)Z

    :cond_11
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    #v0=(Boolean);
    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->size()I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_3

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "MicroMsg.SceneVoice"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Start Send :"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v0, :cond_3

    iget-object v1, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    new-instance v2, Lcom/tencent/mm/compatible/f/k;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    #v2=(Reference);
    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-boolean v9, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    new-instance v1, Lcom/tencent/mm/modelvoice/s;

    #v1=(UninitRef);
    invoke-direct {v1, v0}, Lcom/tencent/mm/modelvoice/s;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pO()Lcom/tencent/mm/o/ac;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/tencent/mm/o/ac;->d(Lcom/tencent/mm/o/x;)Z

    goto/16 :goto_1
.end method

.method static synthetic i(Lcom/tencent/mm/modelvoice/al;)V
    .locals 0
    .parameter

    .prologue
    .line 936
    invoke-direct {p0}, Lcom/tencent/mm/modelvoice/al;->vO()V

    return-void
.end method

.method static synthetic j(Lcom/tencent/mm/modelvoice/al;)J
    .locals 2
    .parameter

    .prologue
    .line 936
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/al;->bQi:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic k(Lcom/tencent/mm/modelvoice/al;)Z
    .locals 1
    .parameter

    .prologue
    .line 936
    const/4 v0, 0x1

    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/al;->bM:Z

    return v0
.end method

.method static synthetic l(Lcom/tencent/mm/modelvoice/al;)Lcom/tencent/mm/sdk/platformtools/ax;
    .locals 1
    .parameter

    .prologue
    .line 936
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQl:Lcom/tencent/mm/sdk/platformtools/ax;

    #v0=(Reference);
    return-object v0
.end method

.method private vO()V
    .locals 4

    .prologue
    const/4 v1, 0x0

    .line 1121
    #v1=(Null);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    #v0=(Reference);
    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 1122
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bQg:Ljava/util/Queue;

    invoke-interface {v0}, Ljava/util/Queue;->clear()V

    .line 1123
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/al;->bXE:Ljava/util/Queue;

    invoke-interface {v0}, Ljava/util/Queue;->clear()V

    .line 1124
    iput-boolean v1, p0, Lcom/tencent/mm/modelvoice/al;->bQj:Z

    .line 1125
    iput-boolean v1, p0, Lcom/tencent/mm/modelvoice/al;->bXG:Z

    .line 1126
    iput-boolean v1, p0, Lcom/tencent/mm/modelvoice/al;->bM:Z

    .line 1127
    const-string v0, "MicroMsg.SceneVoice"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Finish service use time(ms):"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/al;->bQk:Lcom/tencent/mm/compatible/f/k;

    invoke-virtual {v2}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 1128
    return-void
.end method

.method static synthetic zk()I
    .locals 2

    .prologue
    .line 936
    sget v0, Lcom/tencent/mm/modelvoice/al;->bXJ:I

    #v0=(Integer);
    add-int/lit8 v1, v0, 0x1

    #v1=(Integer);
    sput v1, Lcom/tencent/mm/modelvoice/al;->bXJ:I

    return v0
.end method

.method static synthetic zl()I
    .locals 2

    .prologue
    .line 936
    sget v0, Lcom/tencent/mm/modelvoice/al;->bXJ:I

    #v0=(Integer);
    add-int/lit8 v1, v0, -0x1

    #v1=(Integer);
    sput v1, Lcom/tencent/mm/modelvoice/al;->bXJ:I

    return v0
.end method

.method static synthetic zm()I
    .locals 1

    .prologue
    .line 936
    sget v0, Lcom/tencent/mm/modelvoice/al;->bXJ:I

    #v0=(Integer);
    return v0
.end method


# virtual methods
.method public final a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V
    .locals 2
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 1073
    invoke-static {}, Lcom/tencent/mm/model/ba;->pH()Lcom/tencent/mm/sdk/platformtools/al;

    move-result-object v0

    #v0=(Reference);
    new-instance v1, Lcom/tencent/mm/modelvoice/am;

    #v1=(UninitRef);
    invoke-direct {v1, p0, p4, p1, p2}, Lcom/tencent/mm/modelvoice/am;-><init>(Lcom/tencent/mm/modelvoice/al;Lcom/tencent/mm/o/x;II)V

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/sdk/platformtools/al;->m(Ljava/lang/Runnable;)I

    .line 1116
    return-void
.end method

.method public final run()V
    .locals 2

    .prologue
    .line 1133
    invoke-static {}, Lcom/tencent/mm/model/ba;->pH()Lcom/tencent/mm/sdk/platformtools/al;

    move-result-object v0

    #v0=(Reference);
    new-instance v1, Lcom/tencent/mm/modelvoice/an;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mm/modelvoice/an;-><init>(Lcom/tencent/mm/modelvoice/al;)V

    #v1=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/sdk/platformtools/al;->m(Ljava/lang/Runnable;)I

    .line 1156
    return-void
.end method

.method public final stop()V
    .locals 1

    .prologue
    .line 1169
    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/tencent/mm/modelvoice/al;->bQh:I

    .line 1170
    return-void
.end method

*/}
