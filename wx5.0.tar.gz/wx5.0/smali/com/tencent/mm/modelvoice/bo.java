package com.tencent.mm.modelvoice; class bo {/*

.class final Lcom/tencent/mm/modelvoice/bo;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/modelvoice/n;


# instance fields
.field final synthetic bZE:Lcom/tencent/mm/modelvoice/bn;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/bn;)V
    .locals 0
    .parameter

    .prologue
    .line 63
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bo;->bZE:Lcom/tencent/mm/modelvoice/bn;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final kX()V
    .locals 4

    .prologue
    .line 66
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bo;->bZE:Lcom/tencent/mm/modelvoice/bn;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bn;->a(Lcom/tencent/mm/modelvoice/bn;)Lcom/tencent/mm/modelvoice/bp;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 67
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bo;->bZE:Lcom/tencent/mm/modelvoice/bn;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bn;->a(Lcom/tencent/mm/modelvoice/bn;)Lcom/tencent/mm/modelvoice/bp;

    move-result-object v0

    invoke-interface {v0}, Lcom/tencent/mm/modelvoice/bp;->kX()V

    .line 70
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bo;->bZE:Lcom/tencent/mm/modelvoice/bn;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bn;->b(Lcom/tencent/mm/modelvoice/bn;)Lcom/tencent/mm/modelvoice/MediaRecorder;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/MediaRecorder;->release()V

    .line 71
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bo;->bZE:Lcom/tencent/mm/modelvoice/bn;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bn;->c(Lcom/tencent/mm/modelvoice/bn;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 75
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 72
    :catch_0
    #v1=(Uninit);v2=(Uninit);v3=(Uninit);
    move-exception v0

    .line 73
    const-string v1, "VoiceRecorder"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "setErrorListener File["

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bo;->bZE:Lcom/tencent/mm/modelvoice/bn;

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bn;->getFileName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "] ErrMsg["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "]"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

*/}
