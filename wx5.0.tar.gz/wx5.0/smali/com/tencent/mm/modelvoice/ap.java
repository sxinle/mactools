package com.tencent.mm.modelvoice; class ap {/*

.class public final Lcom/tencent/mm/modelvoice/ap;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/compatible/audio/i;
.implements Lcom/tencent/mm/o/r;


# static fields
.field private static bzP:I


# instance fields
.field private ah:Ljava/lang/String;

.field private bYE:Z

.field private bYG:J

.field private bYH:J

.field private bYI:I

.field private bYK:I

.field private bYL:Lcom/tencent/mm/o/t;

.field private bYM:Lcom/tencent/mm/o/s;

.field private bYN:Lcom/tencent/mm/sdk/platformtools/ax;

.field private bYO:Z

.field private bYT:Lcom/tencent/mm/modelvoice/az;

.field private bYU:Lcom/tencent/mm/modelvoice/at;

.field private bYu:Lcom/tencent/mm/compatible/f/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 454
    const/16 v0, 0x64

    #v0=(PosByte);
    sput v0, Lcom/tencent/mm/modelvoice/ap;->bzP:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4
    .parameter

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x0

    .line 408
    #v3=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 385
    #p0=(Reference);
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    .line 388
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    .line 389
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYE:Z

    .line 392
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYH:J

    .line 393
    iput v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYI:I

    .line 401
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYU:Lcom/tencent/mm/modelvoice/at;

    .line 404
    iput v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYK:I

    .line 406
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYM:Lcom/tencent/mm/o/s;

    .line 470
    new-instance v0, Lcom/tencent/mm/sdk/platformtools/ax;

    #v0=(UninitRef);
    new-instance v1, Lcom/tencent/mm/modelvoice/aq;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mm/modelvoice/aq;-><init>(Lcom/tencent/mm/modelvoice/ap;)V

    #v1=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    invoke-direct {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/ax;-><init>(Lcom/tencent/mm/sdk/platformtools/ay;Z)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYN:Lcom/tencent/mm/sdk/platformtools/ax;

    .line 578
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYO:Z

    .line 409
    new-instance v0, Lcom/tencent/mm/compatible/f/a;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Lcom/tencent/mm/compatible/f/a;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYu:Lcom/tencent/mm/compatible/f/a;

    .line 410
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/ap;J)J
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 383
    iput-wide p1, p0, Lcom/tencent/mm/modelvoice/ap;->bYH:J

    return-wide p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/ap;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 383
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/ap;)I
    .locals 1
    .parameter

    .prologue
    .line 383
    iget v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYK:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/ap;)Lcom/tencent/mm/o/t;
    .locals 1
    .parameter

    .prologue
    .line 383
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYL:Lcom/tencent/mm/o/t;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/ap;)I
    .locals 1
    .parameter

    .prologue
    .line 383
    const/4 v0, 0x2

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYK:I

    return v0
.end method

.method static synthetic e(Lcom/tencent/mm/modelvoice/ap;)Lcom/tencent/mm/modelvoice/az;
    .locals 1
    .parameter

    .prologue
    .line 383
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic f(Lcom/tencent/mm/modelvoice/ap;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 383
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic g(Lcom/tencent/mm/modelvoice/ap;)Lcom/tencent/mm/modelvoice/az;
    .locals 1
    .parameter

    .prologue
    .line 383
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    return-object v0
.end method

.method static synthetic h(Lcom/tencent/mm/modelvoice/ap;)Lcom/tencent/mm/compatible/f/a;
    .locals 1
    .parameter

    .prologue
    .line 383
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic i(Lcom/tencent/mm/modelvoice/ap;)J
    .locals 2
    .parameter

    .prologue
    .line 383
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYG:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic j(Lcom/tencent/mm/modelvoice/ap;)Z
    .locals 1
    .parameter

    .prologue
    .line 383
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYO:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic k(Lcom/tencent/mm/modelvoice/ap;)Lcom/tencent/mm/o/s;
    .locals 1
    .parameter

    .prologue
    .line 383
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYM:Lcom/tencent/mm/o/s;

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/o/s;)V
    .locals 0
    .parameter

    .prologue
    .line 683
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ap;->bYM:Lcom/tencent/mm/o/s;

    .line 685
    return-void
.end method

.method public final a(Lcom/tencent/mm/o/t;)V
    .locals 0
    .parameter

    .prologue
    .line 689
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ap;->bYL:Lcom/tencent/mm/o/t;

    .line 691
    return-void
.end method

.method public final aH(I)V
    .locals 4
    .parameter

    .prologue
    const/4 v3, 0x1

    .line 662
    #v3=(One);
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "dkbt Recorder onAudioStatChange :"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 663
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYO:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 679
    :goto_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 666
    :cond_0
    #v0=(Boolean);v2=(Reference);v3=(One);
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYO:Z

    .line 667
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/tencent/mm/compatible/audio/d;->b(Lcom/tencent/mm/compatible/audio/i;)V

    .line 668
    new-instance v0, Lcom/tencent/mm/modelvoice/az;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/az;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    .line 669
    new-instance v0, Lcom/tencent/mm/modelvoice/as;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/as;-><init>(Lcom/tencent/mm/modelvoice/ap;)V

    #v0=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    .line 670
    :cond_1
    new-instance v0, Lcom/tencent/mm/modelvoice/at;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/at;-><init>(Lcom/tencent/mm/modelvoice/ap;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYU:Lcom/tencent/mm/modelvoice/at;

    .line 671
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYU:Lcom/tencent/mm/modelvoice/at;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/at;->start()V

    .line 673
    iput v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYK:I

    .line 676
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYN:Lcom/tencent/mm/sdk/platformtools/ax;

    const-wide/16 v1, 0xbb8

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/ax;->bL(J)V

    .line 678
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "start end time:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-wide v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYG:J

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/ce;->N(J)J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public final cancel()Z
    .locals 3

    .prologue
    .line 583
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "cancel Record :"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 584
    monitor-enter p0

    .line 585
    :try_start_0
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "stop synchronized Record :"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 586
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    if-eqz v0, :cond_0

    .line 587
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/az;->kM()Z

    .line 588
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    .line 590
    :cond_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 592
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->hb(Ljava/lang/String;)Z

    .line 593
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zp()Lcom/tencent/mm/modelvoice/al;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/al;->run()V

    .line 594
    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    .line 595
    const/4 v0, 0x1

    #v0=(One);
    return v0

    .line 590
    :catchall_0
    #v0=(Reference);v1=(Conflicted);
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final ef(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 532
    #v0=(Null);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/ap;->reset()V

    .line 533
    invoke-static {}, Lcom/tencent/mm/sdk/platformtools/ce;->Az()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    iput-wide v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYG:J

    .line 535
    if-nez p1, :cond_0

    .line 536
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    #v1=(Reference);
    const-string v2, "Start Record toUser null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 575
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 540
    :cond_0
    #v0=(Null);v1=(LongLo);v2=(LongHi);v3=(Uninit);
    const-string v1, "_USER_FOR_THROWBOTTLE_"

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    iput-boolean v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYE:Z

    .line 542
    const-string v1, "medianote"

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_1

    .line 543
    invoke-static {}, Lcom/tencent/mm/model/s;->oA()I

    .line 548
    :cond_1
    invoke-static {p1}, Lcom/tencent/mm/modelvoice/bh;->gZ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    iput-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    .line 549
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-gtz v1, :cond_3

    .line 550
    :cond_2
    #v1=(Conflicted);
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    #v1=(Reference);
    const-string v2, "Start Record DBError "

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 553
    :cond_3
    #v1=(Integer);v2=(LongHi);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, p0}, Lcom/tencent/mm/compatible/audio/d;->a(Lcom/tencent/mm/compatible/audio/i;)V

    .line 554
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tencent/mm/compatible/audio/d;->kB()I

    move-result v1

    .line 556
    #v1=(Integer);
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYO:Z

    .line 557
    if-eqz v1, :cond_4

    .line 558
    const/16 v0, 0x64

    #v0=(PosByte);
    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/ap;->aH(I)V

    .line 575
    :goto_1
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0

    .line 560
    :cond_4
    #v0=(Null);v1=(Integer);v2=(LongHi);v3=(Uninit);
    new-instance v1, Lcom/tencent/mm/modelvoice/ar;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mm/modelvoice/ar;-><init>(Lcom/tencent/mm/modelvoice/ap;)V

    #v1=(Reference);
    const-wide/16 v2, 0x32

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {v1, v0, v2, v3}, Lcom/tencent/mm/modelvoice/ar;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_1
.end method

.method public final getFileName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 443
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getMaxAmplitude()I
    .locals 5

    .prologue
    .line 458
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    if-eqz v0, :cond_1

    .line 459
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/az;->getMaxAmplitude()I

    move-result v0

    .line 460
    #v0=(Integer);
    sget v1, Lcom/tencent/mm/modelvoice/ap;->bzP:I

    #v1=(Integer);
    if-le v0, v1, :cond_0

    .line 461
    sput v0, Lcom/tencent/mm/modelvoice/ap;->bzP:I

    .line 463
    :cond_0
    const-string v1, "getMaxAmplitude"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, " map: "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " max:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget v3, Lcom/tencent/mm/modelvoice/ap;->bzP:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " per:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    mul-int/lit8 v3, v0, 0x64

    #v3=(Integer);
    sget v4, Lcom/tencent/mm/modelvoice/ap;->bzP:I

    #v4=(Integer);
    div-int/2addr v3, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 464
    mul-int/lit8 v0, v0, 0x64

    sget v1, Lcom/tencent/mm/modelvoice/ap;->bzP:I

    #v1=(Integer);
    div-int/2addr v0, v1

    .line 467
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final kR()Z
    .locals 5

    .prologue
    const/4 v0, 0x0

    .line 600
    #v0=(Null);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/compatible/audio/d;->kC()V

    .line 601
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "stop Record :"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 603
    monitor-enter p0

    .line 604
    :try_start_0
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "stop synchronized Record :"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 605
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    if-eqz v1, :cond_0

    .line 606
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/az;->kM()Z

    .line 607
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v1}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    .line 609
    :cond_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 610
    iget v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYK:I

    #v1=(Integer);
    const/4 v2, 0x2

    #v2=(PosByte);
    if-eq v1, v2, :cond_1

    .line 611
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->hd(Ljava/lang/String;)Z

    .line 612
    const/4 v1, 0x0

    #v1=(Null);
    iput-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    .line 614
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Stop "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " by not onPart: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYG:J

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/ce;->N(J)J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 630
    :goto_0
    #v0=(Boolean);v3=(Conflicted);
    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYK:I

    .line 631
    return v0

    .line 609
    :catchall_0
    #v0=(Null);v1=(Reference);v2=(Conflicted);v3=(Reference);v4=(Uninit);
    move-exception v0

    #v0=(Reference);
    monitor-exit p0

    throw v0

    .line 616
    :cond_1
    #v0=(Null);v1=(Integer);v2=(PosByte);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/ap;->rK()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    long-to-int v1, v1

    #v1=(Integer);
    iput v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYI:I

    .line 617
    iget v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYI:I

    int-to-long v1, v1

    #v1=(LongLo);
    const-wide/16 v3, 0x320

    #v3=(LongLo);v4=(LongHi);
    cmp-long v1, v1, v3

    #v1=(Byte);
    if-ltz v1, :cond_2

    iget-boolean v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYE:Z

    #v1=(Boolean);
    if-eqz v1, :cond_3

    iget v1, p0, Lcom/tencent/mm/modelvoice/ap;->bYI:I

    #v1=(Integer);
    int-to-long v1, v1

    #v1=(LongLo);
    const-wide/16 v3, 0x3e8

    cmp-long v1, v1, v3

    #v1=(Byte);
    if-gez v1, :cond_3

    .line 618
    :cond_2
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Stop "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " by voiceLen: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYI:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 619
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->hd(Ljava/lang/String;)Z

    .line 620
    const-string v1, ""

    iput-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    .line 628
    :goto_1
    #v0=(Boolean);v3=(Conflicted);
    const-string v1, ""

    iput-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    goto :goto_0

    .line 623
    :cond_3
    #v0=(Null);v1=(Byte);v2=(LongHi);v3=(LongLo);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYI:I

    #v2=(Integer);
    invoke-static {v1, v2, v0}, Lcom/tencent/mm/modelvoice/bh;->n(Ljava/lang/String;II)Z

    .line 624
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zp()Lcom/tencent/mm/modelvoice/al;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/al;->run()V

    .line 625
    const/4 v0, 0x1

    .line 626
    #v0=(One);
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Stop file success: "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1
.end method

.method public final rJ()Z
    .locals 3

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 448
    #v0=(Null);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    #v2=(Reference);
    if-nez v2, :cond_1

    .line 451
    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v2=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/az;->getStatus()I

    move-result v2

    #v2=(Integer);
    if-ne v2, v1, :cond_0

    move v0, v1

    #v0=(One);
    goto :goto_0
.end method

.method public final rK()J
    .locals 6

    .prologue
    const-wide/16 v0, 0x0

    .line 653
    #v0=(LongLo);v1=(LongHi);
    const-string v2, "MicroMsg.SceneVoice.Recorder"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "recordStartTime "

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-wide v4, p0, Lcom/tencent/mm/modelvoice/ap;->bYH:J

    #v4=(LongLo);v5=(LongHi);
    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 654
    iget-wide v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYH:J

    #v2=(LongLo);v3=(LongHi);
    cmp-long v2, v2, v0

    #v2=(Byte);
    if-nez v2, :cond_0

    .line 657
    :goto_0
    return-wide v0

    :cond_0
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYH:J

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/ce;->N(J)J

    move-result-wide v0

    goto :goto_0
.end method

.method public final rL()I
    .locals 1

    .prologue
    .line 438
    iget v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYI:I

    #v0=(Integer);
    return v0
.end method

.method public final reset()V
    .locals 5

    .prologue
    const-wide/16 v3, 0x0

    #v3=(LongLo);v4=(LongHi);
    const/4 v2, 0x0

    .line 421
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 422
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYT:Lcom/tencent/mm/modelvoice/az;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/az;->kM()Z

    .line 423
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    .line 424
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    const-string v1, "Reset recorder.stopReocrd"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 426
    :cond_0
    #v1=(Conflicted);
    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/ap;->ah:Ljava/lang/String;

    .line 427
    iput-wide v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYG:J

    .line 428
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYU:Lcom/tencent/mm/modelvoice/at;

    .line 429
    const/4 v0, 0x0

    #v0=(Null);
    iput v0, p0, Lcom/tencent/mm/modelvoice/ap;->bYK:I

    .line 430
    iput-wide v3, p0, Lcom/tencent/mm/modelvoice/ap;->bYH:J

    .line 432
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYL:Lcom/tencent/mm/o/t;

    .line 433
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/ap;->bYM:Lcom/tencent/mm/o/s;

    .line 434
    return-void
.end method

*/}
