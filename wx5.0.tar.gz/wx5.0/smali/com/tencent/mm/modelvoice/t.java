package com.tencent.mm.modelvoice; class t {/*

.class final Lcom/tencent/mm/modelvoice/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/sdk/platformtools/ay;


# instance fields
.field final synthetic bYk:Lcom/tencent/mm/modelvoice/s;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/s;)V
    .locals 0
    .parameter

    .prologue
    .line 305
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final jK()Z
    .locals 11

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v10, 0x3

    #v10=(PosByte);
    const/4 v9, -0x1

    .line 308
    #v9=(Byte);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;)Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3, v2}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v2

    .line 309
    if-eqz v2, :cond_0

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bg;->zu()Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_2

    .line 310
    :cond_0
    #v3=(Conflicted);
    const-string v1, "MicroMsg.NetSceneUploadVoice"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Get info Failed file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 311
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v2

    #v2=(Integer);
    add-int/lit16 v2, v2, 0x2710

    invoke-static {v1, v2}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;I)I

    .line 312
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/s;->b(Lcom/tencent/mm/modelvoice/s;)Lcom/tencent/mm/o/m;

    move-result-object v1

    const-string v2, "doScene failed"

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-interface {v1, v10, v9, v2, v3}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    .line 343
    :cond_1
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return v0

    .line 316
    :cond_2
    #v0=(Null);v1=(One);v2=(Reference);v3=(Boolean);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v3

    #v3=(Integer);
    if-eq v10, v3, :cond_5

    const/16 v3, 0x8

    #v3=(PosByte);
    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v4

    #v4=(Integer);
    if-eq v3, v4, :cond_5

    .line 317
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    .line 319
    #v3=(LongLo);v4=(LongHi);
    const-wide/16 v5, 0x3e8

    #v5=(LongLo);v6=(LongHi);
    div-long v5, v3, v5

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bg;->yJ()J

    move-result-wide v7

    #v7=(LongLo);v8=(LongHi);
    sub-long/2addr v5, v7

    const-wide/16 v7, 0x1e

    cmp-long v5, v5, v7

    #v5=(Byte);
    if-lez v5, :cond_3

    .line 320
    const-string v1, "MicroMsg.NetSceneUploadVoice"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Error ModifyTime in Read file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 321
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v2

    #v2=(Integer);
    add-int/lit16 v2, v2, 0x2710

    invoke-static {v1, v2}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;I)I

    .line 322
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/s;->b(Lcom/tencent/mm/modelvoice/s;)Lcom/tencent/mm/o/m;

    move-result-object v1

    const-string v2, "doScene failed"

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-interface {v1, v10, v9, v2, v3}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto :goto_0

    .line 326
    :cond_3
    #v1=(One);v3=(LongLo);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    #v5=(Reference);
    invoke-static {v5}, Lcom/tencent/mm/modelvoice/s;->c(Lcom/tencent/mm/modelvoice/s;)J

    move-result-wide v5

    #v5=(LongLo);
    sub-long v5, v3, v5

    const-wide/16 v7, 0x7d0

    cmp-long v5, v5, v7

    #v5=(Byte);
    if-gez v5, :cond_4

    .line 327
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v5, "TimerExpired :"

    #v5=(Reference);
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v5}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " but last send time:"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v5, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v5}, Lcom/tencent/mm/modelvoice/s;->c(Lcom/tencent/mm/modelvoice/s;)J

    move-result-wide v5

    #v5=(LongLo);
    sub-long/2addr v3, v5

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v1

    .line 328
    #v0=(One);
    goto/16 :goto_0

    .line 331
    :cond_4
    #v0=(Null);v5=(Byte);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    #v3=(Reference);
    invoke-static {v3}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/bh;->gY(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/b;

    move-result-object v3

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v4

    #v4=(Integer);
    const/16 v5, 0x1770

    #v5=(PosShort);
    invoke-interface {v3, v4, v5}, Lcom/tencent/mm/modelvoice/b;->C(II)Lcom/tencent/mm/modelvoice/u;

    move-result-object v3

    .line 333
    const-string v4, "MicroMsg.NetSceneUploadVoice"

    #v4=(Reference);
    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    const-string v6, "pusher doscene:"

    #v6=(Reference);
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    iget-object v6, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v6}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " readByte:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, v3, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " stat:"

    #v6=(Reference);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 335
    iget v2, v3, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v2=(Integer);
    const/16 v3, 0x7d0

    #v3=(PosShort);
    if-ge v2, v3, :cond_5

    move v0, v1

    .line 336
    #v0=(One);
    goto/16 :goto_0

    .line 339
    :cond_5
    #v0=(Null);v2=(Conflicted);v3=(Integer);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/modelvoice/s;->d(Lcom/tencent/mm/modelvoice/s;)Lcom/tencent/mm/network/q;

    move-result-object v2

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    #v3=(Reference);
    invoke-static {v3}, Lcom/tencent/mm/modelvoice/s;->b(Lcom/tencent/mm/modelvoice/s;)Lcom/tencent/mm/o/m;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/network/q;Lcom/tencent/mm/o/m;)I

    move-result v1

    #v1=(Integer);
    if-ne v1, v9, :cond_1

    .line 340
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    #v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v2

    #v2=(Integer);
    add-int/lit16 v2, v2, 0x2710

    invoke-static {v1, v2}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/modelvoice/s;I)I

    .line 341
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/s;->b(Lcom/tencent/mm/modelvoice/s;)Lcom/tencent/mm/o/m;

    move-result-object v1

    const-string v2, "doScene failed"

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/t;->bYk:Lcom/tencent/mm/modelvoice/s;

    invoke-interface {v1, v10, v9, v2, v3}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0
.end method

*/}
