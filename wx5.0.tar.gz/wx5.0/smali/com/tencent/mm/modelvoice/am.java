package com.tencent.mm.modelvoice; class am {/*

.class final Lcom/tencent/mm/modelvoice/am;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic bIX:Lcom/tencent/mm/o/x;

.field final synthetic bIZ:I

.field final synthetic bJa:I

.field final synthetic bYS:Lcom/tencent/mm/modelvoice/al;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/al;Lcom/tencent/mm/o/x;II)V
    .locals 0
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 1073
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    iput-object p2, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    iput p3, p0, Lcom/tencent/mm/modelvoice/am;->bIZ:I

    iput p4, p0, Lcom/tencent/mm/modelvoice/am;->bJa:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .prologue
    .line 1077
    invoke-static {}, Lcom/tencent/mm/modelvoice/al;->zk()I

    .line 1079
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/o/x;->getType()I

    move-result v0

    #v0=(Integer);
    const/16 v1, 0x80

    #v1=(PosShort);
    if-ne v0, v1, :cond_3

    .line 1082
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->a(Lcom/tencent/mm/modelvoice/al;)Z

    .line 1083
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    check-cast v0, Lcom/tencent/mm/modelvoice/p;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/p;->getFileName()Ljava/lang/String;

    move-result-object v1

    .line 1084
    #v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    check-cast v0, Lcom/tencent/mm/modelvoice/p;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/p;->yz()I

    move-result v0

    #v0=(Integer);
    move v2, v0

    #v2=(Integer);
    move-object v3, v1

    .line 1094
    :goto_0
    #v3=(Reference);
    const-wide/16 v0, 0x0

    .line 1095
    #v0=(LongLo);v1=(LongHi);
    if-eqz v3, :cond_0

    iget-object v4, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v4=(Reference);
    iget-object v4, v4, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 1096
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/compatible/f/k;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v0

    .line 1097
    #v0=(LongLo);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    iget-object v4, v4, Lcom/tencent/mm/modelvoice/al;->bXF:Ljava/util/Map;

    invoke-interface {v4, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1099
    :cond_0
    #v4=(Conflicted);
    const-string v4, "MicroMsg.SceneVoice"

    #v4=(Reference);
    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    const-string v6, "onSceneEnd SceneType:"

    #v6=(Reference);
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    iget-object v6, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    invoke-virtual {v6}, Lcom/tencent/mm/o/x;->getType()I

    move-result v6

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " errtype:"

    #v6=(Reference);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, p0, Lcom/tencent/mm/modelvoice/am;->bIZ:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " errCode:"

    #v6=(Reference);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, p0, Lcom/tencent/mm/modelvoice/am;->bJa:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " retCode:"

    #v6=(Reference);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " file:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " time:"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 1101
    iget v0, p0, Lcom/tencent/mm/modelvoice/am;->bIZ:I

    #v0=(Integer);
    const/4 v1, 0x3

    #v1=(PosByte);
    if-ne v0, v1, :cond_5

    if-eqz v2, :cond_5

    .line 1102
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->c(Lcom/tencent/mm/modelvoice/al;)I

    .line 1107
    :cond_1
    :goto_1
    #v0=(Conflicted);
    const-string v0, "MicroMsg.SceneVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "onSceneEnd  inCnt:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/modelvoice/al;->zm()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " stop:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/al;->d(Lcom/tencent/mm/modelvoice/al;)I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " running:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/al;->e(Lcom/tencent/mm/modelvoice/al;)Z

    move-result v2

    #v2=(Boolean);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " recving:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/al;->f(Lcom/tencent/mm/modelvoice/al;)Z

    move-result v2

    #v2=(Boolean);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " sending:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/al;->g(Lcom/tencent/mm/modelvoice/al;)Z

    move-result v2

    #v2=(Boolean);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 1108
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->d(Lcom/tencent/mm/modelvoice/al;)I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_6

    .line 1109
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->h(Lcom/tencent/mm/modelvoice/al;)V

    .line 1113
    :cond_2
    :goto_2
    #v0=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/modelvoice/al;->zl()I

    .line 1114
    :goto_3
    #v2=(Integer);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return-void

    .line 1085
    :cond_3
    #v0=(Integer);v1=(PosShort);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/o/x;->getType()I

    move-result v0

    #v0=(Integer);
    const/16 v1, 0x7f

    #v1=(PosByte);
    if-ne v0, v1, :cond_4

    .line 1086
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->b(Lcom/tencent/mm/modelvoice/al;)Z

    .line 1087
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    check-cast v0, Lcom/tencent/mm/modelvoice/s;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/s;->getFileName()Ljava/lang/String;

    move-result-object v1

    .line 1088
    #v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    check-cast v0, Lcom/tencent/mm/modelvoice/s;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/s;->yz()I

    move-result v0

    #v0=(Integer);
    move v2, v0

    #v2=(Integer);
    move-object v3, v1

    #v3=(Reference);
    goto/16 :goto_0

    .line 1090
    :cond_4
    #v1=(PosByte);v2=(Uninit);v3=(Uninit);
    const-string v0, "MicroMsg.SceneVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "onSceneEnd Error SceneType:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/am;->bIX:Lcom/tencent/mm/o/x;

    invoke-virtual {v2}, Lcom/tencent/mm/o/x;->getType()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 1091
    invoke-static {}, Lcom/tencent/mm/modelvoice/al;->zl()I

    goto :goto_3

    .line 1103
    :cond_5
    #v0=(Integer);v1=(PosByte);v3=(Reference);v4=(Reference);v5=(Reference);v6=(Reference);
    iget v0, p0, Lcom/tencent/mm/modelvoice/am;->bIZ:I

    if-eqz v0, :cond_1

    .line 1104
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-static {v0, v1}, Lcom/tencent/mm/modelvoice/al;->a(Lcom/tencent/mm/modelvoice/al;I)I

    goto/16 :goto_1

    .line 1110
    :cond_6
    #v0=(Integer);v1=(Reference);v2=(Boolean);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->g(Lcom/tencent/mm/modelvoice/al;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_2

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->f(Lcom/tencent/mm/modelvoice/al;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_2

    .line 1111
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/am;->bYS:Lcom/tencent/mm/modelvoice/al;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->i(Lcom/tencent/mm/modelvoice/al;)V

    goto :goto_2
.end method

*/}
