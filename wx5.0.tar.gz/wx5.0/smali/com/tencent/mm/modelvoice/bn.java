package com.tencent.mm.modelvoice; class bn {/*

.class public final Lcom/tencent/mm/modelvoice/bn;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static bzP:I


# instance fields
.field private ah:Ljava/lang/String;

.field private bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

.field private bZD:Lcom/tencent/mm/modelvoice/bp;

.field private status:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 30
    const/16 v0, 0x64

    #v0=(PosByte);
    sput v0, Lcom/tencent/mm/modelvoice/bn;->bzP:I

    return-void
.end method

.method public constructor <init>(Lcom/tencent/mm/compatible/audio/b;)V
    .locals 1
    .parameter

    .prologue
    .line 47
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    #p0=(Reference);
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    .line 16
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->bZD:Lcom/tencent/mm/modelvoice/bp;

    .line 28
    const/4 v0, 0x0

    iput v0, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    .line 48
    new-instance v0, Lcom/tencent/mm/modelvoice/MediaRecorder;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Lcom/tencent/mm/modelvoice/MediaRecorder;-><init>(Lcom/tencent/mm/compatible/audio/b;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    .line 49
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/bn;)Lcom/tencent/mm/modelvoice/bp;
    .locals 1
    .parameter

    .prologue
    .line 7
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->bZD:Lcom/tencent/mm/modelvoice/bp;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/bn;)Lcom/tencent/mm/modelvoice/MediaRecorder;
    .locals 1
    .parameter

    .prologue
    .line 7
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/bn;)I
    .locals 1
    .parameter

    .prologue
    .line 7
    const/4 v0, -0x1

    #v0=(Byte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    return v0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/modelvoice/bp;)V
    .locals 0
    .parameter

    .prologue
    .line 43
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bn;->bZD:Lcom/tencent/mm/modelvoice/bp;

    .line 44
    return-void
.end method

.method public final gS(Ljava/lang/String;)Z
    .locals 7
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 54
    #v0=(Null);
    new-instance v2, Lcom/tencent/mm/compatible/f/k;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    .line 55
    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    #v3=(Reference);
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    #v3=(Integer);
    if-lez v3, :cond_0

    .line 56
    const-string v1, "VoiceRecorder"

    #v1=(Reference);
    const-string v2, "Duplicate Call startRecord , maybe Stop Fail Before"

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 95
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return v0

    .line 60
    :cond_0
    #v0=(Null);v1=(One);v3=(Integer);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    .line 63
    :try_start_0
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    #v3=(Reference);
    new-instance v4, Lcom/tencent/mm/modelvoice/bo;

    #v4=(UninitRef);
    invoke-direct {v4, p0}, Lcom/tencent/mm/modelvoice/bo;-><init>(Lcom/tencent/mm/modelvoice/bn;)V

    #v4=(Reference);
    invoke-virtual {v3, v4}, Lcom/tencent/mm/modelvoice/MediaRecorder;->a(Lcom/tencent/mm/modelvoice/n;)V

    .line 78
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/MediaRecorder;->kP()V

    .line 79
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/MediaRecorder;->kQ()V

    .line 80
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/MediaRecorder;->kO()V

    .line 81
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    iget-object v4, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lcom/tencent/mm/modelvoice/MediaRecorder;->setOutputFile(Ljava/lang/String;)V

    .line 82
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/MediaRecorder;->kN()V

    .line 83
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/MediaRecorder;->prepare()V

    .line 84
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/MediaRecorder;->start()V

    .line 86
    const-string v3, "VoiceRecorder"

    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "StartRecord File["

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "] start time:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v2}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 93
    iput v1, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    move v0, v1

    .line 95
    #v0=(One);
    goto :goto_0

    .line 88
    :catch_0
    #v0=(Null);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    move-exception v1

    .line 89
    #v1=(Reference);
    const-string v2, "VoiceRecorder"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "StartRecord File["

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "] ErrMsg["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "]"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    goto/16 :goto_0
.end method

.method public final getFileName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 118
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getMaxAmplitude()I
    .locals 2

    .prologue
    .line 123
    iget v0, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    if-ne v0, v1, :cond_1

    .line 124
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/MediaRecorder;->getMaxAmplitude()I

    move-result v0

    .line 125
    #v0=(Integer);
    sget v1, Lcom/tencent/mm/modelvoice/bn;->bzP:I

    #v1=(Integer);
    if-le v0, v1, :cond_0

    .line 126
    sput v0, Lcom/tencent/mm/modelvoice/bn;->bzP:I

    .line 129
    :cond_0
    mul-int/lit8 v0, v0, 0x64

    sget v1, Lcom/tencent/mm/modelvoice/bn;->bzP:I

    div-int/2addr v0, v1

    .line 131
    :goto_0
    return v0

    :cond_1
    #v1=(One);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final getStatus()I
    .locals 1

    .prologue
    .line 36
    iget v0, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    #v0=(Integer);
    return v0
.end method

.method public final kM()Z
    .locals 5

    .prologue
    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    .line 99
    #v1=(Null);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    #v2=(Reference);
    if-nez v2, :cond_0

    .line 114
    :goto_0
    #v0=(Boolean);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 104
    :cond_0
    :try_start_0
    #v0=(One);v3=(Uninit);v4=(Uninit);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/MediaRecorder;->kR()Z

    .line 105
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/MediaRecorder;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 112
    const-string v2, ""

    iput-object v2, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    .line 113
    iput v1, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    goto :goto_0

    .line 107
    :catch_0
    move-exception v0

    .line 108
    #v0=(Reference);
    const-string v2, "VoiceRecorder"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "StopRecord File["

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/bn;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "] ErrMsg["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "]"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    const/4 v0, -0x1

    #v0=(Byte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bn;->status:I

    move v0, v1

    .line 110
    #v0=(Null);
    goto :goto_0
.end method

.method public final yZ()I
    .locals 1

    .prologue
    .line 40
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bn;->bZC:Lcom/tencent/mm/modelvoice/MediaRecorder;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/MediaRecorder;->yZ()I

    move-result v0

    #v0=(Integer);
    return v0
.end method

*/}
