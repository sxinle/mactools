package com.tencent.mm.modelvoice; class v {/*

.class public interface abstract Lcom/tencent/mm/modelvoice/v;
.super Ljava/lang/Object;
.source "SourceFile"

*/}
