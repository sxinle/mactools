package com.tencent.mm.modelvoice; class x {/*

.class public final Lcom/tencent/mm/modelvoice/x;
.super Ljava/lang/Object;
.source "SourceFile"

*/}
