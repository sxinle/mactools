package com.tencent.mm.modelvoice; class bd {/*

.class final Lcom/tencent/mm/modelvoice/bd;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/ao/k;


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 61
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final jE()[Ljava/lang/String;
    .locals 1

    .prologue
    .line 64
    sget-object v0, Lcom/tencent/mm/modelvoice/bq;->bGp:[Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

*/}
