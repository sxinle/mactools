package com.tencent.mm.modelvoice; class ar {/*

.class final Lcom/tencent/mm/modelvoice/ar;
.super Landroid/os/Handler;
.source "SourceFile"


# instance fields
.field final synthetic bYV:Lcom/tencent/mm/modelvoice/ap;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/ap;)V
    .locals 0
    .parameter

    .prologue
    .line 560
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ar;->bYV:Lcom/tencent/mm/modelvoice/ap;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 2
    .parameter

    .prologue
    .line 563
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    const-string v1, "dkbt Recorder handleMessage"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 564
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ar;->bYV:Lcom/tencent/mm/modelvoice/ap;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/ap;->j(Lcom/tencent/mm/modelvoice/ap;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 570
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 567
    :cond_0
    #v0=(Boolean);v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/ar;->bYV:Lcom/tencent/mm/modelvoice/ap;

    invoke-virtual {v0, v1}, Lcom/tencent/mm/compatible/audio/d;->b(Lcom/tencent/mm/compatible/audio/i;)V

    .line 568
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->kC()V

    .line 569
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ar;->bYV:Lcom/tencent/mm/modelvoice/ap;

    const/16 v1, 0xc8

    #v1=(PosShort);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/modelvoice/ap;->aH(I)V

    goto :goto_0
.end method

*/}
