package com.tencent.mm.modelvoice; class m {/*

.class final Lcom/tencent/mm/modelvoice/m;
.super Ljava/lang/Thread;
.source "SourceFile"


# instance fields
.field final synthetic bXU:Lcom/tencent/mm/modelvoice/j;


# direct methods
.method private constructor <init>(Lcom/tencent/mm/modelvoice/j;)V
    .locals 0
    .parameter

    .prologue
    .line 705
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    #p0=(Reference);
    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/mm/modelvoice/j;B)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 705
    invoke-direct {p0, p1}, Lcom/tencent/mm/modelvoice/m;-><init>(Lcom/tencent/mm/modelvoice/j;)V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .prologue
    const/16 v6, 0xa

    #v6=(PosByte);
    const/4 v5, 0x0

    .line 708
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Null);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/j;->a(Lcom/tencent/mm/modelvoice/j;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_6

    .line 710
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v1=(Reference);
    monitor-enter v1

    .line 711
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/j;->b(Lcom/tencent/mm/modelvoice/j;)Z

    move-result v2

    .line 712
    #v2=(Boolean);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 713
    const-string v0, "MicroMsg.MediaRecorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v3, "ThreadAmr in :"

    #v3=(Reference);
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " cnt :"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/j;->c(Lcom/tencent/mm/modelvoice/j;)Ljava/util/concurrent/BlockingQueue;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/concurrent/BlockingQueue;->size()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 714
    if-eqz v2, :cond_0

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/j;->c(Lcom/tencent/mm/modelvoice/j;)Ljava/util/concurrent/BlockingQueue;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/BlockingQueue;->isEmpty()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_6

    .line 715
    :cond_0
    :try_start_1
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/j;->c(Lcom/tencent/mm/modelvoice/j;)Ljava/util/concurrent/BlockingQueue;

    move-result-object v0

    const-wide/16 v3, 0xc8

    #v3=(LongLo);v4=(LongHi);
    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v3, v4, v1}, Ljava/util/concurrent/BlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/modelvoice/k;
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0

    .line 725
    if-nez v0, :cond_1

    .line 726
    const-string v0, "MicroMsg.MediaRecorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "poll byte null file:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/j;->d(Lcom/tencent/mm/modelvoice/j;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 712
    :catchall_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    .line 722
    :catch_0
    #v0=(Conflicted);v2=(Boolean);
    move-exception v0

    #v0=(Reference);
    const-string v0, "MicroMsg.MediaRecorder"

    const-string v1, "ThreadAmr poll null"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 728
    :cond_1
    #v3=(LongLo);v4=(LongHi);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v3=(Reference);
    invoke-static {v3}, Lcom/tencent/mm/modelvoice/j;->c(Lcom/tencent/mm/modelvoice/j;)Ljava/util/concurrent/BlockingQueue;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/concurrent/BlockingQueue;->size()I

    move-result v3

    #v3=(Integer);
    invoke-static {v1, v3}, Lcom/tencent/mm/modelvoice/j;->a(Lcom/tencent/mm/modelvoice/j;I)I

    .line 729
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/j;->e(Lcom/tencent/mm/modelvoice/j;)I

    move-result v1

    #v1=(Integer);
    if-gt v1, v6, :cond_2

    if-eqz v2, :cond_5

    .line 730
    :cond_2
    const-string v1, "MicroMsg.MediaRecorder"

    #v1=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "speed up amrcodec queue:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v4}, Lcom/tencent/mm/modelvoice/j;->e(Lcom/tencent/mm/modelvoice/j;)I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " stop:"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 731
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v1, v5}, Lcom/tencent/mm/modelvoice/j;->b(Lcom/tencent/mm/modelvoice/j;I)I

    .line 735
    :cond_3
    :goto_1
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/modelvoice/j;->ze()Lcom/tencent/mm/modelvoice/l;

    move-result-object v1

    #v1=(Reference);
    iget v1, v1, Lcom/tencent/mm/modelvoice/l;->count:I

    #v1=(Integer);
    if-lt v1, v6, :cond_4

    invoke-static {}, Lcom/tencent/mm/modelvoice/j;->ze()Lcom/tencent/mm/modelvoice/l;

    move-result-object v1

    #v1=(Reference);
    iget-wide v1, v1, Lcom/tencent/mm/modelvoice/l;->bzF:J

    #v1=(LongLo);v2=(LongHi);
    const-wide/16 v3, 0xf0

    #v3=(LongLo);v4=(LongHi);
    cmp-long v1, v1, v3

    #v1=(Byte);
    if-lez v1, :cond_4

    .line 736
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v1=(Reference);
    invoke-static {v1, v5}, Lcom/tencent/mm/modelvoice/j;->b(Lcom/tencent/mm/modelvoice/j;I)I

    .line 738
    :cond_4
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/modelvoice/j;->f(Lcom/tencent/mm/modelvoice/j;)I

    move-result v2

    #v2=(Integer);
    invoke-static {v1, v0, v2}, Lcom/tencent/mm/modelvoice/j;->a(Lcom/tencent/mm/modelvoice/j;Lcom/tencent/mm/modelvoice/k;I)V

    goto/16 :goto_0

    .line 732
    :cond_5
    #v1=(Integer);v2=(Boolean);v3=(Integer);v4=(LongHi);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/j;->e(Lcom/tencent/mm/modelvoice/j;)I

    move-result v1

    #v1=(Integer);
    const/16 v2, 0x9

    #v2=(PosByte);
    if-ge v1, v2, :cond_3

    .line 733
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v1=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    invoke-static {v1, v2}, Lcom/tencent/mm/modelvoice/j;->b(Lcom/tencent/mm/modelvoice/j;I)I

    goto :goto_1

    .line 742
    :cond_6
    :try_start_2
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/j;->g(Lcom/tencent/mm/modelvoice/j;)Ljava/io/FileOutputStream;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 746
    :goto_2
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/j;->a(Lcom/tencent/mm/modelvoice/j;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_7

    .line 748
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/j;->h(Lcom/tencent/mm/modelvoice/j;)Lcom/tencent/mm/modelvoice/i;

    invoke-static {}, Lcom/tencent/mm/modelvoice/MediaRecorder;->zd()Z

    .line 749
    const-string v0, "MicroMsg.MediaRecorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "finish Thread :"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/j;->d(Lcom/tencent/mm/modelvoice/j;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 751
    :cond_7
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);
    return-void

    .line 743
    :catch_1
    move-exception v0

    .line 744
    #v0=(Reference);
    const-string v1, "MicroMsg.MediaRecorder"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "close amr file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/m;->bXU:Lcom/tencent/mm/modelvoice/j;

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/j;->d(Lcom/tencent/mm/modelvoice/j;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "msg:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2
.end method

*/}
