package com.tencent.mm.modelvoice; class q {/*

.class final Lcom/tencent/mm/modelvoice/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic bPW:Lcom/tencent/mm/storage/am;

.field final synthetic bYf:Lcom/tencent/mm/modelvoice/c;

.field final synthetic bYg:Lcom/tencent/mm/modelvoice/p;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/p;Lcom/tencent/mm/modelvoice/c;Lcom/tencent/mm/storage/am;)V
    .locals 0
    .parameter
    .parameter
    .parameter

    .prologue
    .line 75
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/q;->bYg:Lcom/tencent/mm/modelvoice/p;

    iput-object p2, p0, Lcom/tencent/mm/modelvoice/q;->bYf:Lcom/tencent/mm/modelvoice/c;

    iput-object p3, p0, Lcom/tencent/mm/modelvoice/q;->bPW:Lcom/tencent/mm/storage/am;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .prologue
    .line 79
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/q;->bYf:Lcom/tencent/mm/modelvoice/c;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/q;->bPW:Lcom/tencent/mm/storage/am;

    #v1=(Reference);
    invoke-interface {v0, v1}, Lcom/tencent/mm/modelvoice/c;->i(Lcom/tencent/mm/storage/am;)V

    .line 81
    return-void
.end method

*/}
