package com.tencent.mm.modelvoice; class bg {/*

.class public final Lcom/tencent/mm/modelvoice/bg;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private ah:Ljava/lang/String;

.field private bHB:Ljava/lang/String;

.field private bHx:I

.field private bPA:I

.field private bPE:I

.field private bWZ:I

.field private bXi:Ljava/lang/String;

.field private bXk:Ljava/lang/String;

.field private bXl:I

.field private bXo:J

.field private bXp:J

.field private bXs:I

.field private bYh:I

.field private bZx:I

.field private bnm:I

.field private status:I

.field private user:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    .prologue
    const-wide/16 v2, 0x0

    #v2=(LongLo);v3=(LongHi);
    const/4 v1, 0x0

    .line 213
    #v1=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 108
    #p0=(Reference);
    const/4 v0, -0x1

    #v0=(Byte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    .line 203
    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bYh:I

    .line 214
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->ah:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->user:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXk:Ljava/lang/String;

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bPA:I

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bWZ:I

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bXl:I

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bHx:I

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    iput-wide v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXo:J

    iput-wide v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXp:J

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bZx:I

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bPE:I

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXi:Ljava/lang/String;

    iput v1, p0, Lcom/tencent/mm/modelvoice/bg;->bXs:I

    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bHB:Ljava/lang/String;

    .line 215
    return-void
.end method


# virtual methods
.method public final F(J)V
    .locals 0
    .parameter

    .prologue
    .line 328
    iput-wide p1, p0, Lcom/tencent/mm/modelvoice/bg;->bXo:J

    .line 329
    return-void
.end method

.method public final G(J)V
    .locals 0
    .parameter

    .prologue
    .line 336
    iput-wide p1, p0, Lcom/tencent/mm/modelvoice/bg;->bXp:J

    .line 337
    return-void
.end method

.method public final a(Landroid/database/Cursor;)V
    .locals 2
    .parameter

    .prologue
    .line 169
    const/4 v0, 0x0

    #v0=(Null);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->ah:Ljava/lang/String;

    .line 170
    const/4 v0, 0x1

    #v0=(One);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->user:Ljava/lang/String;

    .line 171
    const/4 v0, 0x2

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bPA:I

    .line 172
    const/4 v0, 0x3

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bWZ:I

    .line 173
    const/4 v0, 0x4

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXl:I

    .line 174
    const/4 v0, 0x5

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bHx:I

    .line 175
    const/4 v0, 0x6

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    .line 176
    const/4 v0, 0x7

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXo:J

    .line 177
    const/16 v0, 0x8

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    #v0=(LongLo);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXp:J

    .line 178
    const/16 v0, 0x9

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXk:Ljava/lang/String;

    .line 179
    const/16 v0, 0xa

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bZx:I

    .line 180
    const/16 v0, 0xb

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bPE:I

    .line 181
    const/16 v0, 0xc

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXi:Ljava/lang/String;

    .line 182
    const/16 v0, 0xd

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    #v0=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXs:I

    .line 183
    const/16 v0, 0xe

    #v0=(PosByte);
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bHB:Ljava/lang/String;

    .line 184
    return-void
.end method

.method public final bM(I)V
    .locals 0
    .parameter

    .prologue
    .line 312
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bHx:I

    .line 313
    return-void
.end method

.method public final bO(I)V
    .locals 0
    .parameter

    .prologue
    .line 111
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    .line 112
    return-void
.end method

.method public final cA(I)V
    .locals 0
    .parameter

    .prologue
    .line 248
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bPE:I

    .line 249
    return-void
.end method

.method public final cC(I)V
    .locals 0
    .parameter

    .prologue
    .line 288
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bPA:I

    .line 289
    return-void
.end method

.method public final cy(I)V
    .locals 0
    .parameter

    .prologue
    .line 344
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bXs:I

    .line 345
    return-void
.end method

.method public final dE(I)V
    .locals 0
    .parameter

    .prologue
    .line 210
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bYh:I

    .line 211
    return-void
.end method

.method public final dF(I)V
    .locals 0
    .parameter

    .prologue
    .line 256
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bZx:I

    .line 257
    return-void
.end method

.method public final dx(I)V
    .locals 0
    .parameter

    .prologue
    .line 296
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bWZ:I

    .line 297
    return-void
.end method

.method public final dy(I)V
    .locals 0
    .parameter

    .prologue
    .line 304
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->bXl:I

    .line 305
    return-void
.end method

.method public final gA(Ljava/lang/String;)V
    .locals 0
    .parameter

    .prologue
    .line 240
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bg;->bXi:Ljava/lang/String;

    .line 241
    return-void
.end method

.method public final gV(Ljava/lang/String;)V
    .locals 0
    .parameter

    .prologue
    .line 280
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bg;->bXk:Ljava/lang/String;

    .line 281
    return-void
.end method

.method public final getFileName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 260
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getStatus()I
    .locals 1

    .prologue
    .line 316
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    #v0=(Integer);
    return v0
.end method

.method public final getUser()Ljava/lang/String;
    .locals 1

    .prologue
    .line 268
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->user:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final gz(Ljava/lang/String;)V
    .locals 0
    .parameter

    .prologue
    .line 264
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bg;->ah:Ljava/lang/String;

    .line 265
    return-void
.end method

.method public final jA()Landroid/content/ContentValues;
    .locals 4

    .prologue
    .line 119
    new-instance v0, Landroid/content/ContentValues;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 120
    #v0=(Reference);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit8 v1, v1, 0x1

    if-eqz v1, :cond_0

    .line 121
    const-string v1, "FileName"

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bg;->ah:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 123
    :cond_0
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit8 v1, v1, 0x2

    if-eqz v1, :cond_1

    .line 124
    const-string v1, "User"

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bg;->user:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 126
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit8 v1, v1, 0x4

    if-eqz v1, :cond_2

    .line 127
    const-string v1, "MsgId"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->bPA:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 129
    :cond_2
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit8 v1, v1, 0x8

    if-eqz v1, :cond_3

    .line 130
    const-string v1, "NetOffset"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->bWZ:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 132
    :cond_3
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit8 v1, v1, 0x10

    if-eqz v1, :cond_4

    .line 133
    const-string v1, "FileNowSize"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXl:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 135
    :cond_4
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit8 v1, v1, 0x20

    if-eqz v1, :cond_5

    .line 136
    const-string v1, "TotalLen"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->bHx:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 138
    :cond_5
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit8 v1, v1, 0x40

    if-eqz v1, :cond_6

    .line 139
    const-string v1, "Status"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 141
    :cond_6
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x80

    if-eqz v1, :cond_7

    .line 142
    const-string v1, "CreateTime"

    #v1=(Reference);
    iget-wide v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXo:J

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 144
    :cond_7
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x100

    if-eqz v1, :cond_8

    .line 145
    const-string v1, "LastModifyTime"

    #v1=(Reference);
    iget-wide v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXp:J

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 147
    :cond_8
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x200

    if-eqz v1, :cond_9

    .line 148
    const-string v1, "ClientId"

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXk:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 150
    :cond_9
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x400

    if-eqz v1, :cond_a

    .line 151
    const-string v1, "VoiceLength"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->bZx:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 153
    :cond_a
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x800

    if-eqz v1, :cond_b

    .line 154
    const-string v1, "MsgLocalId"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->bPE:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 156
    :cond_b
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x1000

    if-eqz v1, :cond_c

    .line 157
    const-string v1, "Human"

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXi:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 159
    :cond_c
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x2000

    if-eqz v1, :cond_d

    .line 160
    const-string v1, "reserved1"

    #v1=(Reference);
    iget v2, p0, Lcom/tencent/mm/modelvoice/bg;->bXs:I

    #v2=(Integer);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 162
    :cond_d
    #v1=(Conflicted);v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v1=(Integer);
    and-int/lit16 v1, v1, 0x4000

    if-eqz v1, :cond_e

    .line 163
    const-string v1, "reserved2"

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bg;->bHB:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 165
    :cond_e
    #v1=(Conflicted);v2=(Conflicted);
    return-object v0
.end method

.method public final qU()I
    .locals 1

    .prologue
    .line 308
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bHx:I

    #v0=(Integer);
    return v0
.end method

.method public final qX()I
    .locals 1

    .prologue
    .line 115
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bnm:I

    #v0=(Integer);
    return v0
.end method

.method public final setStatus(I)V
    .locals 0
    .parameter

    .prologue
    .line 320
    iput p1, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    .line 321
    return-void
.end method

.method public final setUser(Ljava/lang/String;)V
    .locals 0
    .parameter

    .prologue
    .line 272
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bg;->user:Ljava/lang/String;

    .line 273
    return-void
.end method

.method public final vD()I
    .locals 1

    .prologue
    .line 244
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bPE:I

    #v0=(Integer);
    return v0
.end method

.method public final vF()I
    .locals 1

    .prologue
    .line 284
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bPA:I

    #v0=(Integer);
    return v0
.end method

.method public final yD()Ljava/lang/String;
    .locals 1

    .prologue
    .line 236
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXi:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final yE()I
    .locals 1

    .prologue
    .line 292
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bWZ:I

    #v0=(Integer);
    return v0
.end method

.method public final yF()I
    .locals 1

    .prologue
    .line 300
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXl:I

    #v0=(Integer);
    return v0
.end method

.method public final yI()J
    .locals 2

    .prologue
    .line 324
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXo:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final yJ()J
    .locals 2

    .prologue
    .line 332
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXp:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method public final yM()I
    .locals 1

    .prologue
    .line 340
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXs:I

    #v0=(Integer);
    return v0
.end method

.method public final zt()Z
    .locals 2

    .prologue
    .line 39
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    #v0=(Integer);
    const/4 v1, 0x5

    #v1=(PosByte);
    if-eq v0, v1, :cond_0

    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    const/4 v1, 0x6

    if-ne v0, v1, :cond_1

    .line 40
    :cond_0
    const/4 v0, 0x1

    .line 42
    :goto_0
    #v0=(Boolean);
    return v0

    :cond_1
    #v0=(Integer);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final zu()Z
    .locals 3

    .prologue
    const/4 v0, 0x1

    .line 46
    #v0=(One);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    #v1=(Integer);
    if-le v1, v0, :cond_0

    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    const/4 v2, 0x3

    #v2=(PosByte);
    if-le v1, v2, :cond_1

    :cond_0
    #v2=(Conflicted);
    iget v1, p0, Lcom/tencent/mm/modelvoice/bg;->status:I

    const/16 v2, 0x8

    #v2=(PosByte);
    if-ne v1, v2, :cond_2

    .line 49
    :cond_1
    :goto_0
    #v0=(Boolean);
    return v0

    :cond_2
    #v0=(One);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final zv()I
    .locals 1

    .prologue
    .line 206
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bYh:I

    #v0=(Integer);
    return v0
.end method

.method public final zw()I
    .locals 1

    .prologue
    .line 252
    iget v0, p0, Lcom/tencent/mm/modelvoice/bg;->bZx:I

    #v0=(Integer);
    return v0
.end method

.method public final zx()Ljava/lang/String;
    .locals 1

    .prologue
    .line 276
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bg;->bXk:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

*/}
