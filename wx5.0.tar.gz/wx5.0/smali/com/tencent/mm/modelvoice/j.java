package com.tencent.mm.modelvoice; class j {/*

.class public final Lcom/tencent/mm/modelvoice/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static bXS:Lcom/tencent/mm/modelvoice/l;


# instance fields
.field private bXR:Lcom/tencent/mm/modelvoice/i;

.field private bXT:Lcom/tencent/mm/modelvoice/m;

.field private bzA:I

.field private bzB:I

.field private bzu:Ljava/util/concurrent/BlockingQueue;

.field private bzv:Z

.field private bzw:Ljava/io/FileOutputStream;

.field private bzx:Ljava/lang/String;

.field private bzy:I

.field private bzz:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 701
    new-instance v0, Lcom/tencent/mm/modelvoice/l;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/l;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/modelvoice/j;->bXS:Lcom/tencent/mm/modelvoice/l;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 570
    #v2=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 583
    #p0=(Reference);
    new-instance v0, Ljava/util/concurrent/ArrayBlockingQueue;

    #v0=(UninitRef);
    const/16 v1, 0x400

    #v1=(PosShort);
    invoke-direct {v0, v1}, Ljava/util/concurrent/ArrayBlockingQueue;-><init>(I)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bzu:Ljava/util/concurrent/BlockingQueue;

    .line 584
    iput-boolean v2, p0, Lcom/tencent/mm/modelvoice/j;->bzv:Z

    .line 590
    new-instance v0, Lcom/tencent/mm/modelvoice/i;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/i;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXR:Lcom/tencent/mm/modelvoice/i;

    .line 640
    iput-boolean v2, p0, Lcom/tencent/mm/modelvoice/j;->bzz:Z

    .line 686
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/mm/modelvoice/j;->bzA:I

    .line 687
    iput v2, p0, Lcom/tencent/mm/modelvoice/j;->bzB:I

    .line 703
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXT:Lcom/tencent/mm/modelvoice/m;

    .line 705
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/j;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 570
    iput p1, p0, Lcom/tencent/mm/modelvoice/j;->bzB:I

    return p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/j;Lcom/tencent/mm/modelvoice/k;I)V
    .locals 8
    .parameter
    .parameter
    .parameter

    .prologue
    .line 570
    new-instance v0, Lcom/tencent/mm/pointers/PByteArray;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/pointers/PByteArray;-><init>()V

    #v0=(Reference);
    new-instance v1, Lcom/tencent/mm/compatible/f/k;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/j;->bXR:Lcom/tencent/mm/modelvoice/i;

    #v2=(Reference);
    iget-object v3, p1, Lcom/tencent/mm/modelvoice/k;->buf:[B

    #v3=(Reference);
    iget v4, p1, Lcom/tencent/mm/modelvoice/k;->bzE:I

    #v4=(Integer);
    invoke-virtual {v2, v3, v4, v0, p2}, Lcom/tencent/mm/modelvoice/i;->a([BILcom/tencent/mm/pointers/PByteArray;I)I

    move-result v2

    #v2=(Integer);
    if-gez v2, :cond_0

    const-string v0, "MicroMsg.MediaRecorder"

    const-string v1, "pcm2amr failed, native failed"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    #v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-void

    :cond_0
    #v2=(Integer);v4=(Integer);v5=(Uninit);v6=(Uninit);v7=(Uninit);
    invoke-virtual {v1}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    const/4 v3, 0x1

    #v3=(One);
    if-ne p2, v3, :cond_1

    sget-object v3, Lcom/tencent/mm/modelvoice/j;->bXS:Lcom/tencent/mm/modelvoice/l;

    #v3=(Reference);
    iget-wide v4, v3, Lcom/tencent/mm/modelvoice/l;->bzF:J

    #v4=(LongLo);v5=(LongHi);
    iget v6, v3, Lcom/tencent/mm/modelvoice/l;->count:I

    #v6=(Integer);
    int-to-long v6, v6

    #v6=(LongLo);v7=(LongHi);
    mul-long/2addr v4, v6

    add-long/2addr v4, v1

    iget v6, v3, Lcom/tencent/mm/modelvoice/l;->count:I

    #v6=(Integer);
    add-int/lit8 v6, v6, 0x1

    int-to-long v6, v6

    #v6=(LongLo);
    div-long/2addr v4, v6

    iput-wide v4, v3, Lcom/tencent/mm/modelvoice/l;->bzF:J

    iget v4, v3, Lcom/tencent/mm/modelvoice/l;->count:I

    #v4=(Integer);
    add-int/lit8 v4, v4, 0x1

    iput v4, v3, Lcom/tencent/mm/modelvoice/l;->count:I

    :cond_1
    #v3=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    const-string v3, "MicroMsg.MediaRecorder"

    #v3=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "append2amrfile AmrTime:"

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    invoke-virtual {v4, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    #v1=(Reference);
    const-string v2, " useFloat:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " nowqueue:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/tencent/mm/modelvoice/j;->bzB:I

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " avg:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Lcom/tencent/mm/modelvoice/j;->bXS:Lcom/tencent/mm/modelvoice/l;

    iget-wide v4, v2, Lcom/tencent/mm/modelvoice/l;->bzF:J

    #v4=(LongLo);v5=(LongHi);
    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " cnt:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v2, Lcom/tencent/mm/modelvoice/j;->bXS:Lcom/tencent/mm/modelvoice/l;

    iget v2, v2, Lcom/tencent/mm/modelvoice/l;->count:I

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/j;->bzw:Ljava/io/FileOutputStream;

    iget-object v0, v0, Lcom/tencent/mm/pointers/PByteArray;->value:[B

    invoke-virtual {v1, v0}, Ljava/io/FileOutputStream;->write([B)V

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bzw:Ljava/io/FileOutputStream;

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->flush()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    const-string v0, "MicroMsg.MediaRecorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Write File Error file:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/j;->bzx:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/j;)Z
    .locals 1
    .parameter

    .prologue
    .line 570
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/j;->bzz:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/j;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 570
    iput p1, p0, Lcom/tencent/mm/modelvoice/j;->bzA:I

    return p1
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/j;)Z
    .locals 1
    .parameter

    .prologue
    .line 570
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/j;->bzv:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/j;)Ljava/util/concurrent/BlockingQueue;
    .locals 1
    .parameter

    .prologue
    .line 570
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bzu:Ljava/util/concurrent/BlockingQueue;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/j;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 570
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bzx:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic e(Lcom/tencent/mm/modelvoice/j;)I
    .locals 1
    .parameter

    .prologue
    .line 570
    iget v0, p0, Lcom/tencent/mm/modelvoice/j;->bzB:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic f(Lcom/tencent/mm/modelvoice/j;)I
    .locals 1
    .parameter

    .prologue
    .line 570
    iget v0, p0, Lcom/tencent/mm/modelvoice/j;->bzA:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic g(Lcom/tencent/mm/modelvoice/j;)Ljava/io/FileOutputStream;
    .locals 1
    .parameter

    .prologue
    .line 570
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bzw:Ljava/io/FileOutputStream;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic h(Lcom/tencent/mm/modelvoice/j;)Lcom/tencent/mm/modelvoice/i;
    .locals 1
    .parameter

    .prologue
    .line 570
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXR:Lcom/tencent/mm/modelvoice/i;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic ze()Lcom/tencent/mm/modelvoice/l;
    .locals 1

    .prologue
    .line 570
    sget-object v0, Lcom/tencent/mm/modelvoice/j;->bXS:Lcom/tencent/mm/modelvoice/l;

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final c(ILjava/lang/String;)Z
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 593
    #v0=(Null);
    if-nez p2, :cond_0

    .line 610
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 597
    :cond_0
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    iput p1, p0, Lcom/tencent/mm/modelvoice/j;->bzy:I

    .line 598
    iput-object p2, p0, Lcom/tencent/mm/modelvoice/j;->bzx:Ljava/lang/String;

    .line 599
    const-wide/16 v1, 0x0

    #v1=(LongLo);v2=(LongHi);
    invoke-static {v1, v2}, Lcom/tencent/mm/modelvoice/MediaRecorder;->I(J)J

    .line 601
    :try_start_0
    new-instance v1, Ljava/io/FileOutputStream;

    #v1=(UninitRef);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/j;->bzx:Ljava/lang/String;

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iput-object v1, p0, Lcom/tencent/mm/modelvoice/j;->bzw:Ljava/io/FileOutputStream;

    .line 602
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/j;->bzw:Ljava/io/FileOutputStream;

    const-string v2, "#!AMR\n"

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/io/FileOutputStream;->write([B)V

    .line 603
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/j;->bzw:Ljava/io/FileOutputStream;

    invoke-virtual {v1}, Ljava/io/FileOutputStream;->flush()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 609
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXR:Lcom/tencent/mm/modelvoice/i;

    #v0=(Reference);
    iget v1, p0, Lcom/tencent/mm/modelvoice/j;->bzy:I

    #v1=(Integer);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/modelvoice/i;->dD(I)Z

    .line 610
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0

    .line 604
    :catch_0
    #v0=(Null);v1=(Conflicted);v2=(Conflicted);
    move-exception v1

    .line 605
    #v1=(Reference);
    const-string v2, "MicroMsg.MediaRecorder"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "init Amr out file Error"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public final e([BI)V
    .locals 4
    .parameter
    .parameter

    .prologue
    .line 614
    const-string v0, "MicroMsg.MediaRecorder"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "push into queue queueLen:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/j;->bzu:Ljava/util/concurrent/BlockingQueue;

    invoke-interface {v2}, Ljava/util/concurrent/BlockingQueue;->size()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " buf:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 615
    invoke-static {}, Lcom/tencent/mm/modelvoice/MediaRecorder;->zb()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    int-to-long v2, p2

    #v2=(LongLo);v3=(LongHi);
    add-long/2addr v0, v2

    invoke-static {v0, v1}, Lcom/tencent/mm/modelvoice/MediaRecorder;->I(J)J

    .line 616
    if-gtz p2, :cond_0

    .line 624
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 619
    :cond_0
    #v0=(LongLo);v1=(LongHi);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXT:Lcom/tencent/mm/modelvoice/m;

    #v0=(Reference);
    if-nez v0, :cond_1

    .line 620
    new-instance v0, Lcom/tencent/mm/modelvoice/m;

    #v0=(UninitRef);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-direct {v0, p0, v1}, Lcom/tencent/mm/modelvoice/m;-><init>(Lcom/tencent/mm/modelvoice/j;B)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXT:Lcom/tencent/mm/modelvoice/m;

    .line 621
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXT:Lcom/tencent/mm/modelvoice/m;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/m;->start()V

    .line 623
    :cond_1
    #v1=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bzu:Ljava/util/concurrent/BlockingQueue;

    new-instance v1, Lcom/tencent/mm/modelvoice/k;

    #v1=(UninitRef);
    invoke-direct {v1, p1, p2}, Lcom/tencent/mm/modelvoice/k;-><init>([BI)V

    #v1=(Reference);
    invoke-interface {v0, v1}, Ljava/util/concurrent/BlockingQueue;->add(Ljava/lang/Object;)Z

    goto :goto_0
.end method

.method public final kV()Z
    .locals 2

    .prologue
    .line 627
    const-string v0, "MicroMsg.MediaRecorder"

    #v0=(Reference);
    const-string v1, "wait finish"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 629
    monitor-enter p0

    .line 630
    const/4 v0, 0x1

    :try_start_0
    #v0=(One);
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/j;->bzv:Z

    .line 631
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 633
    :try_start_1
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/j;->bXT:Lcom/tencent/mm/modelvoice/m;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/m;->join()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0

    .line 635
    :goto_0
    const/4 v0, 0x0

    #v0=(Null);
    return v0

    .line 631
    :catchall_0
    #v0=(One);
    move-exception v0

    #v0=(Reference);
    monitor-exit p0

    throw v0

    :catch_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    goto :goto_0
.end method

*/}
