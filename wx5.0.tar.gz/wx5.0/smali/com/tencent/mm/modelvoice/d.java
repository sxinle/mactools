package com.tencent.mm.modelvoice; class d {/*

.class public interface abstract Lcom/tencent/mm/modelvoice/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lcom/tencent/mm/modelvoice/e;)V
.end method

.method public abstract a(Lcom/tencent/mm/modelvoice/f;)V
.end method

.method public abstract getStatus()I
.end method

.method public abstract isPlaying()Z
.end method

.method public abstract kR()Z
.end method

.method public abstract l(Ljava/lang/String;Z)Z
.end method

.method public abstract p(Z)V
.end method

.method public abstract pause()Z
.end method

.method public abstract rH()Z
.end method

*/}
