package com.tencent.mm.modelvoice; class s {/*

.class public final Lcom/tencent/mm/modelvoice/s;
.super Lcom/tencent/mm/o/x;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/network/aa;


# instance fields
.field private ah:Ljava/lang/String;

.field private bFU:Lcom/tencent/mm/o/m;

.field private bGI:Lcom/tencent/mm/o/a;

.field bGV:Lcom/tencent/mm/sdk/platformtools/ax;

.field private bWS:I

.field private bXA:I

.field private bYd:Z

.field private bYh:I

.field private bYi:J

.field private bYj:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1
    .parameter

    .prologue
    .line 52
    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0, p1, v0}, Lcom/tencent/mm/modelvoice/s;-><init>(Ljava/lang/String;I)V

    .line 53
    #p0=(Reference);
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 4
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    .line 55
    #v1=(Null);
    invoke-direct {p0}, Lcom/tencent/mm/o/x;-><init>()V

    .line 43
    #p0=(Reference);
    iput v1, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    .line 49
    iput v1, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    .line 62
    iput-boolean v1, p0, Lcom/tencent/mm/modelvoice/s;->bYd:Z

    .line 63
    iput v1, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    .line 305
    new-instance v2, Lcom/tencent/mm/sdk/platformtools/ax;

    #v2=(UninitRef);
    new-instance v3, Lcom/tencent/mm/modelvoice/t;

    #v3=(UninitRef);
    invoke-direct {v3, p0}, Lcom/tencent/mm/modelvoice/t;-><init>(Lcom/tencent/mm/modelvoice/s;)V

    #v3=(Reference);
    invoke-direct {v2, v3, v0}, Lcom/tencent/mm/sdk/platformtools/ax;-><init>(Lcom/tencent/mm/sdk/platformtools/ay;Z)V

    #v2=(Reference);
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/s;->bGV:Lcom/tencent/mm/sdk/platformtools/ax;

    .line 56
    if-eqz p1, :cond_0

    :goto_0
    #v0=(Boolean);
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 57
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "NetSceneUploadVoice:  file:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    .line 59
    iput p2, p0, Lcom/tencent/mm/modelvoice/s;->bYh:I

    .line 60
    return-void

    :cond_0
    #v0=(One);v1=(Null);
    move v0, v1

    .line 56
    #v0=(Null);
    goto :goto_0
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/s;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 26
    iput p1, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    return p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/s;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/s;)Lcom/tencent/mm/o/m;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/s;)J
    .locals 2
    .parameter

    .prologue
    .line 26
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/s;->bYi:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/s;)Lcom/tencent/mm/network/q;
    .locals 1
    .parameter

    .prologue
    .line 26
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/s;->rQ()Lcom/tencent/mm/network/q;

    move-result-object v0

    #v0=(Reference);
    return-object v0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/network/q;Lcom/tencent/mm/o/m;)I
    .locals 10
    .parameter
    .parameter

    .prologue
    const/16 v9, 0x1770

    #v9=(PosShort);
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v3, 0x1

    #v3=(One);
    const/4 v4, -0x1

    .line 68
    #v4=(Byte);
    iput-object p2, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    .line 69
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/s;->bYd:Z

    .line 70
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    #v1=(Reference);
    if-nez v1, :cond_0

    .line 71
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    const-string v1, "doScene:  filename null!"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 72
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 217
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return v0

    .line 76
    :cond_0
    #v0=(Null);v1=(Reference);v2=(Uninit);v3=(One);v4=(Byte);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2, v1}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v6

    .line 77
    #v6=(Reference);
    if-eqz v6, :cond_1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->zu()Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_2

    .line 78
    :cond_1
    #v1=(Conflicted);
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Get info Failed file:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 80
    #v0=(Byte);
    goto :goto_0

    .line 83
    :cond_2
    #v0=(Null);v1=(Boolean);
    const-string v1, "MicroMsg.NetSceneUploadVoice"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v5, "doScene file:"

    #v5=(Reference);
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " netTimes:"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yM()I

    move-result v5

    #v5=(Integer);
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->gW(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_3

    .line 85
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "checkVoiceNetTimes Failed file:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 86
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 87
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 88
    #v0=(Byte);
    goto/16 :goto_0

    .line 91
    :cond_3
    #v0=(Null);v1=(Boolean);
    new-instance v1, Lcom/tencent/mm/modelvoice/u;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/modelvoice/u;-><init>()V

    .line 95
    #v1=(Reference);
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    #v2=(Integer);
    const/16 v5, 0x8

    #v5=(PosByte);
    if-ne v2, v5, :cond_4

    .line 97
    const-string v2, "MicroMsg.NetSceneUploadVoice"

    #v2=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    #v4=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " cancelFlag = 1"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    .line 100
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/bh;->hd(Ljava/lang/String;)Z

    move v2, v3

    #v2=(One);
    move-object v4, v1

    move v1, v0

    .line 175
    :goto_1
    #v1=(Integer);v2=(Boolean);v5=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->zw()I

    move-result v0

    .line 176
    #v0=(Integer);
    if-nez v0, :cond_10

    .line 177
    iget v0, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    add-int/lit8 v0, v0, -0x6

    div-int/lit8 v0, v0, 0x20

    mul-int/lit8 v0, v0, 0x14

    move v5, v0

    .line 180
    :goto_2
    #v5=(Integer);
    new-instance v0, Lcom/tencent/mm/o/b;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/o/b;-><init>()V

    .line 181
    #v0=(Reference);
    new-instance v7, Lcom/tencent/mm/protocal/a/vt;

    #v7=(UninitRef);
    invoke-direct {v7}, Lcom/tencent/mm/protocal/a/vt;-><init>()V

    #v7=(Reference);
    invoke-virtual {v0, v7}, Lcom/tencent/mm/o/b;->a(Lcom/tencent/mm/al/a;)V

    .line 182
    new-instance v7, Lcom/tencent/mm/protocal/a/vu;

    #v7=(UninitRef);
    invoke-direct {v7}, Lcom/tencent/mm/protocal/a/vu;-><init>()V

    #v7=(Reference);
    invoke-virtual {v0, v7}, Lcom/tencent/mm/o/b;->b(Lcom/tencent/mm/al/a;)V

    .line 183
    const-string v7, "/cgi-bin/micromsg-bin/uploadvoice"

    invoke-virtual {v0, v7}, Lcom/tencent/mm/o/b;->ee(Ljava/lang/String;)V

    .line 184
    const/16 v7, 0x7f

    #v7=(PosByte);
    invoke-virtual {v0, v7}, Lcom/tencent/mm/o/b;->bQ(I)V

    .line 185
    const/16 v7, 0x13

    invoke-virtual {v0, v7}, Lcom/tencent/mm/o/b;->bR(I)V

    .line 186
    const v7, 0x3b9aca13

    #v7=(Integer);
    invoke-virtual {v0, v7}, Lcom/tencent/mm/o/b;->bS(I)V

    .line 187
    invoke-virtual {v0}, Lcom/tencent/mm/o/b;->rA()Lcom/tencent/mm/o/a;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/s;->bGI:Lcom/tencent/mm/o/a;

    .line 189
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->bGI:Lcom/tencent/mm/o/a;

    invoke-virtual {v0}, Lcom/tencent/mm/o/a;->ru()Lcom/tencent/mm/al/a;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/protocal/a/vt;

    .line 191
    invoke-static {}, Lcom/tencent/mm/model/s;->ow()Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    iput-object v7, v0, Lcom/tencent/mm/protocal/a/vt;->eDV:Ljava/lang/String;

    .line 192
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v7

    iput-object v7, v0, Lcom/tencent/mm/protocal/a/vt;->eDX:Ljava/lang/String;

    .line 193
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v7

    #v7=(Integer);
    iput v7, v0, Lcom/tencent/mm/protocal/a/vt;->eEL:I

    .line 194
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->zx()Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    iput-object v7, v0, Lcom/tencent/mm/protocal/a/vt;->eDZ:Ljava/lang/String;

    .line 195
    iput v5, v0, Lcom/tencent/mm/protocal/a/vt;->eIJ:I

    .line 196
    iget v5, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    iput v5, v0, Lcom/tencent/mm/protocal/a/vt;->eER:I

    .line 197
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v5

    iput v5, v0, Lcom/tencent/mm/protocal/a/vt;->eDx:I

    .line 198
    iput v2, v0, Lcom/tencent/mm/protocal/a/vt;->eEN:I

    .line 199
    iget v5, p0, Lcom/tencent/mm/modelvoice/s;->bYh:I

    iput v5, v0, Lcom/tencent/mm/protocal/a/vt;->fbg:I

    .line 200
    invoke-static {}, Lcom/tencent/mm/model/bv;->qj()Ljava/lang/String;

    move-result-object v5

    #v5=(Reference);
    iput-object v5, v0, Lcom/tencent/mm/protocal/a/vt;->eDG:Ljava/lang/String;

    .line 201
    iput v1, v0, Lcom/tencent/mm/protocal/a/vt;->fbe:I

    .line 203
    if-eq v2, v3, :cond_f

    .line 204
    new-instance v1, Lcom/tencent/mm/protocal/a/ps;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/protocal/a/ps;-><init>()V

    #v1=(Reference);
    iget-object v3, v4, Lcom/tencent/mm/modelvoice/u;->buf:[B

    #v3=(Reference);
    iget v5, v4, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v5=(Integer);
    invoke-virtual {v1, v3, v5}, Lcom/tencent/mm/protocal/a/ps;->i([BI)Lcom/tencent/mm/protocal/a/ps;

    move-result-object v1

    .line 205
    iput-object v1, v0, Lcom/tencent/mm/protocal/a/vt;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    .line 206
    iget v1, v4, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v1=(Integer);
    iput v1, v0, Lcom/tencent/mm/protocal/a/vt;->eEP:I

    .line 212
    :goto_3
    #v1=(Conflicted);v3=(Conflicted);v5=(Conflicted);
    const-string v1, "MicroMsg.NetSceneUploadVoice"

    #v1=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v5, "cancelFlag:"

    #v5=(Reference);
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " endFlag:"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v5, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    #v5=(Integer);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " svrId:"

    #v5=(Reference);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v5

    #v5=(Integer);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 213
    const-string v1, "MicroMsg.NetSceneUploadVoice"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v5, "doscene msgId:"

    #v5=(Reference);
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget v5, v0, Lcom/tencent/mm/protocal/a/vt;->eDx:I

    #v5=(Integer);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " user:"

    #v5=(Reference);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, v0, Lcom/tencent/mm/protocal/a/vt;->eDX:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " offset:"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v5, v0, Lcom/tencent/mm/protocal/a/vt;->eEL:I

    #v5=(Integer);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " dataLen:"

    #v5=(Reference);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, v0, Lcom/tencent/mm/protocal/a/vt;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    invoke-virtual {v5}, Lcom/tencent/mm/protocal/a/ps;->anY()I

    move-result v5

    #v5=(Integer);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " endFlag:"

    #v5=(Reference);
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v0, v0, Lcom/tencent/mm/protocal/a/vt;->eER:I

    #v0=(Integer);
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 214
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v3, "doScene MsgId:"

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " file:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " readBytes:"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v3, v4, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " neTTTOff:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " neWWWOff:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v3, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " endFlag:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v3, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " cancelFlag:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " status:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 216
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/s;->bYi:J

    .line 217
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->bGI:Lcom/tencent/mm/o/a;

    #v0=(Reference);
    invoke-virtual {p0, p1, v0, p0}, Lcom/tencent/mm/modelvoice/s;->a(Lcom/tencent/mm/network/q;Lcom/tencent/mm/network/ai;Lcom/tencent/mm/network/aa;)I

    move-result v0

    #v0=(Integer);
    goto/16 :goto_0

    .line 106
    :cond_4
    #v0=(Null);v1=(Reference);v3=(One);v4=(Byte);v5=(PosByte);v7=(Uninit);v8=(Uninit);
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v1

    #v1=(Integer);
    const/4 v2, 0x3

    #v2=(PosByte);
    if-ne v1, v2, :cond_5

    .line 107
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/s;->bYd:Z

    .line 110
    :cond_5
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->gY(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/b;

    move-result-object v2

    .line 111
    #v2=(Reference);
    if-nez v2, :cond_6

    .line 112
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 113
    #v0=(Byte);
    goto/16 :goto_0

    .line 116
    :cond_6
    #v0=(Null);
    invoke-interface {v2}, Lcom/tencent/mm/modelvoice/b;->getFormat()I

    move-result v1

    .line 118
    #v1=(Integer);
    const-string v5, "MicroMsg.NetSceneUploadVoice"

    #v5=(Reference);
    new-instance v7, Ljava/lang/StringBuilder;

    #v7=(UninitRef);
    const-string v8, "format "

    #v8=(Reference);
    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v7=(Reference);
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 120
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v5

    #v5=(Integer);
    invoke-interface {v2, v5, v9}, Lcom/tencent/mm/modelvoice/b;->C(II)Lcom/tencent/mm/modelvoice/u;

    move-result-object v2

    .line 121
    if-nez v2, :cond_7

    .line 122
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 123
    #v0=(Byte);
    goto/16 :goto_0

    .line 126
    :cond_7
    #v0=(Null);
    const-string v5, "MicroMsg.NetSceneUploadVoice"

    #v5=(Reference);
    new-instance v7, Ljava/lang/StringBuilder;

    #v7=(UninitRef);
    const-string v8, "doScene READ file["

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v7=(Reference);
    iget-object v8, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "] read ret:"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget v8, v2, Lcom/tencent/mm/modelvoice/u;->ret:I

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " readlen:"

    #v8=(Reference);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget v8, v2, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " newOff:"

    #v8=(Reference);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget v8, v2, Lcom/tencent/mm/modelvoice/u;->bXA:I

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " netOff:"

    #v8=(Reference);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v8

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " line:"

    #v8=(Reference);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v8

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 128
    iget v5, v2, Lcom/tencent/mm/modelvoice/u;->ret:I

    #v5=(Integer);
    if-gez v5, :cond_8

    .line 129
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v3, "Err doScene READ file["

    #v3=(Reference);
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "] read ret:"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v3, v2, Lcom/tencent/mm/modelvoice/u;->ret:I

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " readlen:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v3, v2, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " newOff:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, v2, Lcom/tencent/mm/modelvoice/u;->bXA:I

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " netOff:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 130
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 131
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 132
    #v0=(Byte);
    goto/16 :goto_0

    .line 135
    :cond_8
    #v0=(Null);v1=(Integer);v2=(Reference);v3=(One);
    iget v5, v2, Lcom/tencent/mm/modelvoice/u;->bXA:I

    iput v5, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    .line 137
    iget v5, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v7

    #v7=(Integer);
    if-lt v5, v7, :cond_9

    iget v5, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    const v7, 0x72808

    if-lt v5, v7, :cond_a

    .line 138
    :cond_9
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Err doScene READ file["

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "] newOff:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " OldtOff:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 139
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 140
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 141
    #v0=(Byte);
    goto/16 :goto_0

    .line 144
    :cond_a
    #v0=(Null);v1=(Integer);v2=(Reference);
    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    .line 145
    iget v5, v2, Lcom/tencent/mm/modelvoice/u;->bzE:I

    if-nez v5, :cond_b

    .line 146
    iget-boolean v5, p0, Lcom/tencent/mm/modelvoice/s;->bYd:Z

    #v5=(Boolean);
    if-nez v5, :cond_b

    .line 147
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "doScene:  file:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " No Data temperature , will be retry"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 150
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 151
    #v0=(Byte);
    goto/16 :goto_0

    .line 155
    :cond_b
    #v0=(Null);v1=(Integer);v5=(Integer);
    iget-boolean v5, p0, Lcom/tencent/mm/modelvoice/s;->bYd:Z

    #v5=(Boolean);
    if-eqz v5, :cond_e

    .line 156
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v5

    #v5=(Integer);
    if-gtz v5, :cond_c

    .line 157
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Err doScene READ file["

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "] read totalLen:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 158
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 159
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 160
    #v0=(Byte);
    goto/16 :goto_0

    .line 163
    :cond_c
    #v0=(Null);v1=(Integer);v2=(Reference);
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v5

    iget v7, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    if-le v5, v7, :cond_d

    iget v5, v2, Lcom/tencent/mm/modelvoice/u;->bzE:I

    if-ge v5, v9, :cond_d

    .line 164
    const-string v0, "MicroMsg.NetSceneUploadVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v3, "Err doScene READ file["

    #v3=(Reference);
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "] readlen:"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v3, v2, Lcom/tencent/mm/modelvoice/u;->bzE:I

    #v3=(Integer);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " newOff:"

    #v3=(Reference);
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, v2, Lcom/tencent/mm/modelvoice/u;->bXA:I

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " netOff:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " totalLen:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 165
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 166
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lA()I

    move-result v0

    #v0=(Integer);
    add-int/lit16 v0, v0, 0x2710

    iput v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    move v0, v4

    .line 167
    #v0=(Byte);
    goto/16 :goto_0

    .line 168
    :cond_d
    #v0=(Null);v1=(Integer);v2=(Reference);v3=(One);
    invoke-virtual {v6}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v4

    #v4=(Integer);
    iget v5, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    if-gt v4, v5, :cond_e

    .line 169
    iput v3, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    :cond_e
    move-object v4, v2

    #v4=(Reference);
    move v2, v0

    #v2=(Null);
    goto/16 :goto_1

    .line 208
    :cond_f
    #v0=(Reference);v2=(Boolean);v5=(Reference);v7=(Reference);v8=(Conflicted);
    new-instance v1, Lcom/tencent/mm/protocal/a/ps;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/protocal/a/ps;-><init>()V

    #v1=(Reference);
    new-array v5, v3, [B

    invoke-static {v5}, Lcom/tencent/mm/al/b;->at([B)Lcom/tencent/mm/al/b;

    move-result-object v5

    invoke-virtual {v1, v5}, Lcom/tencent/mm/protocal/a/ps;->a(Lcom/tencent/mm/al/b;)Lcom/tencent/mm/protocal/a/ps;

    move-result-object v1

    .line 209
    iput-object v1, v0, Lcom/tencent/mm/protocal/a/vt;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    .line 210
    iput v3, v0, Lcom/tencent/mm/protocal/a/vt;->eEP:I

    goto/16 :goto_3

    :cond_10
    #v0=(Integer);v1=(Integer);v5=(Conflicted);v7=(Conflicted);
    move v5, v0

    #v5=(Integer);
    goto/16 :goto_2
.end method

.method protected final a(Lcom/tencent/mm/network/ai;)Lcom/tencent/mm/o/aa;
    .locals 5
    .parameter

    .prologue
    const/4 v4, 0x1

    .line 222
    #v4=(One);
    check-cast p1, Lcom/tencent/mm/o/a;

    invoke-virtual {p1}, Lcom/tencent/mm/o/a;->ru()Lcom/tencent/mm/al/a;

    move-result-object v0

    #v0=(Reference);
    check-cast v0, Lcom/tencent/mm/protocal/a/vt;

    .line 223
    const-string v1, "MicroMsg.NetSceneUploadVoice"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "check msgId:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget v3, v0, Lcom/tencent/mm/protocal/a/vt;->eDx:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " offset:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcom/tencent/mm/protocal/a/vt;->eEL:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " dataLen:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v0, Lcom/tencent/mm/protocal/a/vt;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    invoke-virtual {v3}, Lcom/tencent/mm/protocal/a/ps;->anY()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " endFlag:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcom/tencent/mm/protocal/a/vt;->eER:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 224
    iget v1, v0, Lcom/tencent/mm/protocal/a/vt;->eDx:I

    #v1=(Integer);
    if-nez v1, :cond_0

    iget v1, v0, Lcom/tencent/mm/protocal/a/vt;->eEL:I

    if-nez v1, :cond_2

    :cond_0
    iget-object v1, v0, Lcom/tencent/mm/protocal/a/vt;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    #v1=(Reference);
    if-eqz v1, :cond_1

    iget-object v1, v0, Lcom/tencent/mm/protocal/a/vt;->eEQ:Lcom/tencent/mm/protocal/a/ps;

    invoke-virtual {v1}, Lcom/tencent/mm/protocal/a/ps;->anY()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_3

    :cond_1
    #v1=(Conflicted);
    iget v1, v0, Lcom/tencent/mm/protocal/a/vt;->eER:I

    #v1=(Integer);
    if-eq v1, v4, :cond_3

    iget v0, v0, Lcom/tencent/mm/protocal/a/vt;->eEN:I

    #v0=(Integer);
    if-eq v0, v4, :cond_3

    .line 227
    :cond_2
    #v0=(Conflicted);
    sget-object v0, Lcom/tencent/mm/o/aa;->bIJ:Lcom/tencent/mm/o/aa;

    .line 229
    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_3
    #v0=(Conflicted);
    sget-object v0, Lcom/tencent/mm/o/aa;->bII:Lcom/tencent/mm/o/aa;

    #v0=(Reference);
    goto :goto_0
.end method

.method public final a(IIILjava/lang/String;Lcom/tencent/mm/network/ai;[B)V
    .locals 15
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 246
    const-string v3, "MicroMsg.NetSceneUploadVoice"

    #v3=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "onGYNetEnd file:"

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " errtype:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    move/from16 v0, p2

    #v0=(Integer);
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " errCode:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    move/from16 v0, p3

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    move-object/from16 v3, p5

    .line 247
    check-cast v3, Lcom/tencent/mm/o/a;

    invoke-virtual {v3}, Lcom/tencent/mm/o/a;->ru()Lcom/tencent/mm/al/a;

    move-result-object v3

    check-cast v3, Lcom/tencent/mm/protocal/a/vt;

    .line 248
    check-cast p5, Lcom/tencent/mm/o/a;

    invoke-virtual/range {p5 .. p5}, Lcom/tencent/mm/o/a;->rv()Lcom/tencent/mm/al/a;

    move-result-object v4

    check-cast v4, Lcom/tencent/mm/protocal/a/vu;

    .line 250
    const/4 v5, 0x4

    #v5=(PosByte);
    move/from16 v0, p2

    if-ne v0, v5, :cond_2

    const/16 v5, -0x16

    #v5=(Byte);
    move/from16 v0, p3

    if-ne v0, v5, :cond_2

    .line 254
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v4

    #v4=(Integer);
    const/4 v5, 0x3

    #v5=(PosByte);
    if-ne v4, v5, :cond_0

    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {v4}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v4

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v5

    #v5=(Integer);
    int-to-long v5, v5

    #v5=(LongLo);v6=(LongHi);
    invoke-virtual {v4, v5, v6}, Lcom/tencent/mm/storage/ar;->bR(J)Lcom/tencent/mm/storage/am;

    move-result-object v4

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v5

    #v5=(Reference);
    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bg;->zw()I

    move-result v6

    #v6=(Integer);
    int-to-long v6, v6

    #v6=(LongLo);v7=(LongHi);
    const/4 v8, 0x0

    #v8=(Null);
    invoke-static {v5, v6, v7, v8}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    const/4 v5, 0x2

    #v5=(PosByte);
    invoke-virtual {v4, v5}, Lcom/tencent/mm/storage/am;->setStatus(I)V

    const/16 v5, 0x108

    #v5=(PosShort);
    invoke-virtual {v4, v5}, Lcom/tencent/mm/storage/am;->bO(I)V

    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v5

    #v5=(Reference);
    invoke-virtual {v5}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v5

    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v6

    #v6=(Integer);
    int-to-long v6, v6

    #v6=(LongLo);
    invoke-virtual {v5, v6, v7, v4}, Lcom/tencent/mm/storage/ar;->a(JLcom/tencent/mm/storage/am;)V

    :cond_0
    #v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    const/16 v4, 0x61

    #v4=(PosByte);
    invoke-virtual {v3, v4}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    const-wide/16 v6, 0x3e8

    #v6=(LongLo);v7=(LongHi);
    div-long/2addr v4, v6

    invoke-virtual {v3, v4, v5}, Lcom/tencent/mm/modelvoice/bg;->G(J)V

    const/16 v4, 0x140

    #v4=(PosShort);
    invoke-virtual {v3, v4}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    .line 255
    :cond_1
    #v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    move/from16 v0, p2

    move/from16 v1, p3

    #v1=(Integer);
    move-object/from16 v2, p4

    #v2=(Reference);
    invoke-interface {v3, v0, v1, v2, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    .line 303
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);
    return-void

    .line 260
    :cond_2
    #v1=(Uninit);v2=(Uninit);v3=(Reference);v4=(Reference);v5=(Byte);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);v10=(Uninit);v11=(Uninit);v12=(Uninit);v13=(Uninit);v14=(Uninit);
    const/4 v5, 0x4

    #v5=(PosByte);
    move/from16 v0, p2

    if-ne v0, v5, :cond_3

    if-eqz p3, :cond_3

    const/16 v5, -0xd

    #v5=(Byte);
    move/from16 v0, p3

    if-eq v0, v5, :cond_3

    const/4 v5, -0x6

    move/from16 v0, p3

    if-eq v0, v5, :cond_3

    .line 261
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 262
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    move/from16 v0, p2

    move/from16 v1, p3

    #v1=(Integer);
    move-object/from16 v2, p4

    #v2=(Reference);
    invoke-interface {v3, v0, v1, v2, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto :goto_0

    .line 266
    :cond_3
    #v1=(Uninit);v2=(Uninit);
    if-nez p2, :cond_4

    if-eqz p3, :cond_5

    .line 267
    :cond_4
    const-string v3, "MicroMsg.NetSceneUploadVoice"

    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "onGYNetEnd file:"

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " errType:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    move/from16 v0, p2

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " errCode:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    move/from16 v0, p3

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 268
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    move/from16 v0, p2

    move/from16 v1, p3

    #v1=(Integer);
    move-object/from16 v2, p4

    #v2=(Reference);
    invoke-interface {v3, v0, v1, v2, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto :goto_0

    .line 272
    :cond_5
    #v1=(Uninit);v2=(Uninit);v5=(Byte);
    const-string v5, "MicroMsg.NetSceneUploadVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "onGYNetEnd msgId:"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    iget v7, v4, Lcom/tencent/mm/protocal/a/vu;->eDx:I

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " toUser:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, v3, Lcom/tencent/mm/protocal/a/vt;->eDX:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 273
    iget v5, v4, Lcom/tencent/mm/protocal/a/vu;->eDx:I

    #v5=(Integer);
    if-gtz v5, :cond_6

    iget-object v3, v3, Lcom/tencent/mm/protocal/a/vt;->eDX:Ljava/lang/String;

    invoke-static {v3}, Lcom/tencent/mm/storage/i;->rW(Ljava/lang/String;)Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_6

    .line 274
    const-string v3, "MicroMsg.NetSceneUploadVoice"

    #v3=(Reference);
    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    const-string v6, "onGYNetEnd file:"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    iget-object v6, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " getMsgId:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, v4, Lcom/tencent/mm/protocal/a/vu;->eDx:I

    #v6=(Integer);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " netoff:"

    #v6=(Reference);
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v4, v4, Lcom/tencent/mm/protocal/a/vu;->eEL:I

    #v4=(Integer);
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 275
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v3}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 276
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    move/from16 v0, p2

    move/from16 v1, p3

    #v1=(Integer);
    move-object/from16 v2, p4

    #v2=(Reference);
    invoke-interface {v3, v0, v1, v2, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 281
    :cond_6
    #v1=(Uninit);v2=(Uninit);v3=(Conflicted);v5=(Integer);
    const-string v3, "MicroMsg.NetSceneUploadVoice"

    #v3=(Reference);
    const-string v5, "dkmsgid  set svrmsgid %d -> %d"

    #v5=(Reference);
    const/4 v6, 0x2

    #v6=(PosByte);
    new-array v6, v6, [Ljava/lang/Object;

    #v6=(Reference);
    const/4 v7, 0x0

    #v7=(Null);
    iget v8, v4, Lcom/tencent/mm/protocal/a/vu;->eDx:I

    #v8=(Integer);
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    #v8=(Reference);
    aput-object v8, v6, v7

    const/4 v7, 0x1

    #v7=(One);
    sget v8, Lcom/tencent/mm/platformtools/an;->cdG:I

    #v8=(Integer);
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    #v8=(Reference);
    aput-object v8, v6, v7

    invoke-static {v3, v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 282
    const/16 v3, 0x2717

    #v3=(PosShort);
    sget v5, Lcom/tencent/mm/platformtools/an;->cdF:I

    #v5=(Integer);
    if-ne v3, v5, :cond_7

    sget v3, Lcom/tencent/mm/platformtools/an;->cdG:I

    #v3=(Integer);
    if-eqz v3, :cond_7

    .line 283
    sget v3, Lcom/tencent/mm/platformtools/an;->cdG:I

    iput v3, v4, Lcom/tencent/mm/protocal/a/vu;->eDx:I

    .line 284
    const/4 v3, 0x0

    #v3=(Null);
    sput v3, Lcom/tencent/mm/platformtools/an;->cdG:I

    .line 286
    :cond_7
    #v3=(Integer);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    #v5=(Reference);
    iget v6, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    #v6=(Integer);
    iget v3, v4, Lcom/tencent/mm/protocal/a/vu;->eDx:I

    iget-object v7, v4, Lcom/tencent/mm/protocal/a/vu;->eDZ:Ljava/lang/String;

    #v7=(Reference);
    iget v8, p0, Lcom/tencent/mm/modelvoice/s;->bYj:I

    #v8=(Integer);
    iget v9, p0, Lcom/tencent/mm/modelvoice/s;->bYh:I

    #v9=(Integer);
    if-nez v5, :cond_9

    const/4 v3, -0x1

    .line 287
    :cond_8
    :goto_1
    #v3=(Byte);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v10=(Conflicted);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);
    const-string v5, "MicroMsg.NetSceneUploadVoice"

    #v5=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "dkmsgid onGYNetEnd updateAfterSend:"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " file:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " MsgSvrId:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget v7, v4, Lcom/tencent/mm/protocal/a/vu;->eDx:I

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " clientId:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, v4, Lcom/tencent/mm/protocal/a/vu;->eDZ:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " neWWOff:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget v7, p0, Lcom/tencent/mm/modelvoice/s;->bXA:I

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " neTTTT:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget v4, v4, Lcom/tencent/mm/protocal/a/vu;->eEP:I

    #v4=(Integer);
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    #v4=(Reference);
    const-string v6, " forwardflag:"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget v6, p0, Lcom/tencent/mm/modelvoice/s;->bYh:I

    #v6=(Integer);
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v5, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 288
    if-gez v3, :cond_e

    .line 289
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-static {v4}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 290
    const-string v4, "MicroMsg.NetSceneUploadVoice"

    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    const-string v6, "onGYNetEnd file:"

    #v6=(Reference);
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    iget-object v6, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "UpdateAfterSend Ret:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 291
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    move/from16 v0, p2

    move/from16 v1, p3

    #v1=(Integer);
    move-object/from16 v2, p4

    #v2=(Reference);
    invoke-interface {v3, v0, v1, v2, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 286
    :cond_9
    #v1=(Uninit);v2=(Uninit);v3=(Integer);v6=(Integer);v8=(Integer);v10=(Uninit);v11=(Uninit);v12=(Uninit);v13=(Uninit);v14=(Uninit);
    const-string v10, "MicroMsg.VoiceLogic"

    #v10=(Reference);
    new-instance v11, Ljava/lang/StringBuilder;

    #v11=(UninitRef);
    const-string v12, "dkmsgid UpdateAfterSend file:["

    #v12=(Reference);
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v11=(Reference);
    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "] newOff:"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, " SvrID:"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, " clientID:"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, " hasSendEndFlag "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v10

    invoke-virtual {v10, v5}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v10

    if-nez v10, :cond_a

    const/4 v3, -0x1

    #v3=(Byte);
    goto/16 :goto_1

    :cond_a
    #v3=(Integer);
    invoke-virtual {v10, v6}, Lcom/tencent/mm/modelvoice/bg;->dx(I)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    #v11=(LongLo);v12=(LongHi);
    const-wide/16 v13, 0x3e8

    #v13=(LongLo);v14=(LongHi);
    div-long/2addr v11, v13

    invoke-virtual {v10, v11, v12}, Lcom/tencent/mm/modelvoice/bg;->G(J)V

    const/16 v11, 0x108

    #v11=(PosShort);
    invoke-virtual {v10, v11}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->zx()Ljava/lang/String;

    move-result-object v11

    #v11=(Reference);
    invoke-static {v11}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v11

    #v11=(Boolean);
    if-eqz v11, :cond_b

    if-eqz v7, :cond_b

    invoke-virtual {v10, v7}, Lcom/tencent/mm/modelvoice/bg;->gV(Ljava/lang/String;)V

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v7

    #v7=(Integer);
    or-int/lit16 v7, v7, 0x200

    invoke-virtual {v10, v7}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    :cond_b
    #v7=(Conflicted);
    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v7

    #v7=(Integer);
    if-nez v7, :cond_c

    if-eqz v3, :cond_c

    invoke-virtual {v10, v3}, Lcom/tencent/mm/modelvoice/bg;->cC(I)V

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v3

    or-int/lit8 v3, v3, 0x4

    invoke-virtual {v10, v3}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    :cond_c
    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v7

    if-gt v7, v6, :cond_d

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v6

    const/4 v7, 0x3

    #v7=(PosByte);
    if-ne v6, v7, :cond_d

    const/4 v6, 0x1

    #v6=(One);
    if-ne v8, v6, :cond_d

    const/16 v3, 0x63

    #v3=(PosByte);
    invoke-virtual {v10, v3}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v3

    #v3=(Integer);
    or-int/lit8 v3, v3, 0x40

    invoke-virtual {v10, v3}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    new-instance v3, Lcom/tencent/mm/storage/am;

    #v3=(UninitRef);
    invoke-direct {v3}, Lcom/tencent/mm/storage/am;-><init>()V

    #v3=(Reference);
    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    invoke-virtual {v3, v6}, Lcom/tencent/mm/storage/am;->te(Ljava/lang/String;)V

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v6

    #v6=(Integer);
    invoke-virtual {v3, v6}, Lcom/tencent/mm/storage/am;->cC(I)V

    const/4 v6, 0x2

    #v6=(PosByte);
    invoke-virtual {v3, v6}, Lcom/tencent/mm/storage/am;->setStatus(I)V

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->zw()I

    move-result v7

    #v7=(Integer);
    int-to-long v7, v7

    #v7=(LongLo);v8=(LongHi);
    const/4 v11, 0x0

    #v11=(Null);
    invoke-static {v6, v7, v8, v11}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    const/16 v6, 0x90a

    #v6=(PosShort);
    invoke-virtual {v3, v6}, Lcom/tencent/mm/storage/am;->bO(I)V

    invoke-virtual {v3, v9}, Lcom/tencent/mm/storage/am;->kg(I)V

    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v6

    #v6=(Reference);
    invoke-virtual {v6}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v6

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v7

    #v7=(Integer);
    int-to-long v7, v7

    #v7=(LongLo);
    invoke-virtual {v6, v7, v8, v3}, Lcom/tencent/mm/storage/ar;->a(JLcom/tencent/mm/storage/am;)V

    const-string v3, "MicroMsg.VoiceLogic"

    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "END!!! updateSend  file:"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " total:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " status:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " netTimes:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v10}, Lcom/tencent/mm/modelvoice/bg;->yM()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v3, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    #v3=(One);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v6

    invoke-virtual {v6, v5}, Lcom/tencent/mm/modelvoice/bq;->hg(Ljava/lang/String;)V

    :cond_d
    #v3=(Boolean);v6=(Conflicted);v8=(Conflicted);v11=(Boolean);
    invoke-static {v10}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v5

    #v5=(Boolean);
    if-nez v5, :cond_8

    const/4 v3, -0x4

    #v3=(Byte);
    goto/16 :goto_1

    .line 294
    :cond_e
    #v5=(Reference);v6=(Integer);v7=(Reference);v10=(Conflicted);v11=(Conflicted);v12=(Conflicted);v13=(Conflicted);v14=(Conflicted);
    const/4 v4, 0x1

    #v4=(One);
    if-ne v3, v4, :cond_f

    .line 295
    const-string v3, "MicroMsg.NetSceneUploadVoice"

    #v3=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "onGYNetEnd finish file:"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 296
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/s;->bFU:Lcom/tencent/mm/o/m;

    move/from16 v0, p2

    move/from16 v1, p3

    #v1=(Integer);
    move-object/from16 v2, p4

    #v2=(Reference);
    invoke-interface {v3, v0, v1, v2, p0}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    goto/16 :goto_0

    .line 300
    :cond_f
    #v1=(Uninit);v2=(Uninit);v3=(Byte);v4=(One);
    iget-boolean v3, p0, Lcom/tencent/mm/modelvoice/s;->bYd:Z

    #v3=(Boolean);
    if-eqz v3, :cond_10

    const-wide/16 v3, 0x0

    .line 301
    :goto_2
    #v3=(LongLo);v4=(LongHi);
    const-string v5, "MicroMsg.NetSceneUploadVoice"

    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "onGYNetEnd file:"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    iget-object v7, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " delay:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 302
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/s;->bGV:Lcom/tencent/mm/sdk/platformtools/ax;

    invoke-virtual {v5, v3, v4}, Lcom/tencent/mm/sdk/platformtools/ax;->bL(J)V

    goto/16 :goto_0

    .line 300
    :cond_10
    #v3=(Boolean);v4=(One);v6=(Integer);
    const-wide/16 v3, 0x1f4

    #v3=(LongLo);v4=(LongHi);
    goto :goto_2
.end method

.method protected final a(Lcom/tencent/mm/o/z;)V
    .locals 1
    .parameter

    .prologue
    .line 241
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    .line 242
    return-void
.end method

.method public final getFileName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 40
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/s;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getType()I
    .locals 1

    .prologue
    .line 349
    const/16 v0, 0x7f

    #v0=(PosByte);
    return v0
.end method

.method protected final rh()I
    .locals 1

    .prologue
    .line 236
    const/16 v0, 0x3c

    #v0=(PosByte);
    return v0
.end method

.method public final yz()I
    .locals 1

    .prologue
    .line 46
    iget v0, p0, Lcom/tencent/mm/modelvoice/s;->bWS:I

    #v0=(Integer);
    return v0
.end method

*/}
