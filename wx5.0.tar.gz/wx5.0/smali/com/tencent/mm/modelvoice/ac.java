package com.tencent.mm.modelvoice; class ac {/*

.class final Lcom/tencent/mm/modelvoice/ac;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic bYA:Lcom/tencent/mm/modelvoice/ab;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/ab;)V
    .locals 0
    .parameter

    .prologue
    .line 885
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ac;->bYA:Lcom/tencent/mm/modelvoice/ab;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .prologue
    .line 890
    :try_start_0
    sget-object v0, Lcom/tencent/mm/compatible/c/s;->bBE:Lcom/tencent/mm/compatible/c/a;

    #v0=(Reference);
    iget v0, v0, Lcom/tencent/mm/compatible/c/a;->bAa:I

    #v0=(Integer);
    const/4 v1, 0x1

    #v1=(One);
    if-ne v0, v1, :cond_0

    .line 891
    const-wide/16 v0, 0x12c

    #v0=(LongLo);v1=(LongHi);
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    .line 893
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ac;->bYA:Lcom/tencent/mm/modelvoice/ab;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ab;->bYy:Lcom/tencent/mm/modelvoice/y;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/y;->c(Lcom/tencent/mm/modelvoice/y;)Lcom/tencent/mm/o/p;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 894
    new-instance v0, Lcom/tencent/mm/modelvoice/ad;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/ad;-><init>(Lcom/tencent/mm/modelvoice/ac;)V

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/sdk/platformtools/al;->h(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 919
    :cond_1
    :goto_0
    return-void

    .line 918
    :catch_0
    move-exception v0

    #v0=(Reference);
    goto :goto_0
.end method

*/}
