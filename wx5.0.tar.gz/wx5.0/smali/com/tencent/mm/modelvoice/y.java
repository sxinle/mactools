package com.tencent.mm.modelvoice; class y {/*

.class public final Lcom/tencent/mm/modelvoice/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/o/o;


# instance fields
.field private bYs:Lcom/tencent/mm/modelvoice/d;

.field private bYt:Z

.field private bYu:Lcom/tencent/mm/compatible/f/a;

.field private bYv:I

.field private bYw:Lcom/tencent/mm/o/q;

.field private bYx:Lcom/tencent/mm/o/p;

.field private bll:Z

.field private context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .parameter

    .prologue
    .line 706
    const/4 v0, 0x0

    #v0=(Null);
    invoke-direct {p0, p1, v0}, Lcom/tencent/mm/modelvoice/y;-><init>(Landroid/content/Context;I)V

    .line 707
    #p0=(Reference);
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .locals 2
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v0, 0x0

    .line 709
    #v0=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 696
    #p0=(Reference);
    iput-object v1, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    .line 697
    iput-object v1, p0, Lcom/tencent/mm/modelvoice/y;->context:Landroid/content/Context;

    .line 698
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/y;->bll:Z

    .line 699
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/y;->bYt:Z

    .line 703
    iput v0, p0, Lcom/tencent/mm/modelvoice/y;->bYv:I

    .line 841
    iput-object v1, p0, Lcom/tencent/mm/modelvoice/y;->bYw:Lcom/tencent/mm/o/q;

    .line 710
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/y;->context:Landroid/content/Context;

    .line 711
    new-instance v0, Lcom/tencent/mm/compatible/f/a;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Lcom/tencent/mm/compatible/f/a;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYu:Lcom/tencent/mm/compatible/f/a;

    .line 712
    iput p2, p0, Lcom/tencent/mm/modelvoice/y;->bYv:I

    .line 713
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/y;)Lcom/tencent/mm/compatible/f/a;
    .locals 1
    .parameter

    .prologue
    .line 695
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/y;)Lcom/tencent/mm/o/q;
    .locals 1
    .parameter

    .prologue
    .line 695
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYw:Lcom/tencent/mm/o/q;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/y;)Lcom/tencent/mm/o/p;
    .locals 1
    .parameter

    .prologue
    .line 695
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYx:Lcom/tencent/mm/o/p;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/y;)Landroid/content/Context;
    .locals 1
    .parameter

    .prologue
    .line 695
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->context:Landroid/content/Context;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic e(Lcom/tencent/mm/modelvoice/y;)Z
    .locals 1
    .parameter

    .prologue
    .line 695
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/y;->bll:Z

    #v0=(Boolean);
    return v0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/o/p;)V
    .locals 0
    .parameter

    .prologue
    .line 875
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/y;->bYx:Lcom/tencent/mm/o/p;

    .line 876
    return-void
.end method

.method public final a(Lcom/tencent/mm/o/q;)V
    .locals 0
    .parameter

    .prologue
    .line 845
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/y;->bYw:Lcom/tencent/mm/o/q;

    .line 846
    return-void
.end method

.method public final a(Ljava/lang/String;ZZI)Z
    .locals 7
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v3, -0x1

    #v3=(Byte);
    const/4 v1, 0x1

    #v1=(One);
    const/4 v2, 0x0

    .line 725
    #v2=(Null);
    const-string v0, "MicroMsg.SceneVoice"

    #v0=(Reference);
    const-string v4, "start file name:[%s] speakerOn:[%b]"

    #v4=(Reference);
    const/4 v5, 0x2

    #v5=(PosByte);
    new-array v5, v5, [Ljava/lang/Object;

    #v5=(Reference);
    aput-object p1, v5, v2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    #v6=(Reference);
    aput-object v6, v5, v1

    invoke-static {v0, v4, v5}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 726
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->kB()I

    .line 727
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    if-lez v0, :cond_4

    move v0, v1

    :goto_0
    #v0=(Boolean);
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 728
    if-ne p4, v3, :cond_d

    .line 729
    iget v0, p0, Lcom/tencent/mm/modelvoice/y;->bYv:I

    #v0=(Integer);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v4

    #v4=(Boolean);
    if-eqz v4, :cond_5

    move v0, v3

    .line 731
    :goto_1
    #v3=(Conflicted);v4=(Conflicted);
    if-nez v0, :cond_8

    .line 732
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->context:Landroid/content/Context;

    #v0=(Reference);
    if-eqz v0, :cond_7

    .line 733
    new-instance v0, Lcom/tencent/mm/modelvoice/bk;

    #v0=(UninitRef);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/y;->context:Landroid/content/Context;

    #v3=(Reference);
    invoke-direct {v0, v2}, Lcom/tencent/mm/modelvoice/bk;-><init>(B)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    .line 745
    :cond_0
    :goto_2
    #v0=(Conflicted);v3=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->kD()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    move p2, v2

    .line 748
    :cond_1
    iput-boolean p2, p0, Lcom/tencent/mm/modelvoice/y;->bll:Z

    .line 749
    new-instance v0, Lcom/tencent/mm/modelvoice/ab;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/ab;-><init>(Lcom/tencent/mm/modelvoice/y;)V

    #v0=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v3=(Reference);
    if-eqz v3, :cond_2

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    invoke-interface {v3, v0}, Lcom/tencent/mm/modelvoice/d;->a(Lcom/tencent/mm/modelvoice/e;)V

    .line 750
    :cond_2
    new-instance v0, Lcom/tencent/mm/modelvoice/z;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/z;-><init>(Lcom/tencent/mm/modelvoice/y;)V

    #v0=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    if-eqz v3, :cond_3

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    invoke-interface {v3, v0}, Lcom/tencent/mm/modelvoice/d;->a(Lcom/tencent/mm/modelvoice/f;)V

    .line 751
    :cond_3
    const/4 v0, 0x0

    .line 752
    #v0=(Null);
    if-eqz p3, :cond_a

    move-object v0, p1

    .line 761
    :goto_3
    #v0=(Reference);v3=(Conflicted);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v3=(Reference);
    invoke-interface {v3, v0, p2}, Lcom/tencent/mm/modelvoice/d;->l(Ljava/lang/String;Z)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_c

    .line 762
    const-string v0, "MicroMsg.SceneVoice"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v3, "Start Record PlayError fileName["

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "], ["

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "]"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 767
    :goto_4
    #v1=(Conflicted);v2=(Boolean);
    return v2

    :cond_4
    #v0=(Integer);v1=(One);v2=(Null);v3=(Byte);v4=(Reference);
    move v0, v2

    .line 727
    #v0=(Null);
    goto :goto_0

    .line 729
    :cond_5
    #v0=(Integer);v4=(Boolean);
    const-string v3, "MicroMsg.VoiceFile"

    #v3=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "fileName "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p1, v0, p3}, Lcom/tencent/mm/modelvoice/bf;->a(Ljava/lang/String;IZ)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_6

    move v0, v2

    #v0=(Null);
    goto/16 :goto_1

    :cond_6
    #v0=(Boolean);
    move v0, v1

    #v0=(One);
    goto/16 :goto_1

    .line 735
    :cond_7
    #v0=(Reference);v3=(Conflicted);v4=(Conflicted);
    new-instance v0, Lcom/tencent/mm/modelvoice/bk;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/bk;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    goto/16 :goto_2

    .line 737
    :cond_8
    #v0=(Integer);
    if-ne v0, v1, :cond_0

    .line 738
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->context:Landroid/content/Context;

    #v0=(Reference);
    if-eqz v0, :cond_9

    .line 739
    new-instance v0, Lcom/tencent/mm/modelvoice/av;

    #v0=(UninitRef);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/y;->context:Landroid/content/Context;

    #v3=(Reference);
    invoke-direct {v0, v3}, Lcom/tencent/mm/modelvoice/av;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    goto/16 :goto_2

    .line 741
    :cond_9
    #v3=(Conflicted);
    new-instance v0, Lcom/tencent/mm/modelvoice/av;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/av;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    goto/16 :goto_2

    .line 754
    :cond_a
    #v0=(Null);v3=(Reference);
    iget v3, p0, Lcom/tencent/mm/modelvoice/y;->bYv:I

    #v3=(Integer);
    if-nez v3, :cond_b

    .line 756
    invoke-static {p1}, Lcom/tencent/mm/modelvoice/bh;->fF(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    goto :goto_3

    .line 757
    :cond_b
    #v0=(Null);
    iget v3, p0, Lcom/tencent/mm/modelvoice/y;->bYv:I

    goto :goto_3

    .line 766
    :cond_c
    #v0=(Boolean);v3=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/a;->requestFocus()Z

    move v2, v1

    .line 767
    #v2=(One);
    goto :goto_4

    :cond_d
    #v0=(Boolean);v2=(Null);v3=(Byte);v4=(Reference);
    move v0, p4

    #v0=(Integer);
    goto/16 :goto_1
.end method

.method public final isPlaying()Z
    .locals 3

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 717
    #v0=(Null);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v2=(Reference);
    if-nez v2, :cond_1

    .line 720
    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v2=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    invoke-interface {v2}, Lcom/tencent/mm/modelvoice/d;->getStatus()I

    move-result v2

    #v2=(Integer);
    if-ne v2, v1, :cond_0

    move v0, v1

    #v0=(One);
    goto :goto_0
.end method

.method public final m(Ljava/lang/String;Z)Z
    .locals 2
    .parameter
    .parameter

    .prologue
    .line 802
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v1, -0x1

    #v1=(Byte);
    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/tencent/mm/modelvoice/y;->a(Ljava/lang/String;ZZI)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final p(Z)V
    .locals 1
    .parameter

    .prologue
    .line 827
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->kD()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 829
    const/4 p1, 0x0

    .line 832
    :cond_0
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/y;->bll:Z

    if-ne v0, p1, :cond_2

    .line 839
    :cond_1
    :goto_0
    #v0=(Conflicted);
    return-void

    .line 835
    :cond_2
    #v0=(Boolean);
    iput-boolean p1, p0, Lcom/tencent/mm/modelvoice/y;->bll:Z

    .line 836
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v0=(Reference);
    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    invoke-interface {v0}, Lcom/tencent/mm/modelvoice/d;->isPlaying()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    .line 837
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v0=(Reference);
    invoke-interface {v0, p1}, Lcom/tencent/mm/modelvoice/d;->p(Z)V

    goto :goto_0
.end method

.method public final pause()Z
    .locals 2

    .prologue
    const/4 v0, 0x0

    .line 771
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v1=(Reference);
    if-nez v1, :cond_0

    .line 783
    :goto_0
    #v0=(Boolean);
    return v0

    .line 776
    :cond_0
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    invoke-interface {v1}, Lcom/tencent/mm/modelvoice/d;->isPlaying()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_1

    .line 777
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v0=(Reference);
    invoke-interface {v0}, Lcom/tencent/mm/modelvoice/d;->pause()Z

    move-result v0

    .line 779
    :cond_1
    #v0=(Boolean);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/compatible/audio/d;->kC()V

    .line 780
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tencent/mm/compatible/audio/d;->ky()V

    .line 782
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/y;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v1}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    goto :goto_0
.end method

.method public final rG()Z
    .locals 1

    .prologue
    .line 807
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/y;->bYt:Z

    #v0=(Boolean);
    return v0
.end method

.method public final rH()Z
    .locals 2

    .prologue
    const/4 v0, 0x0

    .line 787
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v1=(Reference);
    if-nez v1, :cond_0

    .line 797
    :goto_0
    #v0=(Boolean);
    return v0

    .line 791
    :cond_0
    #v0=(Null);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tencent/mm/compatible/audio/d;->kB()I

    .line 792
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v1

    invoke-virtual {v1}, Lcom/tencent/mm/compatible/audio/d;->kD()Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_1

    .line 793
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/y;->bll:Z

    .line 795
    :cond_1
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v0=(Reference);
    invoke-interface {v0}, Lcom/tencent/mm/modelvoice/d;->rH()Z

    move-result v0

    .line 796
    #v0=(Boolean);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/y;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/compatible/f/a;->requestFocus()Z

    goto :goto_0
.end method

.method public final stop()V
    .locals 1

    .prologue
    .line 812
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 823
    :goto_0
    return-void

    .line 816
    :cond_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    invoke-interface {v0}, Lcom/tencent/mm/modelvoice/d;->isPlaying()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_1

    .line 817
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYs:Lcom/tencent/mm/modelvoice/d;

    #v0=(Reference);
    invoke-interface {v0}, Lcom/tencent/mm/modelvoice/d;->kR()Z

    .line 819
    :cond_1
    #v0=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->kC()V

    .line 820
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->ky()V

    .line 822
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/y;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    goto :goto_0
.end method

*/}
