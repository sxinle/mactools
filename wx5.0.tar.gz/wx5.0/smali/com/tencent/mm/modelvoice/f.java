package com.tencent.mm.modelvoice; class f {/*

.class public interface abstract Lcom/tencent/mm/modelvoice/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract kX()V
.end method

*/}
