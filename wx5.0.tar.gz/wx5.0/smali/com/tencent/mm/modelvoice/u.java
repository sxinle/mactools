package com.tencent.mm.modelvoice; class u {/*

.class public final Lcom/tencent/mm/modelvoice/u;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public bXA:I

.field public buf:[B

.field public bzE:I

.field public ret:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .prologue
    const/4 v1, 0x0

    .line 9
    #v1=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/u;->buf:[B

    .line 11
    iput v1, p0, Lcom/tencent/mm/modelvoice/u;->bzE:I

    .line 12
    iput v1, p0, Lcom/tencent/mm/modelvoice/u;->bXA:I

    .line 13
    iput v1, p0, Lcom/tencent/mm/modelvoice/u;->ret:I

    .line 14
    return-void
.end method

*/}
