package com.tencent.mm.modelvoice; class n {/*

.class public interface abstract Lcom/tencent/mm/modelvoice/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract kX()V
.end method

*/}
