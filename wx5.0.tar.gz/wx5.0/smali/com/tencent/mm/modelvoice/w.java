package com.tencent.mm.modelvoice; class w {/*

.class final Lcom/tencent/mm/modelvoice/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/sdk/platformtools/ay;


# instance fields
.field final synthetic bYr:Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;)V
    .locals 0
    .parameter

    .prologue
    .line 53
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/w;->bYr:Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final jK()Z
    .locals 2

    .prologue
    .line 57
    const-string v0, "MicroMsg.RemoteControlReceiver"

    #v0=(Reference);
    const-string v1, "got remote key event up"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    invoke-static {}, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->zh()Lcom/tencent/mm/modelvoice/v;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 59
    invoke-static {}, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->zh()Lcom/tencent/mm/modelvoice/v;

    .line 61
    :cond_0
    invoke-static {}, Lcom/tencent/mm/modelvoice/RemoteController$RemoteControlReceiver;->zi()Lcom/tencent/mm/sdk/platformtools/ax;

    .line 62
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

*/}
