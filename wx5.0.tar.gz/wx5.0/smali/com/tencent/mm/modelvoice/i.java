package com.tencent.mm.modelvoice; class i {/*

.class public final Lcom/tencent/mm/modelvoice/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private bzy:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 755
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 760
    #p0=(Reference);
    return-void
.end method

.method public static release()V
    .locals 0

    .prologue
    .line 779
    invoke-static {}, Lcom/tencent/mm/modelvoice/MediaRecorder;->zd()Z

    .line 780
    return-void
.end method


# virtual methods
.method public final a([BILcom/tencent/mm/pointers/PByteArray;I)I
    .locals 1
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 784
    if-nez p3, :cond_0

    .line 785
    const/4 v0, -0x2

    .line 791
    :goto_0
    #v0=(Integer);
    return v0

    .line 787
    :cond_0
    #v0=(Uninit);
    iget v0, p0, Lcom/tencent/mm/modelvoice/i;->bzy:I

    #v0=(Integer);
    invoke-static {v0, p1, p2, p3, p4}, Lcom/tencent/mm/modelvoice/MediaRecorder;->b(I[BILcom/tencent/mm/pointers/PByteArray;I)Z

    move-result v0

    .line 788
    #v0=(Boolean);
    if-eqz v0, :cond_1

    iget-object v0, p3, Lcom/tencent/mm/pointers/PByteArray;->value:[B

    #v0=(Reference);
    if-nez v0, :cond_2

    .line 789
    :cond_1
    #v0=(Conflicted);
    const/4 v0, -0x1

    #v0=(Byte);
    goto :goto_0

    .line 791
    :cond_2
    #v0=(Reference);
    iget-object v0, p3, Lcom/tencent/mm/pointers/PByteArray;->value:[B

    array-length v0, v0

    #v0=(Integer);
    goto :goto_0
.end method

.method public final dD(I)Z
    .locals 1
    .parameter

    .prologue
    .line 773
    iput p1, p0, Lcom/tencent/mm/modelvoice/i;->bzy:I

    .line 774
    invoke-static {}, Lcom/tencent/mm/modelvoice/MediaRecorder;->zc()Z

    .line 775
    const/4 v0, 0x1

    #v0=(One);
    return v0
.end method

*/}
