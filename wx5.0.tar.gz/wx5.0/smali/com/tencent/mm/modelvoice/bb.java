package com.tencent.mm.modelvoice; class bb {/*

.class public final Lcom/tencent/mm/modelvoice/bb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/modelvoice/b;


# instance fields
.field private ah:Ljava/lang/String;

.field private bSJ:Ljava/io/RandomAccessFile;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1
    .parameter

    .prologue
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 19
    #p0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    .line 20
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    .line 16
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    .line 17
    return-void
.end method

.method private gR(Ljava/lang/String;)Z
    .locals 5
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v2, 0x0

    .line 35
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    if-ltz v0, :cond_1

    move v0, v1

    :goto_0
    #v0=(Boolean);
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 36
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    #v0=(Reference);
    if-nez v0, :cond_2

    move v0, v1

    :goto_1
    #v0=(Boolean);
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 37
    const-string v0, "r"

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    const-string v0, "rw"

    #v0=(Reference);
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_3

    :cond_0
    move v0, v1

    :goto_2
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 38
    const-string v0, "MicroMsg.SpxFileOperator"

    #v0=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "Open file:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " mode:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 40
    :try_start_0
    new-instance v0, Ljava/io/RandomAccessFile;

    #v0=(UninitRef);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    invoke-direct {v0, v3, p1}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 46
    :goto_3
    #v1=(Boolean);
    return v1

    :cond_1
    #v0=(Integer);v1=(One);v3=(Uninit);v4=(Uninit);
    move v0, v2

    .line 35
    #v0=(Null);
    goto :goto_0

    :cond_2
    #v0=(Reference);
    move v0, v2

    .line 36
    #v0=(Null);
    goto :goto_1

    :cond_3
    #v0=(Boolean);
    move v0, v2

    .line 37
    #v0=(Null);
    goto :goto_2

    .line 41
    :catch_0
    #v0=(Conflicted);v3=(Reference);v4=(Reference);
    move-exception v0

    .line 42
    #v0=(Reference);
    const-string v1, "MicroMsg.SpxFileOperator"

    #v1=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "ERR: OpenFile["

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "] failed:["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "]"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    move v1, v2

    .line 44
    #v1=(Null);
    goto :goto_3
.end method


# virtual methods
.method public final C(II)Lcom/tencent/mm/modelvoice/u;
    .locals 9
    .parameter
    .parameter

    .prologue
    const/4 v2, 0x0

    .line 52
    #v2=(Null);
    new-instance v0, Lcom/tencent/mm/modelvoice/u;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/u;-><init>()V

    .line 53
    #v0=(Reference);
    if-ltz p1, :cond_0

    if-gtz p2, :cond_1

    .line 54
    :cond_0
    const/4 v1, -0x3

    #v1=(Byte);
    iput v1, v0, Lcom/tencent/mm/modelvoice/u;->ret:I

    .line 81
    :goto_0
    #v1=(Integer);v2=(Reference);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return-object v0

    .line 57
    :cond_1
    #v1=(Uninit);v2=(Null);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    #v1=(Reference);
    if-nez v1, :cond_2

    const-string v1, "r"

    invoke-direct {p0, v1}, Lcom/tencent/mm/modelvoice/bb;->gR(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_2

    .line 58
    const/4 v1, -0x2

    #v1=(Byte);
    iput v1, v0, Lcom/tencent/mm/modelvoice/u;->ret:I

    goto :goto_0

    .line 61
    :cond_2
    #v1=(Conflicted);
    new-array v1, p2, [B

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/modelvoice/u;->buf:[B

    .line 64
    :try_start_0
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->length()J

    move-result-wide v3

    .line 65
    #v3=(LongLo);v4=(LongHi);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    int-to-long v5, p1

    #v5=(LongLo);v6=(LongHi);
    invoke-virtual {v1, v5, v6}, Ljava/io/RandomAccessFile;->seek(J)V

    .line 66
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    iget-object v5, v0, Lcom/tencent/mm/modelvoice/u;->buf:[B

    #v5=(Reference);
    const/4 v6, 0x0

    #v6=(Null);
    invoke-virtual {v1, v5, v6, p2}, Ljava/io/RandomAccessFile;->read([BII)I

    move-result v1

    .line 67
    #v1=(Integer);
    const-string v5, "MicroMsg.SpxFileOperator"

    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "DBG: ReadFile["

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    iget-object v7, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "] readOffset:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " readRet:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " fileNow:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    invoke-virtual {v7}, Ljava/io/RandomAccessFile;->getFilePointer()J

    move-result-wide v7

    #v7=(LongLo);v8=(LongHi);
    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " fileSize:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    if-gez v1, :cond_3

    move v1, v2

    .line 72
    :cond_3
    iput v1, v0, Lcom/tencent/mm/modelvoice/u;->bzE:I

    .line 73
    add-int/2addr v1, p1

    iput v1, v0, Lcom/tencent/mm/modelvoice/u;->bXA:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 80
    iput v2, v0, Lcom/tencent/mm/modelvoice/u;->ret:I

    goto :goto_0

    .line 74
    :catch_0
    #v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    move-exception v1

    .line 75
    #v1=(Reference);
    const-string v2, "MicroMsg.SpxFileOperator"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "ERR: ReadFile["

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "] Offset:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "  failed:["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "] "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bb;->yY()V

    .line 77
    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, v0, Lcom/tencent/mm/modelvoice/u;->ret:I

    goto/16 :goto_0
.end method

.method public final getFormat()I
    .locals 1

    .prologue
    .line 109
    const/4 v0, 0x1

    #v0=(One);
    return v0
.end method

.method public final write([BII)I
    .locals 5
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v2, 0x0

    .line 86
    #v2=(Null);
    array-length v0, p1

    #v0=(Integer);
    if-lez v0, :cond_0

    if-lez p2, :cond_0

    move v0, v1

    :goto_0
    #v0=(Boolean);
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 87
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    #v0=(Reference);
    if-nez v0, :cond_1

    const-string v0, "rw"

    invoke-direct {p0, v0}, Lcom/tencent/mm/modelvoice/bb;->gR(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 88
    const/4 v0, -0x1

    .line 104
    :goto_1
    #v0=(Integer);v1=(Conflicted);v2=(Reference);v3=(Conflicted);v4=(Conflicted);
    return v0

    :cond_0
    #v1=(One);v2=(Null);v3=(Uninit);v4=(Uninit);
    move v0, v2

    .line 86
    #v0=(Null);
    goto :goto_0

    .line 91
    :cond_1
    :try_start_0
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    #v0=(Reference);
    int-to-long v3, p3

    #v3=(LongLo);v4=(LongHi);
    invoke-virtual {v0, v3, v4}, Ljava/io/RandomAccessFile;->seek(J)V

    .line 94
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    const/4 v3, 0x0

    #v3=(Null);
    invoke-virtual {v0, p1, v3, p2}, Ljava/io/RandomAccessFile;->write([BII)V

    .line 95
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    invoke-virtual {v0}, Ljava/io/RandomAccessFile;->getFilePointer()J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-wide v3

    #v3=(LongLo);
    long-to-int v0, v3

    .line 101
    #v0=(Integer);
    add-int v3, p3, p2

    .line 102
    #v3=(Integer);
    if-ne v0, v3, :cond_2

    move v0, v1

    :goto_2
    #v0=(Boolean);
    invoke-static {v0}, Ljunit/framework/Assert;->assertTrue(Z)V

    .line 103
    if-ltz v3, :cond_3

    :goto_3
    #v1=(Boolean);
    invoke-static {v1}, Ljunit/framework/Assert;->assertTrue(Z)V

    move v0, v3

    .line 104
    #v0=(Integer);
    goto :goto_1

    .line 96
    :catch_0
    #v0=(Conflicted);v1=(One);v3=(Conflicted);v4=(Conflicted);
    move-exception v0

    .line 97
    #v0=(Reference);
    const-string v1, "MicroMsg.SpxFileOperator"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "ERR: WriteFile["

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "] Offset:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " failed:["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "]"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 98
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bb;->yY()V

    .line 99
    const/4 v0, -0x3

    #v0=(Byte);
    goto :goto_1

    :cond_2
    #v0=(Integer);v1=(One);v2=(Null);v3=(Integer);v4=(LongHi);
    move v0, v2

    .line 102
    #v0=(Null);
    goto :goto_2

    :cond_3
    #v0=(Boolean);
    move v1, v2

    .line 103
    #v1=(Null);
    goto :goto_3
.end method

.method public final yY()V
    .locals 3

    .prologue
    .line 24
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 26
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    invoke-virtual {v0}, Ljava/io/RandomAccessFile;->close()V

    .line 27
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bb;->bSJ:Ljava/io/RandomAccessFile;

    .line 28
    const-string v0, "MicroMsg.SpxFileOperator"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Close :"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bb;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    :cond_0
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);
    return-void

    :catch_0
    move-exception v0

    goto :goto_0
.end method

*/}
