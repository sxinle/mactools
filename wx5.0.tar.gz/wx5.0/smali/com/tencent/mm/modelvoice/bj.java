package com.tencent.mm.modelvoice; class bj {/*

.class final Lcom/tencent/mm/modelvoice/bj;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic bYf:Lcom/tencent/mm/modelvoice/c;

.field final synthetic bZA:Lcom/tencent/mm/modelvoice/bi;

.field final synthetic bZz:Lcom/tencent/mm/modelvoice/bg;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/bi;Lcom/tencent/mm/modelvoice/c;Lcom/tencent/mm/modelvoice/bg;)V
    .locals 0
    .parameter
    .parameter
    .parameter

    .prologue
    .line 133
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/bj;->bZA:Lcom/tencent/mm/modelvoice/bi;

    iput-object p2, p0, Lcom/tencent/mm/modelvoice/bj;->bYf:Lcom/tencent/mm/modelvoice/c;

    iput-object p3, p0, Lcom/tencent/mm/modelvoice/bj;->bZz:Lcom/tencent/mm/modelvoice/bg;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .prologue
    .line 137
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/bj;->bYf:Lcom/tencent/mm/modelvoice/c;

    #v0=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/bj;->bZz:Lcom/tencent/mm/modelvoice/bg;

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/bj;->bZz:Lcom/tencent/mm/modelvoice/bg;

    #v3=(Reference);
    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/storage/ar;->ad(Ljava/lang/String;I)Lcom/tencent/mm/storage/am;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/tencent/mm/modelvoice/c;->i(Lcom/tencent/mm/storage/am;)V

    .line 139
    return-void
.end method

*/}
