package com.tencent.mm.modelvoice; class ae {/*

.class final Lcom/tencent/mm/modelvoice/ae;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/sdk/platformtools/bn;


# instance fields
.field final synthetic bYC:Lcom/tencent/mm/modelvoice/ad;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/ad;)V
    .locals 0
    .parameter

    .prologue
    .line 899
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ae;->bYC:Lcom/tencent/mm/modelvoice/ad;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final rI()V
    .locals 2

    .prologue
    .line 902
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ae;->bYC:Lcom/tencent/mm/modelvoice/ad;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ad;->bYB:Lcom/tencent/mm/modelvoice/ac;

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ac;->bYA:Lcom/tencent/mm/modelvoice/ab;

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ab;->bYy:Lcom/tencent/mm/modelvoice/y;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/y;->isPlaying()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 903
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/d;->ky()V

    .line 904
    const-string v0, "MicroMsg.SceneVoice"

    const-string v1, "onCompletion() resetSpeaker"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 906
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ae;->bYC:Lcom/tencent/mm/modelvoice/ad;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ad;->bYB:Lcom/tencent/mm/modelvoice/ac;

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ac;->bYA:Lcom/tencent/mm/modelvoice/ab;

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ab;->bYy:Lcom/tencent/mm/modelvoice/y;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/y;->c(Lcom/tencent/mm/modelvoice/y;)Lcom/tencent/mm/o/p;

    move-result-object v0

    invoke-interface {v0}, Lcom/tencent/mm/o/p;->rI()V

    .line 907
    return-void
.end method

*/}
