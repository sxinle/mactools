package com.tencent.mm.modelvoice; class ao {/*

.class final Lcom/tencent/mm/modelvoice/ao;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/sdk/platformtools/ay;


# instance fields
.field final synthetic bYS:Lcom/tencent/mm/modelvoice/al;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/al;)V
    .locals 0
    .parameter

    .prologue
    .line 1158
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ao;->bYS:Lcom/tencent/mm/modelvoice/al;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final jK()Z
    .locals 2

    .prologue
    .line 1162
    const-string v0, "MicroMsg.SceneVoice"

    #v0=(Reference);
    const-string v1, "onTimerExpired"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 1163
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ao;->bYS:Lcom/tencent/mm/modelvoice/al;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/al;->h(Lcom/tencent/mm/modelvoice/al;)V

    .line 1164
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

*/}
