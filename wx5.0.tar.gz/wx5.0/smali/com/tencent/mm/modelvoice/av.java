package com.tencent.mm.modelvoice; class av {/*

.class public final Lcom/tencent/mm/modelvoice/av;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/modelvoice/d;


# instance fields
.field private ah:Ljava/lang/String;

.field private bUL:Lcom/tencent/qqpinyin/voicerecoapi/a;

.field private bYY:Landroid/media/AudioTrack;

.field private bYZ:Lcom/tencent/mm/modelvoice/e;

.field private bYu:Lcom/tencent/mm/compatible/f/a;

.field private bZa:Lcom/tencent/mm/modelvoice/f;

.field private bZb:I

.field private bZc:I

.field private bZd:I

.field private bZe:Ljava/lang/Thread;

.field private bZf:Landroid/media/MediaPlayer$OnCompletionListener;

.field private bZg:Landroid/media/MediaPlayer$OnErrorListener;

.field private bZh:I

.field bZi:I

.field private bZj:Z

.field private bZk:Ljava/lang/String;

.field private bZl:Ljava/lang/String;

.field private bZm:[B

.field private bZn:I

.field private bZo:Ljava/io/FileInputStream;

.field private bZp:I

.field private byI:I

.field private status:I


# direct methods
.method public constructor <init>()V
    .locals 4

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v1, 0x0

    .line 56
    #v1=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    #p0=(Reference);
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->ah:Ljava/lang/String;

    .line 23
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/av;->bYZ:Lcom/tencent/mm/modelvoice/e;

    .line 24
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/av;->bZa:Lcom/tencent/mm/modelvoice/f;

    .line 32
    iput v1, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    .line 34
    const/4 v0, 0x2

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->bZb:I

    .line 37
    const/16 v0, 0x3e80

    #v0=(PosShort);
    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->byI:I

    .line 38
    const/4 v0, 0x1

    #v0=(One);
    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->bZc:I

    .line 39
    const/16 v0, 0x14

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->bZd:I

    .line 41
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/av;->bUL:Lcom/tencent/qqpinyin/voicerecoapi/a;

    .line 45
    iput v1, p0, Lcom/tencent/mm/modelvoice/av;->bZi:I

    .line 47
    iput-boolean v1, p0, Lcom/tencent/mm/modelvoice/av;->bZj:Z

    .line 48
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZk:Ljava/lang/String;

    .line 49
    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZl:Ljava/lang/String;

    .line 251
    sget v0, Lcom/tencent/qqpinyin/voicerecoapi/a;->goP:I

    #v0=(Integer);
    new-array v0, v0, [B

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZm:[B

    .line 252
    iput v1, p0, Lcom/tencent/mm/modelvoice/av;->bZn:I

    .line 253
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/av;->bZo:Ljava/io/FileInputStream;

    .line 254
    const/16 v0, 0x13a

    #v0=(PosShort);
    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->bZp:I

    .line 57
    new-instance v0, Lcom/tencent/mm/modelvoice/aw;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/aw;-><init>(Lcom/tencent/mm/modelvoice/av;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZf:Landroid/media/MediaPlayer$OnCompletionListener;

    .line 58
    new-instance v0, Lcom/tencent/mm/modelvoice/ax;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/ax;-><init>(Lcom/tencent/mm/modelvoice/av;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZg:Landroid/media/MediaPlayer$OnErrorListener;

    .line 59
    new-instance v0, Lcom/tencent/qqpinyin/voicerecoapi/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/qqpinyin/voicerecoapi/a;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bUL:Lcom/tencent/qqpinyin/voicerecoapi/a;

    .line 60
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bUL:Lcom/tencent/qqpinyin/voicerecoapi/a;

    invoke-virtual {v0}, Lcom/tencent/qqpinyin/voicerecoapi/a;->aDX()I

    move-result v0

    .line 61
    #v0=(Integer);
    if-eqz v0, :cond_0

    .line 62
    const-string v1, "speex"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "res: "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 65
    :cond_0
    #v0=(Conflicted);v3=(Conflicted);
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .parameter

    .prologue
    .line 68
    invoke-direct {p0}, Lcom/tencent/mm/modelvoice/av;-><init>()V

    .line 69
    #p0=(Reference);
    new-instance v0, Lcom/tencent/mm/compatible/f/a;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Lcom/tencent/mm/compatible/f/a;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYu:Lcom/tencent/mm/compatible/f/a;

    .line 70
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/av;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 18
    iput p1, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    return p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/av;)Lcom/tencent/mm/compatible/f/a;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/av;Ljava/io/FileInputStream;)Ljava/io/FileInputStream;
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 18
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/av;->bZo:Ljava/io/FileInputStream;

    return-object p1
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/av;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 18
    iput p1, p0, Lcom/tencent/mm/modelvoice/av;->bZn:I

    return p1
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/av;)Landroid/media/AudioTrack;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/av;)Landroid/media/AudioTrack;
    .locals 1
    .parameter

    .prologue
    .line 18
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    return-object v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/av;)V
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZe:Ljava/lang/Thread;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZe:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->join()V

    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZe:Ljava/lang/Thread;

    :cond_0
    #v0=(Reference);
    return-void
.end method

.method static synthetic e(Lcom/tencent/mm/modelvoice/av;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic f(Lcom/tencent/mm/modelvoice/av;)Lcom/tencent/mm/modelvoice/f;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZa:Lcom/tencent/mm/modelvoice/f;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic g(Lcom/tencent/mm/modelvoice/av;)I
    .locals 1
    .parameter

    .prologue
    .line 18
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic h(Lcom/tencent/mm/modelvoice/av;)[B
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZm:[B

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic i(Lcom/tencent/mm/modelvoice/av;)Ljava/io/FileInputStream;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZo:Ljava/io/FileInputStream;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic j(Lcom/tencent/mm/modelvoice/av;)I
    .locals 1
    .parameter

    .prologue
    .line 18
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->bZn:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic k(Lcom/tencent/mm/modelvoice/av;)Lcom/tencent/qqpinyin/voicerecoapi/a;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bUL:Lcom/tencent/qqpinyin/voicerecoapi/a;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic l(Lcom/tencent/mm/modelvoice/av;)I
    .locals 1
    .parameter

    .prologue
    .line 18
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->bZp:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic m(Lcom/tencent/mm/modelvoice/av;)Z
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/av;->bZj:Z

    #v0=(Boolean);
    return v0
.end method

.method static synthetic n(Lcom/tencent/mm/modelvoice/av;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZl:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method private n(Ljava/lang/String;Z)Z
    .locals 4
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    #v0=(Null);
    const/4 v1, 0x1

    .line 189
    #v1=(One);
    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v2=(Integer);
    if-eqz v2, :cond_0

    .line 190
    const-string v1, "MicroMsg.SpeexPlayer"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "startPlay error status:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget v3, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 208
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 194
    :cond_0
    #v0=(Null);v1=(One);v2=(Integer);v3=(Uninit);
    iput v1, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    .line 195
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/av;->ah:Ljava/lang/String;

    .line 197
    :try_start_0
    invoke-direct {p0, p2}, Lcom/tencent/mm/modelvoice/av;->v(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    move v0, v1

    .line 208
    #v0=(One);
    goto :goto_0

    :catch_0
    #v0=(Null);
    move-exception v2

    .line 200
    #v2=(Reference);
    const/4 v2, 0x1

    :try_start_1
    #v2=(One);
    invoke-direct {p0, v2}, Lcom/tencent/mm/modelvoice/av;->v(Z)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    .line 202
    :catch_1
    move-exception v1

    #v1=(Reference);
    const-string v1, "MicroMsg.SpeexPlayer"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "startPlay File["

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/av;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "] failed"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 203
    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    goto :goto_0
.end method

.method static synthetic o(Lcom/tencent/mm/modelvoice/av;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZk:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic p(Lcom/tencent/mm/modelvoice/av;)Landroid/media/MediaPlayer$OnErrorListener;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZg:Landroid/media/MediaPlayer$OnErrorListener;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic q(Lcom/tencent/mm/modelvoice/av;)Lcom/tencent/mm/modelvoice/e;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYZ:Lcom/tencent/mm/modelvoice/e;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic r(Lcom/tencent/mm/modelvoice/av;)Landroid/media/MediaPlayer$OnCompletionListener;
    .locals 1
    .parameter

    .prologue
    .line 18
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZf:Landroid/media/MediaPlayer$OnCompletionListener;

    #v0=(Reference);
    return-object v0
.end method

.method private v(Z)V
    .locals 7
    .parameter

    .prologue
    const/4 v1, 0x3

    #v1=(PosByte);
    const/4 v3, 0x1

    .line 212
    #v3=(One);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->ah:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/a/c;->ak(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 248
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    return-void

    .line 218
    :cond_1
    #v0=(Boolean);v1=(PosByte);v2=(Uninit);v3=(One);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    if-eqz p1, :cond_5

    move v0, v1

    .line 219
    :goto_1
    :try_start_0
    #v0=(PosByte);
    sget-object v2, Lcom/tencent/mm/compatible/c/s;->bBE:Lcom/tencent/mm/compatible/c/a;

    #v2=(Reference);
    iget-boolean v2, v2, Lcom/tencent/mm/compatible/c/a;->bzR:Z

    #v2=(Boolean);
    if-eqz v2, :cond_6

    .line 220
    sget-object v2, Lcom/tencent/mm/compatible/c/s;->bBE:Lcom/tencent/mm/compatible/c/a;

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/compatible/c/a;->dump()V

    .line 221
    sget-object v2, Lcom/tencent/mm/compatible/c/s;->bBE:Lcom/tencent/mm/compatible/c/a;

    iget v2, v2, Lcom/tencent/mm/compatible/c/a;->bzY:I

    #v2=(Integer);
    if-ne v2, v3, :cond_6

    .line 226
    :goto_2
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->byI:I

    #v0=(Integer);
    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->bZb:I

    const/4 v3, 0x2

    #v3=(PosByte);
    invoke-static {v0, v2, v3}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result v0

    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->bZh:I

    .line 228
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    #v0=(Reference);
    if-eqz v0, :cond_2

    .line 229
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->stop()V

    .line 230
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->release()V

    .line 231
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    .line 233
    :cond_2
    #v0=(Reference);
    new-instance v0, Landroid/media/AudioTrack;

    #v0=(UninitRef);
    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->byI:I

    iget v3, p0, Lcom/tencent/mm/modelvoice/av;->bZb:I

    #v3=(Integer);
    const/4 v4, 0x2

    #v4=(PosByte);
    iget v5, p0, Lcom/tencent/mm/modelvoice/av;->bZh:I

    #v5=(Integer);
    mul-int/lit8 v5, v5, 0x8

    const/4 v6, 0x1

    #v6=(One);
    invoke-direct/range {v0 .. v6}, Landroid/media/AudioTrack;-><init>(IIIIII)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    .line 234
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->byI:I

    #v0=(Integer);
    div-int/lit16 v0, v0, 0x3e8

    iget v1, p0, Lcom/tencent/mm/modelvoice/av;->bZc:I

    #v1=(Integer);
    mul-int/2addr v0, v1

    iget v1, p0, Lcom/tencent/mm/modelvoice/av;->bZd:I

    mul-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->bZp:I

    .line 235
    if-eqz p1, :cond_3

    .line 237
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v0=(Reference);
    if-eqz v0, :cond_3

    .line 238
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/a;->requestFocus()Z

    .line 241
    :cond_3
    #v0=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    #v0=(Reference);
    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V

    new-instance v0, Lcom/tencent/mm/modelvoice/ay;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/ay;-><init>(Lcom/tencent/mm/modelvoice/av;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZe:Ljava/lang/Thread;

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bZe:Ljava/lang/Thread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 242
    :catch_0
    #v0=(Conflicted);v2=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);
    move-exception v0

    .line 243
    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/av;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v1=(Reference);
    if-eqz v1, :cond_4

    .line 244
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/av;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v1}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    .line 246
    :cond_4
    const-string v1, "MicroMsg.SpeexPlayer"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "playImp : fail, exception = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 218
    :cond_5
    #v0=(Boolean);v1=(PosByte);v2=(Uninit);v3=(One);v4=(Uninit);v5=(Uninit);v6=(Uninit);
    const/4 v0, 0x0

    #v0=(Null);
    goto/16 :goto_1

    :cond_6
    #v0=(PosByte);v2=(Integer);
    move v1, v0

    goto/16 :goto_2
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/modelvoice/e;)V
    .locals 0
    .parameter

    .prologue
    .line 74
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/av;->bYZ:Lcom/tencent/mm/modelvoice/e;

    .line 75
    return-void
.end method

.method public final a(Lcom/tencent/mm/modelvoice/f;)V
    .locals 0
    .parameter

    .prologue
    .line 79
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/av;->bZa:Lcom/tencent/mm/modelvoice/f;

    .line 80
    return-void
.end method

.method public final getStatus()I
    .locals 1

    .prologue
    .line 53
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v0=(Integer);
    return v0
.end method

.method public final isPlaying()Z
    .locals 2

    .prologue
    const/4 v0, 0x1

    .line 412
    #v0=(One);
    iget v1, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v1=(Integer);
    if-ne v1, v0, :cond_0

    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(One);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final kR()Z
    .locals 5

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 418
    #v0=(Null);
    const-string v2, "MicroMsg.SpeexPlayer"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "stop  status:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget v4, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 419
    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v2=(Integer);
    if-eq v2, v1, :cond_0

    .line 420
    const-string v1, "MicroMsg.SpeexPlayer"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "stop  error status:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget v3, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 432
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v3=(Conflicted);
    return v0

    .line 423
    :cond_0
    #v0=(Null);v1=(One);v2=(Integer);v3=(Reference);
    const/4 v2, 0x3

    #v2=(PosByte);
    iput v2, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    .line 424
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/av;->bZk:Ljava/lang/String;

    #v2=(Reference);
    monitor-enter v2

    .line 426
    :try_start_0
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/av;->bZk:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/Object;->notify()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 431
    monitor-exit v2

    move v0, v1

    .line 432
    #v0=(One);
    goto :goto_0

    .line 428
    :catch_0
    #v0=(Null);
    move-exception v1

    :try_start_1
    #v1=(Reference);
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 431
    :catchall_0
    #v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0
.end method

.method public final l(Ljava/lang/String;Z)Z
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 184
    invoke-direct {p0, p1, p2}, Lcom/tencent/mm/modelvoice/av;->n(Ljava/lang/String;Z)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final p(Z)V
    .locals 8
    .parameter

    .prologue
    const/4 v7, 0x0

    #v7=(Null);
    const/4 v1, 0x3

    #v1=(PosByte);
    const/4 v6, 0x1

    #v6=(One);
    const/4 v4, 0x2

    .line 154
    #v4=(PosByte);
    iput-boolean v6, p0, Lcom/tencent/mm/modelvoice/av;->bZj:Z

    .line 155
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->bZc:I

    #v0=(Integer);
    if-ne v0, v4, :cond_1

    .line 156
    iput v1, p0, Lcom/tencent/mm/modelvoice/av;->bZb:I

    .line 161
    :goto_0
    iget v0, p0, Lcom/tencent/mm/modelvoice/av;->byI:I

    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->bZb:I

    #v2=(Integer);
    invoke-static {v0, v2, v4}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result v0

    iput v0, p0, Lcom/tencent/mm/modelvoice/av;->bZh:I

    .line 162
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 163
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->stop()V

    .line 164
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->release()V

    .line 165
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    .line 168
    :cond_0
    #v0=(Reference);
    if-eqz p1, :cond_2

    move v0, v1

    .line 169
    :goto_1
    #v0=(PosByte);
    sget-object v2, Lcom/tencent/mm/compatible/c/s;->bBE:Lcom/tencent/mm/compatible/c/a;

    #v2=(Reference);
    iget-boolean v2, v2, Lcom/tencent/mm/compatible/c/a;->bzR:Z

    #v2=(Boolean);
    if-eqz v2, :cond_3

    .line 170
    sget-object v2, Lcom/tencent/mm/compatible/c/s;->bBE:Lcom/tencent/mm/compatible/c/a;

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/compatible/c/a;->dump()V

    .line 171
    sget-object v2, Lcom/tencent/mm/compatible/c/s;->bBE:Lcom/tencent/mm/compatible/c/a;

    iget v2, v2, Lcom/tencent/mm/compatible/c/a;->bzY:I

    #v2=(Integer);
    if-ne v2, v6, :cond_3

    .line 175
    :goto_2
    new-instance v0, Landroid/media/AudioTrack;

    #v0=(UninitRef);
    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->byI:I

    iget v3, p0, Lcom/tencent/mm/modelvoice/av;->bZb:I

    #v3=(Integer);
    iget v5, p0, Lcom/tencent/mm/modelvoice/av;->bZh:I

    #v5=(Integer);
    mul-int/lit8 v5, v5, 0x8

    invoke-direct/range {v0 .. v6}, Landroid/media/AudioTrack;-><init>(IIIIII)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    .line 176
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/av;->bYY:Landroid/media/AudioTrack;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V

    .line 178
    iput-boolean v7, p0, Lcom/tencent/mm/modelvoice/av;->bZj:Z

    .line 180
    return-void

    .line 158
    :cond_1
    #v0=(Integer);v2=(Uninit);v3=(Uninit);v5=(Uninit);
    iput v4, p0, Lcom/tencent/mm/modelvoice/av;->bZb:I

    goto :goto_0

    :cond_2
    #v0=(Reference);v2=(Integer);
    move v0, v7

    .line 168
    #v0=(Null);
    goto :goto_1

    :cond_3
    #v0=(PosByte);
    move v1, v0

    goto :goto_2
.end method

.method public final pause()Z
    .locals 9

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 373
    #v0=(Null);
    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v2=(Integer);
    if-eq v2, v1, :cond_0

    .line 388
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    return v0

    .line 376
    :cond_0
    #v0=(Null);v1=(One);v2=(Integer);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);
    const/4 v2, 0x2

    #v2=(PosByte);
    iput v2, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    .line 377
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/av;->bZl:Ljava/lang/String;

    #v2=(Reference);
    monitor-enter v2

    .line 379
    :try_start_0
    const-string v3, "MicroMsg.SpeexPlayer"

    #v3=(Reference);
    const-string v4, "before mOk.wait"

    #v4=(Reference);
    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 380
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    .line 381
    #v3=(LongLo);v4=(LongHi);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/av;->bZl:Ljava/lang/String;

    #v5=(Reference);
    invoke-virtual {v5}, Ljava/lang/Object;->wait()V

    .line 382
    const-string v5, "MicroMsg.SpeexPlayer"

    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "after mOk.wait time:"

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    #v7=(LongLo);v8=(LongHi);
    sub-long v3, v7, v3

    invoke-virtual {v6, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 387
    monitor-exit v2

    move v0, v1

    .line 388
    #v0=(One);
    goto :goto_0

    .line 384
    :catch_0
    #v0=(Null);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    move-exception v1

    :try_start_1
    #v1=(Reference);
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 387
    :catchall_0
    #v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0
.end method

.method public final rH()Z
    .locals 5

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 393
    #v0=(Null);
    iget v2, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    #v2=(Integer);
    const/4 v3, 0x2

    #v3=(PosByte);
    if-eq v2, v3, :cond_0

    .line 407
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 396
    :cond_0
    #v0=(Null);v1=(One);v2=(Integer);v3=(PosByte);v4=(Uninit);
    iput v1, p0, Lcom/tencent/mm/modelvoice/av;->status:I

    .line 397
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/av;->bZk:Ljava/lang/String;

    #v2=(Reference);
    monitor-enter v2

    .line 399
    :try_start_0
    const-string v3, "MicroMsg.SpeexPlayer"

    #v3=(Reference);
    const-string v4, "before mpause.notify"

    #v4=(Reference);
    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 400
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/av;->bZk:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/Object;->notify()V

    .line 401
    const-string v3, "MicroMsg.SpeexPlayer"

    const-string v4, "after mpause.notify"

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 406
    monitor-exit v2

    move v0, v1

    .line 407
    #v0=(One);
    goto :goto_0

    .line 403
    :catch_0
    #v0=(Null);v3=(Conflicted);v4=(Conflicted);
    move-exception v1

    :try_start_1
    #v1=(Reference);
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 406
    :catchall_0
    #v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v2

    throw v0
.end method

*/}
