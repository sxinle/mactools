package com.tencent.mm.modelvoice; class bc {/*

.class public Lcom/tencent/mm/modelvoice/bc;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/model/ay;


# static fields
.field private static bwv:Ljava/util/HashMap;


# instance fields
.field private bZu:Lcom/tencent/mm/modelvoice/bq;

.field private bZv:Lcom/tencent/mm/modelvoice/al;

.field private bZw:Lcom/tencent/mm/modelvoice/bi;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .prologue
    .line 58
    new-instance v0, Ljava/util/HashMap;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 61
    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/modelvoice/bc;->bwv:Ljava/util/HashMap;

    const-string v1, "VOICE_TABLE"

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    new-instance v2, Lcom/tencent/mm/modelvoice/bd;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/modelvoice/bd;-><init>()V

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 67
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .prologue
    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    #p0=(Reference);
    new-instance v0, Lcom/tencent/mm/modelvoice/bi;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/bi;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/bc;->bZw:Lcom/tencent/mm/modelvoice/bi;

    return-void
.end method

.method private static zn()Lcom/tencent/mm/modelvoice/bc;
    .locals 2

    .prologue
    .line 21
    const-class v0, Lcom/tencent/mm/modelvoice/bc;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/model/ba;->dg(Ljava/lang/String;)Lcom/tencent/mm/model/ay;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/modelvoice/bc;

    .line 22
    if-nez v0, :cond_0

    .line 23
    new-instance v0, Lcom/tencent/mm/modelvoice/bc;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/bc;-><init>()V

    .line 24
    #v0=(Reference);
    const-class v1, Lcom/tencent/mm/modelvoice/bc;

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/tencent/mm/model/ba;->a(Ljava/lang/String;Lcom/tencent/mm/model/ay;)V

    .line 26
    :cond_0
    #v1=(Conflicted);
    return-object v0
.end method

.method public static zo()Lcom/tencent/mm/modelvoice/bq;
    .locals 3

    .prologue
    .line 30
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_0

    .line 31
    new-instance v0, Lcom/tencent/mm/model/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/model/a;-><init>()V

    #v0=(Reference);
    throw v0

    .line 33
    :cond_0
    #v0=(Integer);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/bc;->bZu:Lcom/tencent/mm/modelvoice/bq;

    if-nez v0, :cond_1

    .line 34
    const-string v1, "dataDB is null "

    #v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nI()Lcom/tencent/mm/ao/i;

    move-result-object v0

    if-eqz v0, :cond_2

    const/4 v0, 0x1

    :goto_0
    #v0=(Boolean);
    invoke-static {v1, v0}, Ljunit/framework/Assert;->assertTrue(Ljava/lang/String;Z)V

    .line 35
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    #v0=(Reference);
    new-instance v1, Lcom/tencent/mm/modelvoice/bq;

    #v1=(UninitRef);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/model/b;->nI()Lcom/tencent/mm/ao/i;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/tencent/mm/modelvoice/bq;-><init>(Lcom/tencent/mm/ao/i;)V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/modelvoice/bc;->bZu:Lcom/tencent/mm/modelvoice/bq;

    .line 37
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/bc;->bZu:Lcom/tencent/mm/modelvoice/bq;

    return-object v0

    .line 34
    :cond_2
    #v1=(Reference);v2=(Uninit);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public static zp()Lcom/tencent/mm/modelvoice/al;
    .locals 2

    .prologue
    .line 41
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_0

    .line 42
    new-instance v0, Lcom/tencent/mm/model/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/model/a;-><init>()V

    #v0=(Reference);
    throw v0

    .line 44
    :cond_0
    #v0=(Integer);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/bc;->bZv:Lcom/tencent/mm/modelvoice/al;

    if-nez v0, :cond_1

    .line 45
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    new-instance v1, Lcom/tencent/mm/modelvoice/al;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/modelvoice/al;-><init>()V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/modelvoice/bc;->bZv:Lcom/tencent/mm/modelvoice/al;

    .line 47
    :cond_1
    #v1=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/bc;->bZv:Lcom/tencent/mm/modelvoice/al;

    return-object v0
.end method


# virtual methods
.method public final aQ(I)V
    .locals 0
    .parameter

    .prologue
    .line 76
    return-void
.end method

.method public final l(Z)V
    .locals 2
    .parameter

    .prologue
    .line 80
    const/16 v0, 0x22

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/bc;->bZw:Lcom/tencent/mm/modelvoice/bi;

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/o/l;->a(Ljava/lang/Object;Lcom/tencent/mm/o/j;)V

    .line 81
    return-void
.end method

.method public final lP()V
    .locals 2

    .prologue
    .line 52
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/bc;->bZv:Lcom/tencent/mm/modelvoice/al;

    if-eqz v0, :cond_0

    .line 53
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zn()Lcom/tencent/mm/modelvoice/bc;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/bc;->bZv:Lcom/tencent/mm/modelvoice/al;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/al;->stop()V

    .line 55
    :cond_0
    const/16 v0, 0x22

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/bc;->bZw:Lcom/tencent/mm/modelvoice/bi;

    #v1=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/o/l;->m(Ljava/lang/Object;)V

    .line 56
    return-void
.end method

.method public final lQ()Ljava/util/HashMap;
    .locals 1

    .prologue
    .line 71
    sget-object v0, Lcom/tencent/mm/modelvoice/bc;->bwv:Ljava/util/HashMap;

    #v0=(Reference);
    return-object v0
.end method

.method public final p(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 85
    return-void
.end method

*/}
