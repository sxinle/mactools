package com.tencent.mm.modelvoice; class af {/*

.class public Lcom/tencent/mm/modelvoice/af;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/compatible/audio/i;
.implements Lcom/tencent/mm/o/r;


# instance fields
.field private ah:Ljava/lang/String;

.field private bYD:Lcom/tencent/mm/modelvoice/bn;

.field private bYE:Z

.field private bYF:Z

.field private bYG:J

.field private bYH:J

.field private bYI:I

.field private bYJ:Lcom/tencent/mm/modelvoice/aj;

.field private bYK:I

.field protected bYL:Lcom/tencent/mm/o/t;

.field protected bYM:Lcom/tencent/mm/o/s;

.field private bYN:Lcom/tencent/mm/sdk/platformtools/ax;

.field private bYO:Z

.field private bYu:Lcom/tencent/mm/compatible/f/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4
    .parameter

    .prologue
    const/4 v2, 0x0

    #v2=(Null);
    const/4 v3, 0x0

    .line 79
    #v3=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 53
    #p0=(Reference);
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    .line 56
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    .line 57
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/af;->bYE:Z

    .line 58
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/af;->bYF:Z

    .line 62
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/af;->bYH:J

    .line 63
    iput v3, p0, Lcom/tencent/mm/modelvoice/af;->bYI:I

    .line 71
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYJ:Lcom/tencent/mm/modelvoice/aj;

    .line 74
    iput v3, p0, Lcom/tencent/mm/modelvoice/af;->bYK:I

    .line 77
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYM:Lcom/tencent/mm/o/s;

    .line 130
    new-instance v0, Lcom/tencent/mm/sdk/platformtools/ax;

    #v0=(UninitRef);
    new-instance v1, Lcom/tencent/mm/modelvoice/ag;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mm/modelvoice/ag;-><init>(Lcom/tencent/mm/modelvoice/af;)V

    #v1=(Reference);
    const/4 v2, 0x1

    #v2=(One);
    invoke-direct {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/ax;-><init>(Lcom/tencent/mm/sdk/platformtools/ay;Z)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYN:Lcom/tencent/mm/sdk/platformtools/ax;

    .line 247
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/af;->bYO:Z

    .line 80
    new-instance v0, Lcom/tencent/mm/compatible/f/a;

    #v0=(UninitRef);
    invoke-direct {v0, p1}, Lcom/tencent/mm/compatible/f/a;-><init>(Landroid/content/Context;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYu:Lcom/tencent/mm/compatible/f/a;

    .line 81
    return-void
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/af;J)J
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 51
    iput-wide p1, p0, Lcom/tencent/mm/modelvoice/af;->bYH:J

    return-wide p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/af;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 51
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/af;)I
    .locals 1
    .parameter

    .prologue
    .line 51
    iget v0, p0, Lcom/tencent/mm/modelvoice/af;->bYK:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/af;)I
    .locals 1
    .parameter

    .prologue
    .line 51
    const/4 v0, 0x2

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/af;->bYK:I

    return v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/af;)Lcom/tencent/mm/modelvoice/bn;
    .locals 1
    .parameter

    .prologue
    .line 51
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic e(Lcom/tencent/mm/modelvoice/af;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 51
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic f(Lcom/tencent/mm/modelvoice/af;)Lcom/tencent/mm/modelvoice/bn;
    .locals 1
    .parameter

    .prologue
    .line 51
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    return-object v0
.end method

.method static synthetic g(Lcom/tencent/mm/modelvoice/af;)Lcom/tencent/mm/compatible/f/a;
    .locals 1
    .parameter

    .prologue
    .line 51
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYu:Lcom/tencent/mm/compatible/f/a;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic h(Lcom/tencent/mm/modelvoice/af;)J
    .locals 2
    .parameter

    .prologue
    .line 51
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/af;->bYG:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic i(Lcom/tencent/mm/modelvoice/af;)Z
    .locals 1
    .parameter

    .prologue
    .line 51
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/af;->bYO:Z

    #v0=(Boolean);
    return v0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/o/s;)V
    .locals 0
    .parameter

    .prologue
    .line 373
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/af;->bYM:Lcom/tencent/mm/o/s;

    .line 374
    return-void
.end method

.method public final a(Lcom/tencent/mm/o/t;)V
    .locals 0
    .parameter

    .prologue
    .line 378
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/af;->bYL:Lcom/tencent/mm/o/t;

    .line 379
    return-void
.end method

.method public final aH(I)V
    .locals 4
    .parameter

    .prologue
    const/4 v3, 0x1

    .line 352
    #v3=(One);
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "dkbt Recorder onAudioStatChange :"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 353
    iget-boolean v0, p0, Lcom/tencent/mm/modelvoice/af;->bYO:Z

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 369
    :goto_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 356
    :cond_0
    #v0=(Boolean);v2=(Reference);v3=(One);
    iput-boolean v3, p0, Lcom/tencent/mm/modelvoice/af;->bYO:Z

    .line 357
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/tencent/mm/compatible/audio/d;->b(Lcom/tencent/mm/compatible/audio/i;)V

    .line 358
    new-instance v0, Lcom/tencent/mm/modelvoice/bn;

    #v0=(UninitRef);
    invoke-static {}, Lcom/tencent/mm/compatible/audio/a;->kw()Lcom/tencent/mm/compatible/audio/b;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/tencent/mm/modelvoice/bn;-><init>(Lcom/tencent/mm/compatible/audio/b;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    .line 359
    new-instance v0, Lcom/tencent/mm/modelvoice/ai;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/ai;-><init>(Lcom/tencent/mm/modelvoice/af;)V

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bn;->a(Lcom/tencent/mm/modelvoice/bp;)V

    .line 360
    :cond_1
    new-instance v0, Lcom/tencent/mm/modelvoice/aj;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/aj;-><init>(Lcom/tencent/mm/modelvoice/af;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYJ:Lcom/tencent/mm/modelvoice/aj;

    .line 361
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYJ:Lcom/tencent/mm/modelvoice/aj;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/aj;->start()V

    .line 363
    iput v3, p0, Lcom/tencent/mm/modelvoice/af;->bYK:I

    .line 366
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYN:Lcom/tencent/mm/sdk/platformtools/ax;

    const-wide/16 v1, 0xbb8

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/ax;->bL(J)V

    .line 368
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "start end time:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-wide v2, p0, Lcom/tencent/mm/modelvoice/af;->bYG:J

    #v2=(LongLo);v3=(LongHi);
    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/ce;->N(J)J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method

.method public final cancel()Z
    .locals 4

    .prologue
    const/4 v3, 0x1

    .line 252
    #v3=(One);
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "cancel Record :"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 253
    monitor-enter p0

    .line 254
    :try_start_0
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "stop synchronized Record :"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 255
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    if-eqz v0, :cond_0

    .line 256
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bn;->kM()Z

    .line 257
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    .line 259
    :cond_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 261
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->hb(Ljava/lang/String;)Z

    .line 262
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zp()Lcom/tencent/mm/modelvoice/al;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/al;->run()V

    .line 264
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 265
    new-instance v0, Lcom/tencent/mm/compatible/e/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/compatible/e/a;-><init>()V

    .line 266
    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/tencent/mm/compatible/e/a;->bd(Ljava/lang/String;)V

    .line 267
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/af;->rK()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/compatible/e/a;->l(J)V

    .line 268
    invoke-virtual {v0, v3}, Lcom/tencent/mm/compatible/e/a;->aL(I)V

    .line 269
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bn;->yZ()I

    move-result v1

    #v1=(Integer);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/compatible/e/a;->aM(I)V

    .line 270
    sget-object v1, Lcom/tencent/mm/plugin/c/c/m;->dkF:Lcom/tencent/mm/plugin/c/c/m;

    #v1=(Reference);
    const/16 v2, 0x2911

    #v2=(PosShort);
    invoke-virtual {v0}, Lcom/tencent/mm/compatible/e/a;->lx()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Lcom/tencent/mm/plugin/c/c/m;->j(ILjava/lang/String;)V

    .line 273
    :cond_1
    #v0=(Conflicted);v2=(Conflicted);
    const-string v0, ""

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    .line 274
    return v3

    .line 259
    :catchall_0
    #v1=(Conflicted);v2=(Reference);
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final ef(Ljava/lang/String;)Z
    .locals 5
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 192
    #v0=(Null);
    const-string v2, "MicroMsg.SceneVoice.Recorder"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "Start Record to  "

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 193
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/af;->reset()V

    .line 194
    invoke-static {}, Lcom/tencent/mm/sdk/platformtools/ce;->Az()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    iput-wide v2, p0, Lcom/tencent/mm/modelvoice/af;->bYG:J

    .line 196
    if-nez p1, :cond_0

    .line 197
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    #v1=(Reference);
    const-string v2, "Start Record toUser null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 244
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 201
    :cond_0
    #v0=(Null);v1=(One);v2=(LongLo);v3=(LongHi);v4=(Reference);
    const-string v2, "_USER_FOR_THROWBOTTLE_"

    #v2=(Reference);
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    iput-boolean v2, p0, Lcom/tencent/mm/modelvoice/af;->bYE:Z

    .line 203
    const-string v2, "medianote"

    #v2=(Reference);
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_1

    .line 204
    invoke-static {}, Lcom/tencent/mm/model/s;->oA()I

    move-result v2

    #v2=(Integer);
    and-int/lit16 v2, v2, 0x4000

    if-nez v2, :cond_3

    .line 205
    iput-boolean v1, p0, Lcom/tencent/mm/modelvoice/af;->bYF:Z

    .line 211
    :cond_1
    :goto_1
    iget-boolean v2, p0, Lcom/tencent/mm/modelvoice/af;->bYE:Z

    #v2=(Boolean);
    if-eqz v2, :cond_4

    .line 212
    invoke-static {}, Lcom/tencent/mm/model/s;->ow()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/modelvoice/bq;->hf(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    .line 218
    :goto_2
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    if-eqz v2, :cond_2

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    #v2=(Integer);
    if-gtz v2, :cond_6

    .line 219
    :cond_2
    #v2=(Conflicted);
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    #v1=(Reference);
    const-string v2, "Start Record DBError "

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 207
    :cond_3
    #v1=(One);v2=(Integer);
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/af;->bYF:Z

    goto :goto_1

    .line 213
    :cond_4
    #v2=(Boolean);
    iget-boolean v2, p0, Lcom/tencent/mm/modelvoice/af;->bYF:Z

    if-eqz v2, :cond_5

    .line 214
    const-string v2, "medianote"

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/modelvoice/bq;->hf(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    goto :goto_2

    .line 216
    :cond_5
    #v2=(Boolean);
    invoke-static {p1}, Lcom/tencent/mm/modelvoice/bh;->gZ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    iput-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    goto :goto_2

    .line 222
    :cond_6
    #v2=(Integer);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2, p0}, Lcom/tencent/mm/compatible/audio/d;->a(Lcom/tencent/mm/compatible/audio/i;)V

    .line 223
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/mm/compatible/audio/d;->kB()I

    move-result v2

    .line 225
    #v2=(Integer);
    iput-boolean v0, p0, Lcom/tencent/mm/modelvoice/af;->bYO:Z

    .line 226
    if-eqz v2, :cond_7

    .line 227
    const/16 v0, 0x64

    #v0=(PosByte);
    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/af;->aH(I)V

    :goto_3
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    move v0, v1

    .line 244
    #v0=(One);
    goto :goto_0

    .line 229
    :cond_7
    #v0=(Null);v2=(Integer);v3=(LongHi);v4=(Reference);
    new-instance v2, Lcom/tencent/mm/modelvoice/ah;

    #v2=(UninitRef);
    invoke-direct {v2, p0}, Lcom/tencent/mm/modelvoice/ah;-><init>(Lcom/tencent/mm/modelvoice/af;)V

    #v2=(Reference);
    const-wide/16 v3, 0x32

    #v3=(LongLo);v4=(LongHi);
    invoke-virtual {v2, v0, v3, v4}, Lcom/tencent/mm/modelvoice/ah;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_3
.end method

.method public getFileName()Ljava/lang/String;
    .locals 1

    .prologue
    .line 111
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method public final getMaxAmplitude()I
    .locals 1

    .prologue
    .line 124
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    #v0=(Reference);
    if-nez v0, :cond_0

    .line 125
    const/4 v0, 0x0

    .line 127
    :goto_0
    #v0=(Integer);
    return v0

    :cond_0
    #v0=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bn;->getMaxAmplitude()I

    move-result v0

    #v0=(Integer);
    goto :goto_0
.end method

.method public kR()Z
    .locals 8

    .prologue
    const/4 v0, 0x1

    #v0=(One);
    const/4 v7, 0x2

    #v7=(PosByte);
    const/4 v1, 0x0

    .line 280
    #v1=(Null);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pP()Lcom/tencent/mm/compatible/audio/d;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/compatible/audio/d;->kC()V

    .line 281
    const-string v2, "MicroMsg.SceneVoice.Recorder"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "stop Record :"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 284
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    if-eqz v2, :cond_0

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-static {v2}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_0

    .line 285
    new-instance v2, Lcom/tencent/mm/compatible/e/a;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/compatible/e/a;-><init>()V

    .line 286
    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lcom/tencent/mm/compatible/e/a;->bd(Ljava/lang/String;)V

    .line 287
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/af;->rK()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    invoke-virtual {v2, v3, v4}, Lcom/tencent/mm/compatible/e/a;->l(J)V

    .line 288
    invoke-virtual {v2, v7}, Lcom/tencent/mm/compatible/e/a;->aL(I)V

    .line 289
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    #v3=(Reference);
    invoke-virtual {v3}, Lcom/tencent/mm/modelvoice/bn;->yZ()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Lcom/tencent/mm/compatible/e/a;->aM(I)V

    .line 290
    sget-object v3, Lcom/tencent/mm/plugin/c/c/m;->dkF:Lcom/tencent/mm/plugin/c/c/m;

    #v3=(Reference);
    const/16 v4, 0x2911

    #v4=(PosShort);
    invoke-virtual {v2}, Lcom/tencent/mm/compatible/e/a;->lx()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v4, v2}, Lcom/tencent/mm/plugin/c/c/m;->j(ILjava/lang/String;)V

    .line 292
    :cond_0
    #v2=(Conflicted);v4=(Conflicted);
    monitor-enter p0

    .line 293
    :try_start_0
    const-string v2, "MicroMsg.SceneVoice.Recorder"

    #v2=(Reference);
    const-string v3, "stop synchronized Record:%s, recorder:%s"

    const/4 v4, 0x2

    #v4=(PosByte);
    new-array v4, v4, [Ljava/lang/Object;

    #v4=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    iget-object v6, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    #v6=(Reference);
    aput-object v6, v4, v5

    const/4 v5, 0x1

    #v5=(One);
    iget-object v6, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    aput-object v6, v4, v5

    invoke-static {v2, v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 294
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    if-eqz v2, :cond_1

    .line 295
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bn;->kM()Z

    .line 296
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v2}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    .line 298
    :cond_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 299
    iget v2, p0, Lcom/tencent/mm/modelvoice/af;->bYK:I

    #v2=(Integer);
    if-eq v2, v7, :cond_2

    .line 300
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->hd(Ljava/lang/String;)Z

    .line 301
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    .line 303
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Stop "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " by not onPart: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v3, p0, Lcom/tencent/mm/modelvoice/af;->bYG:J

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/ce;->N(J)J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 319
    :goto_0
    #v0=(Conflicted);v1=(Boolean);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    const/4 v0, -0x1

    #v0=(Byte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/af;->bYK:I

    .line 320
    return v1

    .line 298
    :catchall_0
    #v0=(One);v1=(Null);v2=(Conflicted);v3=(Reference);v6=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit p0

    throw v0

    .line 305
    :cond_2
    #v0=(One);v2=(Integer);v4=(Reference);v5=(One);v6=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/af;->rK()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    long-to-int v2, v2

    #v2=(Integer);
    iput v2, p0, Lcom/tencent/mm/modelvoice/af;->bYI:I

    .line 306
    iget v2, p0, Lcom/tencent/mm/modelvoice/af;->bYI:I

    int-to-long v2, v2

    #v2=(LongLo);
    const-wide/16 v4, 0x320

    #v4=(LongLo);v5=(LongHi);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-ltz v2, :cond_3

    iget-boolean v2, p0, Lcom/tencent/mm/modelvoice/af;->bYE:Z

    #v2=(Boolean);
    if-eqz v2, :cond_4

    iget v2, p0, Lcom/tencent/mm/modelvoice/af;->bYI:I

    #v2=(Integer);
    int-to-long v2, v2

    #v2=(LongLo);
    const-wide/16 v4, 0x3e8

    cmp-long v2, v2, v4

    #v2=(Byte);
    if-gez v2, :cond_4

    .line 307
    :cond_3
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    #v0=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Stop "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " by voiceLen: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, p0, Lcom/tencent/mm/modelvoice/af;->bYI:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 308
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->hd(Ljava/lang/String;)Z

    .line 309
    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    move v0, v1

    .line 317
    :goto_1
    #v0=(Boolean);v1=(Reference);v3=(Conflicted);
    const-string v1, ""

    iput-object v1, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    move v1, v0

    #v1=(Boolean);
    goto :goto_0

    .line 312
    :cond_4
    #v0=(One);v1=(Null);v2=(Byte);v3=(LongHi);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    #v2=(Reference);
    iget v3, p0, Lcom/tencent/mm/modelvoice/af;->bYI:I

    #v3=(Integer);
    invoke-static {v2, v3, v1}, Lcom/tencent/mm/modelvoice/bh;->n(Ljava/lang/String;II)Z

    .line 313
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zp()Lcom/tencent/mm/modelvoice/al;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/al;->run()V

    .line 315
    const-string v1, "MicroMsg.SceneVoice.Recorder"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Stop file success: "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1
.end method

.method public final rJ()Z
    .locals 3

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 116
    #v0=(Null);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    #v2=(Reference);
    if-nez v2, :cond_1

    .line 119
    :cond_0
    :goto_0
    #v0=(Boolean);v2=(Conflicted);
    return v0

    :cond_1
    #v0=(Null);v2=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/bn;->getStatus()I

    move-result v2

    #v2=(Integer);
    if-ne v2, v1, :cond_0

    move v0, v1

    #v0=(One);
    goto :goto_0
.end method

.method public final rK()J
    .locals 4

    .prologue
    const-wide/16 v0, 0x0

    .line 343
    #v0=(LongLo);v1=(LongHi);
    iget-wide v2, p0, Lcom/tencent/mm/modelvoice/af;->bYH:J

    #v2=(LongLo);v3=(LongHi);
    cmp-long v2, v2, v0

    #v2=(Byte);
    if-nez v2, :cond_0

    .line 346
    :goto_0
    return-wide v0

    :cond_0
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/af;->bYH:J

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/ce;->N(J)J

    move-result-wide v0

    goto :goto_0
.end method

.method public final rL()I
    .locals 1

    .prologue
    .line 106
    iget v0, p0, Lcom/tencent/mm/modelvoice/af;->bYI:I

    #v0=(Integer);
    return v0
.end method

.method public final reset()V
    .locals 4

    .prologue
    const-wide/16 v2, 0x0

    .line 92
    #v2=(LongLo);v3=(LongHi);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    #v0=(Reference);
    if-eqz v0, :cond_0

    .line 93
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYD:Lcom/tencent/mm/modelvoice/bn;

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bn;->kM()Z

    .line 94
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYu:Lcom/tencent/mm/compatible/f/a;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/f/a;->ly()Z

    .line 95
    const-string v0, "MicroMsg.SceneVoice.Recorder"

    const-string v1, "Reset recorder.stopReocrd"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 97
    :cond_0
    #v1=(Conflicted);
    const-string v0, ""

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->ah:Ljava/lang/String;

    .line 98
    iput-wide v2, p0, Lcom/tencent/mm/modelvoice/af;->bYG:J

    .line 99
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/af;->bYJ:Lcom/tencent/mm/modelvoice/aj;

    .line 100
    const/4 v0, 0x0

    iput v0, p0, Lcom/tencent/mm/modelvoice/af;->bYK:I

    .line 101
    iput-wide v2, p0, Lcom/tencent/mm/modelvoice/af;->bYH:J

    .line 102
    return-void
.end method

.method public final zj()Z
    .locals 1

    .prologue
    .line 187
    const-string v0, "_USER_FOR_THROWBOTTLE_"

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/af;->ef(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

*/}
