package com.tencent.mm.modelvoice; class r {/*

.class final Lcom/tencent/mm/modelvoice/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/sdk/platformtools/ay;


# instance fields
.field final synthetic bYg:Lcom/tencent/mm/modelvoice/p;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/p;)V
    .locals 0
    .parameter

    .prologue
    .line 256
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/r;->bYg:Lcom/tencent/mm/modelvoice/p;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final jK()Z
    .locals 5

    .prologue
    const/4 v4, -0x1

    .line 259
    #v4=(Byte);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/r;->bYg:Lcom/tencent/mm/modelvoice/p;

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/r;->bYg:Lcom/tencent/mm/modelvoice/p;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/p;->a(Lcom/tencent/mm/modelvoice/p;)Lcom/tencent/mm/network/q;

    move-result-object v1

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/r;->bYg:Lcom/tencent/mm/modelvoice/p;

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/modelvoice/p;->b(Lcom/tencent/mm/modelvoice/p;)Lcom/tencent/mm/o/m;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/modelvoice/p;->a(Lcom/tencent/mm/network/q;Lcom/tencent/mm/o/m;)I

    move-result v0

    #v0=(Integer);
    if-ne v0, v4, :cond_0

    .line 260
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/r;->bYg:Lcom/tencent/mm/modelvoice/p;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/p;->b(Lcom/tencent/mm/modelvoice/p;)Lcom/tencent/mm/o/m;

    move-result-object v0

    const/4 v1, 0x3

    #v1=(PosByte);
    const-string v2, "doScene failed"

    iget-object v3, p0, Lcom/tencent/mm/modelvoice/r;->bYg:Lcom/tencent/mm/modelvoice/p;

    #v3=(Reference);
    invoke-interface {v0, v1, v4, v2, v3}, Lcom/tencent/mm/o/m;->a(IILjava/lang/String;Lcom/tencent/mm/o/x;)V

    .line 262
    :cond_0
    #v0=(Conflicted);v1=(Conflicted);v3=(Conflicted);
    const/4 v0, 0x0

    #v0=(Null);
    return v0
.end method

*/}
