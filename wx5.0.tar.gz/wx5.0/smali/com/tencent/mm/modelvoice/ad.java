package com.tencent.mm.modelvoice; class ad {/*

.class final Lcom/tencent/mm/modelvoice/ad;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic bYB:Lcom/tencent/mm/modelvoice/ac;


# direct methods
.method constructor <init>(Lcom/tencent/mm/modelvoice/ac;)V
    .locals 0
    .parameter

    .prologue
    .line 894
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/ad;->bYB:Lcom/tencent/mm/modelvoice/ac;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .prologue
    .line 899
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/ad;->bYB:Lcom/tencent/mm/modelvoice/ac;

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ac;->bYA:Lcom/tencent/mm/modelvoice/ab;

    iget-object v0, v0, Lcom/tencent/mm/modelvoice/ab;->bYy:Lcom/tencent/mm/modelvoice/y;

    invoke-static {v0}, Lcom/tencent/mm/modelvoice/y;->d(Lcom/tencent/mm/modelvoice/y;)Landroid/content/Context;

    move-result-object v0

    sget v1, Lcom/tencent/mm/k;->aSo:I

    #v1=(Integer);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/ad;->bYB:Lcom/tencent/mm/modelvoice/ac;

    #v2=(Reference);
    iget-object v2, v2, Lcom/tencent/mm/modelvoice/ac;->bYA:Lcom/tencent/mm/modelvoice/ab;

    iget-object v2, v2, Lcom/tencent/mm/modelvoice/ab;->bYy:Lcom/tencent/mm/modelvoice/y;

    invoke-static {v2}, Lcom/tencent/mm/modelvoice/y;->e(Lcom/tencent/mm/modelvoice/y;)Z

    move-result v2

    #v2=(Boolean);
    new-instance v3, Lcom/tencent/mm/modelvoice/ae;

    #v3=(UninitRef);
    invoke-direct {v3, p0}, Lcom/tencent/mm/modelvoice/ae;-><init>(Lcom/tencent/mm/modelvoice/ad;)V

    #v3=(Reference);
    invoke-static {v0, v1, v2, v3}, Lcom/tencent/mm/sdk/platformtools/bl;->a(Landroid/content/Context;IZLcom/tencent/mm/sdk/platformtools/bn;)V

    .line 910
    return-void
.end method

*/}
