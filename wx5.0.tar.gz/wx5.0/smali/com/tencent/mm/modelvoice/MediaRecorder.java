package com.tencent.mm.modelvoice; class MediaRecorder {/*

.class public Lcom/tencent/mm/modelvoice/MediaRecorder;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final bzb:[I

.field private static bzi:J

.field private static bzj:Ljava/lang/Object;


# instance fields
.field private bXL:Lcom/tencent/mm/modelvoice/n;

.field private bXM:Lcom/tencent/mm/modelvoice/j;

.field private bXN:Lcom/tencent/mm/ae/k;

.field private bXO:Lcom/tencent/mm/ae/d;

.field private bXP:Lcom/tencent/mm/modelvoice/o;

.field private bzd:I

.field private bze:Ljava/lang/String;

.field private bzg:J

.field private bzh:J

.field private bzk:Landroid/media/MediaRecorder;

.field private bzl:I

.field private bzm:Lcom/tencent/mm/compatible/audio/n;

.field private bzn:Lcom/tencent/mm/compatible/audio/b;

.field private bzp:I

.field private bzq:I

.field private bzr:Lcom/tencent/mm/compatible/f/k;

.field private bzs:Lcom/tencent/mm/compatible/audio/p;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .prologue
    .line 43
    const/16 v0, 0x8

    #v0=(PosByte);
    new-array v0, v0, [I

    #v0=(Reference);
    fill-array-data v0, :array_0

    sput-object v0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzb:[I

    .line 79
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    sput-wide v0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzi:J

    .line 83
    new-instance v0, Ljava/lang/Object;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzj:Ljava/lang/Object;

    return-void

    .line 43
    #v0=(Unknown);v1=(Unknown);
    nop

    :array_0
    .array-data 0x4
        0xdt 0x0t 0x0t 0x0t
        0xet 0x0t 0x0t 0x0t
        0x10t 0x0t 0x0t 0x0t
        0x12t 0x0t 0x0t 0x0t
        0x14t 0x0t 0x0t 0x0t
        0x15t 0x0t 0x0t 0x0t
        0x1bt 0x0t 0x0t 0x0t
        0x20t 0x0t 0x0t 0x0t
    .end array-data
.end method

.method public constructor <init>(Lcom/tencent/mm/compatible/audio/b;)V
    .locals 8
    .parameter

    .prologue
    const-wide/16 v0, 0x0

    #v0=(LongLo);v1=(LongHi);
    const/16 v7, 0x1f40

    #v7=(PosShort);
    const/4 v6, 0x1

    #v6=(One);
    const/4 v5, 0x0

    #v5=(Null);
    const/4 v4, 0x0

    .line 126
    #v4=(Null);
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 68
    #p0=(Reference);
    iput v5, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzd:I

    .line 70
    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bze:Ljava/lang/String;

    .line 71
    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    .line 72
    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXN:Lcom/tencent/mm/ae/k;

    .line 73
    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXO:Lcom/tencent/mm/ae/d;

    .line 77
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzg:J

    .line 78
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzh:J

    .line 87
    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    .line 306
    iput v7, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzp:I

    .line 421
    iput v5, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzq:I

    .line 422
    new-instance v0, Lcom/tencent/mm/compatible/f/k;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzr:Lcom/tencent/mm/compatible/f/k;

    .line 424
    new-instance v0, Lcom/tencent/mm/modelvoice/h;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/modelvoice/h;-><init>(Lcom/tencent/mm/modelvoice/MediaRecorder;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzs:Lcom/tencent/mm/compatible/audio/p;

    .line 127
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    .line 128
    sget-object v0, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    if-ne p1, v0, :cond_0

    .line 129
    const/4 v0, 0x7

    #v0=(PosByte);
    iput v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzl:I

    .line 130
    new-instance v0, Landroid/media/MediaRecorder;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/media/MediaRecorder;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    .line 136
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Boolean);
    return-void

    .line 132
    :cond_0
    #v1=(LongHi);v2=(Uninit);v3=(Uninit);v4=(Null);
    invoke-static {}, Lcom/tencent/mm/ae/d;->xH()Lcom/tencent/mm/ae/d;

    move-result-object v0

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXO:Lcom/tencent/mm/ae/d;

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXO:Lcom/tencent/mm/ae/d;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXO:Lcom/tencent/mm/ae/d;

    invoke-virtual {v0}, Lcom/tencent/mm/ae/d;->xG()Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_2

    const/16 v0, 0x3e80

    #v0=(PosShort);
    iput v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzp:I

    :goto_1
    #v0=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pG()Lcom/tencent/mm/storage/d;

    move-result-object v0

    #v0=(Reference);
    const/16 v1, 0x1b

    #v1=(PosByte);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/storage/d;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-static {v0, v5}, Lcom/tencent/mm/sdk/platformtools/ce;->a(Ljava/lang/Integer;I)I

    move-result v0

    #v0=(Integer);
    const-string v1, "MicroMsg.MediaRecorder"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "dk16k sr:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget v3, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzp:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " notsu:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    if-ne v0, v6, :cond_1

    iput v7, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzp:I

    :cond_1
    iput v5, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzd:I

    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bze:Ljava/lang/String;

    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    iput-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXN:Lcom/tencent/mm/ae/k;

    :try_start_0
    const-string v0, "MicroMsg.MediaRecorder"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "!!out mutex :"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    sget-object v2, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzj:Ljava/lang/Object;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v1, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzj:Ljava/lang/Object;

    monitor-enter v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    new-instance v0, Lcom/tencent/mm/compatible/audio/n;

    #v0=(UninitRef);
    iget v2, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzp:I

    const/16 v3, 0x78

    #v3=(PosByte);
    const/4 v4, 0x1

    #v4=(One);
    const/4 v5, 0x0

    invoke-direct {v0, v2, v3, v4, v5}, Lcom/tencent/mm/compatible/audio/n;-><init>(IIZI)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    iget-object v2, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzs:Lcom/tencent/mm/compatible/audio/p;

    #v2=(Reference);
    invoke-virtual {v0, v2}, Lcom/tencent/mm/compatible/audio/n;->a(Lcom/tencent/mm/compatible/audio/p;)V

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXV:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 133
    :goto_2
    #v2=(Conflicted);v3=(Conflicted);v4=(Boolean);
    iput v6, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzl:I

    goto/16 :goto_0

    .line 132
    :cond_2
    #v0=(Conflicted);v1=(LongHi);v2=(Uninit);v3=(Uninit);v4=(Null);
    iput v7, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzp:I

    goto :goto_1

    :catchall_0
    #v1=(Reference);v2=(Conflicted);v3=(Conflicted);v4=(Boolean);
    move-exception v0

    :try_start_3
    #v0=(Reference);
    monitor-exit v1

    throw v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    :catch_0
    #v0=(Conflicted);v1=(Conflicted);
    move-exception v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    if-eqz v1, :cond_3

    const-string v1, "MicroMsg.MediaRecorder"

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXY:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    goto :goto_2

    :cond_3
    const-string v0, "MicroMsg.MediaRecorder"

    const-string v1, "Unknown error occured while initializing recording"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_3
.end method

.method static synthetic I(J)J
    .locals 0
    .parameter

    .prologue
    .line 26
    sput-wide p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzi:J

    return-wide p0
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/MediaRecorder;I)I
    .locals 1
    .parameter
    .parameter

    .prologue
    .line 26
    iget v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzq:I

    #v0=(Integer);
    add-int/2addr v0, p1

    iput v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzq:I

    return v0
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/MediaRecorder;Lcom/tencent/mm/ae/k;)Lcom/tencent/mm/ae/k;
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 26
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXN:Lcom/tencent/mm/ae/k;

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/MediaRecorder;Lcom/tencent/mm/modelvoice/j;)Lcom/tencent/mm/modelvoice/j;
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 26
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/mm/modelvoice/MediaRecorder;)Lcom/tencent/mm/modelvoice/n;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXL:Lcom/tencent/mm/modelvoice/n;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/MediaRecorder;I)I
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 26
    iput p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzd:I

    return p1
.end method

.method static synthetic b(Lcom/tencent/mm/modelvoice/MediaRecorder;)Landroid/media/MediaRecorder;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic b(I[BILcom/tencent/mm/pointers/PByteArray;I)Z
    .locals 1
    .parameter
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    .line 26
    invoke-static {p0, p1, p2, p3, p4}, Lcom/tencent/mm/modelvoice/MediaRecorder;->native_pcm2amr(I[BILcom/tencent/mm/pointers/PByteArray;I)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method static synthetic c(Lcom/tencent/mm/modelvoice/MediaRecorder;)Lcom/tencent/mm/modelvoice/o;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic d(Lcom/tencent/mm/modelvoice/MediaRecorder;)J
    .locals 2
    .parameter

    .prologue
    .line 26
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzh:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic e(Lcom/tencent/mm/modelvoice/MediaRecorder;)J
    .locals 2
    .parameter

    .prologue
    .line 26
    iget-wide v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzg:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic f(Lcom/tencent/mm/modelvoice/MediaRecorder;)Lcom/tencent/mm/compatible/f/k;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzr:Lcom/tencent/mm/compatible/f/k;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic g(Lcom/tencent/mm/modelvoice/MediaRecorder;)I
    .locals 1
    .parameter

    .prologue
    .line 26
    iget v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzq:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic h(Lcom/tencent/mm/modelvoice/MediaRecorder;)Lcom/tencent/mm/ae/k;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXN:Lcom/tencent/mm/ae/k;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic i(Lcom/tencent/mm/modelvoice/MediaRecorder;)Lcom/tencent/mm/ae/d;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXO:Lcom/tencent/mm/ae/d;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic j(Lcom/tencent/mm/modelvoice/MediaRecorder;)I
    .locals 1
    .parameter

    .prologue
    .line 26
    iget v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzp:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic k(Lcom/tencent/mm/modelvoice/MediaRecorder;)Lcom/tencent/mm/modelvoice/j;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic l(Lcom/tencent/mm/modelvoice/MediaRecorder;)I
    .locals 1
    .parameter

    .prologue
    .line 26
    iget v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzl:I

    #v0=(Integer);
    return v0
.end method

.method static synthetic m(Lcom/tencent/mm/modelvoice/MediaRecorder;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 26
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bze:Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

.method static synthetic n(Lcom/tencent/mm/modelvoice/MediaRecorder;)I
    .locals 1
    .parameter

    .prologue
    .line 26
    iget v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzd:I

    #v0=(Integer);
    return v0
.end method

.method private static native native_init()Z
.end method

.method private static native native_pcm2amr(I[BILcom/tencent/mm/pointers/PByteArray;I)Z
.end method

.method private static native native_pcmresamp([BILcom/tencent/mm/pointers/PByteArray;)Z
.end method

.method private static native native_release()Z
.end method

.method static synthetic zb()J
    .locals 2

    .prologue
    .line 26
    sget-wide v0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzi:J

    #v0=(LongLo);v1=(LongHi);
    return-wide v0
.end method

.method static synthetic zc()Z
    .locals 1

    .prologue
    .line 26
    invoke-static {}, Lcom/tencent/mm/modelvoice/MediaRecorder;->native_init()Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method static synthetic zd()Z
    .locals 1

    .prologue
    .line 26
    invoke-static {}, Lcom/tencent/mm/modelvoice/MediaRecorder;->native_release()Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/modelvoice/n;)V
    .locals 2
    .parameter

    .prologue
    .line 139
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_2

    .line 140
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_1

    .line 173
    :cond_0
    :goto_0
    return-void

    .line 143
    :cond_1
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXL:Lcom/tencent/mm/modelvoice/n;

    .line 144
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    new-instance v1, Lcom/tencent/mm/modelvoice/g;

    #v1=(UninitRef);
    invoke-direct {v1, p0}, Lcom/tencent/mm/modelvoice/g;-><init>(Lcom/tencent/mm/modelvoice/MediaRecorder;)V

    #v1=(Reference);
    invoke-virtual {v0, v1}, Landroid/media/MediaRecorder;->setOnErrorListener(Landroid/media/MediaRecorder$OnErrorListener;)V

    .line 158
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXY:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    goto :goto_0

    .line 162
    :cond_2
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v1, Lcom/tencent/mm/modelvoice/o;->bXV:Lcom/tencent/mm/modelvoice/o;

    if-ne v0, v1, :cond_0

    .line 163
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXL:Lcom/tencent/mm/modelvoice/n;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 165
    :catch_0
    move-exception v0

    .line 166
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3

    .line 167
    const-string v1, "MicroMsg.MediaRecorder"

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 171
    :goto_1
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXY:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    goto :goto_0

    .line 169
    :cond_3
    const-string v0, "MicroMsg.MediaRecorder"

    const-string v1, "Unknown error occured while setting output path"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1
.end method

.method public final getMaxAmplitude()I
    .locals 3

    .prologue
    const/4 v0, 0x0

    .line 269
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    sget-object v2, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v2=(Reference);
    if-ne v1, v2, :cond_2

    .line 270
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v1, :cond_1

    .line 281
    :cond_0
    :goto_0
    #v0=(Integer);v1=(Conflicted);
    return v0

    .line 273
    :cond_1
    #v0=(Null);v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    #v0=(Reference);
    invoke-virtual {v0}, Landroid/media/MediaRecorder;->getMaxAmplitude()I

    move-result v0

    #v0=(Integer);
    goto :goto_0

    .line 275
    :cond_2
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v2, Lcom/tencent/mm/modelvoice/o;->bXX:Lcom/tencent/mm/modelvoice/o;

    if-ne v1, v2, :cond_0

    .line 276
    iget v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzd:I

    .line 277
    #v1=(Integer);
    iput v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzd:I

    move v0, v1

    .line 278
    #v0=(Integer);
    goto :goto_0
.end method

.method public final kN()V
    .locals 2

    .prologue
    .line 204
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_1

    .line 205
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_0

    .line 213
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);
    return-void

    .line 208
    :cond_0
    #v0=(Reference);v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    const v1, 0x11170

    #v1=(Integer);
    invoke-virtual {v0, v1}, Landroid/media/MediaRecorder;->setMaxDuration(I)V

    goto :goto_0

    .line 212
    :cond_1
    #v1=(Reference);
    const-wide/32 v0, 0x11170

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzg:J

    goto :goto_0
.end method

.method public final kO()V
    .locals 2

    .prologue
    .line 221
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_0

    .line 222
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_1

    .line 228
    :cond_0
    :goto_0
    #v1=(Conflicted);
    return-void

    .line 225
    :cond_1
    #v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {v0, v1}, Landroid/media/MediaRecorder;->setAudioEncoder(I)V

    goto :goto_0
.end method

.method public final kP()V
    .locals 2

    .prologue
    .line 236
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_0

    .line 237
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_1

    .line 244
    :cond_0
    :goto_0
    #v1=(Conflicted);
    return-void

    .line 240
    :cond_1
    #v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {v0, v1}, Landroid/media/MediaRecorder;->setAudioSource(I)V

    goto :goto_0
.end method

.method public final kQ()V
    .locals 2

    .prologue
    .line 252
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_0

    .line 253
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_1

    .line 259
    :cond_0
    :goto_0
    #v1=(Conflicted);
    return-void

    .line 256
    :cond_1
    #v1=(Reference);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    const/4 v1, 0x3

    #v1=(PosByte);
    invoke-virtual {v0, v1}, Landroid/media/MediaRecorder;->setOutputFormat(I)V

    goto :goto_0
.end method

.method public final kR()Z
    .locals 13

    .prologue
    const/4 v6, 0x0

    #v6=(Null);
    const/4 v1, 0x0

    #v1=(Null);
    const/4 v0, 0x1

    .line 512
    #v0=(One);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v2=(Reference);
    sget-object v3, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v3=(Reference);
    if-ne v2, v3, :cond_1

    .line 513
    const-string v2, "MicroMsg.MediaRecorder"

    const-string v3, "MediaRecorder stop RECMODE.AMR sysMediaRecorder:%s"

    new-array v4, v0, [Ljava/lang/Object;

    #v4=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    #v5=(Reference);
    aput-object v5, v4, v1

    invoke-static {v2, v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 514
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    #v1=(Reference);
    if-eqz v1, :cond_0

    .line 515
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    invoke-virtual {v1}, Landroid/media/MediaRecorder;->stop()V

    .line 516
    iget-object v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    invoke-virtual {v1}, Landroid/media/MediaRecorder;->release()V

    .line 517
    iput-object v6, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    .line 554
    :cond_0
    :goto_0
    #v0=(Boolean);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);v10=(Conflicted);v11=(Conflicted);v12=(Conflicted);
    return v0

    .line 522
    :cond_1
    #v0=(One);v1=(Null);v4=(Uninit);v5=(Uninit);v6=(Null);v7=(Uninit);v8=(Uninit);v9=(Uninit);v10=(Uninit);v11=(Uninit);v12=(Uninit);
    new-instance v2, Lcom/tencent/mm/compatible/f/k;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    .line 524
    #v2=(Reference);
    const-string v3, "MicroMsg.MediaRecorder"

    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "Stop now  state:"

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    iget-object v5, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 525
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v4, Lcom/tencent/mm/modelvoice/o;->bXX:Lcom/tencent/mm/modelvoice/o;

    if-eq v3, v4, :cond_2

    .line 526
    const-string v1, "MicroMsg.MediaRecorder"

    #v1=(Reference);
    const-string v2, "stop() called on illegal state"

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 527
    sget-object v1, Lcom/tencent/mm/modelvoice/o;->bXY:Lcom/tencent/mm/modelvoice/o;

    iput-object v1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    goto :goto_0

    .line 530
    :cond_2
    #v1=(Null);
    sget-object v3, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzj:Ljava/lang/Object;

    monitor-enter v3

    .line 532
    :try_start_0
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    if-eqz v4, :cond_5

    .line 533
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    invoke-virtual {v4}, Lcom/tencent/mm/compatible/audio/n;->kM()Z

    .line 534
    iget-object v4, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    const/4 v5, 0x0

    #v5=(Null);
    invoke-virtual {v4, v5}, Lcom/tencent/mm/compatible/audio/n;->a(Lcom/tencent/mm/compatible/audio/p;)V

    .line 539
    :goto_1
    #v5=(Reference);
    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 540
    invoke-virtual {v2}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v3

    .line 542
    #v3=(LongLo);v4=(LongHi);
    sget-object v5, Lcom/tencent/mm/modelvoice/o;->bXZ:Lcom/tencent/mm/modelvoice/o;

    iput-object v5, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    .line 544
    invoke-virtual {v2}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v5

    .line 546
    #v5=(LongLo);v6=(LongHi);
    iget-object v7, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    #v7=(Reference);
    invoke-virtual {v7}, Lcom/tencent/mm/modelvoice/j;->kV()Z

    .line 547
    iget-object v7, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXN:Lcom/tencent/mm/ae/k;

    if-eqz v7, :cond_3

    .line 548
    iget-object v7, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXN:Lcom/tencent/mm/ae/k;

    invoke-virtual {v7}, Lcom/tencent/mm/ae/k;->stop()V

    .line 551
    :cond_3
    iget-wide v7, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzh:J

    #v7=(LongLo);v8=(LongHi);
    invoke-static {v7, v8}, Lcom/tencent/mm/sdk/platformtools/ce;->M(J)J

    move-result-wide v7

    const-string v9, "MicroMsg.MediaRecorder"

    #v9=(Reference);
    new-instance v10, Ljava/lang/StringBuilder;

    #v10=(UninitRef);
    const-string v11, "toNow "

    #v11=(Reference);
    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v10=(Reference);
    invoke-virtual {v10, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " sStartTS "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    iget-wide v11, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzh:J

    #v11=(LongLo);v12=(LongHi);
    invoke-virtual {v10, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " bufferLen "

    #v11=(Reference);
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    sget-wide v11, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzi:J

    #v11=(LongLo);
    invoke-virtual {v10, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v9, 0x7d0

    #v9=(LongLo);v10=(LongHi);
    cmp-long v7, v7, v9

    #v7=(Byte);
    if-lez v7, :cond_4

    sget-wide v7, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzi:J

    #v7=(LongLo);
    const-wide/16 v9, 0x0

    cmp-long v7, v7, v9

    #v7=(Byte);
    if-nez v7, :cond_4

    invoke-static {}, Lcom/tencent/mm/model/ba;->pG()Lcom/tencent/mm/storage/d;

    move-result-object v7

    #v7=(Reference);
    const/16 v8, 0x1b

    #v8=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v7, v8, v0}, Lcom/tencent/mm/storage/d;->set(ILjava/lang/Object;)V

    const-string v0, "MicroMsg.MediaRecorder"

    const-string v7, "16k not suppourt"

    invoke-static {v0, v7}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 552
    :cond_4
    #v0=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    const-string v0, "MicroMsg.MediaRecorder"

    #v0=(Reference);
    new-instance v7, Ljava/lang/StringBuilder;

    #v7=(UninitRef);
    const-string v8, "Wait Stop Time Media:"

    #v8=(Reference);
    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v7=(Reference);
    invoke-virtual {v7, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    #v3=(Reference);
    const-string v4, " Read:"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " Thr:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v4

    #v4=(LongLo);v5=(LongHi);
    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v1

    .line 554
    #v0=(Null);
    goto/16 :goto_0

    .line 536
    :cond_5
    :try_start_1
    #v0=(One);v4=(Reference);v5=(Reference);v6=(Null);v7=(Uninit);v8=(Uninit);v9=(Uninit);v10=(Uninit);v11=(Uninit);v12=(Uninit);
    const-string v4, "MicroMsg.MediaRecorder"

    const-string v5, "Stop now  recorder:null"

    invoke-static {v4, v5}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto/16 :goto_1

    .line 539
    :catchall_0
    move-exception v0

    #v0=(Reference);
    monitor-exit v3

    throw v0
.end method

.method public final prepare()V
    .locals 2

    .prologue
    .line 381
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_1

    .line 382
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_0

    .line 395
    :goto_0
    return-void

    .line 385
    :cond_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    invoke-virtual {v0}, Landroid/media/MediaRecorder;->prepare()V

    goto :goto_0

    .line 389
    :cond_1
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v1, Lcom/tencent/mm/modelvoice/o;->bXV:Lcom/tencent/mm/modelvoice/o;

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bze:Ljava/lang/String;

    if-nez v0, :cond_3

    .line 390
    :cond_2
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXY:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    .line 391
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/MediaRecorder;->release()V

    goto :goto_0

    .line 394
    :cond_3
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXW:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    goto :goto_0
.end method

.method public final release()V
    .locals 2

    .prologue
    .line 398
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_1

    .line 399
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_0

    .line 418
    :goto_0
    return-void

    .line 402
    :cond_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    invoke-virtual {v0}, Landroid/media/MediaRecorder;->release()V

    goto :goto_0

    .line 406
    :cond_1
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v1, Lcom/tencent/mm/modelvoice/o;->bXX:Lcom/tencent/mm/modelvoice/o;

    if-ne v0, v1, :cond_3

    .line 407
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/MediaRecorder;->kR()Z

    .line 413
    :goto_1
    sget-object v1, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzj:Ljava/lang/Object;

    monitor-enter v1

    .line 414
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    if-eqz v0, :cond_2

    .line 415
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/n;->kM()Z

    .line 416
    const/4 v0, 0x0

    #v0=(Null);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    .line 418
    :cond_2
    #v0=(Reference);
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit v1

    throw v0

    .line 409
    :cond_3
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXW:Lcom/tencent/mm/modelvoice/o;

    goto :goto_1
.end method

.method public final setOutputFile(Ljava/lang/String;)V
    .locals 2
    .parameter

    .prologue
    .line 183
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_1

    .line 184
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_0

    .line 196
    :goto_0
    return-void

    .line 187
    :cond_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    invoke-virtual {v0, p1}, Landroid/media/MediaRecorder;->setOutputFile(Ljava/lang/String;)V

    .line 188
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bze:Ljava/lang/String;

    goto :goto_0

    .line 191
    :cond_1
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v1, Lcom/tencent/mm/modelvoice/o;->bXV:Lcom/tencent/mm/modelvoice/o;

    if-ne v0, v1, :cond_2

    .line 192
    iput-object p1, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bze:Ljava/lang/String;

    goto :goto_0

    .line 194
    :cond_2
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXY:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    goto :goto_0
.end method

.method public final start()V
    .locals 4

    .prologue
    .line 349
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byp:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_1

    .line 350
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    if-nez v0, :cond_0

    .line 378
    :goto_0
    #v2=(Conflicted);v3=(Conflicted);
    return-void

    .line 353
    :cond_0
    #v2=(Uninit);v3=(Uninit);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzk:Landroid/media/MediaRecorder;

    invoke-virtual {v0}, Landroid/media/MediaRecorder;->start()V

    goto :goto_0

    .line 356
    :cond_1
    const-string v0, "MicroMsg.MediaRecorder"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Start now  state:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    iget-object v2, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 357
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    sget-object v1, Lcom/tencent/mm/modelvoice/o;->bXW:Lcom/tencent/mm/modelvoice/o;

    if-ne v0, v1, :cond_3

    .line 358
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    iput-wide v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzh:J

    .line 359
    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzi:J

    .line 360
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXX:Lcom/tencent/mm/modelvoice/o;

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    .line 361
    sget-object v1, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzj:Ljava/lang/Object;

    #v1=(Reference);
    monitor-enter v1

    .line 362
    :try_start_0
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    if-nez v0, :cond_2

    .line 363
    new-instance v0, Lcom/tencent/mm/modelvoice/j;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/modelvoice/j;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    .line 364
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXM:Lcom/tencent/mm/modelvoice/j;

    iget v2, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzl:I

    #v2=(Integer);
    iget-object v3, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bze:Ljava/lang/String;

    #v3=(Reference);
    invoke-virtual {v0, v2, v3}, Lcom/tencent/mm/modelvoice/j;->c(ILjava/lang/String;)Z

    .line 367
    :cond_2
    #v2=(Conflicted);v3=(Conflicted);
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/n;->kL()Z

    .line 369
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    #v0=(Conflicted);
    move-exception v0

    #v0=(Reference);
    monitor-exit v1

    throw v0

    .line 373
    :cond_3
    #v2=(Reference);v3=(Uninit);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pG()Lcom/tencent/mm/storage/d;

    move-result-object v0

    const/16 v1, 0x1b

    #v1=(PosByte);
    const/4 v2, 0x1

    #v2=(One);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/d;->set(ILjava/lang/Object;)V

    .line 374
    const-string v0, "MicroMsg.MediaRecorder"

    const-string v1, "start() called on illegal state"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 375
    sget-object v0, Lcom/tencent/mm/modelvoice/o;->bXY:Lcom/tencent/mm/modelvoice/o;

    iput-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bXP:Lcom/tencent/mm/modelvoice/o;

    goto :goto_0
.end method

.method public final yZ()I
    .locals 2

    .prologue
    .line 114
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byo:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    if-eqz v0, :cond_0

    .line 115
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzm:Lcom/tencent/mm/compatible/audio/n;

    invoke-virtual {v0}, Lcom/tencent/mm/compatible/audio/n;->getState()I

    move-result v0

    .line 117
    :goto_0
    #v0=(Integer);
    return v0

    :cond_0
    #v0=(Reference);
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final za()Z
    .locals 2

    .prologue
    .line 121
    iget-object v0, p0, Lcom/tencent/mm/modelvoice/MediaRecorder;->bzn:Lcom/tencent/mm/compatible/audio/b;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/compatible/audio/b;->byo:Lcom/tencent/mm/compatible/audio/b;

    #v1=(Reference);
    if-ne v0, v1, :cond_0

    .line 122
    const/4 v0, 0x1

    .line 124
    :goto_0
    #v0=(Boolean);
    return v0

    :cond_0
    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

*/}
