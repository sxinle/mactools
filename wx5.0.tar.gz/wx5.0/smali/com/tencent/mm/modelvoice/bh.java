package com.tencent.mm.modelvoice; class bh {/*

.class public final Lcom/tencent/mm/modelvoice/bh;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lcom/tencent/mm/modelvoice/bg;[BILjava/lang/String;)I
    .locals 11
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/16 v10, 0x63

    #v10=(PosByte);
    const/4 v3, -0x1

    #v3=(Byte);
    const/4 v2, 0x1

    #v2=(One);
    const/4 v1, 0x0

    .line 339
    #v1=(Null);
    new-instance v4, Lcom/tencent/mm/compatible/f/k;

    #v4=(UninitRef);
    invoke-direct {v4}, Lcom/tencent/mm/compatible/f/k;-><init>()V

    .line 340
    #v4=(Reference);
    if-nez p0, :cond_1

    .line 341
    const-string v0, "MicroMsg.VoiceLogic"

    #v0=(Reference);
    const-string v1, "setRecvSync voice is null"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    move v1, v3

    .line 423
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Byte);v2=(Conflicted);v3=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    return v1

    .line 345
    :cond_1
    #v0=(Uninit);v1=(Null);v2=(One);v3=(Byte);v5=(Uninit);v6=(Uninit);v7=(Uninit);v8=(Uninit);v9=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v5

    #v5=(Integer);
    invoke-virtual {v0, v5}, Lcom/tencent/mm/modelvoice/bq;->dG(I)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v5

    .line 346
    #v5=(Reference);
    if-eqz v5, :cond_2

    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v0

    #v0=(Integer);
    if-eq v0, v10, :cond_0

    .line 349
    :cond_2
    #v0=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v0

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v0, v6, v7}, Lcom/tencent/mm/storage/ar;->ad(Ljava/lang/String;I)Lcom/tencent/mm/storage/am;

    move-result-object v0

    .line 350
    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lcom/tencent/mm/storage/am;->vF()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v6

    #v6=(Integer);
    if-ne v0, v6, :cond_3

    if-eqz v5, :cond_0

    .line 354
    :cond_3
    #v0=(Conflicted);v6=(Conflicted);
    if-eqz v5, :cond_6

    .line 355
    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/bg;->gz(Ljava/lang/String;)V

    .line 359
    :goto_1
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v0

    #v0=(Integer);
    or-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 361
    const-string v0, "MicroMsg.VoiceLogic"

    #v0=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    #v6=(Reference);
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lC()Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "checktime :"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v4}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v7

    #v7=(LongLo);v8=(LongHi);
    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v0, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 364
    if-eqz p1, :cond_10

    array-length v0, p1

    #v0=(Integer);
    if-le v0, v2, :cond_10

    .line 365
    if-eqz v5, :cond_4

    .line 366
    const-string v0, "MicroMsg.VoiceLogic"

    #v0=(Reference);
    const-string v6, "Sync Voice Buf , But  VoiceInfo is not new !"

    invoke-static {v0, v6}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 368
    :cond_4
    #v0=(Conflicted);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bh;->gX(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/b;

    move-result-object v6

    array-length v7, p1

    #v7=(Integer);
    invoke-interface {v6, p1, v7, v1}, Lcom/tencent/mm/modelvoice/b;->write([BII)I

    move-result v6

    #v6=(Integer);
    if-gez v6, :cond_7

    const-string v7, "MicroMsg.VoiceLogic"

    #v7=(Reference);
    new-instance v8, Ljava/lang/StringBuilder;

    #v8=(UninitRef);
    const-string v9, "Write Failed File:"

    #v9=(Reference);
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v8=(Reference);
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, " newOffset:"

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v1

    .line 371
    :goto_2
    #v0=(Boolean);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);v9=(Conflicted);
    const-string v6, "MicroMsg.VoiceLogic"

    #v6=(Reference);
    new-instance v7, Ljava/lang/StringBuilder;

    #v7=(UninitRef);
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    #v7=(Reference);
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lC()Ljava/lang/String;

    move-result-object v8

    #v8=(Reference);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "checktime :"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v4}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v8

    #v8=(LongLo);v9=(LongHi);
    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 373
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    #v6=(LongLo);v7=(LongHi);
    const-wide/16 v8, 0x3e8

    div-long/2addr v6, v8

    invoke-virtual {p0, v6, v7}, Lcom/tencent/mm/modelvoice/bg;->G(J)V

    .line 374
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v6

    #v6=(Integer);
    or-int/lit16 v6, v6, 0x100

    invoke-virtual {p0, v6}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 376
    if-eqz v0, :cond_9

    .line 377
    invoke-virtual {p0, v10}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    .line 383
    :goto_3
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v6

    or-int/lit8 v6, v6, 0x40

    invoke-virtual {p0, v6}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 386
    if-nez v5, :cond_c

    .line 387
    if-eqz v0, :cond_5

    .line 388
    invoke-static {p0, v0, p2, p3}, Lcom/tencent/mm/modelvoice/bh;->a(Lcom/tencent/mm/modelvoice/bg;ZILjava/lang/String;)J

    move-result-wide v6

    .line 389
    #v6=(LongLo);
    long-to-int v6, v6

    #v6=(Integer);
    invoke-virtual {p0, v6}, Lcom/tencent/mm/modelvoice/bg;->cA(I)V

    .line 391
    :cond_5
    const-string v6, "MicroMsg.VoiceLogic"

    #v6=(Reference);
    new-instance v7, Ljava/lang/StringBuilder;

    #v7=(UninitRef);
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    #v7=(Reference);
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lC()Ljava/lang/String;

    move-result-object v8

    #v8=(Reference);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "checktime :"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v4}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v8

    #v8=(LongLo);
    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 392
    invoke-virtual {p0, v3}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 393
    const-string v3, "MicroMsg.VoiceLogic"

    #v3=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "Insert fileName:"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " stat:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " net:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " total:"

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v7

    #v7=(Integer);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v3, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 394
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v3

    invoke-virtual {v3, p0}, Lcom/tencent/mm/modelvoice/bq;->c(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_b

    .line 395
    const-string v0, "MicroMsg.VoiceLogic"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "Insert Error fileName:"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " stat:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " net:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->yE()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " total:"

    #v2=(Reference);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v2

    #v2=(Integer);
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 396
    const/4 v1, -0x2

    #v1=(Byte);
    goto/16 :goto_0

    .line 357
    :cond_6
    #v0=(Conflicted);v1=(Null);v2=(One);v3=(Byte);v6=(Conflicted);v8=(Uninit);v9=(Uninit);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bq;->hf(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/bg;->gz(Ljava/lang/String;)V

    goto/16 :goto_1

    .line 368
    :cond_7
    #v6=(Integer);v8=(LongHi);
    array-length v7, p1

    if-eq v7, v6, :cond_8

    const-string v7, "MicroMsg.VoiceLogic"

    #v7=(Reference);
    new-instance v8, Ljava/lang/StringBuilder;

    #v8=(UninitRef);
    const-string v9, "Write File:"

    #v9=(Reference);
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v8=(Reference);
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, " fileOff:"

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v6, " bufLen:"

    #v6=(Reference);
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    array-length v6, p1

    #v6=(Integer);
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v1

    #v0=(Null);
    goto/16 :goto_2

    :cond_8
    #v0=(Reference);v7=(Integer);v8=(LongHi);v9=(Uninit);
    const-string v6, "MicroMsg.VoiceLogic"

    #v6=(Reference);
    new-instance v7, Ljava/lang/StringBuilder;

    #v7=(UninitRef);
    const-string v8, "writeVoiceFile file:["

    #v8=(Reference);
    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v7=(Reference);
    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "] + buf:"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    array-length v8, p1

    #v8=(Integer);
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v6

    invoke-virtual {v6, v0}, Lcom/tencent/mm/modelvoice/bq;->hg(Ljava/lang/String;)V

    move v0, v2

    #v0=(One);
    goto/16 :goto_2

    .line 378
    :cond_9
    #v0=(Boolean);v6=(Integer);v7=(LongHi);v8=(LongLo);v9=(LongHi);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v6

    if-nez v6, :cond_a

    .line 379
    const/4 v6, 0x5

    #v6=(PosByte);
    invoke-virtual {p0, v6}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    goto/16 :goto_3

    .line 381
    :cond_a
    #v6=(Integer);
    const/4 v6, 0x6

    #v6=(PosByte);
    invoke-virtual {p0, v6}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    goto/16 :goto_3

    .line 398
    :cond_b
    #v3=(Boolean);v6=(Reference);v7=(Integer);
    const-string v3, "MicroMsg.VoiceLogic"

    #v3=(Reference);
    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    #v6=(Reference);
    invoke-static {}, Lcom/tencent/mm/compatible/f/j;->lC()Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "checktime :"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v4}, Lcom/tencent/mm/compatible/f/k;->lD()J

    move-result-wide v7

    #v7=(LongLo);v8=(LongHi);
    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 399
    if-eqz v0, :cond_e

    move v1, v2

    .line 400
    #v1=(One);
    goto/16 :goto_0

    .line 403
    :cond_c
    #v1=(Null);v3=(Byte);v6=(Integer);v7=(LongHi);v8=(LongLo);
    const-string v3, "MicroMsg.VoiceLogic"

    #v3=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v6, "Sync Update file:"

    #v6=(Reference);
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, " stat:"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v6

    #v6=(Integer);
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 409
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_d

    .line 410
    const/16 v1, -0x2c

    #v1=(Byte);
    goto/16 :goto_0

    .line 412
    :cond_d
    #v1=(Null);
    if-eqz v0, :cond_e

    .line 413
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->a(Lcom/tencent/mm/modelvoice/bg;)Z

    move v1, v2

    .line 414
    #v1=(One);
    goto/16 :goto_0

    .line 417
    :cond_e
    #v1=(Null);v3=(Conflicted);v6=(Conflicted);v7=(Conflicted);v8=(Conflicted);
    if-eqz v5, :cond_f

    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v2

    #v2=(Integer);
    if-ne v0, v2, :cond_f

    .line 418
    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->yF()I

    move-result v2

    invoke-static {v0, v2}, Lcom/tencent/mm/modelvoice/bh;->x(Ljava/lang/String;I)I

    .line 419
    const-string v0, "MicroMsg.VoiceLogic"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Sync TotalLen not Change (send endflag but TotoalLen == FileLen) :"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v5}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 422
    :cond_f
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zp()Lcom/tencent/mm/modelvoice/al;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/al;->run()V

    goto/16 :goto_0

    :cond_10
    #v0=(Conflicted);v2=(One);v3=(Byte);v6=(Reference);v7=(LongLo);v8=(LongHi);v9=(Uninit);
    move v0, v1

    #v0=(Null);
    goto/16 :goto_2
.end method

.method private static a(Lcom/tencent/mm/modelvoice/bg;ZILjava/lang/String;)J
    .locals 5
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 440
    #v1=(Null);
    new-instance v2, Lcom/tencent/mm/storage/am;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/storage/am;-><init>()V

    .line 441
    #v2=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->cC(I)V

    .line 442
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->th(Ljava/lang/String;)V

    .line 443
    invoke-virtual {v2, p2}, Lcom/tencent/mm/storage/am;->setStatus(I)V

    .line 444
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->yI()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v0, v3, v4}, Lcom/tencent/mm/model/bm;->b(Ljava/lang/String;J)J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Lcom/tencent/mm/storage/am;->F(J)V

    .line 445
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->te(Ljava/lang/String;)V

    .line 446
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/model/s;->cb(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    const/4 v0, 0x1

    :goto_0
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->bg(I)V

    .line 447
    const/16 v0, 0x22

    #v0=(PosByte);
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->setType(I)V

    .line 448
    invoke-virtual {v2, p3}, Lcom/tencent/mm/storage/am;->tf(Ljava/lang/String;)V

    .line 449
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->zv()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->kg(I)V

    .line 450
    if-nez p1, :cond_1

    .line 451
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    const-wide/16 v3, 0x0

    invoke-static {v0, v3, v4, v1}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    .line 456
    :goto_1
    invoke-static {v2}, Lcom/tencent/mm/model/bm;->d(Lcom/tencent/mm/storage/am;)J

    move-result-wide v0

    #v0=(LongLo);v1=(LongHi);
    return-wide v0

    :cond_0
    #v0=(Boolean);v1=(Null);
    move v0, v1

    .line 446
    #v0=(Null);
    goto :goto_0

    .line 453
    :cond_1
    #v0=(Integer);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->zw()I

    move-result v3

    #v3=(Integer);
    int-to-long v3, v3

    #v3=(LongLo);
    invoke-static {v0, v3, v4, v1}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    goto :goto_1
.end method

.method private static a(Lcom/tencent/mm/modelvoice/bg;)Z
    .locals 3
    .parameter

    .prologue
    .line 428
    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x3

    :try_start_0
    #v1=(PosByte);
    const-string v2, ""

    #v2=(Reference);
    invoke-static {p0, v0, v1, v2}, Lcom/tencent/mm/modelvoice/bh;->a(Lcom/tencent/mm/modelvoice/bg;ZILjava/lang/String;)J

    move-result-wide v0

    .line 429
    #v0=(LongLo);v1=(LongHi);
    long-to-int v0, v0

    #v0=(Integer);
    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/bg;->cA(I)V

    .line 430
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v0

    or-int/lit16 v0, v0, 0x800

    invoke-virtual {p0, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 431
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v0

    .line 433
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return v0

    :catch_0
    #v0=(Integer);
    move-exception v0

    #v0=(Reference);
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public static b(Lcom/tencent/mm/modelvoice/bg;)Z
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 653
    #v0=(Null);
    if-nez p0, :cond_1

    .line 659
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return v0

    .line 656
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v1

    #v1=(Integer);
    const/4 v2, -0x1

    #v2=(Byte);
    if-eq v1, v2, :cond_0

    .line 659
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/modelvoice/bg;->getFileName()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v0, v1, p0}, Lcom/tencent/mm/modelvoice/bq;->a(Ljava/lang/String;Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
    .locals 5
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 588
    #v0=(Null);
    invoke-static {p0}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_1

    .line 601
    :cond_0
    :goto_0
    #v0=(Reference);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-object v0

    .line 592
    :cond_1
    #v0=(Null);v1=(Boolean);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2

    const-string v1, "amr_"

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_2

    const-string v1, "spx_"

    #v1=(Reference);
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    :cond_2
    #v1=(Conflicted);
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->gZ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 593
    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_0

    .line 596
    invoke-static {p1}, Lcom/tencent/mm/modelvoice/bh;->fF(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->fF(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    const/4 v4, 0x0

    #v4=(Null);
    invoke-static {v2, v3, v4}, Lcom/tencent/mm/sdk/platformtools/l;->f(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 599
    const/4 v0, 0x1

    #v0=(One);
    invoke-static {v1, p2, v0}, Lcom/tencent/mm/modelvoice/bh;->n(Ljava/lang/String;II)Z

    move-object v0, v1

    .line 601
    #v0=(Reference);
    goto :goto_0
.end method

.method public static fF(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .parameter

    .prologue
    .line 81
    invoke-static {p0}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 82
    const/4 v0, 0x0

    .line 84
    :goto_0
    #v0=(Reference);
    return-object v0

    :cond_0
    #v0=(Boolean);
    const/4 v0, 0x0

    #v0=(Null);
    invoke-static {p0, v0}, Lcom/tencent/mm/modelvoice/bh;->o(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    goto :goto_0
.end method

.method public static gL(Ljava/lang/String;)Z
    .locals 6
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 605
    #v0=(Null);
    if-nez p0, :cond_0

    .line 630
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    .line 608
    :cond_0
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    .line 609
    if-nez v1, :cond_1

    .line 610
    const-string v1, "MicroMsg.VoiceLogic"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Set error failed file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 614
    :cond_1
    #v2=(Uninit);v3=(Uninit);
    const/16 v0, 0x62

    #v0=(PosByte);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    .line 615
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    const-wide/16 v4, 0x3e8

    #v4=(LongLo);v5=(LongHi);
    div-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/modelvoice/bg;->G(J)V

    .line 616
    const/16 v0, 0x140

    #v0=(PosShort);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 617
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v0

    .line 618
    #v0=(Boolean);
    const-string v2, "MicroMsg.VoiceLogic"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "setError file:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " msgid:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " old stat:"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 619
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v2

    #v2=(Integer);
    if-eqz v2, :cond_2

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_3

    .line 620
    :cond_2
    #v2=(Integer);
    const-string v2, "MicroMsg.VoiceLogic"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "setError failed msg id:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " user:"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    .line 623
    :cond_3
    #v2=(Boolean);v4=(Integer);
    new-instance v2, Lcom/tencent/mm/storage/am;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/storage/am;-><init>()V

    .line 624
    #v2=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v3

    #v3=(Integer);
    int-to-long v3, v3

    #v3=(LongLo);v4=(LongHi);
    invoke-virtual {v2, v3, v4}, Lcom/tencent/mm/storage/am;->bQ(J)V

    .line 625
    const/4 v3, 0x5

    #v3=(PosByte);
    invoke-virtual {v2, v3}, Lcom/tencent/mm/storage/am;->setStatus(I)V

    .line 626
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v2, v3}, Lcom/tencent/mm/storage/am;->te(Ljava/lang/String;)V

    .line 627
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v1

    const-wide/16 v3, -0x1

    #v3=(LongLo);
    const/4 v5, 0x1

    #v5=(One);
    invoke-static {v1, v3, v4, v5}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    .line 628
    const/16 v1, 0x108

    #v1=(PosShort);
    invoke-virtual {v2, v1}, Lcom/tencent/mm/storage/am;->bO(I)V

    .line 629
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v1

    invoke-virtual {v2}, Lcom/tencent/mm/storage/am;->wm()J

    move-result-wide v3

    invoke-virtual {v1, v3, v4, v2}, Lcom/tencent/mm/storage/ar;->a(JLcom/tencent/mm/storage/am;)V

    goto/16 :goto_0
.end method

.method public static gW(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 33
    #v0=(Null);
    if-nez p0, :cond_1

    .line 46
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 36
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    .line 37
    if-eqz v1, :cond_0

    .line 41
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yM()I

    move-result v2

    #v2=(Integer);
    const/16 v3, 0xfa

    #v3=(PosShort);
    if-ge v2, v3, :cond_0

    .line 44
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yM()I

    move-result v0

    #v0=(Integer);
    add-int/lit8 v0, v0, 0x1

    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->cy(I)V

    .line 45
    const/16 v0, 0x2000

    #v0=(PosShort);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 46
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static gX(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/b;
    .locals 2
    .parameter

    .prologue
    .line 69
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    const/4 v1, 0x1

    #v1=(One);
    invoke-virtual {v0, p0, v1}, Lcom/tencent/mm/modelvoice/bq;->p(Ljava/lang/String;Z)Lcom/tencent/mm/modelvoice/b;

    move-result-object v0

    return-object v0
.end method

.method public static gY(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/b;
    .locals 2
    .parameter

    .prologue
    .line 73
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    invoke-virtual {v0, p0, v1}, Lcom/tencent/mm/modelvoice/bq;->p(Ljava/lang/String;Z)Lcom/tencent/mm/modelvoice/b;

    move-result-object v0

    return-object v0
.end method

.method public static gZ(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .parameter

    .prologue
    const-wide/16 v4, 0x3e8

    .line 122
    #v4=(LongLo);v5=(LongHi);
    invoke-static {}, Lcom/tencent/mm/model/s;->ow()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/modelvoice/bq;->hf(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 123
    new-instance v1, Lcom/tencent/mm/modelvoice/bg;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/modelvoice/bg;-><init>()V

    .line 124
    #v1=(Reference);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->gz(Ljava/lang/String;)V

    .line 125
    invoke-virtual {v1, p0}, Lcom/tencent/mm/modelvoice/bg;->setUser(Ljava/lang/String;)V

    .line 126
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    div-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/modelvoice/bg;->F(J)V

    .line 127
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->gV(Ljava/lang/String;)V

    .line 128
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    div-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/modelvoice/bg;->G(J)V

    .line 129
    const/4 v2, 0x1

    #v2=(One);
    invoke-virtual {v1, v2}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    .line 130
    invoke-static {}, Lcom/tencent/mm/model/s;->ow()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v1, v2}, Lcom/tencent/mm/modelvoice/bg;->gA(Ljava/lang/String;)V

    .line 131
    const/4 v2, -0x1

    #v2=(Byte);
    invoke-virtual {v1, v2}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 132
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2, v1}, Lcom/tencent/mm/modelvoice/bq;->c(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_0

    .line 133
    const/4 v0, 0x0

    .line 135
    :cond_0
    return-object v0
.end method

.method public static ha(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 139
    #v0=(Null);
    if-nez p0, :cond_1

    .line 152
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 142
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    .line 143
    if-nez v1, :cond_2

    .line 144
    const-string v1, "MicroMsg.VoiceLogic"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "startSend null record : "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 147
    :cond_2
    #v2=(Uninit);v3=(Uninit);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    #v2=(Integer);
    const/4 v3, 0x1

    #v3=(One);
    if-ne v2, v3, :cond_0

    .line 150
    const/4 v0, 0x2

    #v0=(PosByte);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    .line 151
    const/16 v0, 0x40

    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 152
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static hb(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 157
    #v0=(Null);
    if-nez p0, :cond_1

    .line 170
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 160
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    const-string v1, "MicroMsg.VoiceLogic"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "Mark Canceled fileName["

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "]"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v1

    invoke-virtual {v1, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    .line 163
    if-eqz v1, :cond_0

    .line 167
    const/16 v0, 0x8

    #v0=(PosByte);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    .line 168
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bf;->gJ(Ljava/lang/String;)I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->bM(I)V

    .line 169
    const/16 v0, 0x40

    #v0=(PosByte);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 170
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static hc(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    .line 175
    if-nez p0, :cond_0

    .line 176
    const/4 v0, 0x0

    .line 189
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 178
    :cond_0
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v0

    .line 179
    if-nez v0, :cond_1

    .line 180
    const-string v0, "MicroMsg.VoiceLogic"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "cancel null download : "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 181
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0

    .line 184
    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Uninit);
    const-string v1, "MicroMsg.VoiceLogic"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "cancel download : "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " SvrlId:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 186
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v1

    #v1=(Integer);
    if-eqz v1, :cond_2

    .line 187
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v1

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->vF()I

    move-result v0

    #v0=(Integer);
    invoke-virtual {v1, v2, v0}, Lcom/tencent/mm/storage/ar;->ag(Ljava/lang/String;I)I

    .line 189
    :cond_2
    #v0=(Conflicted);v1=(Conflicted);
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->he(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static hd(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    .line 193
    if-nez p0, :cond_0

    .line 194
    const/4 v0, 0x0

    .line 207
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 196
    :cond_0
    #v0=(Uninit);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v0

    .line 197
    if-nez v0, :cond_1

    .line 198
    const-string v0, "MicroMsg.VoiceLogic"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "cancel null record : "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 199
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0

    .line 202
    :cond_1
    #v0=(Reference);v1=(Uninit);v2=(Uninit);
    const-string v1, "MicroMsg.VoiceLogic"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "cancel record : "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " LocalId:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 204
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v1

    #v1=(Integer);
    if-eqz v1, :cond_2

    .line 205
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v1

    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/bg;->vD()I

    move-result v0

    #v0=(Integer);
    int-to-long v2, v0

    #v2=(LongLo);v3=(LongHi);
    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/storage/ar;->bS(J)I

    .line 207
    :cond_2
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->he(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static he(Ljava/lang/String;)Z
    .locals 2
    .parameter

    .prologue
    .line 211
    if-nez p0, :cond_0

    .line 212
    const/4 v0, 0x0

    .line 219
    :goto_0
    #v0=(Boolean);v1=(Conflicted);
    return v0

    .line 214
    :cond_0
    #v0=(Uninit);v1=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, p0}, Lcom/tencent/mm/modelvoice/bq;->hh(Ljava/lang/String;)Z

    .line 215
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/tencent/mm/modelvoice/bq;->hg(Ljava/lang/String;)V

    .line 218
    new-instance v0, Ljava/io/File;

    #v0=(UninitRef);
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->fF(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 219
    #v0=(Reference);
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static j(Lcom/tencent/mm/storage/am;)Z
    .locals 2
    .parameter

    .prologue
    .line 685
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->arE()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 686
    :cond_0
    #v0=(Conflicted);
    const/4 v0, 0x0

    .line 689
    :goto_0
    #v0=(Boolean);v1=(Conflicted);
    return v0

    .line 688
    :cond_1
    #v1=(Uninit);
    new-instance v0, Lcom/tencent/mm/modelvoice/be;

    #v0=(UninitRef);
    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->getContent()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-direct {v0, v1}, Lcom/tencent/mm/modelvoice/be;-><init>(Ljava/lang/String;)V

    .line 689
    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/modelvoice/be;->zr()Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public static k(Lcom/tencent/mm/storage/am;)Z
    .locals 6
    .parameter

    .prologue
    const/4 v0, 0x1

    #v0=(One);
    const/4 v1, 0x0

    .line 693
    #v1=(Null);
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->arE()Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->nh()I

    move-result v2

    #v2=(Integer);
    if-ne v2, v0, :cond_2

    :cond_0
    #v2=(Conflicted);
    move v0, v1

    .line 698
    :cond_1
    :goto_0
    #v0=(Boolean);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    .line 697
    :cond_2
    #v0=(One);v2=(Integer);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    new-instance v2, Lcom/tencent/mm/modelvoice/be;

    #v2=(UninitRef);
    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->getContent()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-direct {v2, v3}, Lcom/tencent/mm/modelvoice/be;-><init>(Ljava/lang/String;)V

    .line 698
    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/modelvoice/be;->getTime()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    const-wide/16 v4, 0x0

    #v4=(LongLo);v5=(LongHi);
    cmp-long v2, v2, v4

    #v2=(Byte);
    if-eqz v2, :cond_1

    move v0, v1

    #v0=(Null);
    goto :goto_0
.end method

.method public static l(Lcom/tencent/mm/storage/am;)V
    .locals 5
    .parameter

    .prologue
    .line 702
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->arE()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_1

    .line 717
    :cond_0
    :goto_0
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-void

    .line 705
    :cond_1
    #v0=(Boolean);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v0

    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->wm()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/ar;->bR(J)Lcom/tencent/mm/storage/am;

    move-result-object v0

    .line 706
    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/tencent/mm/storage/am;->wm()J

    move-result-wide v1

    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->wm()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    cmp-long v1, v1, v3

    #v1=(Byte);
    if-nez v1, :cond_0

    .line 709
    new-instance v1, Lcom/tencent/mm/modelvoice/be;

    #v1=(UninitRef);
    invoke-virtual {v0}, Lcom/tencent/mm/storage/am;->getContent()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/tencent/mm/modelvoice/be;-><init>(Ljava/lang/String;)V

    .line 710
    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/be;->zr()Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_0

    .line 713
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/be;->zs()V

    .line 714
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/be;->zq()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {p0, v0}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    .line 715
    const/16 v0, 0x100

    #v0=(PosShort);
    invoke-virtual {p0, v0}, Lcom/tencent/mm/storage/am;->bO(I)V

    .line 716
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nO()Lcom/tencent/mm/storage/ar;

    move-result-object v0

    invoke-virtual {p0}, Lcom/tencent/mm/storage/am;->wm()J

    move-result-wide v1

    #v1=(LongLo);
    invoke-virtual {v0, v1, v2, p0}, Lcom/tencent/mm/storage/ar;->a(JLcom/tencent/mm/storage/am;)V

    goto :goto_0
.end method

.method public static n(Ljava/lang/String;II)Z
    .locals 9
    .parameter
    .parameter
    .parameter

    .prologue
    const/16 v8, 0x62

    #v8=(PosByte);
    const/16 v7, 0x61

    #v7=(PosByte);
    const/4 v6, 0x1

    #v6=(One);
    const/4 v0, 0x0

    .line 228
    #v0=(Null);
    if-nez p0, :cond_1

    .line 272
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    .line 231
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    const-string v1, "MicroMsg.VoiceLogic"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "StopRecord fileName["

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "]"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 233
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v1

    invoke-virtual {v1, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    .line 234
    if-eqz v1, :cond_0

    .line 238
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    #v2=(Integer);
    if-eq v2, v7, :cond_2

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v2

    if-eq v2, v8, :cond_2

    .line 239
    const/4 v2, 0x3

    #v2=(PosByte);
    invoke-virtual {v1, v2}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    .line 241
    :cond_2
    #v2=(Integer);
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bf;->gJ(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/tencent/mm/modelvoice/bg;->bM(I)V

    .line 242
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v2

    if-gtz v2, :cond_3

    .line 243
    invoke-static {p0}, Lcom/tencent/mm/modelvoice/bh;->gL(Ljava/lang/String;)Z

    goto :goto_0

    .line 246
    :cond_3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    const-wide/16 v4, 0x3e8

    #v4=(LongLo);v5=(LongHi);
    div-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/modelvoice/bg;->G(J)V

    .line 247
    invoke-virtual {v1, p1}, Lcom/tencent/mm/modelvoice/bg;->dF(I)V

    .line 249
    const/16 v2, 0xd60

    #v2=(PosShort);
    invoke-virtual {v1, v2}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 251
    new-instance v2, Lcom/tencent/mm/storage/am;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/storage/am;-><init>()V

    .line 252
    #v2=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v2, v3}, Lcom/tencent/mm/storage/am;->te(Ljava/lang/String;)V

    .line 253
    const/16 v3, 0x22

    #v3=(PosByte);
    invoke-virtual {v2, v3}, Lcom/tencent/mm/storage/am;->setType(I)V

    .line 254
    invoke-virtual {v2, v6}, Lcom/tencent/mm/storage/am;->bg(I)V

    .line 255
    invoke-virtual {v2, p0}, Lcom/tencent/mm/storage/am;->th(Ljava/lang/String;)V

    .line 256
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v3

    #v3=(Integer);
    if-ne v3, v7, :cond_4

    .line 257
    const/4 v3, 0x2

    #v3=(PosByte);
    invoke-virtual {v2, v3}, Lcom/tencent/mm/storage/am;->setStatus(I)V

    .line 258
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->zw()I

    move-result v4

    #v4=(Integer);
    int-to-long v4, v4

    #v4=(LongLo);
    invoke-static {v3, v4, v5, v0}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    .line 267
    :goto_1
    #v3=(Conflicted);v4=(Conflicted);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getUser()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/model/bm;->do(Ljava/lang/String;)J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    invoke-virtual {v2, v3, v4}, Lcom/tencent/mm/storage/am;->F(J)V

    .line 268
    invoke-virtual {v2, p2}, Lcom/tencent/mm/storage/am;->kg(I)V

    .line 269
    invoke-static {v2}, Lcom/tencent/mm/model/bm;->d(Lcom/tencent/mm/storage/am;)J

    move-result-wide v2

    .line 271
    #v2=(LongLo);v3=(LongHi);
    long-to-int v0, v2

    #v0=(Integer);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->cA(I)V

    .line 272
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v0

    #v0=(Boolean);
    goto/16 :goto_0

    .line 259
    :cond_4
    #v0=(Null);v2=(Reference);v3=(Integer);v4=(LongLo);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v3

    if-ne v3, v8, :cond_5

    .line 260
    const/4 v0, 0x5

    #v0=(PosByte);
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->setStatus(I)V

    .line 261
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    const-wide/16 v3, -0x1

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v0, v3, v4, v6}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    goto :goto_1

    .line 263
    :cond_5
    #v0=(Null);v3=(Integer);v4=(LongLo);
    invoke-virtual {v2, v6}, Lcom/tencent/mm/storage/am;->setStatus(I)V

    .line 264
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yD()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->zw()I

    move-result v4

    #v4=(Integer);
    int-to-long v4, v4

    #v4=(LongLo);
    invoke-static {v3, v4, v5, v0}, Lcom/tencent/mm/modelvoice/be;->a(Ljava/lang/String;JZ)Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v2, v0}, Lcom/tencent/mm/storage/am;->setContent(Ljava/lang/String;)V

    goto :goto_1
.end method

.method public static o(Ljava/lang/String;Z)Ljava/lang/String;
    .locals 6
    .parameter
    .parameter

    .prologue
    const/4 v5, 0x1

    .line 96
    #v5=(One);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nX()Ljava/lang/String;

    move-result-object v0

    const-string v1, "msg_"

    #v1=(Reference);
    const-string v2, ".amr"

    #v2=(Reference);
    const/4 v3, 0x2

    #v3=(PosByte);
    invoke-static {v0, v1, p0, v2, v3}, Lcom/tencent/mm/sdk/platformtools/k;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    .line 98
    invoke-static {v0}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_1

    .line 99
    const/4 v0, 0x0

    .line 118
    :cond_0
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return-object v0

    .line 101
    :cond_1
    #v1=(Boolean);v2=(Reference);v3=(PosByte);v4=(Uninit);
    if-nez p1, :cond_0

    .line 104
    new-instance v1, Ljava/io/File;

    #v1=(UninitRef);
    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 105
    #v1=(Reference);
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_0

    .line 108
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    #v1=(Reference);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/mm/model/b;->nW()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 109
    new-instance v2, Ljava/io/File;

    #v2=(UninitRef);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    #v3=(Reference);
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ".amr"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 110
    #v2=(Reference);
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_2

    .line 111
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    #v2=(Reference);
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ".amr"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0, v5}, Lcom/tencent/mm/sdk/platformtools/l;->f(Ljava/lang/String;Ljava/lang/String;Z)Z

    goto :goto_0

    .line 113
    :cond_2
    #v2=(Boolean);
    new-instance v2, Ljava/io/File;

    #v2=(UninitRef);
    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 114
    #v2=(Reference);
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 115
    invoke-static {v1, v0, v5}, Lcom/tencent/mm/sdk/platformtools/l;->f(Ljava/lang/String;Ljava/lang/String;Z)Z

    goto :goto_0
.end method

.method public static x(Ljava/lang/String;I)I
    .locals 6
    .parameter
    .parameter

    .prologue
    const/4 v0, -0x1

    .line 460
    #v0=(Byte);
    if-nez p0, :cond_1

    .line 485
    :cond_0
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return v0

    .line 463
    :cond_1
    #v1=(Uninit);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, p0}, Lcom/tencent/mm/modelvoice/bq;->hj(Ljava/lang/String;)Lcom/tencent/mm/modelvoice/bg;

    move-result-object v1

    .line 464
    if-eqz v1, :cond_0

    .line 467
    invoke-virtual {v1, p1}, Lcom/tencent/mm/modelvoice/bg;->dy(I)V

    .line 468
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    #v2=(LongLo);v3=(LongHi);
    const-wide/16 v4, 0x3e8

    #v4=(LongLo);v5=(LongHi);
    div-long/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/modelvoice/bg;->G(J)V

    .line 469
    const/16 v0, 0x110

    #v0=(PosShort);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 471
    const/4 v0, 0x0

    .line 472
    #v0=(Null);
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v2

    #v2=(Integer);
    if-lez v2, :cond_2

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v2

    if-lt p1, v2, :cond_2

    .line 473
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->a(Lcom/tencent/mm/modelvoice/bg;)Z

    .line 474
    const/16 v0, 0x63

    #v0=(PosByte);
    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->setStatus(I)V

    .line 475
    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->qX()I

    move-result v0

    #v0=(Integer);
    or-int/lit8 v0, v0, 0x40

    invoke-virtual {v1, v0}, Lcom/tencent/mm/modelvoice/bg;->bO(I)V

    .line 476
    const-string v0, "MicroMsg.VoiceLogic"

    #v0=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "END!!! updateRecv  file:"

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " newsize:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " total:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " status:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " netTimes:"

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->yM()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 477
    const/4 v0, 0x1

    .line 478
    #v0=(One);
    invoke-static {}, Lcom/tencent/mm/modelvoice/bc;->zo()Lcom/tencent/mm/modelvoice/bq;

    move-result-object v2

    invoke-virtual {v2, p0}, Lcom/tencent/mm/modelvoice/bq;->hg(Ljava/lang/String;)V

    .line 481
    :cond_2
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    const-string v2, "MicroMsg.VoiceLogic"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "updateRecv file:"

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " newsize:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " total:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->qU()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " status:"

    #v4=(Reference);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lcom/tencent/mm/modelvoice/bg;->getStatus()I

    move-result v4

    #v4=(Integer);
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 482
    invoke-static {v1}, Lcom/tencent/mm/modelvoice/bh;->b(Lcom/tencent/mm/modelvoice/bg;)Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_0

    .line 483
    const/4 v0, -0x3

    #v0=(Byte);
    goto/16 :goto_0
.end method

*/}
