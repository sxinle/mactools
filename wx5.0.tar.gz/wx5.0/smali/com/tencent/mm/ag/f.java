package com.tencent.mm.ag; class f {/*

.class public final Lcom/tencent/mm/ag/f;
.super Lcom/tencent/mm/sdk/e/ah;
.source "SourceFile"


# static fields
.field public static final bGp:[Ljava/lang/String;

.field private static final bWB:[Ljava/lang/String;


# instance fields
.field private bNH:Lcom/tencent/mm/sdk/e/af;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .prologue
    const/4 v4, 0x1

    #v4=(One);
    const/4 v3, 0x0

    .line 20
    #v3=(Null);
    new-array v0, v4, [Ljava/lang/String;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/ag/e;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v1=(Reference);
    const-string v2, "fmessage_msginfo"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/e/ah;->a(Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    sput-object v0, Lcom/tencent/mm/ag/f;->bGp:[Ljava/lang/String;

    .line 22
    new-array v0, v4, [Ljava/lang/String;

    const-string v1, "CREATE INDEX IF NOT EXISTS  fmessageTalkerIndex ON fmessage_msginfo ( talker )"

    aput-object v1, v0, v3

    sput-object v0, Lcom/tencent/mm/ag/f;->bWB:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/tencent/mm/sdk/e/af;)V
    .locals 3
    .parameter

    .prologue
    .line 29
    sget-object v0, Lcom/tencent/mm/ag/e;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v0=(Reference);
    const-string v1, "fmessage_msginfo"

    #v1=(Reference);
    sget-object v2, Lcom/tencent/mm/ag/f;->bWB:[Ljava/lang/String;

    #v2=(Reference);
    invoke-direct {p0, p1, v0, v1, v2}, Lcom/tencent/mm/sdk/e/ah;-><init>(Lcom/tencent/mm/sdk/e/af;Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;[Ljava/lang/String;)V

    .line 30
    #p0=(Reference);
    iput-object p1, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    .line 31
    return-void
.end method


# virtual methods
.method public final I(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 3
    .parameter
    .parameter

    .prologue
    .line 158
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "update fmessage_msginfo set talker = \'"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-static {p2}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\'  where talker = \'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 160
    iget-object v1, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    const-string v2, "fmessage_msginfo"

    #v2=(Reference);
    invoke-interface {v1, v2, v0}, Lcom/tencent/mm/sdk/e/af;->aJ(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final a(Lcom/tencent/mm/ag/e;)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 98
    #v0=(Null);
    if-nez p1, :cond_1

    .line 99
    const-string v1, "MicroMsg.FMessageMsgInfoStorage"

    #v1=(Reference);
    const-string v2, "insert fail, fmsgInfo is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 116
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 103
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);v3=(Uninit);
    invoke-super {p0, p1}, Lcom/tencent/mm/sdk/e/ah;->b(Lcom/tencent/mm/sdk/e/ad;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    .line 105
    iget v0, p1, Lcom/tencent/mm/ag/e;->field_isSend:I

    #v0=(Integer);
    if-nez v0, :cond_2

    .line 106
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nJ()Lcom/tencent/mm/storage/e;

    move-result-object v0

    const v1, 0x23102

    #v1=(Integer);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/storage/e;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-static {v0}, Lcom/tencent/mm/sdk/platformtools/ce;->c(Ljava/lang/Integer;)I

    move-result v0

    .line 107
    #v0=(Integer);
    const-string v1, "MicroMsg.FMessageMsgInfoStorage"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "insert succ, udpate unread to = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    add-int/lit8 v0, v0, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 112
    :cond_2
    #v0=(Conflicted);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    #v0=(Reference);
    iget-wide v1, p1, Lcom/tencent/mm/ag/e;->fhl:J

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/tencent/mm/ag/f;->rD(Ljava/lang/String;)V

    .line 113
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final synthetic b(Lcom/tencent/mm/sdk/e/ad;)Z
    .locals 1
    .parameter

    .prologue
    .line 16
    check-cast p1, Lcom/tencent/mm/ag/e;

    invoke-virtual {p0, p1}, Lcom/tencent/mm/ag/f;->a(Lcom/tencent/mm/ag/e;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final gm(Ljava/lang/String;)Z
    .locals 3
    .parameter

    .prologue
    .line 148
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_1

    .line 149
    :cond_0
    #v0=(Conflicted);
    const-string v0, "MicroMsg.FMessageMsgInfoStorage"

    #v0=(Reference);
    const-string v1, "deleteByTalker fail, talker is null"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 150
    const/4 v0, 0x0

    .line 154
    :goto_0
    #v0=(Boolean);v2=(Conflicted);
    return v0

    .line 153
    :cond_1
    #v0=(Integer);v1=(Uninit);v2=(Uninit);
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "delete from fmessage_msginfo where talker = \'"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 154
    iget-object v1, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    const-string v2, "fmessage_msginfo"

    #v2=(Reference);
    invoke-interface {v1, v2, v0}, Lcom/tencent/mm/sdk/e/af;->aJ(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public final go(Ljava/lang/String;)[Lcom/tencent/mm/ag/e;
    .locals 6
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 37
    #v0=(Null);
    const-string v1, "MicroMsg.FMessageMsgInfoStorage"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "getLastFMessageMsgInfo, talker = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", limit = 3"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 39
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select *, rowid from fmessage_msginfo  where talker = \'"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\' order by createTime DESC limit 3"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 40
    iget-object v2, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 42
    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v3

    .line 43
    #v3=(Integer);
    if-gtz v3, :cond_0

    .line 44
    const-string v1, "MicroMsg.FMessageMsgInfoStorage"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "getLastFMessageMsgInfo, cursor count = 0, talker = "

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", limit = 3"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 57
    :goto_0
    #v0=(Reference);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    .line 50
    :cond_0
    #v0=(Null);v1=(Reference);v3=(Integer);v4=(Uninit);v5=(Uninit);
    new-array v0, v3, [Lcom/tencent/mm/ag/e;

    .line 51
    #v0=(Reference);
    const/4 v1, 0x0

    :goto_1
    #v1=(Integer);v4=(Conflicted);v5=(Conflicted);
    if-ge v1, v3, :cond_1

    .line 52
    invoke-interface {v2, v1}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 53
    sub-int v4, v3, v1

    #v4=(Integer);
    add-int/lit8 v4, v4, -0x1

    new-instance v5, Lcom/tencent/mm/ag/e;

    #v5=(UninitRef);
    invoke-direct {v5}, Lcom/tencent/mm/ag/e;-><init>()V

    #v5=(Reference);
    aput-object v5, v0, v4

    .line 54
    sub-int v4, v3, v1

    add-int/lit8 v4, v4, -0x1

    aget-object v4, v0, v4

    #v4=(Null);
    invoke-virtual {v4, v2}, Lcom/tencent/mm/ag/e;->a(Landroid/database/Cursor;)V

    .line 51
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 56
    :cond_1
    #v4=(Conflicted);v5=(Conflicted);
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final gp(Ljava/lang/String;)Lcom/tencent/mm/ag/e;
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 61
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_1

    .line 62
    :cond_0
    #v1=(Conflicted);
    const-string v1, "MicroMsg.FMessageMsgInfoStorage"

    #v1=(Reference);
    const-string v2, "getLastFMsg fail, talker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 75
    :goto_0
    #v0=(Reference);v2=(Conflicted);
    return-object v0

    .line 66
    :cond_1
    #v0=(Null);v1=(Integer);v2=(Uninit);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select * from fmessage_msginfo where talker = \'"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\' order by createTime DESC limit 1"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 67
    iget-object v2, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 69
    new-instance v0, Lcom/tencent/mm/ag/e;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/e;-><init>()V

    .line 70
    #v0=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    if-eqz v2, :cond_2

    .line 71
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 72
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/e;->a(Landroid/database/Cursor;)V

    .line 74
    :cond_2
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final gq(Ljava/lang/String;)Lcom/tencent/mm/ag/e;
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 79
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_1

    .line 80
    :cond_0
    #v1=(Conflicted);
    const-string v1, "MicroMsg.FMessageMsgInfoStorage"

    #v1=(Reference);
    const-string v2, "getLastRecvFMsg fail, talker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    :goto_0
    #v0=(Reference);v2=(Conflicted);
    return-object v0

    .line 84
    :cond_1
    #v0=(Null);v1=(Integer);v2=(Uninit);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select * from fmessage_msginfo where isSend = 0 and talker = \'"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\' order by createTime DESC limit 1"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 85
    iget-object v2, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 87
    new-instance v0, Lcom/tencent/mm/ag/e;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/e;-><init>()V

    .line 88
    #v0=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    if-eqz v2, :cond_2

    .line 89
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 90
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/e;->a(Landroid/database/Cursor;)V

    .line 92
    :cond_2
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final yn()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 142
    #v2=(Null);
    const-string v0, "MicroMsg.FMessageMsgInfoStorage"

    #v0=(Reference);
    const-string v1, "try to deleteAll FMessageMsgInfo"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    iget-object v0, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    const-string v1, "fmessage_msginfo"

    invoke-interface {v0, v1, v2, v2}, Lcom/tencent/mm/sdk/e/af;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 144
    invoke-virtual {p0}, Lcom/tencent/mm/ag/f;->zf()V

    .line 145
    return-void
.end method

.method public final yo()Ljava/util/ArrayList;
    .locals 4

    .prologue
    .line 120
    const-string v0, "MicroMsg.FMessageMsgInfoStorage"

    #v0=(Reference);
    const-string v1, "getFMsgByType, type = 0"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 122
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 124
    #v0=(Reference);
    const-string v1, "select *, rowid from fmessage_msginfo where type = 0"

    .line 125
    iget-object v2, p0, Lcom/tencent/mm/ag/f;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v2, v1, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 127
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 128
    :goto_0
    #v2=(Conflicted);
    invoke-interface {v1}, Landroid/database/Cursor;->isAfterLast()Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_0

    .line 129
    new-instance v2, Lcom/tencent/mm/ag/e;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/e;-><init>()V

    .line 130
    #v2=(Reference);
    invoke-virtual {v2, v1}, Lcom/tencent/mm/ag/e;->a(Landroid/database/Cursor;)V

    .line 131
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 132
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    goto :goto_0

    .line 136
    :cond_0
    #v2=(Boolean);
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 137
    const-string v1, "MicroMsg.FMessageMsgInfoStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "getFMsgByType, size = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 138
    return-object v0
.end method

*/}
