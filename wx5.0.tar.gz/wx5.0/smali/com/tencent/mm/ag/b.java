package com.tencent.mm.ag; class b {/*

.class public final Lcom/tencent/mm/ag/b;
.super Lcom/tencent/mm/sdk/e/ah;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/sdk/e/al;


# static fields
.field public static final bGp:[Ljava/lang/String;

.field private static final bWB:[Ljava/lang/String;


# instance fields
.field private bNH:Lcom/tencent/mm/sdk/e/af;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .prologue
    const/4 v4, 0x1

    #v4=(One);
    const/4 v3, 0x0

    .line 24
    #v3=(Null);
    new-array v0, v4, [Ljava/lang/String;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/ag/a;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v1=(Reference);
    const-string v2, "fmessage_conversation"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/e/ah;->a(Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    sput-object v0, Lcom/tencent/mm/ag/b;->bGp:[Ljava/lang/String;

    .line 26
    new-array v0, v4, [Ljava/lang/String;

    const-string v1, "CREATE INDEX IF NOT EXISTS  fmessageConversationTalkerIndex ON fmessage_conversation ( talker )"

    aput-object v1, v0, v3

    sput-object v0, Lcom/tencent/mm/ag/b;->bWB:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/tencent/mm/sdk/e/af;)V
    .locals 3
    .parameter

    .prologue
    .line 33
    sget-object v0, Lcom/tencent/mm/ag/a;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v0=(Reference);
    const-string v1, "fmessage_conversation"

    #v1=(Reference);
    sget-object v2, Lcom/tencent/mm/ag/b;->bWB:[Ljava/lang/String;

    #v2=(Reference);
    invoke-direct {p0, p1, v0, v1, v2}, Lcom/tencent/mm/sdk/e/ah;-><init>(Lcom/tencent/mm/sdk/e/af;Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;[Ljava/lang/String;)V

    .line 34
    #p0=(Reference);
    iput-object p1, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    .line 35
    return-void
.end method


# virtual methods
.method public final bR(Ljava/lang/String;)V
    .locals 9
    .parameter

    .prologue
    const-wide/16 v4, 0x0

    #v4=(LongLo);v5=(LongHi);
    const/4 v8, 0x1

    #v8=(One);
    const/4 v1, 0x0

    .line 242
    #v1=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_2

    .line 243
    :cond_0
    #v0=(Conflicted);
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v1, "onNotifyChange, id is null"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 362
    :cond_1
    :goto_0
    #v0=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-void

    .line 249
    :cond_2
    :try_start_0
    #v0=(Integer);v1=(Null);v2=(Uninit);v3=(Uninit);v4=(LongLo);v5=(LongHi);v6=(Uninit);v7=(Uninit);
    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-wide v2

    .line 254
    :goto_1
    #v0=(Conflicted);v2=(LongLo);v3=(LongHi);v6=(Conflicted);
    cmp-long v0, v2, v4

    #v0=(Byte);
    if-nez v0, :cond_3

    .line 255
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v1, "onNotifyChange fail, sysRowId is invalid"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 250
    :catch_0
    #v0=(Integer);v1=(Null);v2=(Uninit);v3=(Uninit);v6=(Uninit);
    move-exception v0

    .line 251
    #v0=(Reference);
    const-string v2, "MicroMsg.FMessageConversationStorage"

    #v2=(Reference);
    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v6, "onNotifyChange, id = "

    #v6=(Reference);
    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, ", ex = "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    move-wide v2, v4

    #v2=(LongLo);v3=(LongHi);
    goto :goto_1

    .line 259
    :cond_3
    #v0=(Byte);v6=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_4

    .line 260
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v1, "onNotifyChange, account not ready, can not insert fmessageconversation"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 264
    :cond_4
    #v0=(Integer);v1=(Null);
    new-instance v0, Lcom/tencent/mm/ag/e;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/e;-><init>()V

    .line 265
    #v0=(Reference);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {v4, v2, v3, v0}, Lcom/tencent/mm/ag/f;->b(JLcom/tencent/mm/sdk/e/ad;)Z

    move-result v4

    .line 266
    #v4=(Boolean);
    if-nez v4, :cond_5

    .line 267
    const-string v0, "MicroMsg.FMessageConversationStorage"

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v4, "onNotifyChange, get fail, id = "

    #v4=(Reference);
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 271
    :cond_5
    #v1=(Null);v4=(Boolean);
    const-string v4, "MicroMsg.FMessageConversationStorage"

    #v4=(Reference);
    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    const-string v6, "onNotifyChange succ, sysRowId = "

    #v6=(Reference);
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 273
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v4

    iget-object v5, v0, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    invoke-virtual {v4, v5}, Lcom/tencent/mm/ag/b;->gj(Ljava/lang/String;)Lcom/tencent/mm/ag/a;

    move-result-object v4

    .line 274
    if-nez v4, :cond_a

    .line 275
    const-string v4, "MicroMsg.FMessageConversationStorage"

    new-instance v5, Ljava/lang/StringBuilder;

    #v5=(UninitRef);
    const-string v6, "onNotifyChange, fmessage conversation does not exist, insert a new one, talker = "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v5=(Reference);
    iget-object v6, v0, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 276
    new-instance v4, Lcom/tencent/mm/ag/a;

    #v4=(UninitRef);
    invoke-direct {v4}, Lcom/tencent/mm/ag/a;-><init>()V

    .line 278
    #v4=(Reference);
    iget v5, v0, Lcom/tencent/mm/ag/e;->field_type:I

    #v5=(Integer);
    if-nez v5, :cond_8

    .line 279
    iget-object v5, v0, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    #v5=(Reference);
    invoke-static {v5}, Lcom/tencent/mm/storage/an;->tj(Ljava/lang/String;)Lcom/tencent/mm/storage/an;

    move-result-object v5

    .line 280
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->getDisplayName()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_displayName:Ljava/lang/String;

    .line 281
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->AX()I

    move-result v6

    #v6=(Integer);
    const/4 v7, 0x4

    #v7=(PosByte);
    if-ne v6, v7, :cond_6

    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->ash()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    if-eqz v6, :cond_6

    .line 282
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->ash()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_displayName:Ljava/lang/String;

    .line 284
    :cond_6
    #v6=(Conflicted);
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->AX()I

    move-result v6

    #v6=(Integer);
    iput v6, v4, Lcom/tencent/mm/ag/a;->field_addScene:I

    .line 285
    iput v8, v4, Lcom/tencent/mm/ag/a;->field_isNew:I

    .line 288
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->asd()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_contentFromUsername:Ljava/lang/String;

    .line 289
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->fL()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_contentNickname:Ljava/lang/String;

    .line 290
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->asf()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_contentPhoneNumMD5:Ljava/lang/String;

    .line 291
    invoke-virtual {v5}, Lcom/tencent/mm/storage/an;->asi()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v4, Lcom/tencent/mm/ag/a;->field_contentFullPhoneNumMD5:Ljava/lang/String;

    .line 305
    :cond_7
    :goto_2
    #v5=(Conflicted);v7=(Conflicted);
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    iput-wide v5, v4, Lcom/tencent/mm/ag/a;->field_lastModifiedTime:J

    .line 306
    iput v1, v4, Lcom/tencent/mm/ag/a;->field_state:I

    .line 307
    iget-object v5, v0, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    #v5=(Reference);
    iput-object v5, v4, Lcom/tencent/mm/ag/a;->field_talker:Ljava/lang/String;

    .line 308
    iget-object v5, v0, Lcom/tencent/mm/ag/e;->field_encryptTalker:Ljava/lang/String;

    iput-object v5, v4, Lcom/tencent/mm/ag/a;->field_encryptTalker:Ljava/lang/String;

    .line 310
    iput-wide v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgSysRowId:J

    .line 311
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    #v2=(Integer);
    iput v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgIsSend:I

    .line 312
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_type:I

    iput v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgType:I

    .line 313
    iget-object v2, v0, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    #v2=(Reference);
    iput-object v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgContent:Ljava/lang/String;

    .line 314
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    #v2=(Integer);
    if-nez v2, :cond_9

    iget v0, v0, Lcom/tencent/mm/ag/e;->field_type:I

    :goto_3
    #v0=(Integer);
    iput v0, v4, Lcom/tencent/mm/ag/a;->field_recvFmsgType:I

    .line 315
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, v4}, Lcom/tencent/mm/ag/b;->b(Lcom/tencent/mm/sdk/e/ad;)Z

    .line 349
    :goto_4
    #v2=(Conflicted);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/b;->ym()I

    move-result v0

    .line 350
    #v0=(Integer);
    const-string v2, "MicroMsg.FMessageConversationStorage"

    #v2=(Reference);
    const-string v3, "onNotifyChange, newCount update to = %d"

    #v3=(Reference);
    new-array v4, v8, [Ljava/lang/Object;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-static {v2, v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->f(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 351
    if-lez v0, :cond_1

    .line 352
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1}, Lcom/tencent/mm/model/b;->nJ()Lcom/tencent/mm/storage/e;

    move-result-object v1

    const v2, 0x23102

    #v2=(Integer);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v1, v2, v0}, Lcom/tencent/mm/storage/e;->set(ILjava/lang/Object;)V

    goto/16 :goto_0

    .line 293
    :cond_8
    #v1=(Null);v2=(LongLo);v3=(LongHi);v5=(Integer);v6=(Reference);v7=(Uninit);
    iget v5, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    if-nez v5, :cond_7

    .line 294
    iget-object v5, v0, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    #v5=(Reference);
    invoke-static {v5}, Lcom/tencent/mm/storage/aq;->tn(Ljava/lang/String;)Lcom/tencent/mm/storage/aq;

    move-result-object v5

    .line 295
    invoke-virtual {v5}, Lcom/tencent/mm/storage/aq;->getDisplayName()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_displayName:Ljava/lang/String;

    .line 296
    invoke-virtual {v5}, Lcom/tencent/mm/storage/aq;->AX()I

    move-result v6

    #v6=(Integer);
    iput v6, v4, Lcom/tencent/mm/ag/a;->field_addScene:I

    .line 297
    iput v8, v4, Lcom/tencent/mm/ag/a;->field_isNew:I

    .line 299
    invoke-virtual {v5}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_contentFromUsername:Ljava/lang/String;

    .line 300
    invoke-virtual {v5}, Lcom/tencent/mm/storage/aq;->fL()Ljava/lang/String;

    move-result-object v6

    iput-object v6, v4, Lcom/tencent/mm/ag/a;->field_contentNickname:Ljava/lang/String;

    .line 301
    invoke-virtual {v5}, Lcom/tencent/mm/storage/aq;->getContent()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v4, Lcom/tencent/mm/ag/a;->field_contentVerifyContent:Ljava/lang/String;

    goto :goto_2

    :cond_9
    #v2=(Integer);v6=(LongHi);v7=(Conflicted);
    move v0, v1

    .line 314
    #v0=(Null);
    goto :goto_3

    .line 317
    :cond_a
    #v0=(Reference);v2=(LongLo);v6=(Reference);v7=(Uninit);
    const-string v5, "MicroMsg.FMessageConversationStorage"

    new-instance v6, Ljava/lang/StringBuilder;

    #v6=(UninitRef);
    const-string v7, "onNotifyChange, fmessage conversation has existed, talker = "

    #v7=(Reference);
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v6=(Reference);
    iget-object v7, v0, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 318
    iget v5, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    #v5=(Integer);
    if-nez v5, :cond_b

    .line 319
    iput v8, v4, Lcom/tencent/mm/ag/a;->field_isNew:I

    .line 321
    :cond_b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    #v5=(LongLo);v6=(LongHi);
    iput-wide v5, v4, Lcom/tencent/mm/ag/a;->field_lastModifiedTime:J

    .line 322
    iget-object v5, v0, Lcom/tencent/mm/ag/e;->field_encryptTalker:Ljava/lang/String;

    #v5=(Reference);
    iput-object v5, v4, Lcom/tencent/mm/ag/a;->field_encryptTalker:Ljava/lang/String;

    .line 324
    iput-wide v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgSysRowId:J

    .line 325
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    #v2=(Integer);
    iput v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgIsSend:I

    .line 326
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_type:I

    iput v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgType:I

    .line 327
    iget-object v2, v0, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    #v2=(Reference);
    iput-object v2, v4, Lcom/tencent/mm/ag/a;->field_fmsgContent:Ljava/lang/String;

    .line 328
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    #v2=(Integer);
    if-nez v2, :cond_c

    .line 329
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_type:I

    iput v2, v4, Lcom/tencent/mm/ag/a;->field_recvFmsgType:I

    .line 333
    :cond_c
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_type:I

    if-nez v2, :cond_e

    .line 334
    iget-object v0, v0, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/storage/an;->tj(Ljava/lang/String;)Lcom/tencent/mm/storage/an;

    move-result-object v0

    .line 335
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asd()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    iput-object v2, v4, Lcom/tencent/mm/ag/a;->field_contentFromUsername:Ljava/lang/String;

    .line 336
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->fL()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v4, Lcom/tencent/mm/ag/a;->field_contentNickname:Ljava/lang/String;

    .line 337
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asf()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v4, Lcom/tencent/mm/ag/a;->field_contentPhoneNumMD5:Ljava/lang/String;

    .line 338
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asi()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v4, Lcom/tencent/mm/ag/a;->field_contentFullPhoneNumMD5:Ljava/lang/String;

    .line 346
    :cond_d
    :goto_5
    #v2=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    new-array v2, v1, [Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v0, v4, v2}, Lcom/tencent/mm/ag/b;->a(Lcom/tencent/mm/sdk/e/ad;[Ljava/lang/String;)Z

    goto/16 :goto_4

    .line 340
    :cond_e
    #v2=(Integer);
    iget v2, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    if-nez v2, :cond_d

    .line 341
    iget-object v0, v0, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/mm/storage/aq;->tn(Ljava/lang/String;)Lcom/tencent/mm/storage/aq;

    move-result-object v0

    .line 342
    invoke-virtual {v0}, Lcom/tencent/mm/storage/aq;->getContent()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v4, Lcom/tencent/mm/ag/a;->field_contentVerifyContent:Ljava/lang/String;

    goto :goto_5
.end method

.method public final getCount()I
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 81
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    const-string v2, "select count(*) from fmessage_conversation"

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 84
    invoke-interface {v1}, Landroid/database/Cursor;->moveToLast()Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 85
    invoke-interface {v1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    .line 87
    :cond_0
    #v0=(Integer);
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 88
    const-string v1, "MicroMsg.FMessageConversationStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "getCount = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    return v0
.end method

.method public final gi(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 146
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_1

    .line 147
    :cond_0
    #v1=(Conflicted);
    const-string v1, "MicroMsg.FMessageConversationStorage"

    #v1=(Reference);
    const-string v2, "unsetNew fail, talker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 158
    :goto_0
    #v0=(Boolean);v2=(Conflicted);v3=(Conflicted);
    return v0

    .line 151
    :cond_1
    #v0=(Null);v1=(Integer);v2=(Uninit);v3=(Uninit);
    invoke-virtual {p0, p1}, Lcom/tencent/mm/ag/b;->gj(Ljava/lang/String;)Lcom/tencent/mm/ag/a;

    move-result-object v1

    .line 152
    #v1=(Reference);
    if-eqz v1, :cond_2

    iget-object v2, v1, Lcom/tencent/mm/ag/a;->field_talker:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_3

    .line 153
    :cond_2
    #v2=(Conflicted);
    const-string v1, "MicroMsg.FMessageConversationStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "unsetNew fail, conversation does not exist, talker = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 157
    :cond_3
    #v2=(Boolean);v3=(Uninit);
    iput v0, v1, Lcom/tencent/mm/ag/a;->field_isNew:I

    .line 158
    new-array v0, v0, [Ljava/lang/String;

    #v0=(Reference);
    invoke-super {p0, v1, v0}, Lcom/tencent/mm/sdk/e/ah;->a(Lcom/tencent/mm/sdk/e/ad;[Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    goto :goto_0
.end method

.method public final gj(Ljava/lang/String;)Lcom/tencent/mm/ag/a;
    .locals 4
    .parameter

    .prologue
    const/4 v1, 0x0

    .line 189
    #v1=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_2

    .line 190
    :cond_0
    #v0=(Conflicted);
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v2, "get fail, talker is null"

    #v2=(Reference);
    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v1

    .line 202
    :cond_1
    :goto_0
    #v2=(Conflicted);v3=(Conflicted);
    return-object v0

    .line 194
    :cond_2
    #v0=(Integer);v2=(Uninit);v3=(Uninit);
    new-instance v0, Lcom/tencent/mm/ag/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/a;-><init>()V

    .line 195
    #v0=(Reference);
    iput-object p1, v0, Lcom/tencent/mm/ag/a;->field_talker:Ljava/lang/String;

    .line 197
    const/4 v2, 0x0

    #v2=(Null);
    new-array v2, v2, [Ljava/lang/String;

    #v2=(Reference);
    invoke-super {p0, v0, v2}, Lcom/tencent/mm/sdk/e/ah;->c(Lcom/tencent/mm/sdk/e/ad;[Ljava/lang/String;)Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_1

    .line 201
    const-string v0, "MicroMsg.FMessageConversationStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "get fail, maybe not exist, talker = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v1

    .line 202
    #v0=(Null);
    goto :goto_0
.end method

.method public final gk(Ljava/lang/String;)I
    .locals 5
    .parameter

    .prologue
    .line 206
    new-instance v0, Lcom/tencent/mm/ag/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/a;-><init>()V

    .line 207
    #v0=(Reference);
    const/4 v1, -0x1

    #v1=(Byte);
    iput v1, v0, Lcom/tencent/mm/ag/a;->field_state:I

    .line 208
    const-string v1, "select %s from %s where %s = %s"

    #v1=(Reference);
    const/4 v2, 0x4

    #v2=(PosByte);
    new-array v2, v2, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    const-string v4, "state"

    #v4=(Reference);
    aput-object v4, v2, v3

    const/4 v3, 0x1

    #v3=(One);
    const-string v4, "fmessage_conversation"

    aput-object v4, v2, v3

    const/4 v3, 0x2

    #v3=(PosByte);
    const-string v4, "talker"

    aput-object v4, v2, v3

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/tencent/mm/ao/i;->bI(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 214
    iget-object v2, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v2, v1, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 215
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    if-eqz v2, :cond_0

    .line 216
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 217
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/a;->a(Landroid/database/Cursor;)V

    .line 219
    :cond_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 220
    iget v0, v0, Lcom/tencent/mm/ag/a;->field_state:I

    #v0=(Integer);
    return v0
.end method

.method public final gl(Ljava/lang/String;)Lcom/tencent/mm/ag/a;
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 224
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_1

    .line 225
    :cond_0
    #v1=(Conflicted);
    const-string v1, "MicroMsg.FMessageConversationStorage"

    #v1=(Reference);
    const-string v2, "get fail, encryptTalker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 237
    :goto_0
    #v0=(Reference);v2=(Conflicted);
    return-object v0

    .line 229
    :cond_1
    #v0=(Null);v1=(Integer);v2=(Uninit);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select * from fmessage_conversation  where encryptTalker="

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/ao/i;->bI(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 230
    iget-object v2, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 231
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    if-eqz v2, :cond_2

    .line 232
    new-instance v0, Lcom/tencent/mm/ag/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/a;-><init>()V

    .line 233
    #v0=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 234
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/a;->a(Landroid/database/Cursor;)V

    .line 236
    :cond_2
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final gm(Ljava/lang/String;)Z
    .locals 4
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 372
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_2

    .line 373
    :cond_0
    #v1=(Conflicted);
    const-string v1, "MicroMsg.FMessageConversationStorage"

    #v1=(Reference);
    const-string v2, "deleteByTalker fail, talker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 385
    :cond_1
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v3=(Conflicted);
    return v0

    .line 377
    :cond_2
    #v0=(Null);v1=(Integer);v2=(Uninit);v3=(Uninit);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "delete from fmessage_conversation where talker = \'"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\'"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 378
    iget-object v2, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    const-string v3, "fmessage_conversation"

    #v3=(Reference);
    invoke-interface {v2, v3, v1}, Lcom/tencent/mm/sdk/e/af;->aJ(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    .line 379
    #v1=(Boolean);
    if-eqz v1, :cond_1

    .line 380
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "deleteByTalker success, talker = "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 381
    invoke-virtual {p0, p1}, Lcom/tencent/mm/ag/b;->rD(Ljava/lang/String;)V

    .line 382
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final w(Ljava/lang/String;I)Z
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x1

    #v1=(One);
    const/4 v0, 0x0

    .line 93
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    #v2=(Integer);
    if-nez v2, :cond_2

    .line 94
    :cond_0
    #v2=(Conflicted);
    const-string v1, "MicroMsg.FMessageConversationStorage"

    #v1=(Reference);
    const-string v2, "updateState fail, talker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 116
    :cond_1
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);
    return v0

    .line 98
    :cond_2
    #v0=(Null);v1=(One);v2=(Integer);v3=(Uninit);v4=(Uninit);
    invoke-virtual {p0, p1}, Lcom/tencent/mm/ag/b;->gj(Ljava/lang/String;)Lcom/tencent/mm/ag/a;

    move-result-object v2

    .line 99
    #v2=(Reference);
    if-nez v2, :cond_3

    .line 100
    const-string v1, "MicroMsg.FMessageConversationStorage"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "updateState fail, get fail, talker = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 104
    :cond_3
    #v1=(One);v3=(Uninit);
    iget v3, v2, Lcom/tencent/mm/ag/a;->field_state:I

    #v3=(Integer);
    if-ne p2, v3, :cond_4

    .line 105
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v2, "updateState, no need to update"

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v1

    .line 106
    #v0=(One);
    goto :goto_0

    .line 109
    :cond_4
    #v0=(Null);
    iput p2, v2, Lcom/tencent/mm/ag/a;->field_state:I

    .line 110
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    iput-wide v3, v2, Lcom/tencent/mm/ag/a;->field_lastModifiedTime:J

    .line 112
    new-array v3, v0, [Ljava/lang/String;

    #v3=(Reference);
    invoke-super {p0, v2, v3}, Lcom/tencent/mm/sdk/e/ah;->a(Lcom/tencent/mm/sdk/e/ad;[Ljava/lang/String;)Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_1

    .line 113
    invoke-virtual {p0, p1}, Lcom/tencent/mm/ag/b;->rD(Ljava/lang/String;)V

    move v0, v1

    .line 114
    #v0=(One);
    goto :goto_0
.end method

.method public final wB()Landroid/database/Cursor;
    .locals 3

    .prologue
    .line 42
    iget-object v0, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v0=(Reference);
    const-string v1, "select * from fmessage_conversation  ORDER BY lastModifiedTime DESC"

    #v1=(Reference);
    const/4 v2, 0x0

    #v2=(Null);
    invoke-interface {v0, v1, v2}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    return-object v0
.end method

.method public final yk()Ljava/util/List;
    .locals 8

    .prologue
    const/4 v5, 0x1

    #v5=(One);
    const/4 v7, 0x0

    .line 52
    #v7=(Null);
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v1, "getNewLimit, limit = %d"

    #v1=(Reference);
    new-array v2, v5, [Ljava/lang/Object;

    #v2=(Reference);
    const/4 v3, 0x4

    #v3=(PosByte);
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    #v3=(Reference);
    aput-object v3, v2, v7

    invoke-static {v0, v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->f(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 53
    new-instance v0, Ljava/util/ArrayList;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 55
    #v0=(Reference);
    const-string v1, "select * from fmessage_conversation  where isNew = 1 ORDER BY lastModifiedTime DESC limit 4"

    .line 56
    iget-object v2, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v2, v1, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 58
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    .line 59
    #v2=(Integer);
    const-string v3, "MicroMsg.FMessageConversationStorage"

    #v3=(Reference);
    const-string v4, "getNewLimit, count = %d"

    #v4=(Reference);
    new-array v5, v5, [Ljava/lang/Object;

    #v5=(Reference);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    #v6=(Reference);
    aput-object v6, v5, v7

    invoke-static {v3, v4, v5}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 61
    if-gtz v2, :cond_0

    .line 62
    const-string v2, "MicroMsg.FMessageConversationStorage"

    #v2=(Reference);
    const-string v3, "getNewLimit, cursor count is zero"

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 76
    :goto_0
    #v2=(Conflicted);
    return-object v0

    .line 67
    :cond_0
    #v2=(Integer);
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_1

    .line 68
    :goto_1
    #v2=(Conflicted);
    invoke-interface {v1}, Landroid/database/Cursor;->isAfterLast()Z

    move-result v2

    #v2=(Boolean);
    if-nez v2, :cond_1

    .line 69
    new-instance v2, Lcom/tencent/mm/ag/a;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/a;-><init>()V

    .line 70
    #v2=(Reference);
    invoke-virtual {v2, v1}, Lcom/tencent/mm/ag/a;->a(Landroid/database/Cursor;)V

    .line 71
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    .line 72
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 75
    :cond_1
    #v2=(Boolean);
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final yl()Z
    .locals 3

    .prologue
    .line 120
    iget-object v0, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v0=(Reference);
    const-string v1, "fmessage_conversation"

    #v1=(Reference);
    const-string v2, "update fmessage_conversation set isNew = 0"

    #v2=(Reference);
    invoke-interface {v0, v1, v2}, Lcom/tencent/mm/sdk/e/af;->aJ(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-eqz v0, :cond_0

    .line 123
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v1, "clearAllNew success"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    invoke-virtual {p0}, Lcom/tencent/mm/ag/b;->zf()V

    .line 125
    const/4 v0, 0x1

    .line 129
    :goto_0
    #v0=(Boolean);
    return v0

    .line 128
    :cond_0
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v1, "clearAllNew fail"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 129
    const/4 v0, 0x0

    #v0=(Null);
    goto :goto_0
.end method

.method public final ym()I
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 133
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    const-string v2, "select count(*) from fmessage_conversation where isNew = 1"

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 137
    invoke-interface {v1}, Landroid/database/Cursor;->moveToLast()Z

    move-result v2

    #v2=(Boolean);
    if-eqz v2, :cond_0

    .line 138
    invoke-interface {v1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    .line 140
    :cond_0
    #v0=(Integer);
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 141
    const-string v1, "MicroMsg.FMessageConversationStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "getNewCount = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    return v0
.end method

.method public final yn()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 365
    #v2=(Null);
    const-string v0, "MicroMsg.FMessageConversationStorage"

    #v0=(Reference);
    const-string v1, "try to deleteAll FMessageConversation"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->w(Ljava/lang/String;Ljava/lang/String;)V

    .line 366
    iget-object v0, p0, Lcom/tencent/mm/ag/b;->bNH:Lcom/tencent/mm/sdk/e/af;

    const-string v1, "fmessage_conversation"

    invoke-interface {v0, v1, v2, v2}, Lcom/tencent/mm/sdk/e/af;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 367
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nJ()Lcom/tencent/mm/storage/e;

    move-result-object v0

    const v1, 0x23102

    #v1=(Integer);
    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/e;->set(ILjava/lang/Object;)V

    .line 368
    invoke-virtual {p0}, Lcom/tencent/mm/ag/b;->zf()V

    .line 369
    return-void
.end method

*/}
