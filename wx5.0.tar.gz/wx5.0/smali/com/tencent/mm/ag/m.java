package com.tencent.mm.ag; class m {/*

.class final Lcom/tencent/mm/ag/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/ao/k;


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 111
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final jE()[Ljava/lang/String;
    .locals 1

    .prologue
    .line 114
    sget-object v0, Lcom/tencent/mm/ag/j;->bGp:[Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

*/}
