package com.tencent.mm.ag; class q {/*

.class final Lcom/tencent/mm/ag/q;
.super Lcom/tencent/mm/sdk/b/g;
.source "SourceFile"


# instance fields
.field final synthetic bWL:Lcom/tencent/mm/ag/k;


# direct methods
.method constructor <init>(Lcom/tencent/mm/ag/k;)V
    .locals 0
    .parameter

    .prologue
    .line 162
    iput-object p1, p0, Lcom/tencent/mm/ag/q;->bWL:Lcom/tencent/mm/ag/k;

    invoke-direct {p0}, Lcom/tencent/mm/sdk/b/g;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/sdk/b/e;)Z
    .locals 6
    .parameter

    .prologue
    const/4 v5, 0x2

    #v5=(PosByte);
    const/4 v4, 0x0

    #v4=(Null);
    const/4 v3, 0x1

    .line 165
    #v3=(One);
    check-cast p1, Lcom/tencent/mm/c/a/az;

    .line 166
    iget-object v0, p1, Lcom/tencent/mm/c/a/az;->blx:Lcom/tencent/mm/c/a/ba;

    #v0=(Reference);
    iget v1, v0, Lcom/tencent/mm/c/a/ba;->blz:I

    .line 167
    #v1=(Integer);
    iget-object v0, p1, Lcom/tencent/mm/c/a/az;->blx:Lcom/tencent/mm/c/a/ba;

    iget-object v2, v0, Lcom/tencent/mm/c/a/ba;->blA:Ljava/lang/String;

    .line 168
    #v2=(Reference);
    iget-object v0, p1, Lcom/tencent/mm/c/a/az;->blx:Lcom/tencent/mm/c/a/ba;

    iget v0, v0, Lcom/tencent/mm/c/a/ba;->state:I

    .line 169
    #v0=(Integer);
    if-ne v1, v3, :cond_1

    .line 170
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0, v2}, Lcom/tencent/mm/ag/b;->gk(Ljava/lang/String;)I

    move-result v0

    .line 180
    :cond_0
    :goto_0
    #v0=(Integer);v1=(Conflicted);
    iget-object v1, p1, Lcom/tencent/mm/c/a/az;->bly:Lcom/tencent/mm/c/a/bb;

    #v1=(Reference);
    iput v0, v1, Lcom/tencent/mm/c/a/bb;->state:I

    .line 181
    return v4

    .line 171
    :cond_1
    #v1=(Integer);
    if-nez v1, :cond_0

    .line 172
    if-ne v0, v5, :cond_2

    .line 173
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, v2, v5}, Lcom/tencent/mm/ag/b;->w(Ljava/lang/String;I)Z

    goto :goto_0

    .line 174
    :cond_2
    #v1=(Integer);
    if-ne v0, v3, :cond_3

    .line 175
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, v2, v3}, Lcom/tencent/mm/ag/b;->w(Ljava/lang/String;I)Z

    goto :goto_0

    .line 177
    :cond_3
    #v1=(Integer);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, v2, v4}, Lcom/tencent/mm/ag/b;->w(Ljava/lang/String;I)Z

    goto :goto_0
.end method

*/}
