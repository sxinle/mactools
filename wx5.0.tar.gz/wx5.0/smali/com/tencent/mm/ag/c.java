package com.tencent.mm.ag; class c {/*

.class public final Lcom/tencent/mm/ag/c;
.super Lcom/tencent/mm/model/p;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 20
    invoke-direct {p0}, Lcom/tencent/mm/model/p;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method protected final a(Lcom/tencent/mm/protocal/a/j;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/mm/storage/am;
    .locals 10
    .parameter
    .parameter
    .parameter
    .parameter

    .prologue
    const/4 v9, 0x3

    #v9=(PosByte);
    const/4 v6, 0x1

    #v6=(One);
    const/4 v5, -0x1

    #v5=(Byte);
    const/4 v8, 0x0

    #v8=(Null);
    const/4 v7, 0x0

    .line 26
    #v7=(Null);
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDB:Lcom/tencent/mm/protocal/a/pt;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    .line 27
    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-gtz v1, :cond_1

    .line 28
    :cond_0
    #v1=(Conflicted);
    const-string v0, "MicroMsg.FMessageExtension"

    const-string v1, "possible friend msg : content is null"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    :goto_0
    #v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v6=(Conflicted);
    return-object v8

    .line 32
    :cond_1
    #v1=(Integer);v2=(Uninit);v3=(Uninit);v4=(Uninit);v6=(One);
    invoke-static {v0}, Lcom/tencent/mm/storage/an;->tj(Ljava/lang/String;)Lcom/tencent/mm/storage/an;

    move-result-object v0

    .line 35
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asf()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    if-nez v1, :cond_2

    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asi()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_4

    :cond_2
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->AX()I

    move-result v1

    #v1=(Integer);
    const/16 v2, 0xa

    #v2=(PosByte);
    if-eq v1, v2, :cond_3

    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->AX()I

    move-result v1

    const/16 v2, 0xb

    if-ne v1, v2, :cond_4

    .line 37
    :cond_3
    new-instance v1, Lcom/tencent/mm/c/a/bc;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/c/a/bc;-><init>()V

    .line 38
    #v1=(Reference);
    iget-object v2, v1, Lcom/tencent/mm/c/a/bc;->blB:Lcom/tencent/mm/c/a/bd;

    #v2=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asf()Ljava/lang/String;

    move-result-object v3

    #v3=(Reference);
    iput-object v3, v2, Lcom/tencent/mm/c/a/bd;->blD:Ljava/lang/String;

    .line 39
    iget-object v2, v1, Lcom/tencent/mm/c/a/bc;->blB:Lcom/tencent/mm/c/a/bd;

    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asi()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lcom/tencent/mm/c/a/bd;->blE:Ljava/lang/String;

    .line 40
    invoke-static {}, Lcom/tencent/mm/sdk/b/a;->aoz()Lcom/tencent/mm/sdk/b/f;

    move-result-object v2

    invoke-interface {v2, v1}, Lcom/tencent/mm/sdk/b/f;->f(Lcom/tencent/mm/sdk/b/e;)Z

    .line 41
    iget-object v1, v1, Lcom/tencent/mm/c/a/bc;->blC:Lcom/tencent/mm/c/a/be;

    iget-boolean v1, v1, Lcom/tencent/mm/c/a/be;->blF:Z

    #v1=(Boolean);
    if-eqz v1, :cond_4

    .line 42
    const-string v0, "MicroMsg.FMessageExtension"

    const-string v1, "possible mobile friend is not in local address book"

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->v(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 47
    :cond_4
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asg()J

    move-result-wide v1

    #v1=(LongLo);v2=(LongHi);
    const-wide/16 v3, 0x0

    #v3=(LongLo);v4=(LongHi);
    cmp-long v1, v1, v3

    #v1=(Byte);
    if-lez v1, :cond_5

    .line 48
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asg()J

    move-result-wide v1

    #v1=(LongLo);
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->ase()I

    move-result v3

    #v3=(Integer);
    invoke-static {v1, v2, v3}, Lcom/tencent/mm/n/c;->c(JI)Z

    .line 51
    :cond_5
    #v1=(Conflicted);v3=(Conflicted);
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asd()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/sdk/platformtools/ce;->hC(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-lez v1, :cond_6

    .line 52
    new-instance v1, Lcom/tencent/mm/n/v;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/n/v;-><init>()V

    .line 53
    #v1=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asd()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v1, v2}, Lcom/tencent/mm/n/v;->setUsername(Ljava/lang/String;)V

    .line 54
    invoke-virtual {v1, v9}, Lcom/tencent/mm/n/v;->bb(I)V

    .line 55
    invoke-virtual {v1, v6}, Lcom/tencent/mm/n/v;->o(Z)V

    .line 56
    invoke-virtual {v1, v5}, Lcom/tencent/mm/n/v;->bO(I)V

    .line 57
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asb()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/tencent/mm/n/v;->ea(Ljava/lang/String;)V

    .line 58
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asc()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/tencent/mm/n/v;->eb(Ljava/lang/String;)V

    .line 59
    invoke-virtual {v1, v5}, Lcom/tencent/mm/n/v;->bO(I)V

    .line 60
    const-string v2, "MicroMsg.FMessageExtension"

    const-string v3, "dkhurl user:[%s] big:[%s] sm:[%s]"

    #v3=(Reference);
    new-array v4, v9, [Ljava/lang/Object;

    #v4=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asd()Ljava/lang/String;

    move-result-object v5

    #v5=(Reference);
    aput-object v5, v4, v7

    invoke-virtual {v1}, Lcom/tencent/mm/n/v;->qY()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v6

    const/4 v5, 0x2

    #v5=(PosByte);
    invoke-virtual {v1}, Lcom/tencent/mm/n/v;->qZ()Ljava/lang/String;

    move-result-object v6

    #v6=(Reference);
    aput-object v6, v4, v5

    invoke-static {v2, v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 61
    invoke-static {}, Lcom/tencent/mm/n/ad;->rp()Lcom/tencent/mm/n/w;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/tencent/mm/n/w;->a(Lcom/tencent/mm/n/v;)Z

    .line 64
    :cond_6
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Byte);v6=(Conflicted);
    new-instance v1, Lcom/tencent/mm/ag/e;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/ag/e;-><init>()V

    .line 65
    #v1=(Reference);
    iget v2, p1, Lcom/tencent/mm/protocal/a/j;->eDF:I

    #v2=(Integer);
    int-to-long v2, v2

    #v2=(LongLo);v3=(LongHi);
    invoke-static {p2, v2, v3}, Lcom/tencent/mm/ag/d;->b(Ljava/lang/String;J)J

    move-result-wide v2

    iput-wide v2, v1, Lcom/tencent/mm/ag/e;->field_createTime:J

    .line 66
    iput v7, v1, Lcom/tencent/mm/ag/e;->field_isSend:I

    .line 67
    iget-object v2, p1, Lcom/tencent/mm/protocal/a/j;->eDB:Lcom/tencent/mm/protocal/a/pt;

    #v2=(Reference);
    invoke-static {v2}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    .line 68
    iget v2, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v2=(Integer);
    iput v2, v1, Lcom/tencent/mm/ag/e;->field_svrId:I

    .line 69
    invoke-virtual {v0}, Lcom/tencent/mm/storage/an;->asd()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    .line 70
    iput v7, v1, Lcom/tencent/mm/ag/e;->field_type:I

    .line 72
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    iget-object v2, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    #v2=(Reference);
    invoke-virtual {v0, v2}, Lcom/tencent/mm/ag/b;->gl(Ljava/lang/String;)Lcom/tencent/mm/ag/a;

    move-result-object v0

    .line 73
    if-eqz v0, :cond_7

    .line 74
    const-string v2, "MicroMsg.FMessageExtension"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "getByEncryptTalker success. encryptTalker = "

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    iget-object v4, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " , real talker = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v0, Lcom/tencent/mm/ag/a;->field_talker:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 75
    iget-object v2, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    iput-object v2, v1, Lcom/tencent/mm/ag/e;->field_encryptTalker:Ljava/lang/String;

    .line 76
    iget-object v0, v0, Lcom/tencent/mm/ag/a;->field_talker:Ljava/lang/String;

    iput-object v0, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    .line 78
    :cond_7
    #v3=(Conflicted);v4=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/f;->a(Lcom/tencent/mm/ag/e;)Z

    goto/16 :goto_0
.end method

*/}
