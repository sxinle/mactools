package com.tencent.mm.ag; class n {/*

.class final Lcom/tencent/mm/ag/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/ao/k;


# direct methods
.method constructor <init>()V
    .locals 0

    .prologue
    .line 118
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final jE()[Ljava/lang/String;
    .locals 1

    .prologue
    .line 121
    sget-object v0, Lcom/tencent/mm/ag/s;->bGp:[Ljava/lang/String;

    #v0=(Reference);
    return-object v0
.end method

*/}
