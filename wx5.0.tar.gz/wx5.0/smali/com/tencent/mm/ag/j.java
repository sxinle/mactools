package com.tencent.mm.ag; class j {/*

.class public final Lcom/tencent/mm/ag/j;
.super Lcom/tencent/mm/sdk/e/ah;
.source "SourceFile"


# static fields
.field public static final bGp:[Ljava/lang/String;

.field public static final bpQ:[Ljava/lang/String;


# instance fields
.field private bNH:Lcom/tencent/mm/sdk/e/af;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .prologue
    const/4 v4, 0x1

    #v4=(One);
    const/4 v3, 0x0

    .line 24
    #v3=(Null);
    new-array v0, v4, [Ljava/lang/String;

    #v0=(Reference);
    sget-object v1, Lcom/tencent/mm/ag/i;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v1=(Reference);
    const-string v2, "shakeverifymessage"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/e/ah;->a(Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    sput-object v0, Lcom/tencent/mm/ag/j;->bGp:[Ljava/lang/String;

    .line 26
    const/4 v0, 0x3

    #v0=(PosByte);
    new-array v0, v0, [Ljava/lang/String;

    #v0=(Reference);
    const-string v1, "CREATE INDEX IF NOT EXISTS  shakeverifymessage_unread_index ON shakeverifymessage ( status )"

    aput-object v1, v0, v3

    const-string v1, "CREATE INDEX IF NOT EXISTS shakeverifymessage_statusIndex ON shakeverifymessage ( status )"

    aput-object v1, v0, v4

    const/4 v1, 0x2

    #v1=(PosByte);
    const-string v2, "CREATE INDEX IF NOT EXISTS shakeverifymessage_createtimeIndex ON shakeverifymessage ( createtime )"

    aput-object v2, v0, v1

    sput-object v0, Lcom/tencent/mm/ag/j;->bpQ:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/tencent/mm/sdk/e/af;)V
    .locals 3
    .parameter

    .prologue
    .line 32
    sget-object v0, Lcom/tencent/mm/ag/i;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v0=(Reference);
    const-string v1, "shakeverifymessage"

    #v1=(Reference);
    sget-object v2, Lcom/tencent/mm/ag/j;->bpQ:[Ljava/lang/String;

    #v2=(Reference);
    invoke-direct {p0, p1, v0, v1, v2}, Lcom/tencent/mm/sdk/e/ah;-><init>(Lcom/tencent/mm/sdk/e/af;Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;[Ljava/lang/String;)V

    .line 33
    #p0=(Reference);
    iput-object p1, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    .line 34
    return-void
.end method

.method public static gv(Ljava/lang/String;)J
    .locals 5
    .parameter

    .prologue
    .line 195
    const-wide/16 v0, 0x0

    .line 196
    #v0=(LongLo);v1=(LongHi);
    if-eqz p0, :cond_0

    .line 197
    invoke-static {}, Lcom/tencent/mm/ag/k;->yx()Lcom/tencent/mm/ag/j;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/ag/j;->ys()Lcom/tencent/mm/ag/i;

    move-result-object v2

    .line 198
    if-eqz v2, :cond_0

    .line 199
    iget-wide v0, v2, Lcom/tencent/mm/ag/i;->field_createtime:J

    const-wide/16 v2, 0x1

    #v2=(LongLo);v3=(LongHi);
    add-long/2addr v0, v2

    .line 203
    :cond_0
    #v2=(Conflicted);v3=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/sdk/platformtools/ce;->Ax()J

    move-result-wide v2

    .line 205
    #v2=(LongLo);v3=(LongHi);
    cmp-long v4, v0, v2

    #v4=(Byte);
    if-lez v4, :cond_1

    :goto_0
    return-wide v0

    :cond_1
    move-wide v0, v2

    goto :goto_0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/protocal/a/j;Lcom/tencent/mm/storage/aq;)V
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x3

    .line 117
    #v1=(PosByte);
    const-string v0, "MicroMsg.ShakeVerifyMessageStorage"

    #v0=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "saveToVerifyStg, cmdAM, status = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget v3, p1, Lcom/tencent/mm/protocal/a/j;->eDC:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", id = "

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 119
    new-instance v2, Lcom/tencent/mm/ag/i;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/i;-><init>()V

    .line 120
    #v2=(Reference);
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDB:Lcom/tencent/mm/protocal/a/pt;

    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/i;->field_content:Ljava/lang/String;

    .line 121
    invoke-static {}, Lcom/tencent/mm/sdk/platformtools/ce;->Ax()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    iput-wide v3, v2, Lcom/tencent/mm/ag/i;->field_createtime:J

    .line 122
    const-string v0, ""

    iput-object v0, v2, Lcom/tencent/mm/ag/i;->field_imgpath:Ljava/lang/String;

    .line 123
    invoke-virtual {p2}, Lcom/tencent/mm/storage/aq;->getContent()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/i;->field_sayhicontent:Ljava/lang/String;

    .line 124
    invoke-virtual {p2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/i;->field_sayhiuser:Ljava/lang/String;

    .line 125
    invoke-virtual {p2}, Lcom/tencent/mm/storage/aq;->AX()I

    move-result v0

    #v0=(Integer);
    iput v0, v2, Lcom/tencent/mm/ag/i;->field_scene:I

    .line 126
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDC:I

    if-le v0, v1, :cond_0

    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDC:I

    :goto_0
    iput v0, v2, Lcom/tencent/mm/ag/i;->field_status:I

    .line 127
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    int-to-long v3, v0

    iput-wide v3, v2, Lcom/tencent/mm/ag/i;->field_svrid:J

    .line 128
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDy:Lcom/tencent/mm/protocal/a/pt;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/i;->field_talker:Ljava/lang/String;

    .line 129
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDA:I

    #v0=(Integer);
    iput v0, v2, Lcom/tencent/mm/ag/i;->field_type:I

    .line 130
    const/4 v0, 0x0

    #v0=(Null);
    iput v0, v2, Lcom/tencent/mm/ag/i;->field_isSend:I

    .line 131
    invoke-virtual {p0, v2}, Lcom/tencent/mm/ag/j;->a(Lcom/tencent/mm/ag/i;)Z

    .line 132
    iget-object v0, v2, Lcom/tencent/mm/ag/i;->field_sayhiuser:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/n/c;->q(Ljava/lang/String;I)Z

    .line 133
    return-void

    :cond_0
    #v0=(Integer);
    move v0, v1

    .line 126
    #v0=(PosByte);
    goto :goto_0
.end method

.method public final a(Lcom/tencent/mm/ag/i;)Z
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 137
    #v0=(Null);
    if-nez p1, :cond_1

    .line 138
    const-string v1, "MicroMsg.ShakeVerifyMessageStorage"

    #v1=(Reference);
    const-string v2, "insert fail, shakeMsg is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 147
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return v0

    .line 142
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);
    invoke-super {p0, p1}, Lcom/tencent/mm/sdk/e/ah;->b(Lcom/tencent/mm/sdk/e/ad;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    .line 143
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    #v0=(Reference);
    iget-wide v1, p1, Lcom/tencent/mm/ag/i;->fhl:J

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/tencent/mm/ag/j;->rD(Ljava/lang/String;)V

    .line 144
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final synthetic b(Lcom/tencent/mm/sdk/e/ad;)Z
    .locals 1
    .parameter

    .prologue
    .line 19
    check-cast p1, Lcom/tencent/mm/ag/i;

    invoke-virtual {p0, p1}, Lcom/tencent/mm/ag/j;->a(Lcom/tencent/mm/ag/i;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final dw(I)Landroid/database/Cursor;
    .locals 3
    .parameter

    .prologue
    .line 81
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "SELECT * FROM "

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->uz()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " where isSend = 0 ORDER BY createtime desc LIMIT "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 82
    iget-object v1, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    const/4 v2, 0x0

    #v2=(Null);
    invoke-interface {v1, v0, v2}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    return-object v0
.end method

.method public final getCount()I
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 50
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "select count(*) from "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->uz()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 51
    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v1

    #v1=(Integer);
    const/4 v3, 0x1

    #v3=(One);
    if-eq v1, v3, :cond_1

    .line 52
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 58
    :cond_0
    :goto_0
    #v0=(Integer);
    return v0

    .line 55
    :cond_1
    #v0=(Null);
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 56
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    .line 57
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 58
    if-lez v1, :cond_0

    move v0, v1

    #v0=(Integer);
    goto :goto_0
.end method

.method public final gr(Ljava/lang/String;)V
    .locals 4
    .parameter

    .prologue
    .line 95
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "svrid = \'"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 96
    iget-object v1, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->uz()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v0, v3}, Lcom/tencent/mm/sdk/e/af;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    .line 97
    #v0=(Integer);
    if-lez v0, :cond_0

    .line 98
    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->zf()V

    .line 100
    :cond_0
    const-string v1, "MicroMsg.ShakeVerifyMessageStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "delBySvrId = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    return-void
.end method

.method public final gw(Ljava/lang/String;)Lcom/tencent/mm/ag/i;
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 151
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_1

    .line 152
    :cond_0
    #v1=(Conflicted);
    const-string v1, "MicroMsg.ShakeVerifyMessageStorage"

    #v1=(Reference);
    const-string v2, "getLastRecvShakeMsg fail, talker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 165
    :goto_0
    #v0=(Reference);v2=(Conflicted);
    return-object v0

    .line 156
    :cond_1
    #v0=(Null);v1=(Integer);v2=(Uninit);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select * from ShakeVerifyMessage where isSend = 0 and sayhiuser = \'"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\' order by createTime DESC limit 1"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 157
    iget-object v2, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 159
    new-instance v0, Lcom/tencent/mm/ag/i;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/i;-><init>()V

    .line 160
    #v0=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    if-eqz v2, :cond_2

    .line 161
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 162
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/i;->a(Landroid/database/Cursor;)V

    .line 164
    :cond_2
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final gx(Ljava/lang/String;)[Lcom/tencent/mm/ag/i;
    .locals 6
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 171
    #v0=(Null);
    const-string v1, "MicroMsg.ShakeVerifyMessageStorage"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "getLastShakeVerifyMessage, talker = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", limit = 3"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 173
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select *, rowid from ShakeVerifyMessage  where sayhiuser = \'"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\' order by createtime DESC limit 3"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 174
    iget-object v2, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 176
    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v3

    .line 177
    #v3=(Integer);
    if-gtz v3, :cond_0

    .line 178
    const-string v1, "MicroMsg.ShakeVerifyMessageStorage"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "getLastShakeVerifyMessage, cursor count = 0, talker = "

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", limit = 3"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 179
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 191
    :goto_0
    #v0=(Reference);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    .line 184
    :cond_0
    #v0=(Null);v1=(Reference);v3=(Integer);v4=(Uninit);v5=(Uninit);
    new-array v0, v3, [Lcom/tencent/mm/ag/i;

    .line 185
    #v0=(Reference);
    const/4 v1, 0x0

    :goto_1
    #v1=(Integer);v4=(Conflicted);v5=(Conflicted);
    if-ge v1, v3, :cond_1

    .line 186
    invoke-interface {v2, v1}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 187
    sub-int v4, v3, v1

    #v4=(Integer);
    add-int/lit8 v4, v4, -0x1

    new-instance v5, Lcom/tencent/mm/ag/i;

    #v5=(UninitRef);
    invoke-direct {v5}, Lcom/tencent/mm/ag/i;-><init>()V

    #v5=(Reference);
    aput-object v5, v0, v4

    .line 188
    sub-int v4, v3, v1

    add-int/lit8 v4, v4, -0x1

    aget-object v4, v0, v4

    #v4=(Null);
    invoke-virtual {v4, v2}, Lcom/tencent/mm/ag/i;->a(Landroid/database/Cursor;)V

    .line 185
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 190
    :cond_1
    #v4=(Conflicted);v5=(Conflicted);
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final yn()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 113
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->uz()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-interface {v0, v1, v2, v2}, Lcom/tencent/mm/sdk/e/af;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 114
    return-void
.end method

.method public final yp()I
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 37
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "select count(*) from "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->uz()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " where status != 4"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 38
    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v1

    #v1=(Integer);
    const/4 v3, 0x1

    #v3=(One);
    if-eq v1, v3, :cond_1

    .line 39
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 45
    :cond_0
    :goto_0
    #v0=(Integer);
    return v0

    .line 42
    :cond_1
    #v0=(Null);
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 43
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    .line 44
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 45
    if-lez v1, :cond_0

    move v0, v1

    #v0=(Integer);
    goto :goto_0
.end method

.method public final yr()V
    .locals 7

    .prologue
    .line 86
    new-instance v0, Landroid/content/ContentValues;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 87
    #v0=(Reference);
    const-string v1, "status"

    #v1=(Reference);
    const/4 v2, 0x4

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 88
    iget-object v1, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->uz()Ljava/lang/String;

    move-result-object v2

    const-string v3, "status!=? "

    #v3=(Reference);
    const/4 v4, 0x1

    #v4=(One);
    new-array v4, v4, [Ljava/lang/String;

    #v4=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    const-string v6, "4"

    #v6=(Reference);
    aput-object v6, v4, v5

    invoke-interface {v1, v2, v0, v3, v4}, Lcom/tencent/mm/sdk/e/af;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    .line 89
    #v0=(Integer);
    if-eqz v0, :cond_0

    .line 90
    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->zf()V

    .line 92
    :cond_0
    return-void
.end method

.method public final ys()Lcom/tencent/mm/ag/i;
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 66
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/j;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "SELECT * FROM "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/j;->uz()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " ORDER BY createtime DESC LIMIT 1"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 67
    if-nez v1, :cond_0

    .line 77
    :goto_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);
    return-object v0

    .line 69
    :cond_0
    #v0=(Null);v2=(Reference);v3=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    const/4 v3, 0x1

    #v3=(One);
    if-eq v2, v3, :cond_1

    .line 70
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0

    .line 73
    :cond_1
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 74
    new-instance v0, Lcom/tencent/mm/ag/i;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/i;-><init>()V

    .line 75
    #v0=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/i;->a(Landroid/database/Cursor;)V

    .line 76
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

*/}
