package com.tencent.mm.ag; class h {/*

.class public final Lcom/tencent/mm/ag/h;
.super Lcom/tencent/mm/sdk/e/ah;
.source "SourceFile"


# static fields
.field public static final bGp:[Ljava/lang/String;


# instance fields
.field private bNH:Lcom/tencent/mm/sdk/e/af;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .prologue
    .line 23
    const/4 v0, 0x1

    #v0=(One);
    new-array v0, v0, [Ljava/lang/String;

    #v0=(Reference);
    const/4 v1, 0x0

    #v1=(Null);
    sget-object v2, Lcom/tencent/mm/ag/g;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v2=(Reference);
    const-string v3, "LBSVerifyMessage"

    #v3=(Reference);
    invoke-static {v2, v3}, Lcom/tencent/mm/sdk/e/ah;->a(Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    sput-object v0, Lcom/tencent/mm/ag/h;->bGp:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/tencent/mm/sdk/e/af;)V
    .locals 3
    .parameter

    .prologue
    .line 26
    sget-object v0, Lcom/tencent/mm/ag/g;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v0=(Reference);
    const-string v1, "LBSVerifyMessage"

    #v1=(Reference);
    sget-object v2, Lcom/tencent/mm/c/b/v;->bpQ:[Ljava/lang/String;

    #v2=(Reference);
    invoke-direct {p0, p1, v0, v1, v2}, Lcom/tencent/mm/sdk/e/ah;-><init>(Lcom/tencent/mm/sdk/e/af;Lcom/tencent/mm/sdk/e/ae;Ljava/lang/String;[Ljava/lang/String;)V

    .line 27
    #p0=(Reference);
    iput-object p1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    .line 28
    return-void
.end method

.method public static gv(Ljava/lang/String;)J
    .locals 5
    .parameter

    .prologue
    .line 192
    const-wide/16 v0, 0x0

    .line 193
    #v0=(LongLo);v1=(LongHi);
    if-eqz p0, :cond_0

    .line 194
    invoke-static {}, Lcom/tencent/mm/ag/k;->yw()Lcom/tencent/mm/ag/h;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/ag/h;->yq()Lcom/tencent/mm/ag/g;

    move-result-object v2

    .line 195
    if-eqz v2, :cond_0

    .line 196
    iget-wide v0, v2, Lcom/tencent/mm/ag/g;->field_createtime:J

    const-wide/16 v2, 0x1

    #v2=(LongLo);v3=(LongHi);
    add-long/2addr v0, v2

    .line 199
    :cond_0
    #v2=(Conflicted);v3=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/sdk/platformtools/ce;->Ax()J

    move-result-wide v2

    .line 201
    #v2=(LongLo);v3=(LongHi);
    cmp-long v4, v0, v2

    #v4=(Byte);
    if-lez v4, :cond_1

    :goto_0
    return-wide v0

    :cond_1
    move-wide v0, v2

    goto :goto_0
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/protocal/a/j;Lcom/tencent/mm/storage/aq;)V
    .locals 5
    .parameter
    .parameter

    .prologue
    const/4 v1, 0x3

    .line 114
    #v1=(PosByte);
    const-string v0, "MicroMsg.LBSVerifyMessageStorage"

    #v0=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "saveToVerifyStg, cmdAM, status = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    iget v3, p1, Lcom/tencent/mm/protocal/a/j;->eDC:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", id = "

    #v3=(Reference);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v3=(Integer);
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 116
    new-instance v2, Lcom/tencent/mm/ag/g;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/g;-><init>()V

    .line 117
    #v2=(Reference);
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDB:Lcom/tencent/mm/protocal/a/pt;

    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/g;->field_content:Ljava/lang/String;

    .line 118
    invoke-static {}, Lcom/tencent/mm/sdk/platformtools/ce;->Ax()J

    move-result-wide v3

    #v3=(LongLo);v4=(LongHi);
    iput-wide v3, v2, Lcom/tencent/mm/ag/g;->field_createtime:J

    .line 119
    const-string v0, ""

    iput-object v0, v2, Lcom/tencent/mm/ag/g;->field_imgpath:Ljava/lang/String;

    .line 120
    invoke-virtual {p2}, Lcom/tencent/mm/storage/aq;->getContent()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/g;->field_sayhicontent:Ljava/lang/String;

    .line 121
    invoke-virtual {p2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/g;->field_sayhiuser:Ljava/lang/String;

    .line 122
    invoke-virtual {p2}, Lcom/tencent/mm/storage/aq;->AX()I

    move-result v0

    #v0=(Integer);
    iput v0, v2, Lcom/tencent/mm/ag/g;->field_scene:I

    .line 123
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDC:I

    if-le v0, v1, :cond_0

    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDC:I

    :goto_0
    iput v0, v2, Lcom/tencent/mm/ag/g;->field_status:I

    .line 124
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    int-to-long v3, v0

    iput-wide v3, v2, Lcom/tencent/mm/ag/g;->field_svrid:J

    .line 125
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDy:Lcom/tencent/mm/protocal/a/pt;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v2, Lcom/tencent/mm/ag/g;->field_talker:Ljava/lang/String;

    .line 126
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDA:I

    #v0=(Integer);
    iput v0, v2, Lcom/tencent/mm/ag/g;->field_type:I

    .line 127
    const/4 v0, 0x0

    #v0=(Null);
    iput v0, v2, Lcom/tencent/mm/ag/g;->field_isSend:I

    .line 128
    invoke-virtual {p0, v2}, Lcom/tencent/mm/ag/h;->a(Lcom/tencent/mm/ag/g;)Z

    .line 129
    iget-object v0, v2, Lcom/tencent/mm/ag/g;->field_sayhiuser:Ljava/lang/String;

    #v0=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/n/c;->q(Ljava/lang/String;I)Z

    .line 130
    return-void

    :cond_0
    #v0=(Integer);
    move v0, v1

    .line 123
    #v0=(PosByte);
    goto :goto_0
.end method

.method public final a(Lcom/tencent/mm/ag/g;)Z
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 134
    #v0=(Null);
    if-nez p1, :cond_1

    .line 135
    const-string v1, "MicroMsg.LBSVerifyMessageStorage"

    #v1=(Reference);
    const-string v2, "insert fail, lbsMsg is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 144
    :cond_0
    :goto_0
    #v0=(Boolean);v1=(Conflicted);v2=(Conflicted);
    return v0

    .line 139
    :cond_1
    #v0=(Null);v1=(Uninit);v2=(Uninit);
    invoke-super {p0, p1}, Lcom/tencent/mm/sdk/e/ah;->b(Lcom/tencent/mm/sdk/e/ad;)Z

    move-result v1

    #v1=(Boolean);
    if-eqz v1, :cond_0

    .line 140
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    #v0=(Reference);
    iget-wide v1, p1, Lcom/tencent/mm/ag/g;->fhl:J

    #v1=(LongLo);v2=(LongHi);
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/tencent/mm/ag/h;->rD(Ljava/lang/String;)V

    .line 141
    const/4 v0, 0x1

    #v0=(One);
    goto :goto_0
.end method

.method public final synthetic b(Lcom/tencent/mm/sdk/e/ad;)Z
    .locals 1
    .parameter

    .prologue
    .line 19
    check-cast p1, Lcom/tencent/mm/ag/g;

    invoke-virtual {p0, p1}, Lcom/tencent/mm/ag/h;->a(Lcom/tencent/mm/ag/g;)Z

    move-result v0

    #v0=(Boolean);
    return v0
.end method

.method public final dw(I)Landroid/database/Cursor;
    .locals 3
    .parameter

    .prologue
    .line 77
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "SELECT * FROM "

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " where isSend = 0 ORDER BY createtime desc LIMIT "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 78
    iget-object v1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    const/4 v2, 0x0

    #v2=(Null);
    invoke-interface {v1, v0, v2}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    return-object v0
.end method

.method public final getCount()I
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 45
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "select count(*) from "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 46
    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v1

    #v1=(Integer);
    const/4 v3, 0x1

    #v3=(One);
    if-eq v1, v3, :cond_1

    .line 47
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 53
    :cond_0
    :goto_0
    #v0=(Integer);
    return v0

    .line 50
    :cond_1
    #v0=(Null);
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 51
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    .line 52
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 53
    if-lez v1, :cond_0

    move v0, v1

    #v0=(Integer);
    goto :goto_0
.end method

.method public final gr(Ljava/lang/String;)V
    .locals 4
    .parameter

    .prologue
    .line 92
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "svrid = \'"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 93
    iget-object v1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v0, v3}, Lcom/tencent/mm/sdk/e/af;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    .line 94
    #v0=(Integer);
    if-lez v0, :cond_0

    .line 95
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->zf()V

    .line 97
    :cond_0
    const-string v1, "MicroMsg.LBSVerifyMessageStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "delBySvrId = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 98
    return-void
.end method

.method public final gs(Ljava/lang/String;)V
    .locals 4
    .parameter

    .prologue
    .line 101
    new-instance v0, Ljava/lang/StringBuilder;

    #v0=(UninitRef);
    const-string v1, "sayhiuser = \'"

    #v1=(Reference);
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v0=(Reference);
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 102
    iget-object v1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v2

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v0, v3}, Lcom/tencent/mm/sdk/e/af;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    .line 103
    #v0=(Integer);
    if-lez v0, :cond_0

    .line 104
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->zf()V

    .line 106
    :cond_0
    const-string v1, "MicroMsg.LBSVerifyMessageStorage"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "delByUserName = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 107
    return-void
.end method

.method public final gt(Ljava/lang/String;)[Lcom/tencent/mm/ag/g;
    .locals 6
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 150
    #v0=(Null);
    const-string v1, "MicroMsg.LBSVerifyMessageStorage"

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "getLastLBSVerifyMessage, talker = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", limit = 3"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 152
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select *, rowid from LBSVerifyMessage  where sayhiuser = \'"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\' order by createtime DESC limit 3"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 153
    iget-object v2, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 155
    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v3

    .line 156
    #v3=(Integer);
    if-gtz v3, :cond_0

    .line 157
    const-string v1, "MicroMsg.LBSVerifyMessageStorage"

    new-instance v3, Ljava/lang/StringBuilder;

    #v3=(UninitRef);
    const-string v4, "getLastLBSVerifyMessage, cursor count = 0, talker = "

    #v4=(Reference);
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v3=(Reference);
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ", limit = 3"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 158
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 170
    :goto_0
    #v0=(Reference);v1=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    return-object v0

    .line 163
    :cond_0
    #v0=(Null);v1=(Reference);v3=(Integer);v4=(Uninit);v5=(Uninit);
    new-array v0, v3, [Lcom/tencent/mm/ag/g;

    .line 164
    #v0=(Reference);
    const/4 v1, 0x0

    :goto_1
    #v1=(Integer);v4=(Conflicted);v5=(Conflicted);
    if-ge v1, v3, :cond_1

    .line 165
    invoke-interface {v2, v1}, Landroid/database/Cursor;->moveToPosition(I)Z

    .line 166
    sub-int v4, v3, v1

    #v4=(Integer);
    add-int/lit8 v4, v4, -0x1

    new-instance v5, Lcom/tencent/mm/ag/g;

    #v5=(UninitRef);
    invoke-direct {v5}, Lcom/tencent/mm/ag/g;-><init>()V

    #v5=(Reference);
    aput-object v5, v0, v4

    .line 167
    sub-int v4, v3, v1

    add-int/lit8 v4, v4, -0x1

    aget-object v4, v0, v4

    #v4=(Null);
    invoke-virtual {v4, v2}, Lcom/tencent/mm/ag/g;->a(Landroid/database/Cursor;)V

    .line 164
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 169
    :cond_1
    #v4=(Conflicted);v5=(Conflicted);
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final gu(Ljava/lang/String;)Lcom/tencent/mm/ag/g;
    .locals 3
    .parameter

    .prologue
    const/4 v0, 0x0

    .line 174
    #v0=(Null);
    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    #v1=(Integer);
    if-nez v1, :cond_1

    .line 175
    :cond_0
    #v1=(Conflicted);
    const-string v1, "MicroMsg.LBSVerifyMessageStorage"

    #v1=(Reference);
    const-string v2, "getLastRecvLbsMsg fail, talker is null"

    #v2=(Reference);
    invoke-static {v1, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 188
    :goto_0
    #v0=(Reference);v2=(Conflicted);
    return-object v0

    .line 179
    :cond_1
    #v0=(Null);v1=(Integer);v2=(Uninit);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "select * from LBSVerifyMessage where isSend = 0 and sayhiuser = \'"

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-static {p1}, Lcom/tencent/mm/sdk/platformtools/ce;->hx(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\' order by createTime DESC limit 1"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 180
    iget-object v2, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-interface {v2, v1, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 182
    new-instance v0, Lcom/tencent/mm/ag/g;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/g;-><init>()V

    .line 183
    #v0=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    if-eqz v2, :cond_2

    .line 184
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 185
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/g;->a(Landroid/database/Cursor;)V

    .line 187
    :cond_2
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final yn()V
    .locals 3

    .prologue
    const/4 v2, 0x0

    .line 110
    #v2=(Null);
    iget-object v0, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v0=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v1

    #v1=(Reference);
    invoke-interface {v0, v1, v2, v2}, Lcom/tencent/mm/sdk/e/af;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 111
    return-void
.end method

.method public final yp()I
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 31
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "select count(*) from "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " where status != 4"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    #v3=(Null);
    invoke-interface {v1, v2, v3}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    .line 33
    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result v1

    #v1=(Integer);
    const/4 v3, 0x1

    #v3=(One);
    if-eq v1, v3, :cond_1

    .line 34
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 40
    :cond_0
    :goto_0
    #v0=(Integer);
    return v0

    .line 37
    :cond_1
    #v0=(Null);
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 38
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v1

    .line 39
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 40
    if-lez v1, :cond_0

    move v0, v1

    #v0=(Integer);
    goto :goto_0
.end method

.method public final yq()Lcom/tencent/mm/ag/g;
    .locals 4

    .prologue
    const/4 v0, 0x0

    .line 62
    #v0=(Null);
    iget-object v1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    #v1=(Reference);
    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "SELECT * FROM "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " ORDER BY createtime DESC LIMIT 1"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Lcom/tencent/mm/sdk/e/af;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 63
    if-nez v1, :cond_0

    .line 73
    :goto_0
    #v0=(Reference);v2=(Conflicted);v3=(Conflicted);
    return-object v0

    .line 65
    :cond_0
    #v0=(Null);v2=(Reference);v3=(Reference);
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    #v2=(Integer);
    const/4 v3, 0x1

    #v3=(One);
    if-eq v2, v3, :cond_1

    .line 66
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0

    .line 69
    :cond_1
    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 70
    new-instance v0, Lcom/tencent/mm/ag/g;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/g;-><init>()V

    .line 71
    #v0=(Reference);
    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/g;->a(Landroid/database/Cursor;)V

    .line 72
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_0
.end method

.method public final yr()V
    .locals 7

    .prologue
    .line 82
    new-instance v0, Landroid/content/ContentValues;

    #v0=(UninitRef);
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 83
    #v0=(Reference);
    const-string v1, "status"

    #v1=(Reference);
    const/4 v2, 0x4

    #v2=(PosByte);
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 84
    iget-object v1, p0, Lcom/tencent/mm/ag/h;->bNH:Lcom/tencent/mm/sdk/e/af;

    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->uz()Ljava/lang/String;

    move-result-object v2

    const-string v3, "status!=? "

    #v3=(Reference);
    const/4 v4, 0x1

    #v4=(One);
    new-array v4, v4, [Ljava/lang/String;

    #v4=(Reference);
    const/4 v5, 0x0

    #v5=(Null);
    const-string v6, "4"

    #v6=(Reference);
    aput-object v6, v4, v5

    invoke-interface {v1, v2, v0, v3, v4}, Lcom/tencent/mm/sdk/e/af;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    .line 86
    #v0=(Integer);
    if-eqz v0, :cond_0

    .line 87
    invoke-virtual {p0}, Lcom/tencent/mm/ag/h;->zf()V

    .line 89
    :cond_0
    return-void
.end method

*/}
