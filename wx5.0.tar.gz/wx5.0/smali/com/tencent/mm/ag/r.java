package com.tencent.mm.ag; class r {/*

.class final Lcom/tencent/mm/ag/r;
.super Lcom/tencent/mm/sdk/b/g;
.source "SourceFile"


# instance fields
.field final synthetic bWL:Lcom/tencent/mm/ag/k;


# direct methods
.method constructor <init>(Lcom/tencent/mm/ag/k;)V
    .locals 0
    .parameter

    .prologue
    .line 185
    iput-object p1, p0, Lcom/tencent/mm/ag/r;->bWL:Lcom/tencent/mm/ag/k;

    invoke-direct {p0}, Lcom/tencent/mm/sdk/b/g;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/sdk/b/e;)Z
    .locals 7
    .parameter

    .prologue
    const/4 v6, -0x1

    .line 188
    #v6=(Byte);
    check-cast p1, Lcom/tencent/mm/c/a/bi;

    .line 189
    iget-object v0, p1, Lcom/tencent/mm/c/a/bi;->blJ:Lcom/tencent/mm/c/a/bj;

    #v0=(Reference);
    iget v1, v0, Lcom/tencent/mm/c/a/bj;->blL:I

    .line 190
    #v1=(Integer);
    iget-object v0, p1, Lcom/tencent/mm/c/a/bi;->blJ:Lcom/tencent/mm/c/a/bj;

    iget-object v2, v0, Lcom/tencent/mm/c/a/bj;->username:Ljava/lang/String;

    .line 191
    #v2=(Reference);
    iget-object v0, p1, Lcom/tencent/mm/c/a/bi;->blJ:Lcom/tencent/mm/c/a/bj;

    iget-wide v3, v0, Lcom/tencent/mm/c/a/bj;->blM:J

    .line 193
    #v3=(LongLo);v4=(LongHi);
    new-instance v0, Lcom/tencent/mm/ag/e;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/e;-><init>()V

    .line 195
    #v0=(Reference);
    const/4 v5, 0x1

    #v5=(One);
    if-ne v1, v5, :cond_1

    .line 196
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v1

    #v1=(Reference);
    invoke-virtual {v1, v3, v4, v0}, Lcom/tencent/mm/ag/f;->b(JLcom/tencent/mm/sdk/e/ad;)Z

    .line 202
    :cond_0
    :goto_0
    #v1=(Conflicted);v3=(Conflicted);
    iget-object v1, v0, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    #v1=(Reference);
    if-eqz v1, :cond_2

    iget-object v1, v0, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    const-string v2, ""

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_2

    .line 203
    iget-object v1, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    #v1=(Reference);
    iget-object v2, v0, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    iput-object v2, v1, Lcom/tencent/mm/c/a/bk;->blN:Ljava/lang/String;

    .line 204
    iget-object v1, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    iget-object v2, v0, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    iput-object v2, v1, Lcom/tencent/mm/c/a/bk;->blA:Ljava/lang/String;

    .line 205
    iget-object v1, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    iget v2, v0, Lcom/tencent/mm/ag/e;->field_isSend:I

    #v2=(Integer);
    iput v2, v1, Lcom/tencent/mm/c/a/bk;->blO:I

    .line 206
    iget-object v1, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    iget v0, v0, Lcom/tencent/mm/ag/e;->field_type:I

    #v0=(Integer);
    iput v0, v1, Lcom/tencent/mm/c/a/bk;->type:I

    .line 213
    :goto_1
    #v0=(Conflicted);v2=(Conflicted);
    const/4 v0, 0x0

    #v0=(Null);
    return v0

    .line 198
    :cond_1
    #v0=(Reference);v1=(Integer);v2=(Reference);v3=(LongLo);
    const/4 v3, 0x2

    #v3=(PosByte);
    if-ne v1, v3, :cond_0

    .line 199
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/tencent/mm/ag/f;->gq(Ljava/lang/String;)Lcom/tencent/mm/ag/e;

    move-result-object v0

    goto :goto_0

    .line 208
    :cond_2
    #v1=(Conflicted);v3=(Conflicted);
    iget-object v0, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    const-string v1, ""

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/c/a/bk;->blN:Ljava/lang/String;

    .line 209
    iget-object v0, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    const-string v1, ""

    iput-object v1, v0, Lcom/tencent/mm/c/a/bk;->blA:Ljava/lang/String;

    .line 210
    iget-object v0, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    iput v6, v0, Lcom/tencent/mm/c/a/bk;->blO:I

    .line 211
    iget-object v0, p1, Lcom/tencent/mm/c/a/bi;->blK:Lcom/tencent/mm/c/a/bk;

    iput v6, v0, Lcom/tencent/mm/c/a/bk;->type:I

    goto :goto_1
.end method

*/}
