package com.tencent.mm.ag; class i {/*

.class public Lcom/tencent/mm/ag/i;
.super Lcom/tencent/mm/c/b/ab;
.source "SourceFile"


# static fields
.field protected static bDe:Lcom/tencent/mm/sdk/e/ae;

.field protected static bWC:[Ljava/lang/reflect/Field;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .prologue
    const/16 v5, 0xb

    .line 12
    #v5=(PosByte);
    const-class v0, Lcom/tencent/mm/ag/i;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/c/b/ab;->d(Ljava/lang/Class;)[Ljava/lang/reflect/Field;

    move-result-object v0

    sput-object v0, Lcom/tencent/mm/ag/i;->bWC:[Ljava/lang/reflect/Field;

    .line 14
    new-instance v0, Lcom/tencent/mm/sdk/e/ae;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/sdk/e/ae;-><init>()V

    #v0=(Reference);
    new-array v1, v5, [Ljava/lang/reflect/Field;

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/sdk/e/ae;->bWC:[Ljava/lang/reflect/Field;

    const/16 v1, 0xc

    #v1=(PosByte);
    new-array v1, v1, [Ljava/lang/String;

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    #v1=(Reference);
    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    #v2=(Reference);
    const/4 v3, 0x0

    #v3=(Null);
    const-string v4, "svrid"

    #v4=(Reference);
    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "svrid"

    #v3=(Reference);
    const-string v4, "LONG"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " svrid LONG default \'0\'  PRIMARY KEY "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "svrid"

    iput-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhm:Ljava/lang/String;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/4 v3, 0x1

    #v3=(One);
    const-string v4, "status"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "status"

    #v3=(Reference);
    const-string v4, "INTEGER"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " status INTEGER"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/4 v3, 0x2

    #v3=(PosByte);
    const-string v4, "type"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "type"

    #v3=(Reference);
    const-string v4, "INTEGER"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " type INTEGER"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/4 v3, 0x3

    #v3=(PosByte);
    const-string v4, "scene"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "scene"

    #v3=(Reference);
    const-string v4, "INTEGER"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " scene INTEGER"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/4 v3, 0x4

    #v3=(PosByte);
    const-string v4, "createtime"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "createtime"

    #v3=(Reference);
    const-string v4, "LONG"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " createtime LONG"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/4 v3, 0x5

    #v3=(PosByte);
    const-string v4, "talker"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "talker"

    #v3=(Reference);
    const-string v4, "TEXT"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " talker TEXT"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/4 v3, 0x6

    #v3=(PosByte);
    const-string v4, "content"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "content"

    #v3=(Reference);
    const-string v4, "TEXT"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " content TEXT"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/4 v3, 0x7

    #v3=(PosByte);
    const-string v4, "sayhiuser"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "sayhiuser"

    #v3=(Reference);
    const-string v4, "TEXT"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " sayhiuser TEXT"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/16 v3, 0x8

    #v3=(PosByte);
    const-string v4, "sayhicontent"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "sayhicontent"

    #v3=(Reference);
    const-string v4, "TEXT"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " sayhicontent TEXT"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/16 v3, 0x9

    #v3=(PosByte);
    const-string v4, "imgpath"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "imgpath"

    #v3=(Reference);
    const-string v4, "TEXT"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " imgpath TEXT"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const/16 v3, 0xa

    #v3=(PosByte);
    const-string v4, "isSend"

    aput-object v4, v2, v3

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->fhn:Ljava/util/Map;

    const-string v3, "isSend"

    #v3=(Reference);
    const-string v4, "INTEGER"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " isSend INTEGER"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/tencent/mm/sdk/e/ae;->bwP:[Ljava/lang/String;

    const-string v3, "rowid"

    aput-object v3, v2, v5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/tencent/mm/sdk/e/ae;->bGc:Ljava/lang/String;

    sput-object v0, Lcom/tencent/mm/ag/i;->bDe:Lcom/tencent/mm/sdk/e/ae;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 21
    invoke-direct {p0}, Lcom/tencent/mm/c/b/ab;-><init>()V

    .line 22
    #p0=(Reference);
    return-void
.end method


# virtual methods
.method protected final lX()Lcom/tencent/mm/sdk/e/ae;
    .locals 1

    .prologue
    .line 18
    sget-object v0, Lcom/tencent/mm/ag/i;->bDe:Lcom/tencent/mm/sdk/e/ae;

    #v0=(Reference);
    return-object v0
.end method

*/}
