package com.tencent.mm.ag; class t {/*

.class public final Lcom/tencent/mm/ag/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/o/j;


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    #p0=(Reference);
    return-void
.end method


# virtual methods
.method public final a(Lcom/tencent/mm/protocal/a/j;)Lcom/tencent/mm/o/k;
    .locals 13
    .parameter

    .prologue
    const/4 v12, 0x2

    #v12=(PosByte);
    const/4 v11, 0x0

    #v11=(Null);
    const/4 v10, 0x3

    #v10=(PosByte);
    const/4 v9, 0x0

    #v9=(Null);
    const/4 v8, 0x1

    .line 26
    #v8=(One);
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDy:Lcom/tencent/mm/protocal/a/pt;

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    .line 27
    const-string v1, "fmessage"

    #v1=(Reference);
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    #v1=(Boolean);
    if-nez v1, :cond_1

    .line 120
    :cond_0
    :goto_0
    #v1=(Conflicted);v2=(Conflicted);v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);v6=(Conflicted);v7=(Conflicted);
    return-object v9

    .line 31
    :cond_1
    #v1=(Boolean);v2=(Uninit);v3=(Uninit);v4=(Uninit);v5=(Uninit);v6=(Uninit);v7=(Uninit);
    iget-object v1, p1, Lcom/tencent/mm/protocal/a/j;->eDB:Lcom/tencent/mm/protocal/a/pt;

    #v1=(Reference);
    invoke-static {v1}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v1

    .line 32
    invoke-static {v1}, Lcom/tencent/mm/storage/aq;->tn(Ljava/lang/String;)Lcom/tencent/mm/storage/aq;

    move-result-object v2

    .line 34
    #v2=(Reference);
    if-eqz v2, :cond_2

    .line 35
    const-string v3, "MicroMsg.VerifyMessageExtension"

    #v3=(Reference);
    new-instance v4, Ljava/lang/StringBuilder;

    #v4=(UninitRef);
    const-string v5, "onPreAddMessage, verify scene = "

    #v5=(Reference);
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v4=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->AX()I

    move-result v5

    #v5=(Integer);
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    :cond_2
    #v3=(Conflicted);v4=(Conflicted);v5=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/model/s;->ow()Ljava/lang/String;

    move-result-object v3

    .line 39
    #v3=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v4

    #v4=(Reference);
    if-eqz v4, :cond_3

    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    #v3=(Boolean);
    if-eqz v3, :cond_3

    .line 41
    const-string v0, "MicroMsg.VerifyMessageExtension"

    const-string v1, "fromUserName is self, simply drop this msg"

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 45
    :cond_3
    #v3=(Conflicted);
    new-instance v3, Lcom/tencent/mm/n/v;

    #v3=(UninitRef);
    invoke-direct {v3}, Lcom/tencent/mm/n/v;-><init>()V

    .line 46
    #v3=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/tencent/mm/n/v;->setUsername(Ljava/lang/String;)V

    .line 47
    invoke-virtual {v3, v10}, Lcom/tencent/mm/n/v;->bb(I)V

    .line 48
    invoke-virtual {v3, v8}, Lcom/tencent/mm/n/v;->o(Z)V

    .line 49
    const/4 v4, -0x1

    #v4=(Byte);
    invoke-virtual {v3, v4}, Lcom/tencent/mm/n/v;->bO(I)V

    .line 50
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asb()Ljava/lang/String;

    move-result-object v4

    #v4=(Reference);
    invoke-virtual {v3, v4}, Lcom/tencent/mm/n/v;->ea(Ljava/lang/String;)V

    .line 51
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asc()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/tencent/mm/n/v;->eb(Ljava/lang/String;)V

    .line 52
    const-string v4, "MicroMsg.VerifyMessageExtension"

    const-string v5, "dkhurl user:[%s] big:[%s] sm:[%s]"

    #v5=(Reference);
    new-array v6, v10, [Ljava/lang/Object;

    #v6=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v7

    #v7=(Reference);
    aput-object v7, v6, v11

    invoke-virtual {v3}, Lcom/tencent/mm/n/v;->qY()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v8

    invoke-virtual {v3}, Lcom/tencent/mm/n/v;->qZ()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v12

    invoke-static {v4, v5, v6}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 53
    invoke-static {}, Lcom/tencent/mm/n/ad;->rp()Lcom/tencent/mm/n/w;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/tencent/mm/n/w;->a(Lcom/tencent/mm/n/v;)Z

    .line 55
    if-eqz v2, :cond_6

    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v3

    #v3=(Boolean);
    if-nez v3, :cond_6

    .line 56
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->AX()I

    move-result v3

    #v3=(Integer);
    const/16 v4, 0x12

    #v4=(PosByte);
    if-ne v3, v4, :cond_4

    .line 57
    invoke-static {}, Lcom/tencent/mm/ag/k;->yw()Lcom/tencent/mm/ag/h;

    move-result-object v0

    invoke-virtual {v0, p1, v2}, Lcom/tencent/mm/ag/h;->a(Lcom/tencent/mm/protocal/a/j;Lcom/tencent/mm/storage/aq;)V

    .line 58
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nJ()Lcom/tencent/mm/storage/e;

    move-result-object v0

    const v1, 0x12001

    #v1=(Integer);
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/e;->set(ILjava/lang/Object;)V

    goto/16 :goto_0

    .line 61
    :cond_4
    #v1=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->AX()I

    move-result v3

    invoke-static {v3}, Lcom/tencent/mm/model/bm;->bC(I)Z

    move-result v3

    #v3=(Boolean);
    if-eqz v3, :cond_5

    .line 62
    invoke-static {}, Lcom/tencent/mm/ag/k;->yx()Lcom/tencent/mm/ag/j;

    move-result-object v0

    invoke-virtual {v0, p1, v2}, Lcom/tencent/mm/ag/j;->a(Lcom/tencent/mm/protocal/a/j;Lcom/tencent/mm/storage/aq;)V

    .line 63
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nJ()Lcom/tencent/mm/storage/e;

    move-result-object v0

    const v1, 0x12002

    #v1=(Integer);
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mm/storage/e;->set(ILjava/lang/Object;)V

    goto/16 :goto_0

    .line 66
    :cond_5
    #v1=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->AX()I

    move-result v3

    #v3=(Integer);
    const/16 v4, 0x30

    if-ne v3, v4, :cond_6

    .line 67
    new-instance v0, Lcom/tencent/mm/c/a/eb;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/c/a/eb;-><init>()V

    .line 68
    #v0=(Reference);
    iget-object v3, v0, Lcom/tencent/mm/c/a/eb;->bnB:Lcom/tencent/mm/c/a/ec;

    #v3=(Reference);
    iput-object v1, v3, Lcom/tencent/mm/c/a/ec;->blN:Ljava/lang/String;

    .line 69
    iget-object v1, v0, Lcom/tencent/mm/c/a/eb;->bnB:Lcom/tencent/mm/c/a/ec;

    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lcom/tencent/mm/c/a/ec;->blA:Ljava/lang/String;

    .line 70
    invoke-static {}, Lcom/tencent/mm/sdk/b/a;->aoz()Lcom/tencent/mm/sdk/b/f;

    move-result-object v1

    invoke-interface {v1, v0}, Lcom/tencent/mm/sdk/b/f;->f(Lcom/tencent/mm/sdk/b/e;)Z

    goto/16 :goto_0

    .line 75
    :cond_6
    #v3=(Conflicted);v4=(Conflicted);
    if-eqz v2, :cond_0

    .line 76
    new-instance v1, Lcom/tencent/mm/ag/e;

    #v1=(UninitRef);
    invoke-direct {v1}, Lcom/tencent/mm/ag/e;-><init>()V

    .line 77
    #v1=(Reference);
    iget v3, p1, Lcom/tencent/mm/protocal/a/j;->eDF:I

    #v3=(Integer);
    int-to-long v3, v3

    #v3=(LongLo);v4=(LongHi);
    invoke-static {v0, v3, v4}, Lcom/tencent/mm/ag/d;->b(Ljava/lang/String;J)J

    move-result-wide v3

    iput-wide v3, v1, Lcom/tencent/mm/ag/e;->field_createTime:J

    .line 78
    iput v11, v1, Lcom/tencent/mm/ag/e;->field_isSend:I

    .line 79
    iget-object v0, p1, Lcom/tencent/mm/protocal/a/j;->eDB:Lcom/tencent/mm/protocal/a/pt;

    invoke-static {v0}, Lcom/tencent/mm/platformtools/ah;->a(Lcom/tencent/mm/protocal/a/pt;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lcom/tencent/mm/ag/e;->field_msgContent:Ljava/lang/String;

    .line 80
    iget v0, p1, Lcom/tencent/mm/protocal/a/j;->eDx:I

    #v0=(Integer);
    iput v0, v1, Lcom/tencent/mm/ag/e;->field_svrId:I

    .line 81
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asd()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    .line 83
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asv()I

    move-result v0

    #v0=(Integer);
    packed-switch v0, :pswitch_data_0

    .line 94
    :pswitch_0
    iput v8, v1, Lcom/tencent/mm/ag/e;->field_type:I

    .line 98
    :goto_1
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asw()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/sdk/platformtools/ce;->hD(Ljava/lang/String;)Z

    move-result v0

    #v0=(Boolean);
    if-nez v0, :cond_8

    .line 99
    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asw()Ljava/lang/String;

    move-result-object v0

    #v0=(Reference);
    iput-object v0, v1, Lcom/tencent/mm/ag/e;->field_encryptTalker:Ljava/lang/String;

    .line 101
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    invoke-virtual {v2}, Lcom/tencent/mm/storage/aq;->asw()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/tencent/mm/ag/b;->gj(Ljava/lang/String;)Lcom/tencent/mm/ag/a;

    move-result-object v0

    .line 102
    if-eqz v0, :cond_7

    .line 104
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v0

    iget-object v2, v1, Lcom/tencent/mm/ag/e;->field_encryptTalker:Ljava/lang/String;

    iget-object v3, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    #v3=(Reference);
    invoke-virtual {v0, v2, v3}, Lcom/tencent/mm/ag/f;->I(Ljava/lang/String;Ljava/lang/String;)Z

    .line 105
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    iget-object v2, v1, Lcom/tencent/mm/ag/e;->field_encryptTalker:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lcom/tencent/mm/ag/b;->gm(Ljava/lang/String;)Z

    .line 107
    :cond_7
    #v3=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/f;->a(Lcom/tencent/mm/ag/e;)Z

    goto/16 :goto_0

    .line 85
    :pswitch_1
    #v0=(Integer);v3=(LongLo);
    iput v8, v1, Lcom/tencent/mm/ag/e;->field_type:I

    goto :goto_1

    .line 88
    :pswitch_2
    iput v12, v1, Lcom/tencent/mm/ag/e;->field_type:I

    goto :goto_1

    .line 91
    :pswitch_3
    iput v10, v1, Lcom/tencent/mm/ag/e;->field_type:I

    goto :goto_1

    .line 110
    :cond_8
    #v0=(Boolean);
    const-string v0, "MicroMsg.VerifyMessageExtension"

    #v0=(Reference);
    const-string v2, "it should not go in here"

    invoke-static {v0, v2}, Lcom/tencent/mm/sdk/platformtools/y;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 111
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    iget-object v2, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lcom/tencent/mm/ag/b;->gl(Ljava/lang/String;)Lcom/tencent/mm/ag/a;

    move-result-object v0

    .line 112
    if-eqz v0, :cond_9

    .line 113
    iget-object v2, v0, Lcom/tencent/mm/ag/a;->field_talker:Ljava/lang/String;

    iput-object v2, v1, Lcom/tencent/mm/ag/e;->field_encryptTalker:Ljava/lang/String;

    .line 114
    iget-object v0, v0, Lcom/tencent/mm/ag/a;->field_talker:Ljava/lang/String;

    iput-object v0, v1, Lcom/tencent/mm/ag/e;->field_talker:Ljava/lang/String;

    .line 116
    :cond_9
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/tencent/mm/ag/f;->a(Lcom/tencent/mm/ag/e;)Z

    goto/16 :goto_0

    .line 83
    #v0=(Unknown);v1=(Unknown);v2=(Unknown);v3=(Unknown);v4=(Unknown);v5=(Unknown);v6=(Unknown);v7=(Unknown);v8=(Unknown);v9=(Unknown);v10=(Unknown);v11=(Unknown);v12=(Unknown);p0=(Unknown);p1=(Unknown);
    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_3
    .end packed-switch
.end method

.method public final c(Lcom/tencent/mm/storage/am;)V
    .locals 0
    .parameter

    .prologue
    .line 125
    return-void
.end method

*/}
