package com.tencent.mm.ag; class k {/*

.class public Lcom/tencent/mm/ag/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/tencent/mm/model/ay;


# static fields
.field private static bwv:Ljava/util/HashMap;


# instance fields
.field private bWD:Lcom/tencent/mm/ag/t;

.field private bWE:Lcom/tencent/mm/ag/f;

.field private bWF:Lcom/tencent/mm/ag/b;

.field private bWG:Lcom/tencent/mm/ag/c;

.field private bWH:Lcom/tencent/mm/ag/h;

.field private bWI:Lcom/tencent/mm/ag/j;

.field private bWJ:Lcom/tencent/mm/sdk/b/g;

.field private bWK:Lcom/tencent/mm/sdk/b/g;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .prologue
    .line 101
    new-instance v0, Ljava/util/HashMap;

    #v0=(UninitRef);
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 104
    #v0=(Reference);
    sput-object v0, Lcom/tencent/mm/ag/k;->bwv:Ljava/util/HashMap;

    const-string v1, "LBSVERIFYMESSAGE_TABLE"

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    new-instance v2, Lcom/tencent/mm/ag/l;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/l;-><init>()V

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    sget-object v0, Lcom/tencent/mm/ag/k;->bwv:Ljava/util/HashMap;

    const-string v1, "SHAKEVERIFYMESSAGE_TABLE"

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    new-instance v2, Lcom/tencent/mm/ag/m;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/m;-><init>()V

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    sget-object v0, Lcom/tencent/mm/ag/k;->bwv:Ljava/util/HashMap;

    const-string v1, "VERIFY_CONTACT_TABLE"

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    new-instance v2, Lcom/tencent/mm/ag/n;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/n;-><init>()V

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 125
    sget-object v0, Lcom/tencent/mm/ag/k;->bwv:Ljava/util/HashMap;

    const-string v1, "FMESSAGE_MSGINFO_TABLE"

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    new-instance v2, Lcom/tencent/mm/ag/o;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/o;-><init>()V

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    sget-object v0, Lcom/tencent/mm/ag/k;->bwv:Ljava/util/HashMap;

    const-string v1, "FMESSAGE_CONVERSATION_TABLE"

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    #v1=(Integer);
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    #v1=(Reference);
    new-instance v2, Lcom/tencent/mm/ag/p;

    #v2=(UninitRef);
    invoke-direct {v2}, Lcom/tencent/mm/ag/p;-><init>()V

    #v2=(Reference);
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .prologue
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    #p0=(Reference);
    new-instance v0, Lcom/tencent/mm/ag/t;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/t;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/ag/k;->bWD:Lcom/tencent/mm/ag/t;

    .line 24
    new-instance v0, Lcom/tencent/mm/ag/c;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/c;-><init>()V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/ag/k;->bWG:Lcom/tencent/mm/ag/c;

    .line 162
    new-instance v0, Lcom/tencent/mm/ag/q;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/ag/q;-><init>(Lcom/tencent/mm/ag/k;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/ag/k;->bWJ:Lcom/tencent/mm/sdk/b/g;

    .line 185
    new-instance v0, Lcom/tencent/mm/ag/r;

    #v0=(UninitRef);
    invoke-direct {v0, p0}, Lcom/tencent/mm/ag/r;-><init>(Lcom/tencent/mm/ag/k;)V

    #v0=(Reference);
    iput-object v0, p0, Lcom/tencent/mm/ag/k;->bWK:Lcom/tencent/mm/sdk/b/g;

    return-void
.end method

.method private static yt()Lcom/tencent/mm/ag/k;
    .locals 2

    .prologue
    .line 31
    const-class v0, Lcom/tencent/mm/ag/k;

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/mm/model/ba;->dg(Ljava/lang/String;)Lcom/tencent/mm/model/ay;

    move-result-object v0

    check-cast v0, Lcom/tencent/mm/ag/k;

    .line 32
    if-nez v0, :cond_0

    .line 33
    new-instance v0, Lcom/tencent/mm/ag/k;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/ag/k;-><init>()V

    .line 34
    #v0=(Reference);
    const-class v1, Lcom/tencent/mm/ag/k;

    #v1=(Reference);
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/tencent/mm/model/ba;->a(Ljava/lang/String;Lcom/tencent/mm/model/ay;)V

    .line 36
    :cond_0
    #v1=(Conflicted);
    return-object v0
.end method

.method public static yu()Lcom/tencent/mm/ag/f;
    .locals 3

    .prologue
    .line 50
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_0

    .line 51
    new-instance v0, Lcom/tencent/mm/model/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/model/a;-><init>()V

    #v0=(Reference);
    throw v0

    .line 53
    :cond_0
    #v0=(Integer);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWE:Lcom/tencent/mm/ag/f;

    if-nez v0, :cond_1

    .line 54
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    new-instance v1, Lcom/tencent/mm/ag/f;

    #v1=(UninitRef);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/model/b;->nI()Lcom/tencent/mm/ao/i;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/tencent/mm/ag/f;-><init>(Lcom/tencent/mm/sdk/e/af;)V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/ag/k;->bWE:Lcom/tencent/mm/ag/f;

    .line 56
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    .line 57
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v1

    iget-object v1, v1, Lcom/tencent/mm/ag/k;->bWE:Lcom/tencent/mm/ag/f;

    invoke-virtual {v1, v0}, Lcom/tencent/mm/ag/f;->e(Lcom/tencent/mm/sdk/e/al;)V

    .line 59
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWE:Lcom/tencent/mm/ag/f;

    return-object v0
.end method

.method public static yv()Lcom/tencent/mm/ag/b;
    .locals 3

    .prologue
    .line 63
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_0

    .line 64
    new-instance v0, Lcom/tencent/mm/model/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/model/a;-><init>()V

    #v0=(Reference);
    throw v0

    .line 66
    :cond_0
    #v0=(Integer);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWF:Lcom/tencent/mm/ag/b;

    if-nez v0, :cond_1

    .line 67
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    new-instance v1, Lcom/tencent/mm/ag/b;

    #v1=(UninitRef);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/model/b;->nI()Lcom/tencent/mm/ao/i;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/tencent/mm/ag/b;-><init>(Lcom/tencent/mm/sdk/e/af;)V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/ag/k;->bWF:Lcom/tencent/mm/ag/b;

    .line 69
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWF:Lcom/tencent/mm/ag/b;

    return-object v0
.end method

.method public static yw()Lcom/tencent/mm/ag/h;
    .locals 3

    .prologue
    .line 73
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_0

    .line 74
    new-instance v0, Lcom/tencent/mm/model/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/model/a;-><init>()V

    #v0=(Reference);
    throw v0

    .line 76
    :cond_0
    #v0=(Integer);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWH:Lcom/tencent/mm/ag/h;

    if-nez v0, :cond_1

    .line 77
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    new-instance v1, Lcom/tencent/mm/ag/h;

    #v1=(UninitRef);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/model/b;->nI()Lcom/tencent/mm/ao/i;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/tencent/mm/ag/h;-><init>(Lcom/tencent/mm/sdk/e/af;)V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/ag/k;->bWH:Lcom/tencent/mm/ag/h;

    .line 79
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWH:Lcom/tencent/mm/ag/h;

    return-object v0
.end method

.method public static yx()Lcom/tencent/mm/ag/j;
    .locals 3

    .prologue
    .line 83
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Lcom/tencent/mm/model/b;->nx()I

    move-result v0

    #v0=(Integer);
    if-nez v0, :cond_0

    .line 84
    new-instance v0, Lcom/tencent/mm/model/a;

    #v0=(UninitRef);
    invoke-direct {v0}, Lcom/tencent/mm/model/a;-><init>()V

    #v0=(Reference);
    throw v0

    .line 86
    :cond_0
    #v0=(Integer);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    #v0=(Reference);
    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWI:Lcom/tencent/mm/ag/j;

    if-nez v0, :cond_1

    .line 87
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    new-instance v1, Lcom/tencent/mm/ag/j;

    #v1=(UninitRef);
    invoke-static {}, Lcom/tencent/mm/model/ba;->pN()Lcom/tencent/mm/model/b;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2}, Lcom/tencent/mm/model/b;->nI()Lcom/tencent/mm/ao/i;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/tencent/mm/ag/j;-><init>(Lcom/tencent/mm/sdk/e/af;)V

    #v1=(Reference);
    iput-object v1, v0, Lcom/tencent/mm/ag/k;->bWI:Lcom/tencent/mm/ag/j;

    .line 89
    :cond_1
    #v1=(Conflicted);v2=(Conflicted);
    invoke-static {}, Lcom/tencent/mm/ag/k;->yt()Lcom/tencent/mm/ag/k;

    move-result-object v0

    iget-object v0, v0, Lcom/tencent/mm/ag/k;->bWI:Lcom/tencent/mm/ag/j;

    return-object v0
.end method


# virtual methods
.method public final aQ(I)V
    .locals 0
    .parameter

    .prologue
    .line 147
    return-void
.end method

.method public final l(Z)V
    .locals 3
    .parameter

    .prologue
    .line 151
    const/16 v0, 0x25

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/ag/k;->bWD:Lcom/tencent/mm/ag/t;

    #v1=(Reference);
    invoke-static {v0, v1}, Lcom/tencent/mm/o/l;->a(Ljava/lang/Object;Lcom/tencent/mm/o/j;)V

    .line 152
    const/16 v0, 0x28

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/ag/k;->bWG:Lcom/tencent/mm/ag/c;

    invoke-static {v0, v1}, Lcom/tencent/mm/o/l;->a(Ljava/lang/Object;Lcom/tencent/mm/o/j;)V

    .line 154
    invoke-static {}, Lcom/tencent/mm/sdk/b/a;->aoz()Lcom/tencent/mm/sdk/b/f;

    move-result-object v0

    const-string v1, "FMessageConversationStateOp"

    iget-object v2, p0, Lcom/tencent/mm/ag/k;->bWJ:Lcom/tencent/mm/sdk/b/g;

    #v2=(Reference);
    invoke-interface {v0, v1, v2}, Lcom/tencent/mm/sdk/b/f;->a(Ljava/lang/String;Lcom/tencent/mm/sdk/b/g;)Z

    .line 155
    invoke-static {}, Lcom/tencent/mm/sdk/b/a;->aoz()Lcom/tencent/mm/sdk/b/f;

    move-result-object v0

    const-string v1, "FMsgInfoQuery"

    iget-object v2, p0, Lcom/tencent/mm/ag/k;->bWK:Lcom/tencent/mm/sdk/b/g;

    invoke-interface {v0, v1, v2}, Lcom/tencent/mm/sdk/b/f;->a(Ljava/lang/String;Lcom/tencent/mm/sdk/b/g;)Z

    .line 156
    return-void
.end method

.method public final lP()V
    .locals 3

    .prologue
    .line 94
    const/16 v0, 0x25

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/ag/k;->bWD:Lcom/tencent/mm/ag/t;

    #v1=(Reference);
    invoke-static {v0}, Lcom/tencent/mm/o/l;->m(Ljava/lang/Object;)V

    .line 95
    const/16 v0, 0x28

    #v0=(PosByte);
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    #v0=(Reference);
    iget-object v1, p0, Lcom/tencent/mm/ag/k;->bWG:Lcom/tencent/mm/ag/c;

    invoke-static {v0}, Lcom/tencent/mm/o/l;->m(Ljava/lang/Object;)V

    .line 97
    invoke-static {}, Lcom/tencent/mm/sdk/b/a;->aoz()Lcom/tencent/mm/sdk/b/f;

    move-result-object v0

    const-string v1, "FMessageConversationStateOp"

    iget-object v2, p0, Lcom/tencent/mm/ag/k;->bWJ:Lcom/tencent/mm/sdk/b/g;

    #v2=(Reference);
    invoke-interface {v0, v1, v2}, Lcom/tencent/mm/sdk/b/f;->b(Ljava/lang/String;Lcom/tencent/mm/sdk/b/g;)Z

    .line 98
    invoke-static {}, Lcom/tencent/mm/sdk/b/a;->aoz()Lcom/tencent/mm/sdk/b/f;

    move-result-object v0

    const-string v1, "FMsgInfoQuery"

    iget-object v2, p0, Lcom/tencent/mm/ag/k;->bWK:Lcom/tencent/mm/sdk/b/g;

    invoke-interface {v0, v1, v2}, Lcom/tencent/mm/sdk/b/f;->b(Ljava/lang/String;Lcom/tencent/mm/sdk/b/g;)Z

    .line 99
    return-void
.end method

.method public final lQ()Ljava/util/HashMap;
    .locals 1

    .prologue
    .line 142
    sget-object v0, Lcom/tencent/mm/ag/k;->bwv:Ljava/util/HashMap;

    #v0=(Reference);
    return-object v0
.end method

.method public final p(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .parameter
    .parameter

    .prologue
    .line 160
    return-void
.end method

*/}
