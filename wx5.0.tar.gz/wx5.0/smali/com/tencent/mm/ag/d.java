package com.tencent.mm.ag; class d {/*

.class public final Lcom/tencent/mm/ag/d;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static b(Ljava/lang/String;J)J
    .locals 6
    .parameter
    .parameter

    .prologue
    const-wide/16 v4, 0x3e8

    .line 14
    #v4=(LongLo);v5=(LongHi);
    const-wide/16 v0, 0x0

    .line 15
    #v0=(LongLo);v1=(LongHi);
    if-eqz p0, :cond_0

    .line 16
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v2

    #v2=(Reference);
    invoke-virtual {v2, p0}, Lcom/tencent/mm/ag/f;->gp(Ljava/lang/String;)Lcom/tencent/mm/ag/e;

    move-result-object v2

    .line 17
    if-eqz v2, :cond_0

    .line 18
    iget-wide v0, v2, Lcom/tencent/mm/ag/e;->field_createTime:J

    const-wide/16 v2, 0x1

    #v2=(LongLo);v3=(LongHi);
    add-long/2addr v0, v2

    .line 21
    :cond_0
    #v2=(Conflicted);v3=(Conflicted);
    mul-long v2, p1, v4

    #v2=(LongLo);v3=(LongHi);
    cmp-long v2, v0, v2

    #v2=(Byte);
    if-lez v2, :cond_1

    .line 25
    :goto_0
    return-wide v0

    :cond_1
    mul-long v0, p1, v4

    goto :goto_0
.end method

.method public static gn(Ljava/lang/String;)V
    .locals 4
    .parameter

    .prologue
    .line 50
    const-string v0, "MicroMsg.FMessageLogic"

    #v0=(Reference);
    new-instance v1, Ljava/lang/StringBuilder;

    #v1=(UninitRef);
    const-string v2, "clearFMsgAndFConvByTalker, talker = "

    #v2=(Reference);
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v1=(Reference);
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/tencent/mm/sdk/platformtools/y;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    invoke-static {}, Lcom/tencent/mm/ag/k;->yv()Lcom/tencent/mm/ag/b;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/tencent/mm/ag/b;->gm(Ljava/lang/String;)Z

    move-result v0

    .line 53
    #v0=(Boolean);
    const-string v1, "MicroMsg.FMessageLogic"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "clearFMsgAndFConvByTalker, delete fconversation, ret = "

    #v3=(Reference);
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    invoke-static {}, Lcom/tencent/mm/ag/k;->yu()Lcom/tencent/mm/ag/f;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/tencent/mm/ag/f;->gm(Ljava/lang/String;)Z

    move-result v0

    .line 56
    #v0=(Boolean);
    const-string v1, "MicroMsg.FMessageLogic"

    new-instance v2, Ljava/lang/StringBuilder;

    #v2=(UninitRef);
    const-string v3, "clearFMsgAndFConvByTalker, delete fmsginfo, ret = "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    #v2=(Reference);
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    #v0=(Reference);
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/mm/sdk/platformtools/y;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    return-void
.end method

*/}
